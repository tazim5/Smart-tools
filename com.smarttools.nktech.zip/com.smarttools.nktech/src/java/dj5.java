import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;

public final class dj5 extends xh5
{
    public static dj5 a(final ii5 ii5, final bl4 bl4, final Integer n) {
        final ii5 r = ii5.R;
        final String n2 = ii5.n;
        if (ii5 != r && n == null) {
            throw new GeneralSecurityException(gs1.j("For given Variant ", n2, " the value of idRequirement must be non-null"));
        }
        if (ii5 == r && n != null) {
            throw new GeneralSecurityException("For given Variant NO_PREFIX the value of idRequirement must be null");
        }
        final to5 to5 = (to5)bl4.n;
        if (to5.a.length == 32) {
            if (ii5 == r) {
                to5.a(new byte[0]);
            }
            else if (ii5 == ii5.Q) {
                to5.a(ByteBuffer.allocate(5).put((byte)0).putInt((int)n).array());
            }
            else {
                if (ii5 != ii5.P) {
                    throw new IllegalStateException("Unknown Variant: ".concat(n2));
                }
                to5.a(ByteBuffer.allocate(5).put((byte)1).putInt((int)n).array());
            }
            return (dj5)new Object();
        }
        throw new GeneralSecurityException(e8.c(to5.a.length, "ChaCha20Poly1305 key must be constructed with key of length 32 bytes, not "));
    }
}
