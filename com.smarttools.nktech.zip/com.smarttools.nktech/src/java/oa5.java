import com.google.android.gms.common.internal.BaseGmsClient;
import com.google.android.gms.internal.ads.r2;
import com.google.android.gms.internal.ads.s2;
import android.os.Looper;
import android.content.Context;

public final class oa5
{
    public final Context a;
    public final Looper b;
    
    public oa5(final Context a, final Looper b) {
        this.a = a;
        this.b = b;
    }
    
    public final void a(final String s) {
        final ua5 v = s2.v();
        final String packageName = this.a.getPackageName();
        ((kp5)v).d();
        s2.w((s2)((kp5)v).n, packageName);
        ((kp5)v).d();
        s2.y((s2)((kp5)v).n);
        final ta5 v2 = r2.v();
        ((kp5)v2).d();
        r2.w((r2)((kp5)v2).n, s);
        ((kp5)v2).d();
        r2.x((r2)((kp5)v2).n);
        ((kp5)v).d();
        s2.x((s2)((kp5)v).n, (r2)((kp5)v2).b());
        final pa5 pa5 = new pa5(this.a, this.b, (s2)((kp5)v).b());
        final Object c;
        monitorenter(c = pa5.c);
        Label_0156: {
            try {
                if (!pa5.d) {
                    pa5.d = true;
                    ((BaseGmsClient)pa5.a).checkAvailabilityAndConnect();
                }
                break Label_0156;
            }
            finally {
                monitorexit(c);
                monitorexit(c);
            }
        }
    }
}
