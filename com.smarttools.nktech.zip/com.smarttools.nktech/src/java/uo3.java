import java.util.concurrent.Executor;
import androidx.concurrent.futures.b;
import java.util.concurrent.Future;

public abstract class uo3
{
    public static Object a(final yq1 yq1) {
        final boolean done = ((Future)yq1).isDone();
        final StringBuilder sb = new StringBuilder("Future was expected to be done, ");
        sb.append((Object)yq1);
        jy5.e(sb.toString(), done);
        return b((Future)yq1);
    }
    
    public static Object b(final Future future) {
        boolean b = false;
        try {
            return future.get();
        }
        catch (final InterruptedException ex) {
            b = true;
            return future.get();
        }
        finally {
            if (b) {
                Thread.currentThread().interrupt();
            }
        }
    }
    
    public static zj1 c(final Object o) {
        if (o == null) {
            return zj1.v;
        }
        return new zj1(o, 0);
    }
    
    public static yq1 d(final yq1 yq1) {
        yq1.getClass();
        if (((Future)yq1).isDone()) {
            return yq1;
        }
        return (yq1)ft5.a((hj)new h3((Object)yq1, 13));
    }
    
    public static void e(final boolean b, final yq1 yq1, final b b2, zy0 a) {
        yq1.getClass();
        b2.getClass();
        a.getClass();
        yq1.addListener((Runnable)new ae1(0, (Object)yq1, (Object)new pe1((Object)b2, 11)), (Executor)a);
        if (b) {
            final g7 g7 = new g7((Object)yq1, 10);
            a = wt5.a();
            final gf2 c = b2.c;
            if (c != null) {
                ((a1)c).addListener((Runnable)g7, (Executor)a);
            }
        }
    }
    
    public static zo f(final yq1 yq1, final nb nb, final Executor executor) {
        final zo zo = new zo(nb, yq1);
        yq1.addListener((Runnable)zo, executor);
        return zo;
    }
    
    public abstract hu4 g(final ru4 p0);
    
    public abstract ou4 h(final ru4 p0);
    
    public abstract void i(final ou4 p0, final ou4 p1);
    
    public abstract void j(final ou4 p0, final Thread p1);
    
    public abstract boolean k(final ru4 p0, final hu4 p1, final hu4 p2);
    
    public abstract boolean l(final ru4 p0, final Object p1, final Object p2);
    
    public abstract boolean m(final ru4 p0, final ou4 p1, final ou4 p2);
}
