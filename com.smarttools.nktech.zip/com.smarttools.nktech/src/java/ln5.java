public abstract class ln5
{
    public static final io4 a;
    
    static {
        a = new io4(17);
    }
    
    public static int a(final int n) {
        return n >>> 1 ^ -(n & 0x1);
    }
    
    public static long b(final long n) {
        return n >>> 1 ^ -(0x1L & n);
    }
}
