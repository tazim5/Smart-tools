import android.view.View;
import android.view.Window;

public abstract class jv5
{
    public void a(final Window window) {
    }
    
    public abstract void b(final xu2 p0, final xu2 p1, final Window p2, final View p3, final boolean p4, final boolean p5);
}
