import android.webkit.WebResourceRequest;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.internal.ads.k1;
import java.util.Collections;
import java.io.File;
import com.google.android.gms.internal.ads.j1;
import android.webkit.WebResourceResponse;
import java.util.Map;
import android.webkit.WebView;
import com.google.android.gms.internal.ads.e2;

public final class jc4 extends yb4
{
    public final int o0;
    
    public jc4(final rb4 rb4, final mq3 mq3, final boolean b, final e2 e2, final int o0) {
        this.o0 = o0;
        super(rb4, mq3, b, new u24(rb4, rb4.zzE(), new tr3(rb4.getContext())), e2);
    }
    
    public final WebResourceResponse o0(final WebView webView, final String s, final Map map) {
        if (!(webView instanceof rb4)) {
            d94.zzj("Tried to intercept request from a WebView that wasn't an AdWebView.");
            return null;
        }
        final rb4 rb4 = (rb4)webView;
        final t64 f0 = super.f0;
        if (f0 != null) {
            ((j1)f0).a(s, map, 1);
        }
        if (!"mraid.js".equalsIgnoreCase(new File(s).getName())) {
            Map emptyMap;
            if ((emptyMap = map) == null) {
                emptyMap = Collections.emptyMap();
            }
            return this.q(s, emptyMap);
        }
        if (rb4.zzN() != null) {
            final yb4 zzN = rb4.zzN();
            final Object w = zzN.w;
            synchronized (w) {
                zzN.T = false;
                zzN.Y = true;
                k1.e.execute((Runnable)new sb4((Object)zzN, 0));
            }
        }
        String s2;
        if (rb4.zzO().b()) {
            s2 = (String)zzba.zzc().a(cs3.I);
        }
        else if (rb4.U()) {
            s2 = (String)zzba.zzc().a(cs3.H);
        }
        else {
            s2 = (String)zzba.zzc().a(cs3.G);
        }
        zzt.zzp();
        return com.google.android.gms.ads.internal.util.zzt.zzw(rb4.getContext(), rb4.zzn().c, s2);
    }
    
    public WebResourceResponse shouldInterceptRequest(final WebView webView, final WebResourceRequest webResourceRequest) {
        switch (this.o0) {
            default: {
                return super.shouldInterceptRequest(webView, webResourceRequest);
            }
            case 1: {
                WebResourceResponse o0;
                if (webResourceRequest != null && webResourceRequest.getUrl() != null) {
                    o0 = this.o0(webView, webResourceRequest.getUrl().toString(), webResourceRequest.getRequestHeaders());
                }
                else {
                    o0 = null;
                }
                return o0;
            }
        }
    }
    
    @Override
    public WebResourceResponse shouldInterceptRequest(final WebView webView, final String s) {
        switch (this.o0) {
            default: {
                return super.shouldInterceptRequest(webView, s);
            }
            case 0: {
                return this.o0(webView, s, null);
            }
        }
    }
}
