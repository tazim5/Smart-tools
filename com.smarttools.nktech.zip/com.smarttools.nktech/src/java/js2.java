public final class js2
{
    public final long a;
    public final long b;
    
    public js2(final long a, final long b) {
        this.a = a;
        this.b = b;
    }
}
