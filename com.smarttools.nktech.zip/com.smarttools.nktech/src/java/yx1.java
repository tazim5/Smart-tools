import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.material3.IconKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.graphics.Color;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.material.icons.filled.FavoriteBorderKt;
import androidx.compose.material.icons.filled.FavoriteKt;
import androidx.compose.material.icons.Icons$Filled;
import androidx.compose.runtime.Composer;

public final class yx1 implements nd1
{
    public final boolean c;
    
    public yx1(final boolean c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) != 0x2 || !composer.getSkipping()) {
            final boolean c = this.c;
            final Icons$Filled instance = Icons$Filled.INSTANCE;
            ImageVector imageVector;
            if (c) {
                imageVector = FavoriteKt.getFavorite(instance);
            }
            else {
                imageVector = FavoriteBorderKt.getFavoriteBorder(instance);
            }
            String s;
            if (c) {
                s = "Remove from favorites";
            }
            else {
                s = "Add to favorites";
            }
            composer.startReplaceGroup(-400469117);
            long n;
            if (c) {
                n = ColorKt.Color(4293467747L);
            }
            else {
                n = Color.copy-wmQWz5c$default(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant-0d7_KjU(), 0.5f, 0.0f, 0.0f, 0.0f, 14, (Object)null);
            }
            composer.endReplaceGroup();
            IconKt.Icon-ww6aTOc(imageVector, s, SizeKt.size-3ABfNKs((Modifier)Modifier.Companion, Dp.constructor-impl((float)20)), n, composer, 384, 0);
        }
        else {
            composer.skipToGroupEnd();
        }
        return t43.a;
    }
}
