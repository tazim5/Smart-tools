import com.google.zxing.oned.rss.expanded.decoders.b;

public abstract class k extends b0
{
    public final void e(final int n, final StringBuilder sb) {
        sb.append("(01)");
        final int length = sb.length();
        sb.append('9');
        this.f(sb, n, length);
    }
    
    public final void f(final StringBuilder sb, int i, final int n) {
        final int n2 = 0;
        for (int j = 0; j < 4; ++j) {
            final int c = b.c(j * 10 + i, 10, ((b)super.b).a);
            if (c / 100 == 0) {
                sb.append('0');
            }
            if (c / 10 == 0) {
                sb.append('0');
            }
            sb.append(c);
        }
        i = 0;
        int n3 = 0;
        while (i < 13) {
            int n4 = sb.charAt(i + n) - '0';
            if ((i & 0x1) == 0x0) {
                n4 *= 3;
            }
            n3 += n4;
            ++i;
        }
        i = 10 - n3 % 10;
        if (i == 10) {
            i = n2;
        }
        sb.append(i);
    }
}
