import androidx.compose.runtime.State;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.material3.IconKt;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.material.icons.filled.PlayArrowKt;
import androidx.compose.material.icons.filled.StopKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.runtime.MutableState;

public final class bq2 implements od1
{
    public final MutableState c;
    
    public bq2(final MutableState c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final RowScope rowScope = (RowScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) != 0x10 || !composer.getSkipping()) {
            final MutableState c = this.c;
            ImageVector imageVector;
            if (((State)c).getValue()) {
                imageVector = StopKt.getStop(Icons.INSTANCE.getDefault());
            }
            else {
                imageVector = PlayArrowKt.getPlayArrow(Icons.INSTANCE.getDefault());
            }
            IconKt.Icon-ww6aTOc(imageVector, (String)null, PaddingKt.padding-qDBjuR0$default((Modifier)Modifier.Companion, 0.0f, 0.0f, Dp.constructor-impl((float)8), 0.0f, 11, (Object)null), 0L, composer, 432, 8);
            String s;
            if (((State)c).getValue()) {
                s = "Stop Test";
            }
            else {
                s = "Start Test";
            }
            TextKt.Text--4IGK_g(s, (Modifier)null, 0L, 0L, (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196608, 0, 131038);
        }
        else {
            composer.skipToGroupEnd();
        }
        return t43.a;
    }
}
