import androidx.fragment.app.m;
import androidx.navigation.c;
import kotlin.jvm.internal.Lambda;

public final class vb1 extends z32
{
    public final int d;
    public final Object e;
    
    public vb1(final boolean b, final jd1 jd1) {
        this.d = 2;
        this.e = jd1;
        super(b);
    }
    
    public final void b() {
        switch (this.d) {
            default: {
                ((jd1)this.e).invoke((Object)this);
                return;
            }
            case 1: {
                ((c)this.e).l();
                return;
            }
            case 0: {
                ((m)this.e).d();
                throw null;
            }
        }
    }
}
