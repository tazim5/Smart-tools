import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material.icons.filled.GridViewKt;
import androidx.compose.material.icons.filled.ViewListKt;
import androidx.compose.material.icons.Icons;
import com.smarttools.nktech.core.data.datastore.ViewMode;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.State;

public final class tx1 implements nd1
{
    public final State c;
    
    public tx1(final State c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final State c = this.c;
            final ViewMode viewMode = (ViewMode)c.getValue();
            final ViewMode c2 = ViewMode.c;
            ImageVector imageVector;
            if (viewMode == c2) {
                imageVector = ViewListKt.getViewList(Icons.INSTANCE.getDefault());
            }
            else {
                imageVector = GridViewKt.getGridView(Icons.INSTANCE.getDefault());
            }
            String s;
            if (c.getValue() == c2) {
                s = "Switch to list view";
            }
            else {
                s = "Switch to grid view";
            }
            IconKt.Icon-ww6aTOc(imageVector, s, (Modifier)null, 0L, composer, 0, 12);
        }
        return t43.a;
    }
}
