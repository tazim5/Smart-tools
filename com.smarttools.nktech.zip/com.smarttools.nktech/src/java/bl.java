import android.hardware.camera2.CaptureRequest$Key;

public final class bl implements n71
{
    public final int c;
    public final dz1 n;
    
    public bl(final int c) {
        switch (this.c = c) {
            default: {
                this.n = dz1.d();
                return;
            }
            case 1: {
                this.n = dz1.d();
            }
        }
    }
    
    public static bl c(final no0 no0) {
        final bl bl = new bl(1);
        no0.f(new ng(2, (Object)bl, (Object)no0));
        return bl;
    }
    
    @Override
    public final oy1 a() {
        switch (this.c) {
            default: {
                throw null;
            }
            case 0: {
                throw null;
            }
        }
    }
    
    public void d(final CaptureRequest$Key captureRequest$Key, final Object o) {
        this.n.o(cl.C(captureRequest$Key), o);
    }
}
