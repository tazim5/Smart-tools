import com.google.android.gms.ads.internal.client.zzdn;
import com.google.android.gms.ads.internal.client.zzdg;
import android.os.IInterface;

public interface op3 extends IInterface
{
    void H0(final th1 p0, final up3 p1);
    
    void b0(final zzdg p0);
    
    void d1(final boolean p0);
    
    zzdn zzf();
}
