import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import kotlin.Result$Failure;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlinx.coroutines.b;
import kotlinx.coroutines.a;
import kotlin.coroutines.Continuation;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlinx.coroutines.c;
import java.util.concurrent.locks.LockSupport;
import kotlinx.coroutines.CoroutineStart;
import kotlin.coroutines.EmptyCoroutineContext;

public abstract class xs5
{
    public static nv0 a(final dq0 dq0, kg1 c, final nd1 nd1, final int n) {
        if ((n & 0x1) != 0x0) {
            c = (kg1)EmptyCoroutineContext.c;
        }
        final CoroutineStart c2 = CoroutineStart.c;
        final z z = new z(vu5.b(dq0, (up0)c), true);
        z.b0(c2, z, nd1);
        return (nv0)z;
    }
    
    public static er2 b(final dq0 dq0, up0 c, CoroutineStart c2, final nd1 nd1, final int n) {
        if ((n & 0x1) != 0x0) {
            c = (up0)EmptyCoroutineContext.c;
        }
        if ((n & 0x2) != 0x0) {
            c2 = CoroutineStart.c;
        }
        final up0 b = vu5.b(dq0, c);
        c2.getClass();
        Object o;
        if (c2 == CoroutineStart.n) {
            o = new zo1(b, nd1);
        }
        else {
            o = new z(b, true);
        }
        ((z)o).b0(c2, (z)o, nd1);
        return (er2)o;
    }
    
    public static final Object c(up0 up0, nd1 x) {
        final Thread currentThread = Thread.currentThread();
        final xg1 n = xg1.n;
        final qp0 qp0 = (qp0)up0.get((tp0)n);
        e41 e41;
        if (qp0 == null) {
            final e41 a = py2.a();
            up0 = up0.plus((up0)a);
            final up0 a2 = vu5.a((up0)EmptyCoroutineContext.c, up0, true);
            final zu0 a3 = hz0.a;
            e41 = a;
            if ((up0 = a2) != a3) {
                e41 = a;
                up0 = a2;
                if (a2.get((tp0)n) == null) {
                    up0 = a2.plus((up0)a3);
                    e41 = a;
                }
            }
        }
        else {
            if (qp0 instanceof e41) {
                final e41 e42 = (e41)qp0;
            }
            final e41 e43 = (e41)py2.a.get();
            final up0 a4 = vu5.a((up0)EmptyCoroutineContext.c, up0, true);
            final zu0 a5 = hz0.a;
            e41 = e43;
            if ((up0 = a4) != a5) {
                e41 = e43;
                up0 = a4;
                if (a4.get((tp0)n) == null) {
                    up0 = a4.plus((up0)a5);
                    e41 = e43;
                }
            }
        }
        final vg vg = new vg(up0, currentThread, e41);
        ((z)vg).b0(CoroutineStart.c, (z)vg, x);
        x = (nd1)vg.x;
        if (x != null) {
            final int w = e41.w;
            ((e41)x).Y(false);
        }
    Label_0326_Outer:
        while (true) {
            Label_0257: {
                try {
                    if (Thread.interrupted()) {
                        break Label_0257;
                    }
                    if (x != null) {
                        final long a6 = ((e41)x).a0();
                        break Label_0257;
                    }
                    break Label_0257;
                }
                finally {
                    if (x != null) {
                        final int w2 = e41.w;
                        ((e41)x).V(false);
                    }
                    rt rt = null;
                Label_0299_Outer:
                    while (true) {
                        iftrue(Label_0332:)(rt != null);
                        return null;
                    Block_14:
                        while (true) {
                            AtomicReferenceFieldUpdater c = null;
                            a7 = fp3.a(c.get((Object)vg));
                            iftrue(Label_0324:)(!(a7 instanceof rt));
                            break Block_14;
                            Label_0286: {
                                iftrue(Label_0299:)(x == null);
                            }
                            Block_13: {
                                break Block_13;
                                while (true) {
                                    final long a6;
                                    LockSupport.parkNanos((Object)vg, a6);
                                    continue Label_0326_Outer;
                                    final InterruptedException ex = new InterruptedException();
                                    ((c)vg).t((Object)ex);
                                    throw ex;
                                    a6 = Long.MAX_VALUE;
                                    c = kotlinx.coroutines.c.c;
                                    iftrue(Label_0286:)(!(c.get((Object)vg) instanceof ck1));
                                    continue;
                                }
                            }
                            final int w3 = e41.w;
                            ((e41)x).V(false);
                            continue;
                        }
                        rt = (rt)a7;
                        continue Label_0299_Outer;
                        Label_0324: {
                            rt = null;
                        }
                        continue Label_0299_Outer;
                    }
                    Label_0332: {
                        throw rt.a;
                    }
                }
            }
            break;
        }
    }
    
    public static final Object e(up0 up0, final nd1 nd1, Continuation v) {
        final up0 context = v.getContext();
        if (!(boolean)up0.fold((Object)Boolean.FALSE, (nd1)new vp0(0))) {
            up0 = context.plus(up0);
        }
        else {
            up0 = vu5.a(context, up0, false);
        }
        a.b(up0);
        if (up0 == context) {
            final jj2 jj2 = new jj2(up0, v);
            up0 = (up0)rz5.a(jj2, jj2, nd1);
            return up0;
        }
        final xg1 n = xg1.n;
        if (kl1.b((Object)up0.get((tp0)n), (Object)context.get((tp0)n))) {
            final r43 r43 = new r43(up0, v);
            v = (Continuation)((z)r43).v;
            final Object b = jt3.b((up0)v, (Object)null);
            try {
                rz5.a((jj2)r43, (jj2)r43, nd1);
                return up0;
            }
            finally {
                jt3.a((up0)v, b);
            }
        }
        up0 = (up0)new jj2(up0, v);
        try {
            wm3.a(t43.a, dw5.b(dw5.a(nd1, (Continuation)up0, (Continuation)up0)));
            AtomicIntegerFieldUpdater x;
            do {
                x = b.x;
                final int value = x.get((Object)up0);
                if (value != 0) {
                    if (value != 2) {
                        throw new IllegalStateException("Already suspended");
                    }
                    up0 = (up0)fp3.a(c.c.get((Object)up0));
                    if (!(up0 instanceof rt)) {
                        return up0;
                    }
                    throw ((rt)up0).a;
                }
            } while (!x.compareAndSet((Object)up0, 0, 1));
            up0 = (up0)CoroutineSingletons.c;
            return up0;
        }
        finally {
            final Throwable t;
            ((z)up0).resumeWith((Object)new Result$Failure(t));
        }
    }
}
