import com.smarttools.nktech.core.data.datastore.b;
import com.smarttools.nktech.core.data.datastore.c;
import com.smarttools.nktech.core.data.datastore.d;
import com.smarttools.nktech.core.data.datastore.e;
import com.smarttools.nktech.core.data.datastore.f;
import com.smarttools.nktech.core.data.datastore.g;
import com.smarttools.nktech.core.data.datastore.h;
import com.smarttools.nktech.core.data.datastore.a;
import com.smarttools.nktech.core.data.datastore.k;
import com.smarttools.nktech.core.data.datastore.l;
import com.smarttools.nktech.core.data.datastore.j;
import com.smarttools.nktech.core.data.datastore.n;
import com.smarttools.nktech.core.data.datastore.o;
import com.smarttools.nktech.core.data.datastore.p;
import com.smarttools.nktech.core.data.datastore.q;
import com.smarttools.nktech.features.tools.essential.i;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import com.smarttools.nktech.features.tools.essential.m;
import kotlin.coroutines.Continuation;

public final class h51 implements ja1
{
    public final int c;
    public final ja1 n;
    
    public final Object collect(final ka1 ka1, final Continuation continuation) {
        switch (this.c) {
            default: {
                Object o = this.n.collect((ka1)new m(ka1), continuation);
                if (o != CoroutineSingletons.c) {
                    o = t43.a;
                }
                return o;
            }
            case 28: {
                Object o2 = this.n.collect((ka1)new i(ka1), continuation);
                if (o2 != CoroutineSingletons.c) {
                    o2 = t43.a;
                }
                return o2;
            }
            case 27: {
                Object o3 = this.n.collect((ka1)new q(ka1), continuation);
                if (o3 != CoroutineSingletons.c) {
                    o3 = t43.a;
                }
                return o3;
            }
            case 26: {
                Object o4 = this.n.collect((ka1)new p(ka1), continuation);
                if (o4 != CoroutineSingletons.c) {
                    o4 = t43.a;
                }
                return o4;
            }
            case 25: {
                Object o5 = this.n.collect((ka1)new o(ka1), continuation);
                if (o5 != CoroutineSingletons.c) {
                    o5 = t43.a;
                }
                return o5;
            }
            case 24: {
                Object o6 = this.n.collect((ka1)new n(ka1), continuation);
                if (o6 != CoroutineSingletons.c) {
                    o6 = t43.a;
                }
                return o6;
            }
            case 23: {
                Object o7 = this.n.collect((ka1)new j(ka1), continuation);
                if (o7 != CoroutineSingletons.c) {
                    o7 = t43.a;
                }
                return o7;
            }
            case 22: {
                Object o8 = this.n.collect((ka1)new com.smarttools.nktech.core.data.datastore.m(ka1), continuation);
                if (o8 != CoroutineSingletons.c) {
                    o8 = t43.a;
                }
                return o8;
            }
            case 21: {
                Object o9 = this.n.collect((ka1)new l(ka1), continuation);
                if (o9 != CoroutineSingletons.c) {
                    o9 = t43.a;
                }
                return o9;
            }
            case 20: {
                Object o10 = this.n.collect((ka1)new k(ka1), continuation);
                if (o10 != CoroutineSingletons.c) {
                    o10 = t43.a;
                }
                return o10;
            }
            case 19: {
                Object o11 = this.n.collect((ka1)new a(ka1), continuation);
                if (o11 != CoroutineSingletons.c) {
                    o11 = t43.a;
                }
                return o11;
            }
            case 18: {
                Object o12 = this.n.collect((ka1)new com.smarttools.nktech.core.data.datastore.i(ka1), continuation);
                if (o12 != CoroutineSingletons.c) {
                    o12 = t43.a;
                }
                return o12;
            }
            case 17: {
                Object o13 = this.n.collect((ka1)new h(ka1), continuation);
                if (o13 != CoroutineSingletons.c) {
                    o13 = t43.a;
                }
                return o13;
            }
            case 16: {
                Object o14 = this.n.collect((ka1)new g(ka1), continuation);
                if (o14 != CoroutineSingletons.c) {
                    o14 = t43.a;
                }
                return o14;
            }
            case 15: {
                Object o15 = this.n.collect((ka1)new f(ka1), continuation);
                if (o15 != CoroutineSingletons.c) {
                    o15 = t43.a;
                }
                return o15;
            }
            case 14: {
                Object o16 = this.n.collect((ka1)new e(ka1), continuation);
                if (o16 != CoroutineSingletons.c) {
                    o16 = t43.a;
                }
                return o16;
            }
            case 13: {
                Object o17 = this.n.collect((ka1)new d(ka1), continuation);
                if (o17 != CoroutineSingletons.c) {
                    o17 = t43.a;
                }
                return o17;
            }
            case 12: {
                Object o18 = this.n.collect((ka1)new c(ka1), continuation);
                if (o18 != CoroutineSingletons.c) {
                    o18 = t43.a;
                }
                return o18;
            }
            case 11: {
                Object o19 = this.n.collect((ka1)new b(ka1), continuation);
                if (o19 != CoroutineSingletons.c) {
                    o19 = t43.a;
                }
                return o19;
            }
            case 10: {
                Object o20 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.datetime.f(ka1), continuation);
                if (o20 != CoroutineSingletons.c) {
                    o20 = t43.a;
                }
                return o20;
            }
            case 9: {
                Object o21 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.datetime.e(ka1), continuation);
                if (o21 != CoroutineSingletons.c) {
                    o21 = t43.a;
                }
                return o21;
            }
            case 8: {
                Object o22 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.datetime.d(ka1), continuation);
                if (o22 != CoroutineSingletons.c) {
                    o22 = t43.a;
                }
                return o22;
            }
            case 7: {
                Object o23 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.datetime.c(ka1), continuation);
                if (o23 != CoroutineSingletons.c) {
                    o23 = t43.a;
                }
                return o23;
            }
            case 6: {
                Object o24 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.health.m(ka1), continuation);
                if (o24 != CoroutineSingletons.c) {
                    o24 = t43.a;
                }
                return o24;
            }
            case 5: {
                Object o25 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.finance.n(ka1), continuation);
                if (o25 != CoroutineSingletons.c) {
                    o25 = t43.a;
                }
                return o25;
            }
            case 4: {
                Object o26 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.finance.m(ka1), continuation);
                if (o26 != CoroutineSingletons.c) {
                    o26 = t43.a;
                }
                return o26;
            }
            case 3: {
                Object o27 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.finance.l(ka1), continuation);
                if (o27 != CoroutineSingletons.c) {
                    o27 = t43.a;
                }
                return o27;
            }
            case 2: {
                Object o28 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.finance.c(ka1), continuation);
                if (o28 != CoroutineSingletons.c) {
                    o28 = t43.a;
                }
                return o28;
            }
            case 1: {
                Object o29 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.finance.b(ka1), continuation);
                if (o29 != CoroutineSingletons.c) {
                    o29 = t43.a;
                }
                return o29;
            }
            case 0: {
                Object o30 = this.n.collect((ka1)new com.smarttools.nktech.features.tools.finance.a(ka1), continuation);
                if (o30 != CoroutineSingletons.c) {
                    o30 = t43.a;
                }
                return o30;
            }
        }
    }
}
