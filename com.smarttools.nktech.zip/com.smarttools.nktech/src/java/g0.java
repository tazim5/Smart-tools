public final class g0 extends wr5
{
    public final boolean a(final i0 i0, final d0 d0, final d0 n) {
        monitorenter(i0);
        Label_0027: {
            try {
                if (i0.n == d0) {
                    i0.n = n;
                    monitorexit(i0);
                    return true;
                }
                break Label_0027;
            }
            finally {
                monitorexit(i0);
                monitorexit(i0);
                return false;
            }
        }
    }
    
    public final boolean b(final i0 i0, final Object o, final Object c) {
        monitorenter(i0);
        Label_0027: {
            try {
                if (i0.c == o) {
                    i0.c = c;
                    monitorexit(i0);
                    return true;
                }
                break Label_0027;
            }
            finally {
                monitorexit(i0);
                monitorexit(i0);
                return false;
            }
        }
    }
    
    public final boolean c(final i0 i0, final h0 h0, final h0 v) {
        monitorenter(i0);
        Label_0027: {
            try {
                if (i0.v == h0) {
                    i0.v = v;
                    monitorexit(i0);
                    return true;
                }
                break Label_0027;
            }
            finally {
                monitorexit(i0);
                monitorexit(i0);
                return false;
            }
        }
    }
    
    public final void d(final h0 h0, final h0 b) {
        h0.b = b;
    }
    
    public final void e(final h0 h0, final Thread a) {
        h0.a = a;
    }
}
