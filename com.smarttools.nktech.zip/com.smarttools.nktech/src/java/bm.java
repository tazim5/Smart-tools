import android.hardware.camera2.CameraAccessException;
import androidx.camera.camera2.internal.compat.CameraAccessExceptionCompat;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.params.SessionConfiguration;

public final class bm extends am
{
    @Override
    public final void e(final cl2 cl2) {
        final SessionConfiguration sessionConfiguration = (SessionConfiguration)cl2.a.a();
        sessionConfiguration.getClass();
        try {
            ((CameraDevice)super.a).createCaptureSession(sessionConfiguration);
        }
        catch (final CameraAccessException ex) {
            throw new CameraAccessExceptionCompat(ex);
        }
    }
}
