import android.os.Bundle;
import android.content.Context;

public final class pi4
{
    public final Context a = (Context)gl5.n;
    public final o65 b = (o65)gl5.v;
    public final Bundle c = (Bundle)gl5.w;
    public final l65 d = (l65)gl5.x;
    public final m14 e = (m14)gl5.y;
    public final wx4 f = (wx4)gl5.z;
    
    public final gl5 a() {
        final gl5 gl5 = new gl5(9, false);
        gl5.n = this.a;
        gl5.v = this.b;
        gl5.w = this.c;
        gl5.y = this.e;
        gl5.z = this.f;
        return gl5;
    }
}
