public final class nz4 implements h32
{
    public static final nz4 a;
    
    static {
        a = (nz4)new Object();
        f83.q(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, new kg3(1)), 2)), 3)), 4)));
    }
}
