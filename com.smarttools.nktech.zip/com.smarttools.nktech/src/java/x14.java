import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zze;
import android.os.Parcel;
import android.os.IInterface;
import android.os.IBinder;

public final class x14 extends go3 implements y14
{
    public x14(final IBinder binder) {
        super(binder, "com.google.android.gms.ads.internal.mediation.client.rtb.IBannerCallback");
    }
    
    public final void V(final c14 c14) {
        final Parcel zza = this.zza();
        io3.e(zza, (IInterface)c14);
        this.zzbi(4, zza);
    }
    
    public final void a(final String s) {
        final Parcel zza = this.zza();
        zza.writeString("Adapter returned null.");
        this.zzbi(2, zza);
    }
    
    public final void q(final th1 th1) {
        final Parcel zza = this.zza();
        io3.e(zza, (IInterface)th1);
        this.zzbi(1, zza);
    }
    
    public final void zzf(final zze zze) {
        final Parcel zza = this.zza();
        io3.c(zza, (Parcelable)zze);
        this.zzbi(3, zza);
    }
}
