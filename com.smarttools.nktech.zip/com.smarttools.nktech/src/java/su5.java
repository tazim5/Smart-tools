import android.content.Intent;
import android.content.Context;
import android.os.Handler;
import android.content.BroadcastReceiver;

public final class su5 extends BroadcastReceiver implements Runnable
{
    public final Handler c;
    
    public su5(final Handler c) {
        this.c = c;
    }
    
    public final void onReceive(final Context context, final Intent intent) {
        if ("android.media.AUDIO_BECOMING_NOISY".equals((Object)intent.getAction())) {
            this.c.post((Runnable)this);
        }
    }
    
    public final void run() {
    }
}
