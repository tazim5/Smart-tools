import android.os.Handler;
import com.google.android.gms.internal.ads.zzcbt;
import com.google.android.gms.ads.internal.zza;
import android.app.Activity;
import android.view.ViewGroup$LayoutParams;
import android.widget.FrameLayout$LayoutParams;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.View$OnTouchListener;
import android.view.View$OnClickListener;
import com.google.android.gms.ads.internal.util.zzac;
import java.util.HashMap;
import android.webkit.WebView;
import java.util.Map;
import com.google.android.gms.ads.internal.util.zzt;
import org.json.JSONObject;
import com.google.android.gms.ads.internal.overlay.zzc;
import com.google.android.gms.internal.ads.l2;
import android.view.ViewGroup;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.ads.internal.overlay.zzl;
import android.content.Context;
import android.view.View;
import java.util.concurrent.atomic.AtomicBoolean;
import android.widget.FrameLayout;

public final class dc4 extends FrameLayout implements rb4
{
    public final fc4 c;
    public final f44 n;
    public final AtomicBoolean v;
    
    public dc4(final fc4 c) {
        super(((View)c).getContext());
        this.v = new AtomicBoolean();
        this.c = c;
        final Context c2 = c.c.c;
        final Object n = new Object();
        Context applicationContext = c2;
        if (c2.getApplicationContext() != null) {
            applicationContext = c2.getApplicationContext();
        }
        ((f44)n).c = applicationContext;
        ((f44)n).v = this;
        ((f44)n).n = this;
        ((f44)n).w = null;
        this.n = (f44)n;
        ((ViewGroup)this).addView((View)c);
    }
    
    public final void B(final e11 e11) {
        this.c.B(e11);
    }
    
    public final void C(final boolean b, final int n, final String s, final boolean b2, final boolean b3) {
        this.c.C(b, n, s, b2, b3);
    }
    
    public final void D(final zzl zzl) {
        this.c.D(zzl);
    }
    
    public final boolean E() {
        return this.c.E();
    }
    
    public final void F() {
        final f44 n = this.n;
        n.getClass();
        Preconditions.checkMainThread("onDestroy must be called from the UI thread.");
        final ca4 ca4 = (ca4)n.w;
        if (ca4 != null) {
            ca4.x.a();
            final y94 z = ca4.z;
            if (z != null) {
                z.x();
            }
            ca4.b();
            ((ViewGroup)n.v).removeView((View)n.w);
            n.w = null;
        }
        this.c.F();
    }
    
    public final void G(final int n) {
        this.c.G(n);
    }
    
    public final void I(final String s, final String s2, final boolean b, final int n, final boolean b2) {
        this.c.I(s, s2, b, n, b2);
    }
    
    public final boolean J(final int n, final boolean b) {
        if (!this.v.compareAndSet(false, true)) {
            return true;
        }
        if (zzba.zzc().a(cs3.B0)) {
            return false;
        }
        final fc4 c = this.c;
        if (((View)c).getParent() instanceof ViewGroup) {
            ((ViewGroup)((View)c).getParent()).removeView((View)c);
        }
        c.J(n, b);
        return true;
    }
    
    public final void K() {
        this.c.K();
    }
    
    public final boolean M() {
        return this.c.M();
    }
    
    public final void N(final boolean b) {
        this.c.N(b);
    }
    
    public final void O(final String s, final hx3 hx3) {
        this.c.O(s, hx3);
    }
    
    public final void Q(final Context context) {
        this.c.Q(context);
    }
    
    public final jp3 R() {
        return this.c.R();
    }
    
    public final void S(final int n) {
        this.c.S(n);
    }
    
    public final void T(final String s, final eb4 eb4) {
        this.c.T(s, eb4);
    }
    
    public final boolean U() {
        return this.c.U();
    }
    
    public final void V() {
        this.c.V();
    }
    
    public final void W(final l2 q, final e65 r) {
        final fc4 c = this.c;
        c.Q = q;
        c.R = r;
    }
    
    public final String X() {
        return this.c.X();
    }
    
    public final void Y(final String s, final hx3 hx3) {
        this.c.Y(s, hx3);
    }
    
    public final void Z(final zzc zzc, final boolean b) {
        this.c.Z(zzc, b);
    }
    
    public final l2 a() {
        return this.c.Q;
    }
    
    public final void a0(final long n, final boolean b) {
        this.c.a0(n, b);
    }
    
    public final void b() {
        final fc4 c = this.c;
        if (c != null) {
            c.b();
        }
    }
    
    public final void b0(final hc4 hc4) {
        this.c.b0(hc4);
    }
    
    public final void c(final JSONObject jsonObject, final String s) {
        this.c.c(jsonObject, s);
    }
    
    public final void c0(final boolean b) {
        this.c.c0(b);
    }
    
    public final boolean canGoBack() {
        return ((WebView)this.c).canGoBack();
    }
    
    public final void d() {
        this.c.d();
    }
    
    public final bu3 d0() {
        return this.c.d0();
    }
    
    public final void destroy() {
        final fc4 c = this.c;
        final e95 zzQ = c.zzQ();
        if (zzQ != null) {
            final lb5 zza = zzt.zza;
            ((Handler)zza).post((Runnable)new bc4(zzQ, 0));
            ((Handler)zza).postDelayed((Runnable)new cc4(c, 0), (long)(int)zzba.zzc().a(cs3.s4));
            return;
        }
        c.destroy();
    }
    
    public final void e(final JSONObject jsonObject, final String s) {
        this.c.o0(s, jsonObject.toString());
    }
    
    public final boolean e0() {
        return this.v.get();
    }
    
    public final void f(final String s, final Map map) {
        this.c.f(s, map);
    }
    
    public final void f0(final aq4 aq4) {
        this.c.f0(aq4);
    }
    
    public final void g0() {
        ((View)this).setBackgroundColor(0);
        ((WebView)this.c).setBackgroundColor(0);
    }
    
    public final void goBack() {
        ((WebView)this.c).goBack();
    }
    
    public final void h(final no3 no3) {
        this.c.h(no3);
    }
    
    public final String h0() {
        return this.c.h0();
    }
    
    public final WebView i() {
        return (WebView)this.c;
    }
    
    public final void i0(final zzl zzl) {
        this.c.i0(zzl);
    }
    
    public final zzl j() {
        return this.c.j();
    }
    
    public final void j0() {
        this.c.j0();
    }
    
    public final void k0(final boolean b) {
        this.c.k0(b);
    }
    
    public final zzl l() {
        return this.c.l();
    }
    
    public final void l0(final int n, final boolean b, final boolean b2) {
        this.c.l0(n, b, b2);
    }
    
    public final void loadData(final String s, final String s2, final String s3) {
        this.c.loadData(s, "text/html", s3);
    }
    
    public final void loadDataWithBaseURL(final String s, final String s2, final String s3, final String s4, final String s5) {
        this.c.loadDataWithBaseURL(s, s2, "text/html", "UTF-8", (String)null);
    }
    
    public final void loadUrl(final String s) {
        this.c.loadUrl(s);
    }
    
    public final void m(final int n) {
        final ca4 ca4 = (ca4)this.n.w;
        if (ca4 != null && (boolean)zzba.zzc().a(cs3.z)) {
            ((View)ca4.n).setBackgroundColor(n);
            ca4.v.setBackgroundColor(n);
        }
    }
    
    public final void m0() {
        final fc4 c = this.c;
        if (c != null) {
            c.m0();
        }
    }
    
    public final void n() {
        final HashMap hashMap = new HashMap(3);
        hashMap.put((Object)"app_muted", (Object)String.valueOf(com.google.android.gms.ads.internal.zzt.zzr().zze()));
        hashMap.put((Object)"app_volume", (Object)String.valueOf(com.google.android.gms.ads.internal.zzt.zzr().zza()));
        final fc4 c = this.c;
        hashMap.put((Object)"device_volume", (Object)String.valueOf(zzac.zzb(((View)c).getContext())));
        c.f("volume", (Map)hashMap);
    }
    
    public final void o(final boolean b) {
        this.c.o(b);
    }
    
    public final void onAdClicked() {
        final fc4 c = this.c;
        if (c != null) {
            c.onAdClicked();
        }
    }
    
    public final void onPause() {
        final f44 n = this.n;
        n.getClass();
        Preconditions.checkMainThread("onPause must be called from the UI thread.");
        final ca4 ca4 = (ca4)n.w;
        if (ca4 != null) {
            final y94 z = ca4.z;
            if (z != null) {
                z.s();
            }
        }
        this.c.onPause();
    }
    
    public final void onResume() {
        this.c.onResume();
    }
    
    public final rm3 p() {
        return this.c.n;
    }
    
    public final void p0(final int n) {
        this.c.p0(n);
    }
    
    public final void q(final boolean j0) {
        this.c.U.j0 = j0;
    }
    
    public final void r(final bu3 bu3) {
        this.c.r(bu3);
    }
    
    public final void s(final e95 e95) {
        this.c.s(e95);
    }
    
    public final void setOnClickListener(final View$OnClickListener onClickListener) {
        ((View)this.c).setOnClickListener(onClickListener);
    }
    
    public final void setOnTouchListener(final View$OnTouchListener onTouchListener) {
        ((View)this.c).setOnTouchListener(onTouchListener);
    }
    
    public final void setWebChromeClient(final WebChromeClient webChromeClient) {
        ((WebView)this.c).setWebChromeClient(webChromeClient);
    }
    
    public final void setWebViewClient(final WebViewClient webViewClient) {
        this.c.setWebViewClient(webViewClient);
    }
    
    public final void t(final String s, final String s2) {
        this.c.n0(s, s2);
    }
    
    public final boolean u() {
        return this.c.u();
    }
    
    public final void v(final boolean b) {
        this.c.v(b);
    }
    
    public final boolean w() {
        return this.c.w();
    }
    
    public final void x() {
        final TextView textView = new TextView(((View)this).getContext());
        com.google.android.gms.ads.internal.zzt.zzp();
        textView.setText((CharSequence)zzt.zzx());
        textView.setTextSize(15.0f);
        textView.setTextColor(-1);
        textView.setPadding(5, 0, 5, 0);
        final GradientDrawable background = new GradientDrawable();
        background.setShape(0);
        background.setColor(-12303292);
        background.setCornerRadius(8.0f);
        ((View)textView).setBackground((Drawable)background);
        ((ViewGroup)this).addView((View)textView, (ViewGroup$LayoutParams)new FrameLayout$LayoutParams(-2, -2, 49));
        ((ViewGroup)this).bringChildToFront((View)textView);
    }
    
    public final void z(final String s, final String s2) {
        this.c.z(s, s2);
    }
    
    public final Context zzE() {
        return this.c.c.c;
    }
    
    public final View zzF() {
        return (View)this;
    }
    
    public final yb4 zzN() {
        return this.c.U;
    }
    
    public final e11 zzO() {
        return this.c.zzO();
    }
    
    public final e65 zzP() {
        return this.c.R;
    }
    
    public final e95 zzQ() {
        return this.c.zzQ();
    }
    
    public final yq1 zzR() {
        return this.c.zzR();
    }
    
    public final void zzX() {
        this.c.zzX();
    }
    
    public final void zzbk() {
        this.c.zzbk();
    }
    
    public final void zzbl() {
        this.c.zzbl();
    }
    
    public final int zzf() {
        return this.c.zzf();
    }
    
    public final int zzg() {
        if (zzba.zzc().a(cs3.o3)) {
            return ((View)this.c).getMeasuredHeight();
        }
        return ((View)this).getMeasuredHeight();
    }
    
    public final int zzh() {
        if (zzba.zzc().a(cs3.o3)) {
            return ((View)this.c).getMeasuredWidth();
        }
        return ((View)this).getMeasuredWidth();
    }
    
    public final Activity zzi() {
        return this.c.c.a;
    }
    
    public final zza zzj() {
        return this.c.y;
    }
    
    public final gs3 zzk() {
        return this.c.s0;
    }
    
    public final il3 zzm() {
        return this.c.u0;
    }
    
    public final zzcbt zzn() {
        return this.c.w;
    }
    
    public final f44 zzo() {
        return this.n;
    }
    
    public final hc4 zzq() {
        return this.c.zzq();
    }
    
    public final void zzu() {
        this.c.zzu();
    }
}
