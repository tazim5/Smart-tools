import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.State;

public final class xo2 implements nd1
{
    public final eh c;
    public final boolean n;
    public final State v;
    
    public xo2(final eh c, final boolean n, final State v) {
        this.c = c;
        this.n = n;
        this.v = v;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final String b = this.c.b;
            final TextStyle labelSmall = MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getLabelSmall();
            FontWeight fontWeight;
            if (this.n) {
                fontWeight = FontWeight.Companion.getSemiBold();
            }
            else {
                fontWeight = FontWeight.Companion.getNormal();
            }
            TextKt.Text--4IGK_g(b, (Modifier)null, ((Color)this.v.getValue()).unbox-impl(), TextUnitKt.getSp(11), (FontStyle)null, fontWeight, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, labelSmall, composer, 3072, 0, 65490);
        }
        return t43.a;
    }
}
