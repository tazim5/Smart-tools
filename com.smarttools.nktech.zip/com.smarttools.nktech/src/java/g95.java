import java.util.Iterator;
import java.util.Collection;
import java.util.Collections;
import android.os.Handler;
import android.media.AudioManager;
import android.content.Context;
import android.database.ContentObserver;

public final class g95 extends ContentObserver
{
    public final Context a;
    public final AudioManager b;
    public float c;
    public final r95 d;
    
    public g95(final Handler handler, final Context a, final r95 d) {
        super(handler);
        this.a = a;
        this.b = (AudioManager)a.getSystemService("audio");
        this.d = d;
    }
    
    public final float a() {
        final AudioManager b = this.b;
        final int streamVolume = b.getStreamVolume(3);
        final int streamMaxVolume = b.getStreamMaxVolume(3);
        float n = 0.0f;
        if (streamMaxVolume > 0) {
            if (streamVolume <= 0) {
                n = n;
            }
            else if ((n = streamVolume / (float)streamMaxVolume) > 1.0f) {
                n = 1.0f;
            }
        }
        return n;
    }
    
    public final void b() {
        final float c = this.c;
        final r95 d = this.d;
        d.a = c;
        if (d.c == null) {
            d.c = j95.c;
        }
        final Iterator iterator = Collections.unmodifiableCollection((Collection)d.c.b).iterator();
        while (iterator.hasNext()) {
            jt3.c(((f95)iterator.next()).d.a(), "setDeviceVolume", new Object[] { c });
        }
    }
    
    public final void onChange(final boolean b) {
        super.onChange(b);
        final float a = this.a();
        if (a != this.c) {
            this.c = a;
            this.b();
        }
    }
}
