import java.text.DateFormat;
import androidx.compose.runtime.State;
import java.util.Iterator;
import androidx.compose.runtime.Composer$Companion;
import androidx.compose.ui.text.font.FontWeight$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.ui.Modifier$Companion;
import kotlin.text.c;
import androidx.compose.material3.ButtonColors;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import com.smarttools.nktech.features.tools.finance.IncomeSource;
import androidx.compose.material3.SelectableChipElevation;
import androidx.compose.material3.SelectableChipColors;
import androidx.compose.material3.ChipKt;
import com.smarttools.nktech.features.tools.finance.ExpenseCategory;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.input.PlatformImeOptions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.ui.text.input.KeyboardType;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ButtonKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.ui.graphics.Color;
import com.smarttools.nktech.features.tools.finance.i;
import com.smarttools.nktech.features.tools.finance.TransactionType;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import java.util.List;
import com.smarttools.nktech.features.tools.finance.Currency;
import com.smarttools.nktech.features.tools.finance.g;
import android.content.Context;
import androidx.compose.runtime.MutableState;

public final class h61 implements od1
{
    public final MutableState P;
    public final MutableState Q;
    public final MutableState R;
    public final MutableState S;
    public final MutableState T;
    public final Context U;
    public final boolean c;
    public final g n;
    public final m71 v;
    public final MutableState w;
    public final MutableState x;
    public final Currency y;
    public final List z;
    
    public h61(final boolean c, final g n, final m71 v, final MutableState w, final MutableState x, final Currency y, final List z, final MutableState p13, final MutableState q, final MutableState r, final MutableState s, final MutableState t, final Context u) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p13;
        this.Q = q;
        this.R = r;
        this.S = s;
        this.T = t;
        this.U = u;
    }
    
    public final Object invoke(Object rememberedValue, Object o, Object rememberedValue2) {
        final ColumnScope columnScope = (ColumnScope)rememberedValue;
        final Composer composer = (Composer)o;
        if ((((Number)rememberedValue2).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final float n = 20;
            final float constructor-impl = Dp.constructor-impl(n);
            final float n2 = 8;
            final Modifier padding-qDBjuR0$default = PaddingKt.padding-qDBjuR0$default(PaddingKt.padding-VpY3zN4(fillMaxWidth$default, constructor-impl, Dp.constructor-impl(n2)), 0.0f, 0.0f, 0.0f, Dp.constructor-impl((float)32), 7, (Object)null);
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$Vertical top = instance.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-qDBjuR0$default);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl2, columnMeasurePolicy, constructor-impl2, currentCompositionLocalMap);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl2, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final boolean c = this.c;
            String s;
            if (c) {
                s = "Edit Transaction";
            }
            else {
                s = "Add Transaction";
            }
            final MaterialTheme instance3 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            final TextStyle titleLarge = instance3.getTypography(composer, $stable).getTitleLarge();
            final FontWeight$Companion companion4 = FontWeight.Companion;
            TextKt.Text--4IGK_g(s, (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, titleLarge, composer, 196608, 0, 65502);
            ap.l((float)16, companion, composer, 6);
            final Modifier fillMaxWidth$default2 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl(n2)), companion2.getTop(), composer, 6);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default2);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl3 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl3, rowMeasurePolicy, constructor-impl3, currentCompositionLocalMap2);
            if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl3, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl3, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance4 = RowScopeInstance.INSTANCE;
            final ButtonDefaults instance5 = ButtonDefaults.INSTANCE;
            composer.startReplaceGroup(-38298687);
            final MutableState w = this.w;
            final TransactionType transactionType = (TransactionType)((State)w).getValue();
            final TransactionType n3 = TransactionType.n;
            long n4;
            if (transactionType == n3) {
                n4 = i.b;
            }
            else {
                n4 = instance3.getColorScheme(composer, $stable).getSurfaceVariant-0d7_KjU();
            }
            long n5;
            if (az0.d(composer, -38294396, w) == n3) {
                n5 = Color.Companion.getWhite-0d7_KjU();
            }
            else {
                n5 = instance3.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU();
            }
            composer.endReplaceGroup();
            final int n6 = ButtonDefaults.$stable << 12;
            final ButtonColors buttonColors-ro_MJ88 = instance5.buttonColors-ro_MJ88(n4, n5, 0L, 0L, composer, n6, 12);
            final Modifier weight$default = RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null);
            composer.startReplaceGroup(-38303066);
            o = composer.rememberedValue();
            final Composer$Companion companion5 = Composer.Companion;
            rememberedValue = o;
            if (o == companion5.getEmpty()) {
                rememberedValue = new ny0(w, 16);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id1 = (id1)rememberedValue;
            composer.endReplaceGroup();
            ButtonKt.Button(id1, weight$default, false, (Shape)null, buttonColors-ro_MJ88, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)i30.n, composer, 805306374, 492);
            composer.startReplaceGroup(-38281695);
            final TransactionType transactionType2 = (TransactionType)((State)w).getValue();
            final TransactionType c2 = TransactionType.c;
            long n7;
            if (transactionType2 == c2) {
                n7 = i.a;
            }
            else {
                n7 = instance3.getColorScheme(composer, $stable).getSurfaceVariant-0d7_KjU();
            }
            long n8;
            if (az0.d(composer, -38277405, w) == c2) {
                n8 = Color.Companion.getWhite-0d7_KjU();
            }
            else {
                n8 = instance3.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU();
            }
            composer.endReplaceGroup();
            final ButtonColors buttonColors-ro_MJ89 = instance5.buttonColors-ro_MJ88(n7, n8, 0L, 0L, composer, n6, 12);
            final Modifier weight$default2 = RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null);
            composer.startReplaceGroup(-38286043);
            o = (rememberedValue = composer.rememberedValue());
            if (o == companion5.getEmpty()) {
                rememberedValue = new ny0(w, 17);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id2 = (id1)rememberedValue;
            composer.endReplaceGroup();
            ButtonKt.Button(id2, weight$default2, false, (Shape)null, buttonColors-ro_MJ89, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)i30.o, composer, 805306374, 492);
            composer.endNode();
            final float n9 = 12;
            ap.l(n9, companion, composer, 6);
            final MutableState x = this.x;
            final String s2 = (String)((State)x).getValue();
            final KeyboardOptions keyboardOptions = new KeyboardOptions(0, (Boolean)null, KeyboardType.Companion.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null);
            final Modifier fillMaxWidth$default3 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            composer.startReplaceGroup(1438116897);
            o = composer.rememberedValue();
            if ((rememberedValue = o) == companion5.getEmpty()) {
                rememberedValue = new fw0(x, 21);
                composer.updateRememberedValue(rememberedValue);
            }
            final jd1 jd1 = (jd1)rememberedValue;
            composer.endReplaceGroup();
            OutlinedTextFieldKt.OutlinedTextField(s2, jd1, fillMaxWidth$default3, false, false, (TextStyle)null, (nd1)ComposableLambdaKt.rememberComposableLambda(1641342828, true, (Object)new c61(this.y, 0), composer, 54), (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, false, (VisualTransformation)null, keyboardOptions, (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, composer, 1573296, 12779520, 0, 8224696);
            final TransactionType transactionType3 = (TransactionType)az0.c(n9, companion, composer, 6, w);
            final MutableState p3 = this.P;
            final MutableState q = this.Q;
            final MutableState r = this.R;
            int n11;
            MutableState mutableState2;
            MutableState mutableState3;
            if (transactionType3 == n3) {
                composer.startReplaceGroup(1632430915);
                TextKt.Text--4IGK_g("Category", (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getTitleSmall(), composer, 196614, 0, 65502);
                final float n10 = 6;
                ap.l(n10, companion, composer, 6);
                final Modifier horizontalScroll$default = ScrollKt.horizontalScroll$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
                final MeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl(n10)), companion2.getTop(), composer, 6);
                final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, horizontalScroll$default);
                final id1 constructor3 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor3);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl4 = Updater.constructor-impl(composer);
                final nd1 b3 = ap.b(companion3, constructor-impl4, rowMeasurePolicy2, constructor-impl4, currentCompositionLocalMap3);
                if (constructor-impl4.getInserting() || !kl1.b(constructor-impl4.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                    l3.i(currentCompositeKeyHash3, constructor-impl4, currentCompositeKeyHash3, b3);
                }
                l3.l(companion3, constructor-impl4, materializeModifier3, composer, -38237522);
                for (final ExpenseCategory expenseCategory : ExpenseCategory.v) {
                    final boolean b4 = kl1.b((Object)((State)p3).getValue(), (Object)((Enum)expenseCategory).name()) && !(boolean)((State)q).getValue();
                    composer.startReplaceGroup(-1879176425);
                    final boolean changed = composer.changed((Object)expenseCategory);
                    rememberedValue2 = composer.rememberedValue();
                    if (changed || rememberedValue2 == Composer.Companion.getEmpty()) {
                        rememberedValue2 = new wp((Object)expenseCategory, (Object)p3, (Object)q, 3);
                        composer.updateRememberedValue(rememberedValue2);
                    }
                    final id1 id3 = (id1)rememberedValue2;
                    composer.endReplaceGroup();
                    ChipKt.FilterChip(b4, id3, (nd1)ComposableLambdaKt.rememberComposableLambda(-1640249757, true, (Object)new d61(expenseCategory, 0), composer, 54), (Modifier)null, false, (nd1)ComposableLambdaKt.rememberComposableLambda(892542310, true, (Object)new e61(expenseCategory), composer, 54), (nd1)null, (Shape)null, (SelectableChipColors)null, (SelectableChipElevation)null, (BorderStroke)null, (MutableInteractionSource)null, composer, 196992, 0, 4056);
                }
                composer.endReplaceGroup();
                composer.startReplaceGroup(-38221644);
                for (final nt0 nt0 : (Iterable)this.z) {
                    final boolean b5 = kl1.b((Object)((State)p3).getValue(), (Object)nt0.b) && (boolean)((State)q).getValue();
                    composer.startReplaceGroup(-1879160586);
                    final boolean changed2 = composer.changed((Object)nt0);
                    final Object rememberedValue3 = composer.rememberedValue();
                    if (changed2 || (rememberedValue2 = rememberedValue3) == Composer.Companion.getEmpty()) {
                        rememberedValue2 = new wp((Object)nt0, (Object)p3, (Object)q, 4);
                        composer.updateRememberedValue(rememberedValue2);
                    }
                    final id1 id4 = (id1)rememberedValue2;
                    composer.endReplaceGroup();
                    ChipKt.FilterChip(b5, id4, (nd1)ComposableLambdaKt.rememberComposableLambda(-1075514647, true, (Object)new q((Object)nt0, 17), composer, 54), (Modifier)null, false, (nd1)i30.p, (nd1)null, (Shape)null, (SelectableChipColors)null, (SelectableChipElevation)null, (BorderStroke)null, (MutableInteractionSource)null, composer, 196992, 0, 4056);
                }
                composer.endReplaceGroup();
                composer.endNode();
                composer.endReplaceGroup();
                final MutableState mutableState = q;
                n11 = 1;
                mutableState2 = r;
                mutableState3 = mutableState;
            }
            else {
                final MutableState mutableState4 = q;
                mutableState2 = r;
                composer.startReplaceGroup(1633810663);
                TextKt.Text--4IGK_g("Source", (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getTitleSmall(), composer, 196614, 0, 65502);
                final float n12 = 6;
                ap.l(n12, companion, composer, 6);
                n11 = 1;
                final Modifier horizontalScroll$default2 = ScrollKt.horizontalScroll$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
                final MeasurePolicy rowMeasurePolicy3 = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl(n12)), companion2.getTop(), composer, 6);
                final int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap4 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier4 = ComposedModifierKt.materializeModifier(composer, horizontalScroll$default2);
                final id1 constructor4 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor4);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl5 = Updater.constructor-impl(composer);
                final nd1 b6 = ap.b(companion3, constructor-impl5, rowMeasurePolicy3, constructor-impl5, currentCompositionLocalMap4);
                if (constructor-impl5.getInserting() || !kl1.b(constructor-impl5.rememberedValue(), (Object)currentCompositeKeyHash4)) {
                    l3.i(currentCompositeKeyHash4, constructor-impl5, currentCompositeKeyHash4, b6);
                }
                l3.l(companion3, constructor-impl5, materializeModifier4, composer, -38192667);
                for (final IncomeSource incomeSource : IncomeSource.v) {
                    final boolean b7 = kl1.b((Object)((State)mutableState2).getValue(), (Object)((Enum)incomeSource).name());
                    composer.startReplaceGroup(-1879132128);
                    final boolean changed3 = composer.changed((Object)incomeSource);
                    o = composer.rememberedValue();
                    if (changed3 || o == Composer.Companion.getEmpty()) {
                        o = new d5(4, (Object)incomeSource, (Object)mutableState2);
                        composer.updateRememberedValue(o);
                    }
                    final id1 id5 = (id1)o;
                    composer.endReplaceGroup();
                    ChipKt.FilterChip(b7, id5, (nd1)ComposableLambdaKt.rememberComposableLambda(-807621782, (boolean)(n11 != 0), (Object)new q((Object)incomeSource, 18), composer, 54), (Modifier)null, false, (nd1)ComposableLambdaKt.rememberComposableLambda(1377156743, (boolean)(n11 != 0), (Object)new f61(incomeSource), composer, 54), (nd1)null, (Shape)null, (SelectableChipColors)null, (SelectableChipElevation)null, (BorderStroke)null, (MutableInteractionSource)null, composer, 196992, 0, 4056);
                }
                composer.endReplaceGroup();
                composer.endNode();
                composer.endReplaceGroup();
                mutableState3 = mutableState4;
            }
            final Modifier$Companion companion6 = Modifier.Companion;
            ap.l(n9, companion6, composer, 6);
            final MutableState s3 = this.S;
            final String s4 = (String)((State)s3).getValue();
            final Modifier fillMaxWidth$default4 = SizeKt.fillMaxWidth$default((Modifier)companion6, 0.0f, n11, (Object)null);
            composer.startReplaceGroup(1438208466);
            final Object rememberedValue4 = composer.rememberedValue();
            final Composer$Companion companion7 = Composer.Companion;
            rememberedValue2 = rememberedValue4;
            if (rememberedValue4 == companion7.getEmpty()) {
                rememberedValue2 = new fw0(s3, 22);
                composer.updateRememberedValue(rememberedValue2);
            }
            final jd1 jd2 = (jd1)rememberedValue2;
            composer.endReplaceGroup();
            OutlinedTextFieldKt.OutlinedTextField(s4, jd2, fillMaxWidth$default4, false, false, (TextStyle)null, (nd1)i30.q, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, false, (VisualTransformation)null, (KeyboardOptions)null, (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, composer, 1573296, 12582912, 0, 8257464);
            ap.l(n9, companion6, composer, 6);
            final Modifier fillMaxWidth$default5 = SizeKt.fillMaxWidth$default((Modifier)companion6, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy4 = RowKt.rowMeasurePolicy((Arrangement$Horizontal)Arrangement.INSTANCE.getSpaceBetween(), Alignment.Companion.getCenterVertically(), composer, 54);
            final int currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap5 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier5 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default5);
            final ComposeUiNode$Companion companion8 = ComposeUiNode.Companion;
            final id1 constructor5 = companion8.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor5);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl6 = Updater.constructor-impl(composer);
            final nd1 b8 = ap.b(companion8, constructor-impl6, rowMeasurePolicy4, constructor-impl6, currentCompositionLocalMap5);
            if (constructor-impl6.getInserting() || !kl1.b(constructor-impl6.rememberedValue(), (Object)currentCompositeKeyHash5)) {
                l3.i(currentCompositeKeyHash5, constructor-impl6, currentCompositeKeyHash5, b8);
            }
            Updater.set-impl(constructor-impl6, (Object)materializeModifier5, companion8.getSetModifier());
            final RowScopeInstance instance6 = RowScopeInstance.INSTANCE;
            rememberedValue2 = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault());
            final MutableState t = this.T;
            final String format = ((DateFormat)rememberedValue2).format(new Date(((Number)((State)t).getValue()).longValue()));
            final TextStyle bodyMedium = MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getBodyMedium();
            boolean b9 = false;
            TextKt.Text--4IGK_g(format, (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, bodyMedium, composer, 0, 0, 65534);
            ButtonKt.OutlinedButton((id1)new of(this.U, t, 6), (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)i30.r, composer, 805306368, 510);
            fe2.g(composer, n, companion6, composer, 6);
            if (kotlin.text.c.I((String)((State)x).getValue()) != null) {
                final Double i = kotlin.text.c.I((String)((State)x).getValue());
                double doubleValue;
                if (i != null) {
                    doubleValue = i;
                }
                else {
                    doubleValue = 0.0;
                }
                if (doubleValue > 0.0) {
                    b9 = true;
                }
            }
            final Modifier fillMaxWidth$default6 = SizeKt.fillMaxWidth$default((Modifier)companion6, 0.0f, 1, (Object)null);
            final ButtonDefaults instance7 = ButtonDefaults.INSTANCE;
            long n13;
            if (((State)w).getValue() == c2) {
                n13 = i.a;
            }
            else {
                n13 = i.b;
            }
            final ButtonColors buttonColors-ro_MJ90 = instance7.buttonColors-ro_MJ88(n13, 0L, 0L, 0L, composer, ButtonDefaults.$stable << 12, 14);
            composer.startReplaceGroup(1438263616);
            final g n14 = this.n;
            final boolean changed4 = composer.changed((Object)n14);
            final m71 v = this.v;
            final boolean changed5 = composer.changed((Object)v);
            final Object rememberedValue5 = composer.rememberedValue();
            if ((changed4 | changed5) || (rememberedValue2 = rememberedValue5) == companion7.getEmpty()) {
                rememberedValue2 = new b61(n14, v, x, w, p3, mutableState2, s3, t, mutableState3);
                composer.updateRememberedValue(rememberedValue2);
            }
            final id1 id6 = (id1)rememberedValue2;
            composer.endReplaceGroup();
            ButtonKt.Button(id6, fillMaxWidth$default6, b9, (Shape)null, buttonColors-ro_MJ90, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)ComposableLambdaKt.rememberComposableLambda(1674158786, true, (Object)new g61(w, c), composer, 54), composer, 805306416, 488);
            composer.endNode();
        }
        return t43.a;
    }
}
