import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.material.icons.filled.CloseKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;

public final class q80 implements nd1
{
    public static final q80 c;
    
    static {
        c = (q80)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(CloseKt.getClose(Icons.INSTANCE.getDefault()), "Delete", SizeKt.size-3ABfNKs((Modifier)Modifier.Companion, Dp.constructor-impl((float)20)), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getError-0d7_KjU(), composer, 432, 0);
        }
        return t43.a;
    }
}
