import java.util.Map$Entry;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public final class kk3
{
    public final int a;
    public final byte[] b;
    public final Map c;
    public final List d;
    public final boolean e;
    
    public kk3(final int a, final byte[] b, final Map c, final List list, final boolean e) {
        this.a = a;
        this.b = b;
        this.c = c;
        List unmodifiableList;
        if (list == null) {
            unmodifiableList = null;
        }
        else {
            unmodifiableList = Collections.unmodifiableList(list);
        }
        this.d = unmodifiableList;
        this.e = e;
    }
    
    public kk3(final int n, final byte[] array, final boolean b, final long n2, final List list) {
        Object emptyMap;
        if (list == null) {
            emptyMap = null;
        }
        else if (list.isEmpty()) {
            emptyMap = Collections.emptyMap();
        }
        else {
            final TreeMap treeMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
            final Iterator iterator = list.iterator();
            while (true) {
                emptyMap = treeMap;
                if (!iterator.hasNext()) {
                    break;
                }
                final hk3 hk3 = (hk3)iterator.next();
                treeMap.put((Object)hk3.a, (Object)hk3.b);
            }
        }
        this(n, array, (Map)emptyMap, list, b);
    }
    
    public static List a(final Map map) {
        if (map == null) {
            return null;
        }
        if (map.isEmpty()) {
            return Collections.emptyList();
        }
        final ArrayList list = new ArrayList(map.size());
        for (final Map$Entry map$Entry : map.entrySet()) {
            list.add((Object)new hk3((String)map$Entry.getKey(), (String)map$Entry.getValue()));
        }
        return (List)list;
    }
}
