import java.util.Set;

public final class sf2 implements gc2
{
    public final Set a;
    
    public sf2(final Set a) {
        this.a = a;
    }
}
