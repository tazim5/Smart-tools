public class p71 implements gd2
{
}
