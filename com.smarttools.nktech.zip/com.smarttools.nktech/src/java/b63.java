import androidx.camera.core.impl.UseCaseConfigFactory$CaptureType;

public interface b63
{
    public static final a63 a = new Object();
    
    no0 a(final UseCaseConfigFactory$CaptureType p0, final int p1);
}
