import android.content.Context;

public interface rv1
{
    boolean a(final ws2 p0);
    
    boolean b();
    
    void d(final bv1 p0, final boolean p1);
    
    boolean e(final gv1 p0);
    
    void f(final qv1 p0);
    
    boolean g(final gv1 p0);
    
    void h();
    
    void j(final Context p0, final bv1 p1);
}
