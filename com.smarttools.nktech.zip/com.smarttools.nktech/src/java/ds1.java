import java.util.Collections;
import java.util.ArrayList;
import java.util.List;

public final class ds1
{
    public static final int c = 0;
    public final String a;
    public final List b;
    
    static {
        Collections.unmodifiableList((List)new ArrayList());
    }
    
    public ds1(final String a, final List b) {
        this.a = a;
        this.b = b;
    }
}
