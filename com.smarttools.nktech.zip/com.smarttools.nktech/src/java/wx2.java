import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.geometry.Offset;

public final class wx2
{
    public final String a;
    public final long b;
    public final long c;
    public final float d;
    
    public wx2(final String a, final long b, final long c, final float d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof wx2)) {
            return false;
        }
        final wx2 wx2 = (wx2)o;
        return kl1.b((Object)this.a, (Object)wx2.a) && Offset.equals-impl0(this.b, wx2.b) && Color.equals-impl0(this.c, wx2.c) && Float.compare(this.d, wx2.d) == 0;
    }
    
    @Override
    public final int hashCode() {
        return Float.hashCode(this.d) + ap.a(this.c, (Offset.hashCode-impl(this.b) + this.a.hashCode() * 31) * 31, 31);
    }
    
    @Override
    public final String toString() {
        final String string-impl = Offset.toString-impl(this.b);
        final String string-impl2 = Color.toString-impl(this.c);
        final StringBuilder sb = new StringBuilder("TextStamp(text=");
        te1.i(sb, this.a, ", position=", string-impl, ", color=");
        sb.append(string-impl2);
        sb.append(", fontSize=");
        sb.append(this.d);
        sb.append(")");
        return sb.toString();
    }
}
