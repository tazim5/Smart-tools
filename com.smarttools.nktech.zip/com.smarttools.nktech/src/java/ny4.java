import com.google.android.gms.internal.ads.zzbxc;
import android.os.IBinder;
import com.google.android.gms.ads.internal.client.zze;

public final class ny4 extends x04 implements nj4
{
    public a05 c;
    public y7 n;
    
    public final void B0(final int n) {
        monitorenter(this);
        Label_0025: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.B0(n);
                    monitorexit(this);
                    return;
                }
                break Label_0025;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void C() {
        monitorenter(this);
        Label_0026: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    ((y04)c).C();
                    monitorexit(this);
                    return;
                }
                break Label_0026;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void D(final y7 n) {
        synchronized (this) {
            this.n = n;
        }
    }
    
    public final void F0(final String s, final String s2) {
        monitorenter(this);
        Label_0028: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.F0(s, s2);
                    monitorexit(this);
                    return;
                }
                break Label_0028;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void G(final int n, String a) {
        synchronized (this) {
            final y7 n2 = this.n;
            if (n2 != null) {
                final y7 y7;
                monitorenter(y7 = n2);
                Label_0111: {
                    try {
                        if (n2.c) {
                            monitorexit(y7);
                            return;
                        }
                        n2.c = true;
                        String string;
                        if ((string = a) == null) {
                            a = ((tx4)n2.n).a;
                            final StringBuilder sb = new StringBuilder("Error from: ");
                            sb.append(a);
                            sb.append(", code: ");
                            sb.append(n);
                            string = sb.toString();
                        }
                        break Label_0111;
                    }
                    finally {
                        monitorexit(y7);
                        final String string;
                        n2.o(new zze(n, string, "undefined", (zze)null, (IBinder)null));
                        monitorexit(y7);
                    }
                }
            }
        }
    }
    
    public final void K(final zze zze) {
        synchronized (this) {
            final y7 n = this.n;
            if (n != null) {
                synchronized (n) {
                    if (!n.c) {
                        n.c = true;
                        n.o(zze);
                    }
                    monitorexit(n);
                }
            }
        }
    }
    
    public final void K0(final x54 x54) {
        monitorenter(this);
        Label_0027: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    ((y04)c).K0(x54);
                    monitorexit(this);
                    return;
                }
                break Label_0027;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void T0(final zzbxc zzbxc) {
        monitorenter(this);
        Label_0027: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    ((y04)c).T0(zzbxc);
                    monitorexit(this);
                    return;
                }
                break Label_0027;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void b(final int n) {
        monitorenter(this);
        Label_0025: {
            try {
                final y7 n2 = this.n;
                if (n2 != null) {
                    n2.j(n);
                    monitorexit(this);
                    return;
                }
                break Label_0025;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void d() {
        monitorenter(this);
        Label_0024: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.d();
                    monitorexit(this);
                    return;
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void g(final String s) {
        monitorenter(this);
        Label_0025: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.g(s);
                    monitorexit(this);
                    return;
                }
                break Label_0025;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void g1(final a05 c) {
        monitorenter(this);
        while (true) {
            try {
                this.c = c;
                monitorexit(this);
                return;
                monitorexit(this);
                throw;
            }
            finally {
                continue;
            }
            break;
        }
    }
    
    public final void p0(final zze zze) {
        monitorenter(this);
        Label_0025: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.p0(zze);
                    monitorexit(this);
                    return;
                }
                break Label_0025;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void x(final gv3 gv3, final String s) {
        monitorenter(this);
        monitorexit(this);
    }
    
    public final void zze() {
        monitorenter(this);
        Label_0024: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.zze();
                    monitorexit(this);
                    return;
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzf() {
        monitorenter(this);
        Label_0024: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.zzf();
                    monitorexit(this);
                    return;
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzm() {
        monitorenter(this);
        Label_0026: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    ((y04)c).zzm();
                    monitorexit(this);
                    return;
                }
                break Label_0026;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzn() {
        monitorenter(this);
        Label_0024: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.zzn();
                    monitorexit(this);
                    return;
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzo() {
        monitorenter(this);
        Label_0024: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.zzo();
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                while (true) {
                    final y7 n;
                    synchronized (n) {
                        ((m94)n.v).zzc((Object)null);
                        monitorexit(n);
                        return;
                    }
                    Label_0062: {
                        monitorexit(this);
                    }
                    return;
                    n = this.n;
                    iftrue(Label_0062:)(n == null);
                    continue;
                }
            }
        }
    }
    
    public final void zzp() {
        monitorenter(this);
        Label_0024: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.zzp();
                    monitorexit(this);
                    return;
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzu() {
        monitorenter(this);
        Label_0026: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    ((y04)c).zzu();
                    monitorexit(this);
                    return;
                }
                break Label_0026;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzv() {
        monitorenter(this);
        Label_0026: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    ((y04)c).zzv();
                    monitorexit(this);
                    return;
                }
                break Label_0026;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzx() {
        monitorenter(this);
        Label_0024: {
            try {
                final a05 c = this.c;
                if (c != null) {
                    c.zzx();
                    monitorexit(this);
                    return;
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
}
