public abstract class nm4 extends co3
{
}
