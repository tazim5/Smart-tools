import java.util.Iterator;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Collection;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.io.OutputStream;
import java.nio.charset.Charset;

public final class nk3 implements i32
{
    public static final Charset f;
    public static final u81 g;
    public static final u81 h;
    public static final xj3 i;
    public OutputStream a;
    public final HashMap b;
    public final HashMap c;
    public final xj3 d;
    public final kb2 e;
    
    static {
        f = Charset.forName("UTF-8");
        g = new u81("key", mb.l(f83.h((Class)kj3.class, new kg3(1))));
        h = new u81("value", mb.l(f83.h((Class)kj3.class, new kg3(2))));
        i = xj3.b;
    }
    
    public nk3(final ByteArrayOutputStream a, final HashMap b, final HashMap c, final xj3 d) {
        this.e = new kb2((i32)this, 1);
        this.a = (OutputStream)a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public static int f(final u81 u81) {
        final kj3 kj3 = (kj3)u81.a((Class)kj3.class);
        if (kj3 != null) {
            return ((kg3)kj3).a;
        }
        throw new RuntimeException("Field has no @Protobuf config");
    }
    
    public final i32 a(final u81 u81, final Object o) {
        this.b(u81, o, true);
        return (i32)this;
    }
    
    public final void b(final u81 d, final Object o, final boolean c) {
        if (o == null) {
            return;
        }
        if (o instanceof CharSequence) {
            final CharSequence charSequence = (CharSequence)o;
            if (c && charSequence.length() == 0) {
                return;
            }
            this.h(f(d) << 3 | 0x2);
            final byte[] bytes = charSequence.toString().getBytes(nk3.f);
            this.h(bytes.length);
            this.a.write(bytes);
        }
        else {
            if (o instanceof Collection) {
                final Iterator iterator = ((Collection)o).iterator();
                while (iterator.hasNext()) {
                    this.b(d, iterator.next(), false);
                }
                return;
            }
            if (o instanceof Map) {
                final Iterator iterator2 = ((Map)o).entrySet().iterator();
                while (iterator2.hasNext()) {
                    this.g((h32)nk3.i, d, iterator2.next(), false);
                }
                return;
            }
            if (o instanceof Double) {
                final double doubleValue = (double)o;
                if (!c || doubleValue != 0.0) {
                    this.h(f(d) << 3 | 0x1);
                    this.a.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(doubleValue).array());
                }
                return;
            }
            if (o instanceof Float) {
                final float floatValue = (float)o;
                if (!c || floatValue != 0.0f) {
                    this.h(f(d) << 3 | 0x5);
                    this.a.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(floatValue).array());
                }
                return;
            }
            if (o instanceof Number) {
                final long longValue = ((Number)o).longValue();
                if (!c || longValue != 0L) {
                    final kj3 kj3 = (kj3)d.a((Class)kj3.class);
                    if (kj3 == null) {
                        throw new RuntimeException("Field has no @Protobuf config");
                    }
                    this.h(((kg3)kj3).a << 3);
                    this.i(longValue);
                }
                return;
            }
            if (o instanceof Boolean) {
                this.c(d, ((boolean)o) ? 1 : 0, c);
                return;
            }
            if (o instanceof byte[]) {
                final byte[] array = (byte[])o;
                if (c && array.length == 0) {
                    return;
                }
                this.h(f(d) << 3 | 0x2);
                this.h(array.length);
                this.a.write(array);
            }
            else {
                final h32 h32 = (h32)this.b.get((Object)o.getClass());
                if (h32 != null) {
                    this.g(h32, d, o, c);
                    return;
                }
                final h63 h33 = (h63)this.c.get((Object)o.getClass());
                if (h33 != null) {
                    final kb2 e = this.e;
                    e.b = false;
                    e.d = d;
                    e.c = c;
                    ((n31)h33).a(o, (Object)e);
                    return;
                }
                if (o instanceof yh3) {
                    this.c(d, ((yh3)o).zza(), true);
                    return;
                }
                if (o instanceof Enum) {
                    this.c(d, ((Enum)o).ordinal(), true);
                    return;
                }
                this.g((h32)this.d, d, o, c);
            }
        }
    }
    
    public final void c(final u81 u81, final int n, final boolean b) {
        if (b && n == 0) {
            return;
        }
        final kj3 kj3 = (kj3)u81.a((Class)kj3.class);
        if (kj3 != null) {
            this.h(((kg3)kj3).a << 3);
            this.h(n);
            return;
        }
        throw new RuntimeException("Field has no @Protobuf config");
    }
    
    public final i32 e(final u81 u81, final long n) {
        if (n != 0L) {
            final kj3 kj3 = (kj3)u81.a((Class)kj3.class);
            if (kj3 == null) {
                throw new RuntimeException("Field has no @Protobuf config");
            }
            this.h(((kg3)kj3).a << 3);
            this.i(n);
        }
        return (i32)this;
    }
    
    public final void g(final h32 p0, final u81 p1, final Object p2, final boolean p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: iconst_1       
        //     5: invokespecial   cp1.<init>:(I)V
        //     8: astore          7
        //    10: aload           7
        //    12: lconst_0       
        //    13: putfield        cp1.n:J
        //    16: aload_0        
        //    17: getfield        nk3.a:Ljava/io/OutputStream;
        //    20: astore          8
        //    22: aload_0        
        //    23: aload           7
        //    25: putfield        nk3.a:Ljava/io/OutputStream;
        //    28: aload_1        
        //    29: aload_3        
        //    30: aload_0        
        //    31: invokeinterface n31.a:(Ljava/lang/Object;Ljava/lang/Object;)V
        //    36: aload_0        
        //    37: aload           8
        //    39: putfield        nk3.a:Ljava/io/OutputStream;
        //    42: aload           7
        //    44: getfield        cp1.n:J
        //    47: lstore          5
        //    49: aload           7
        //    51: invokevirtual   java/io/OutputStream.close:()V
        //    54: iload           4
        //    56: ifeq            67
        //    59: lload           5
        //    61: lconst_0       
        //    62: lcmp           
        //    63: ifne            67
        //    66: return         
        //    67: aload_0        
        //    68: aload_2        
        //    69: invokestatic    nk3.f:(Lu81;)I
        //    72: iconst_3       
        //    73: ishl           
        //    74: iconst_2       
        //    75: ior            
        //    76: invokevirtual   nk3.h:(I)V
        //    79: aload_0        
        //    80: lload           5
        //    82: invokevirtual   nk3.i:(J)V
        //    85: aload_1        
        //    86: aload_3        
        //    87: aload_0        
        //    88: invokeinterface n31.a:(Ljava/lang/Object;Ljava/lang/Object;)V
        //    93: return         
        //    94: astore_1       
        //    95: goto            107
        //    98: astore_1       
        //    99: aload_0        
        //   100: aload           8
        //   102: putfield        nk3.a:Ljava/io/OutputStream;
        //   105: aload_1        
        //   106: athrow         
        //   107: aload           7
        //   109: invokevirtual   java/io/OutputStream.close:()V
        //   112: goto            148
        //   115: astore_2       
        //   116: ldc_w           Ljava/lang/Throwable;.class
        //   119: ldc_w           "addSuppressed"
        //   122: iconst_1       
        //   123: anewarray       Ljava/lang/Class;
        //   126: dup            
        //   127: iconst_0       
        //   128: ldc_w           Ljava/lang/Throwable;.class
        //   131: aastore        
        //   132: invokevirtual   java/lang/Class.getDeclaredMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //   135: aload_1        
        //   136: iconst_1       
        //   137: anewarray       Ljava/lang/Object;
        //   140: dup            
        //   141: iconst_0       
        //   142: aload_2        
        //   143: aastore        
        //   144: invokevirtual   java/lang/reflect/Method.invoke:(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
        //   147: pop            
        //   148: aload_1        
        //   149: athrow         
        //   150: astore_2       
        //   151: goto            148
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                 
        //  -----  -----  -----  -----  ---------------------
        //  16     28     94     154    Any
        //  28     36     98     107    Any
        //  36     49     94     154    Any
        //  99     107    94     154    Any
        //  107    112    115    148    Any
        //  116    148    150    154    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0067:
        //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
        //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final void h(int n) {
        while ((n & 0xFFFFFF80) != 0x0L) {
            this.a.write((n & 0x7F) | 0x80);
            n >>>= 7;
        }
        this.a.write(n & 0x7F);
    }
    
    public final void i(long n) {
        while ((0xFFFFFFFFFFFFFF80L & n) != 0x0L) {
            this.a.write(((int)n & 0x7F) | 0x80);
            n >>>= 7;
        }
        this.a.write((int)n & 0x7F);
    }
}
