import android.view.WindowInsets;
import android.view.View;

public abstract class j73
{
    public static wa3 a(final View view) {
        final WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        final wa3 c = wa3.c((View)null, rootWindowInsets);
        final ua3 a = c.a;
        a.r(c);
        a.d(view.getRootView());
        return c;
    }
    
    public static int b(final View view) {
        return view.getScrollIndicators();
    }
    
    public static void c(final View view, final int scrollIndicators) {
        view.setScrollIndicators(scrollIndicators);
    }
    
    public static void d(final View view, final int n, final int n2) {
        view.setScrollIndicators(n, n2);
    }
}
