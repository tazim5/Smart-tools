import com.google.android.gms.internal.mlkit_language_id_common.zzhx;

public final class pt5
{
    public final Long a = (Long)ph5.a;
    public final zzhx b = (zzhx)ph5.b;
    public final Boolean c = (Boolean)ph5.c;
}
