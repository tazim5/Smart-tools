import androidx.compose.material3.MaterialTheme;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;

public final class rz implements nd1
{
    public static final rz P;
    public static final rz Q;
    public static final rz R;
    public static final rz S;
    public static final rz T;
    public static final rz U;
    public static final rz V;
    public static final rz W;
    public static final rz X;
    public static final rz Y;
    public static final rz Z;
    public static final rz a0;
    public static final rz b0;
    public static final rz c0;
    public static final rz d0;
    public static final rz e0;
    public static final rz f0;
    public static final rz g0;
    public static final rz h0;
    public static final rz i0;
    public static final rz j0;
    public static final rz k0;
    public static final rz l0;
    public static final rz m0;
    public static final rz n;
    public static final rz v;
    public static final rz w;
    public static final rz x;
    public static final rz y;
    public static final rz z;
    public final int c;
    
    public final Object invoke(final Object o, final Object o2) {
        switch (this.c) {
            default: {
                final Composer composer = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("\u20b9", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 6, 0, 131070);
                }
                return t43.a;
            }
            case 28: {
                final Composer composer2 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer2.getSkipping()) {
                    composer2.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Flat Discount Amount", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer2, 6, 0, 131070);
                }
                return t43.a;
            }
            case 27: {
                final Composer composer3 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer3.getSkipping()) {
                    composer3.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("\u20b9", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer3, 6, 0, 131070);
                }
                return t43.a;
            }
            case 26: {
                final Composer composer4 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer4.getSkipping()) {
                    composer4.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Original Price", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer4, 6, 0, 131070);
                }
                return t43.a;
            }
            case 25: {
                final Composer composer5 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer5.getSkipping()) {
                    composer5.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("%", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer5, 6, 0, 131070);
                }
                return t43.a;
            }
            case 24: {
                final Composer composer6 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer6.getSkipping()) {
                    composer6.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Discount Calculator", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer6, 6, 0, 131070);
                }
                return t43.a;
            }
            case 23: {
                final Composer composer7 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer7.getSkipping()) {
                    composer7.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Select Timezone", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer7, 6, 0, 131070);
                }
                return t43.a;
            }
            case 22: {
                final Composer composer8 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer8.getSkipping()) {
                    composer8.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Clock Settings", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer8, 6, 0, 131070);
                }
                return t43.a;
            }
            case 21: {
                final Composer composer9 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer9.getSkipping()) {
                    composer9.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Digital Clock", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer9, 6, 0, 131070);
                }
                return t43.a;
            }
            case 20: {
                final Composer composer10 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer10.getSkipping()) {
                    composer10.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Enter a word", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer10, 6, 0, 131070);
                }
                return t43.a;
            }
            case 19: {
                final Composer composer11 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer11.getSkipping()) {
                    composer11.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Dictionary", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer11, 6, 0, 131070);
                }
                return t43.a;
            }
            case 18: {
                final Composer composer12 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer12.getSkipping()) {
                    composer12.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Device Info", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer12, 6, 0, 131070);
                }
                return t43.a;
            }
            case 17: {
                final Composer composer13 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer13.getSkipping()) {
                    composer13.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Select Country", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer13, 6, 0, 131070);
                }
                return t43.a;
            }
            case 16: {
                final Composer composer14 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer14.getSkipping()) {
                    composer14.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Denomination Calculator", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer14, 6, 0, 131070);
                }
                return t43.a;
            }
            case 15: {
                final Composer composer15 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer15.getSkipping()) {
                    composer15.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("No results found", (Modifier)null, MaterialTheme.INSTANCE.getColorScheme(composer15, MaterialTheme.$stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer15, 6, 0, 131066);
                }
                return t43.a;
            }
            case 14: {
                final Composer composer16 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer16.getSkipping()) {
                    composer16.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Search currency...", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer16, 6, 0, 131070);
                }
                return t43.a;
            }
            case 13: {
                final Composer composer17 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer17.getSkipping()) {
                    composer17.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("No results found", (Modifier)null, MaterialTheme.INSTANCE.getColorScheme(composer17, MaterialTheme.$stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer17, 6, 0, 131066);
                }
                return t43.a;
            }
            case 12: {
                final Composer composer18 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer18.getSkipping()) {
                    composer18.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Search currency...", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer18, 6, 0, 131070);
                }
                return t43.a;
            }
            case 11: {
                final Composer composer19 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer19.getSkipping()) {
                    composer19.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Amount", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer19, 6, 0, 131070);
                }
                return t43.a;
            }
            case 10: {
                final Composer composer20 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer20.getSkipping()) {
                    composer20.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Currency Converter", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer20, 6, 0, 131070);
                }
                return t43.a;
            }
            case 9: {
                final Composer composer21 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer21.getSkipping()) {
                    composer21.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Start fresh? Current match will be lost.", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer21, 6, 0, 131070);
                }
                return t43.a;
            }
            case 8: {
                final Composer composer22 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer22.getSkipping()) {
                    composer22.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("New Match", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer22, 6, 0, 131070);
                }
                return t43.a;
            }
            case 7: {
                final Composer composer23 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer23.getSkipping()) {
                    composer23.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Team 2", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer23, 6, 0, 131070);
                }
                return t43.a;
            }
            case 6: {
                final Composer composer24 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer24.getSkipping()) {
                    composer24.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Team 1 (Bat First)", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer24, 6, 0, 131070);
                }
                return t43.a;
            }
            case 5: {
                final Composer composer25 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2) {
                    if (composer25.getSkipping()) {
                        composer25.skipToGroupEnd();
                    }
                }
                return t43.a;
            }
            case 4: {
                final Composer composer26 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer26.getSkipping()) {
                    composer26.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Purchase Failed", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer26, 6, 0, 131070);
                }
                return t43.a;
            }
            case 3: {
                final Composer composer27 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer27.getSkipping()) {
                    composer27.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Your credits have been added successfully. You can now use them in any AI tool.", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer27, 6, 0, 131070);
                }
                return t43.a;
            }
            case 2: {
                final Composer composer28 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer28.getSkipping()) {
                    composer28.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Purchase Successful", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer28, 6, 0, 131070);
                }
                return t43.a;
            }
            case 1: {
                final Composer composer29 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer29.getSkipping()) {
                    composer29.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("CPU Info", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer29, 6, 0, 131070);
                }
                return t43.a;
            }
            case 0: {
                final Composer composer30 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer30.getSkipping()) {
                    composer30.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g("Compass", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer30, 6, 0, 131070);
                }
                return t43.a;
            }
        }
    }
}
