import androidx.compose.ui.graphics.Color;

public final class is
{
    public final long a;
    public final String b;
    
    public is(final String b, final long a) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof is)) {
            return false;
        }
        final is is = (is)o;
        return Color.equals-impl0(this.a, is.a) && kl1.b(this.b, is.b);
    }
    
    @Override
    public final int hashCode() {
        return this.b.hashCode() + Color.hashCode-impl(this.a) * 31;
    }
    
    @Override
    public final String toString() {
        return ap.h(vo2.j("ColorItem(color=", Color.toString-impl(this.a), ", hex="), this.b, ")");
    }
}
