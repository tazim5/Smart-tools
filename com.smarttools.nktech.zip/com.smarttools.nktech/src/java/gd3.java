import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable$ConstantState;

public final class gd3 extends Drawable$ConstantState
{
    public int a;
    public int b;
    
    public final int getChangingConfigurations() {
        return this.a;
    }
    
    public final Drawable newDrawable() {
        return (Drawable)new hd3(this);
    }
}
