import java.lang.ref.Reference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import android.util.SparseArray;
import java.lang.ref.WeakReference;
import android.os.Build$VERSION;
import android.view.KeyEvent;
import android.view.View;
import java.lang.reflect.Method;

public abstract class jw5
{
    public static boolean a;
    public static Method b;
    
    public static boolean a(View view, final KeyEvent keyEvent) {
        final Field a = q73.a;
        final int sdk_INT = Build$VERSION.SDK_INT;
        boolean b = false;
        if (sdk_INT < 28) {
            final ArrayList d = p73.d;
            final p73 p2 = (p73)view.getTag(2131230911);
            final Reference reference = null;
            Object o;
            if ((o = p2) == null) {
                o = new Object();
                ((p73)o).a = null;
                ((p73)o).b = null;
                ((p73)o).c = null;
                view.setTag(2131230911, o);
            }
            final WeakReference c = ((p73)o).c;
            if (c == null || ((Reference)c).get() != keyEvent) {
                ((p73)o).c = new WeakReference((Object)keyEvent);
                if (((p73)o).b == null) {
                    ((p73)o).b = new SparseArray();
                }
                final SparseArray b2 = ((p73)o).b;
                Object o2 = reference;
                if (keyEvent.getAction() == 1) {
                    final int indexOfKey = b2.indexOfKey(keyEvent.getKeyCode());
                    o2 = reference;
                    if (indexOfKey >= 0) {
                        o2 = b2.valueAt(indexOfKey);
                        b2.removeAt(indexOfKey);
                    }
                }
                Object o3;
                if ((o3 = o2) == null) {
                    o3 = b2.get(keyEvent.getKeyCode());
                }
                if (o3 != null) {
                    view = (View)((Reference)o3).get();
                    if (view != null && view.isAttachedToWindow()) {
                        final ArrayList list = (ArrayList)view.getTag(2131230912);
                        if (list != null) {
                            final int n = list.size() - 1;
                            if (n >= 0) {
                                list.get(n).getClass();
                                throw new ClassCastException();
                            }
                        }
                    }
                    b = true;
                }
            }
        }
        return b;
    }
}
