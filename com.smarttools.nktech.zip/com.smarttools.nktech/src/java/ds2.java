public final class ds2
{
    public final long a;
    public final long b;
    public final long c;
    public final float d;
    
    public ds2(final float d, final long a, final long b, final long c) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ds2)) {
            return false;
        }
        final ds2 ds2 = (ds2)o;
        return this.a == ds2.a && this.b == ds2.b && this.c == ds2.c && Float.compare(this.d, ds2.d) == 0;
    }
    
    @Override
    public final int hashCode() {
        return Float.hashCode(this.d) + (Long.hashCode(this.c) + (Long.hashCode(this.b) + Long.hashCode(this.a) * 31) * 31) * 31;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("StorageData(totalBytes=");
        sb.append(this.a);
        sb.append(", freeBytes=");
        sb.append(this.b);
        sb.append(", usedBytes=");
        sb.append(this.c);
        sb.append(", usagePercent=");
        sb.append(this.d);
        sb.append(")");
        return sb.toString();
    }
}
