public final class v34 extends go3 implements w34
{
}
