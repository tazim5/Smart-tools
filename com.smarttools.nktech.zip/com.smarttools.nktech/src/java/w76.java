import java.util.Comparator;
import java.util.Arrays;

public abstract class w76 implements h86
{
    public final pk4 a;
    public final int b;
    public final int[] c;
    public final ak3[] d;
    public int e;
    
    public w76(final pk4 a, final int[] array) {
        final int length = array.length;
        aq3.k(length > 0);
        a.getClass();
        this.a = a;
        this.b = length;
        this.d = new ak3[length];
        int n = 0;
        ak3[] c;
        while (true) {
            final int length2 = array.length;
            c = a.c;
            if (n >= length2) {
                break;
            }
            this.d[n] = c[array[n]];
            ++n;
        }
        Arrays.sort((Object[])this.d, (Comparator)m74.v);
        this.c = new int[this.b];
        int i = 0;
    Label_0107:
        while (i < this.b) {
            final int[] c2 = this.c;
            final ak3 ak3 = this.d[i];
            while (true) {
                for (int j = 0; j <= 0; ++j) {
                    if (ak3 == c[j]) {
                        c2[i] = j;
                        ++i;
                        continue Label_0107;
                    }
                }
                int j = -1;
                continue;
            }
        }
    }
    
    @Override
    public final ak3 a(final int n) {
        return this.d[n];
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o != null) {
            if (this.getClass() == o.getClass()) {
                final w76 w76 = (w76)o;
                if (this.a.equals((Object)w76.a) && Arrays.equals(this.c, w76.c)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        final int e = this.e;
        if (e == 0) {
            return this.e = Arrays.hashCode(this.c) + System.identityHashCode((Object)this.a) * 31;
        }
        return e;
    }
    
    @Override
    public final int zza() {
        return this.c[0];
    }
    
    @Override
    public final int zzb(final int n) {
        for (int i = 0; i < this.b; ++i) {
            if (this.c[i] == n) {
                return i;
            }
        }
        return -1;
    }
    
    @Override
    public final int zzc() {
        return this.c.length;
    }
    
    @Override
    public final pk4 zze() {
        return this.a;
    }
}
