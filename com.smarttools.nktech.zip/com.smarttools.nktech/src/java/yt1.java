import androidx.compose.runtime.IntState;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Composer$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.unit.Dp;
import com.smarttools.nktech.features.tools.games.MathDifficulty;
import com.smarttools.nktech.features.tools.games.k;
import kotlin.NoWhenBranchMatchedException;
import com.smarttools.nktech.features.tools.games.MathGameState;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.MutableIntState;

public final class yt1 implements od1
{
    public final MutableIntState P;
    public final MutableState Q;
    public final MutableState R;
    public final MutableState S;
    public final int c;
    public final long n;
    public final MutableState v;
    public final MutableState w;
    public final MutableIntState x;
    public final MutableIntState y;
    public final MutableIntState z;
    
    public yt1(final int c, final long n, final MutableState v, final MutableState w, final MutableIntState x, final MutableIntState y, final MutableIntState z, final MutableIntState p11, final MutableState q, final MutableState r, final MutableState s) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p11;
        this.Q = q;
        this.R = r;
        this.S = s;
    }
    
    public final Object invoke(Object o, Object o2, final Object o3) {
        final PaddingValues paddingValues = (PaddingValues)o;
        final Composer composer = (Composer)o2;
        int intValue;
        final int n = intValue = ((Number)o3).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), paddingValues);
            final Arrangement$Vertical top = Arrangement.INSTANCE.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default(ColumnScope.weight$default((ColumnScope)ColumnScopeInstance.INSTANCE, (Modifier)companion, 1.0f, false, 2, (Object)null), 0.0f, 1, (Object)null);
            final MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getTopStart(), false);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, maybeCachedBoxMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final BoxScopeInstance instance = BoxScopeInstance.INSTANCE;
            final MutableState v = this.v;
            final int ordinal = ((Enum)((State)v).getValue()).ordinal();
            final MutableState w = this.w;
            final MutableIntState z = this.z;
            final MutableState r = this.R;
            final int c = this.c;
            final long n3 = this.n;
            final MutableIntState x = this.x;
            final MutableIntState y = this.y;
            final MutableIntState p3 = this.P;
            final MutableState q = this.Q;
            final MutableState s = this.S;
            if (ordinal != 0) {
                if (ordinal != 1) {
                    if (ordinal != 2) {
                        composer.startReplaceGroup(1851809160);
                        composer.endReplaceGroup();
                        throw new NoWhenBranchMatchedException();
                    }
                    composer.startReplaceGroup(1851821945);
                    final int intValue2 = ((IntState)x).getIntValue();
                    final int intValue3 = ((IntState)y).getIntValue();
                    composer.startReplaceGroup(1851823575);
                    final boolean changed = composer.changed(c);
                    o2 = composer.rememberedValue();
                    if (changed || (o = o2) == Composer.Companion.getEmpty()) {
                        o = new xt1(c, x, y, z, p3, q, r, w, s, v, 1);
                        composer.updateRememberedValue(o);
                    }
                    final id1 id1 = (id1)o;
                    o2 = fe2.c(composer, 1851824138);
                    if ((o = o2) == Composer.Companion.getEmpty()) {
                        o = new ff1(v, 24);
                        composer.updateRememberedValue(o);
                    }
                    final id1 id2 = (id1)o;
                    composer.endReplaceGroup();
                    k.f(intValue2, intValue3, id1, id2, n3, SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), composer, 1597824);
                    composer.endReplaceGroup();
                }
                else {
                    composer.startReplaceGroup(1851815307);
                    final eu1 eu1 = (eu1)((State)s).getValue();
                    composer.startReplaceGroup(1851816156);
                    o2 = composer.rememberedValue();
                    if ((o = o2) == Composer.Companion.getEmpty()) {
                        o = new vi(s, r, x, y, 1);
                        composer.updateRememberedValue(o);
                    }
                    final jd1 jd1 = (jd1)o;
                    composer.endReplaceGroup();
                    k.e(eu1, jd1, ((IntState)z).getIntValue(), ((IntState)p3).getIntValue(), c, (Boolean)((State)r).getValue(), n3, SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), composer, 100666424);
                    composer.endReplaceGroup();
                }
            }
            else {
                composer.startReplaceGroup(1851810634);
                final MathDifficulty mathDifficulty = (MathDifficulty)((State)w).getValue();
                composer.startReplaceGroup(1851811291);
                o2 = composer.rememberedValue();
                final Composer$Companion companion4 = Composer.Companion;
                if ((o = o2) == companion4.getEmpty()) {
                    o = new hm1(w, 15);
                    composer.updateRememberedValue(o);
                }
                final jd1 jd2 = (jd1)o;
                composer.endReplaceGroup();
                composer.startReplaceGroup(1851811959);
                final boolean changed2 = composer.changed(c);
                o2 = composer.rememberedValue();
                if (changed2 || (o = o2) == companion4.getEmpty()) {
                    o = new xt1(c, x, y, z, p3, q, r, w, s, v, 0);
                    composer.updateRememberedValue(o);
                }
                final id1 id3 = (id1)o;
                composer.endReplaceGroup();
                k.c(mathDifficulty, jd2, id3, n3, SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), composer, 24624);
                composer.endReplaceGroup();
            }
            composer.endNode();
            b02.a(PaddingKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), 0.0f, Dp.constructor-impl((float)16), 0.0f, 0.0f, 13, (Object)null), composer, 6);
            composer.endNode();
        }
        return t43.a;
    }
}
