import androidx.compose.runtime.State;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Modifier$Companion;
import java.util.TimeZone;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.material3.MaterialTheme;
import java.util.Arrays;
import com.smarttools.nktech.features.tools.datetime.a;
import androidx.compose.foundation.layout.AspectRatioKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.runtime.MutableState;
import java.util.Calendar;

public final class c7 implements od1
{
    public final int c;
    public final int n;
    public final int v;
    public final Calendar w;
    public final MutableState x;
    
    public c7(final int c, final int n, final int v, final Calendar w, final MutableState x) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final PaddingValues paddingValues = (PaddingValues)o;
        final Composer composer = (Composer)o2;
        int intValue;
        final int n = intValue = ((Number)o3).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), paddingValues);
            final float n3 = 16;
            final Modifier verticalScroll$default = ScrollKt.verticalScroll$default(PaddingKt.padding-3ABfNKs(padding, Dp.constructor-impl(n3)), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.Companion.getCenterHorizontally(), composer, 48);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, verticalScroll$default);
            final ComposeUiNode$Companion companion2 = ComposeUiNode.Companion;
            final id1 constructor = companion2.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion2, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion2.getSetModifier());
            final ColumnScopeInstance instance = ColumnScopeInstance.INSTANCE;
            final Modifier aspectRatio$default = AspectRatioKt.aspectRatio$default(SizeKt.fillMaxWidth((Modifier)companion, 0.85f), 1.0f, false, 2, (Object)null);
            final int c = this.c;
            final int n4 = this.n;
            final int v = this.v;
            a.c(c, n4, v, aspectRatio$default, composer, 3072);
            ap.l((float)24, companion, composer, 6);
            final String format = String.format("%02d:%02d:%02d", Arrays.copyOf(new Object[] { this.w.get(11), n4, v }, 3));
            final MaterialTheme instance2 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            TextKt.Text--4IGK_g(format, (Modifier)null, instance2.getColorScheme(composer, $stable).getOnSurface-0d7_KjU(), 0L, (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance2.getTypography(composer, $stable).getHeadlineMedium(), composer, 196608, 0, 65498);
            ap.l((float)8, companion, composer, 6);
            TextKt.Text--4IGK_g(((TimeZone)((State)this.x).getValue()).getDisplayName(), (Modifier)null, instance2.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance2.getTypography(composer, $stable).getBodyMedium(), composer, 0, 0, 65530);
            b02.a(PaddingKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), 0.0f, Dp.constructor-impl(n3), 0.0f, 0.0f, 13, (Object)null), composer, 6);
            composer.endNode();
        }
        return t43.a;
    }
}
