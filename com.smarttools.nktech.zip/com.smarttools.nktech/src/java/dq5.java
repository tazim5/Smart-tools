public final class dq5 implements hq5
{
    public final hq5[] a;
    
    public dq5(final hq5... a) {
        this.a = a;
    }
    
    @Override
    public final qq5 c(final Class clazz) {
        for (int i = 0; i < 2; ++i) {
            final hq5 hq5 = this.a[i];
            if (hq5.d(clazz)) {
                return hq5.c(clazz);
            }
        }
        throw new UnsupportedOperationException("No factory is available for message type: ".concat(clazz.getName()));
    }
    
    @Override
    public final boolean d(final Class clazz) {
        for (int i = 0; i < 2; ++i) {
            if (this.a[i].d(clazz)) {
                return true;
            }
        }
        return false;
    }
}
