import java.util.Collection;
import kotlin.text.b;
import java.util.NoSuchElementException;
import java.util.ArrayList;
import java.util.Collections;
import kotlin.collections.EmptyList;
import java.util.List;
import java.util.Arrays;

public abstract class wa
{
    public static boolean a(final Object[] array, final Object o) {
        return t(array, o) >= 0;
    }
    
    public static boolean b(final Object[] array, final Object[] array2) {
        if (array == array2) {
            return true;
        }
        if (array != null && array2 != null && array.length == array2.length) {
            for (int length = array.length, i = 0; i < length; ++i) {
                final Object o = array[i];
                final Object obj = array2[i];
                if (o != obj) {
                    if (o == null || obj == null) {
                        return false;
                    }
                    if (o instanceof Object[] && obj instanceof Object[]) {
                        if (!b((Object[])o, (Object[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof byte[] && obj instanceof byte[]) {
                        if (!Arrays.equals((byte[])o, (byte[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof short[] && obj instanceof short[]) {
                        if (!Arrays.equals((short[])o, (short[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof int[] && obj instanceof int[]) {
                        if (!Arrays.equals((int[])o, (int[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof long[] && obj instanceof long[]) {
                        if (!Arrays.equals((long[])o, (long[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof float[] && obj instanceof float[]) {
                        if (!Arrays.equals((float[])o, (float[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof double[] && obj instanceof double[]) {
                        if (!Arrays.equals((double[])o, (double[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof char[] && obj instanceof char[]) {
                        if (!Arrays.equals((char[])o, (char[])obj)) {
                            return false;
                        }
                    }
                    else if (o instanceof boolean[] && obj instanceof boolean[]) {
                        if (!Arrays.equals((boolean[])o, (boolean[])obj)) {
                            return false;
                        }
                    }
                    else if (!o.equals(obj)) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    public static void c(final int n, final int n2, final int n3, final int[] array, final int[] array2) {
        System.arraycopy((Object)array, n2, (Object)array2, n, n3 - n2);
    }
    
    public static void d(final char[] array, final char[] array2, final int n, final int n2, final int n3) {
        System.arraycopy((Object)array, n2, (Object)array2, n, n3 - n2);
    }
    
    public static void e(final float[] array, final float[] array2, final int n, final int n2, final int n3) {
        System.arraycopy((Object)array, n2, (Object)array2, n, n3 - n2);
    }
    
    public static void f(final Object[] array, final Object[] array2, final int n, final int n2, final int n3) {
        System.arraycopy((Object)array, n2, (Object)array2, n, n3 - n2);
    }
    
    public static void g(int n, int length, final int n2, final int[] array, final int[] array2) {
        if ((n2 & 0x2) != 0x0) {
            n = 0;
        }
        if ((n2 & 0x8) != 0x0) {
            length = array.length;
        }
        System.arraycopy((Object)array, 0, (Object)array2, n, length);
    }
    
    public static void h(final byte[] array, final byte[] array2, final int n, final int n2) {
        System.arraycopy((Object)array, n, (Object)array2, 0, n2 - n);
    }
    
    public static void i(final float[] array, int length, final float[] array2, final int n) {
        if ((n & 0x8) != 0x0) {
            length = array.length;
        }
        System.arraycopy((Object)array, 0, (Object)array2, 0, length);
    }
    
    public static void j(final Object[] array, final Object[] array2, int n, int n2, int length, final int n3) {
        if ((n3 & 0x2) != 0x0) {
            n = 0;
        }
        if ((n3 & 0x4) != 0x0) {
            n2 = 0;
        }
        if ((n3 & 0x8) != 0x0) {
            length = array.length;
        }
        System.arraycopy((Object)array, n2, (Object)array2, n, length - n2);
    }
    
    public static Object[] k(final Object[] array, final int n, final int n2) {
        l(n2, array.length);
        return Arrays.copyOfRange(array, n, n2);
    }
    
    public static final void l(final int n, final int n2) {
        if (n <= n2) {
            return;
        }
        throw new IndexOutOfBoundsException(xg.f("toIndex (", n, ") is greater than size (", n2, ")."));
    }
    
    public static List m(int i, final Object[] array) {
        if (i < 0) {
            throw new IllegalArgumentException(xg.e(i, "Requested element count ", " is less than zero.").toString());
        }
        if ((i = array.length - i) < 0) {
            i = 0;
        }
        if (i >= 0) {
            Object o;
            if (i == 0) {
                o = EmptyList.c;
            }
            else {
                final int length = array.length;
                if (i >= length) {
                    o = x(array);
                }
                else if (i == 1) {
                    o = Collections.singletonList(array[length - 1]);
                }
                else {
                    final ArrayList list = new ArrayList(i);
                    for (i = length - i; i < length; ++i) {
                        list.add(array[i]);
                    }
                    o = list;
                }
            }
            return (List)o;
        }
        throw new IllegalArgumentException(xg.e(i, "Requested element count ", " is less than zero.").toString());
    }
    
    public static void n(final int[] array, final int n, int length, final int n2) {
        if ((n2 & 0x4) != 0x0) {
            length = array.length;
        }
        Arrays.fill(array, 0, length, n);
    }
    
    public static void o(final long[] array) {
        Arrays.fill(array, 0, array.length, -9187201950435737472L);
    }
    
    public static void p(final Object[] array) {
        Arrays.fill(array, 0, array.length, (Object)null);
    }
    
    public static ArrayList q(final Object[] array) {
        final ArrayList list = new ArrayList();
        for (final Object o : array) {
            if (o != null) {
                list.add(o);
            }
        }
        return list;
    }
    
    public static Object r(final Object[] array) {
        if (array.length != 0) {
            return array[0];
        }
        throw new NoSuchElementException("Array is empty.");
    }
    
    public static cl1 s(final int[] array) {
        return (cl1)new al1(0, array.length - 1, 1);
    }
    
    public static int t(final Object[] array, final Object o) {
        final int n = 0;
        int i = 0;
        if (o == null) {
            while (i < array.length) {
                if (array[i] == null) {
                    return i;
                }
                ++i;
            }
        }
        else {
            for (int length = array.length, j = n; j < length; ++j) {
                if (o.equals(array[j])) {
                    return j;
                }
            }
        }
        return -1;
    }
    
    public static String u(final byte[] array, final String s, String s2, String s3, jd1 jd1, int n) {
        if ((n & 0x2) != 0x0) {
            s2 = "";
        }
        if ((n & 0x4) != 0x0) {
            s3 = "";
        }
        if ((n & 0x20) != 0x0) {
            jd1 = null;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append((CharSequence)s2);
        final int length = array.length;
        int i = 0;
        n = 0;
        while (i < length) {
            final byte b = array[i];
            if (++n > 1) {
                sb.append((CharSequence)s);
            }
            if (jd1 != null) {
                sb.append((CharSequence)jd1.invoke((Object)b));
            }
            else {
                sb.append((CharSequence)String.valueOf((int)b));
            }
            ++i;
        }
        sb.append((CharSequence)s3);
        return sb.toString();
    }
    
    public static String v(final Object[] array, final String s, jd1 jd1, int i) {
        if ((i & 0x20) != 0x0) {
            jd1 = null;
        }
        final StringBuilder sb = new StringBuilder();
        sb.append((CharSequence)"");
        final int length = array.length;
        i = 0;
        int n = 0;
        while (i < length) {
            final Object o = array[i];
            if (++n > 1) {
                sb.append((CharSequence)s);
            }
            b.a(sb, o, jd1);
            ++i;
        }
        sb.append((CharSequence)"");
        return sb.toString();
    }
    
    public static int w(final int[] array) {
        if (array.length != 0) {
            final int n = array[0];
            final int length = array.length;
            int n2 = 1;
            final int n3 = length - 1;
            int n4 = n;
            if (1 <= n3) {
                int n5 = n;
                while (true) {
                    final int n6 = array[n2];
                    int n7 = n5;
                    if (n5 < n6) {
                        n7 = n6;
                    }
                    n4 = n7;
                    if (n2 == n3) {
                        break;
                    }
                    ++n2;
                    n5 = n7;
                }
            }
            return n4;
        }
        throw new NoSuchElementException();
    }
    
    public static List x(final Object[] array) {
        final int length = array.length;
        Object o;
        if (length != 0) {
            if (length != 1) {
                o = new ArrayList((Collection)new ka(array, false));
            }
            else {
                o = Collections.singletonList(array[0]);
            }
        }
        else {
            o = EmptyList.c;
        }
        return (List)o;
    }
    
    public static Float[] y(final float[] array) {
        final Float[] array2 = new Float[array.length];
        for (int length = array.length, i = 0; i < length; ++i) {
            array2[i] = array[i];
        }
        return array2;
    }
}
