public interface oo3
{
    void h(final no3 p0);
}
