import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.foundation.lazy.grid.LazyGridState;
import androidx.compose.foundation.lazy.grid.GridCells;
import androidx.compose.foundation.lazy.grid.LazyGridDslKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.foundation.lazy.grid.GridCells$Fixed;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import com.smarttools.nktech.b;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.snapshots.SnapshotStateMap;
import java.util.Map;
import java.util.List;
import android.content.Context;
import androidx.compose.runtime.State;
import com.smarttools.nktech.core.data.datastore.r;

public final class gq implements od1
{
    public final r P;
    public final State Q;
    public final dq0 R;
    public final Context S;
    public final List c;
    public final Map n;
    public final SnapshotStateMap v;
    public final MutableState w;
    public final boolean x;
    public final boolean y;
    public final b z;
    
    public gq(final List c, final Map n, final SnapshotStateMap v, final MutableState w, final boolean x, final boolean y, final b z, final r p11, final State q, final dq0 r, final Context s) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p11;
        this.Q = q;
        this.R = r;
        this.S = s;
    }
    
    public final Object invoke(final Object o, Object o2, final Object o3) {
        final PaddingValues paddingValues = (PaddingValues)o;
        final Composer composer = (Composer)o2;
        int intValue;
        final int n = intValue = ((Number)o3).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            o2 = new GridCells$Fixed(4);
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), paddingValues);
            final float n3 = 8;
            final PaddingValues paddingValues-0680j_4 = PaddingKt.PaddingValues-0680j_4(Dp.constructor-impl(n3));
            final Arrangement instance = Arrangement.INSTANCE;
            LazyGridDslKt.LazyVerticalGrid((GridCells)o2, padding, (LazyGridState)null, paddingValues-0680j_4, false, (Arrangement$Vertical)instance.spacedBy-0680j_4(Dp.constructor-impl(n3)), (Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl(n3)), (FlingBehavior)null, false, (jd1)new dq(this.c, this.n, this.v, this.w, this.x, this.y, this.z, this.P, this.Q, this.R, this.S), composer, 1772544, 404);
        }
        return t43.a;
    }
}
