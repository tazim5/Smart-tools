public final class qe2
{
    public final dc2 a;
    
    public qe2(final dc2 a) {
        this.a = a;
    }
}
