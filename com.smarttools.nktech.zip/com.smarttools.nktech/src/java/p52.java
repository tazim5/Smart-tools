import android.hardware.camera2.params.OutputConfiguration;

public class p52 extends n52
{
    @Override
    public Object c() {
        final Object a = super.a;
        jy5.b(a instanceof o52);
        return ((o52)a).a;
    }
    
    @Override
    public final String d() {
        return null;
    }
    
    @Override
    public void g(final long b) {
        ((o52)super.a).b = b;
    }
    
    @Override
    public final void h(final String physicalCameraId) {
        ((OutputConfiguration)this.c()).setPhysicalCameraId(physicalCameraId);
    }
}
