import com.google.android.gms.internal.ads.n2;
import com.google.android.gms.ads.internal.util.zze;

public final class pz3 implements p94, o94
{
    public final wz3 c;
    public final o85 n;
    public final xz3 v;
    
    public void zza() {
        zze.zza("loadNewJavascriptEngine (failure): Trying to acquire lock");
        final Object a;
        monitorenter(a = this.v.a);
        Label_0109: {
            try {
                zze.zza("loadNewJavascriptEngine (failure): Lock acquired");
                this.v.h = 1;
                zze.zza("Failed loading new engine. Marking new engine destroyable.");
                this.c.f();
                if (!(boolean)ws3.d.k()) {
                    break Label_0109;
                }
                final n2 e = this.v.e;
                if (e != null) {
                    final o85 n = this.n;
                    n.c("Failed loading new engine");
                    n.zzf(false);
                    e.b(n.zzl());
                }
                break Label_0109;
            }
            finally {
                monitorexit(a);
                monitorexit(a);
                zze.zza("loadNewJavascriptEngine (failure): Lock released");
            }
        }
    }
}
