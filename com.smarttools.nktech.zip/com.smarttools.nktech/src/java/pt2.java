import android.util.Size;
import android.hardware.camera2.params.StreamConfigurationMap;

public abstract class pt2
{
    public static Size[] a(final StreamConfigurationMap streamConfigurationMap, final int n) {
        return streamConfigurationMap.getHighResolutionOutputSizes(n);
    }
}
