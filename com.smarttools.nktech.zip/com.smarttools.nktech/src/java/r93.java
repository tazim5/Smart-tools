public final class r93
{
    public final boolean a;
    public final String b;
    public final String c;
    public final String d;
    public final int e;
    public final int f;
    public final int g;
    public final int h;
    
    public r93(final boolean a, final String b, final String c, final String d, final int e, final int f, final int g, final int h) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof r93)) {
            return false;
        }
        final r93 r93 = (r93)o;
        return this.a == r93.a && this.b.equals(r93.b) && this.c.equals(r93.c) && this.d.equals(r93.d) && this.e == r93.e && this.f == r93.f && this.g == r93.g && this.h == r93.h;
    }
    
    @Override
    public final int hashCode() {
        return Integer.hashCode(this.h) + gs1.b(this.g, gs1.b(this.f, gs1.b(this.e, vo2.c(vo2.c(vo2.c(Boolean.hashCode(this.a) * 31, 31, this.b), 31, this.c), 31, this.d), 31), 31), 31);
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("WifiData(isConnected=");
        sb.append(this.a);
        sb.append(", ssid=");
        sb.append(this.b);
        sb.append(", bssid=");
        sb.append(this.c);
        sb.append(", ipAddress=");
        sb.append(this.d);
        sb.append(", linkSpeed=");
        sb.append(this.e);
        sb.append(", rssi=");
        sb.append(this.f);
        sb.append(", frequency=");
        sb.append(this.g);
        sb.append(", signalStrength=");
        return mb.h(sb, this.h, ")");
    }
}
