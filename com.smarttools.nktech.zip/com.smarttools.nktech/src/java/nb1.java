import androidx.fragment.app.l;
import java.util.concurrent.atomic.AtomicReference;

public final class nb1
{
    public final td1 a;
    public final AtomicReference b;
    public final z2 c;
    public final y2 d;
    public final l e;
    
    public nb1(final l e, final td1 a, final AtomicReference b, final z2 c, final y2 d) {
        this.e = e;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
}
