import androidx.compose.runtime.State;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.material.icons.filled.FullscreenKt;
import androidx.compose.material.icons.filled.FullscreenExitKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableState;

public final class cx1 implements nd1
{
    public final MutableState c;
    
    public cx1(final MutableState c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            ImageVector imageVector;
            if (((State)this.c).getValue()) {
                imageVector = FullscreenExitKt.getFullscreenExit(Icons.INSTANCE.getDefault());
            }
            else {
                imageVector = FullscreenKt.getFullscreen(Icons.INSTANCE.getDefault());
            }
            IconKt.Icon-ww6aTOc(imageVector, "Toggle Fullscreen", (Modifier)null, Color.Companion.getWhite-0d7_KjU(), composer, 3120, 4);
        }
        return t43.a;
    }
}
