import java.util.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import android.content.Intent;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import java.util.Objects;
import android.content.Context;
import android.os.PowerManager$WakeLock;

public final class rv0 implements db3, h41, yb3
{
    public static final int R = 0;
    public PowerManager$WakeLock P;
    public boolean Q;
    public final Context c;
    public final int n;
    public final String v;
    public final wu2 w;
    public final eb3 x;
    public final Object y;
    public int z;
    
    static {
        fs1.g("DelayMetCommandHandler");
    }
    
    public rv0(final Context c, final int n, final String v, final wu2 w) {
        this.c = c;
        this.n = n;
        this.w = w;
        this.v = v;
        this.x = new eb3(c, (hw2)w.n, (db3)this);
        this.Q = false;
        this.z = 0;
        this.y = new Object();
    }
    
    public final void a() {
        final Object y;
        monitorenter(y = this.y);
        Label_0080: {
            try {
                this.x.c();
                this.w.v.b(this.v);
                final PowerManager$WakeLock p = this.P;
                if (p != null && p.isHeld()) {
                    final fs1 e = fs1.e();
                    Objects.toString((Object)this.P);
                    e.a(new Throwable[0]);
                    this.P.release();
                }
                break Label_0080;
            }
            finally {
                monitorexit(y);
                monitorexit(y);
            }
        }
    }
    
    public final void b(final String s, final boolean b) {
        fs1.e().a(new Throwable[0]);
        this.a();
        final int n = this.n;
        final wu2 w = this.w;
        final Context c = this.c;
        if (b) {
            w.e((Runnable)new l9((Object)w, (Object)at.c(c, this.v), n, 3));
        }
        if (this.Q) {
            final Intent intent = new Intent(c, (Class)SystemAlarmService.class);
            intent.setAction("ACTION_CONSTRAINTS_CHANGED");
            w.e((Runnable)new l9((Object)w, (Object)intent, n, 3));
        }
    }
    
    public final void c() {
        final StringBuilder sb = new StringBuilder();
        final String v = this.v;
        sb.append(v);
        sb.append(" (");
        this.P = v83.a(this.c, mb.h(sb, this.n, ")"));
        final fs1 e = fs1.e();
        Objects.toString((Object)this.P);
        e.a(new Throwable[0]);
        this.P.acquire();
        final ub3 h = this.w.x.c.n().h(v);
        if (h == null) {
            this.e();
            return;
        }
        if (!(this.Q = h.b())) {
            fs1.e().a(new Throwable[0]);
            this.f(Collections.singletonList((Object)v));
        }
        else {
            this.x.b((Collection)Collections.singletonList((Object)h));
        }
    }
    
    public final void d(final ArrayList list) {
        this.e();
    }
    
    public final void e() {
        final Object y;
        monitorenter(y = this.y);
        Label_0173: {
            try {
                if (this.z >= 2) {
                    break Label_0173;
                }
                this.z = 2;
                fs1.e().a(new Throwable[0]);
                final Context c = this.c;
                final String v = this.v;
                final Intent intent = new Intent(c, (Class)SystemAlarmService.class);
                intent.setAction("ACTION_STOP_WORK");
                intent.putExtra("KEY_WORKSPEC_ID", v);
                final wu2 w = this.w;
                w.e((Runnable)new l9((Object)w, (Object)intent, this.n, 3));
                if (this.w.w.d(this.v)) {
                    fs1.e().a(new Throwable[0]);
                    final Intent c2 = at.c(this.c, this.v);
                    final wu2 w2 = this.w;
                    w2.e((Runnable)new l9((Object)w2, (Object)c2, this.n, 3));
                    break Label_0173;
                }
                break Label_0173;
            }
            finally {
                monitorexit(y);
                fs1.e().a(new Throwable[0]);
                break Label_0173;
                fs1.e().a(new Throwable[0]);
                monitorexit(y);
            }
        }
    }
    
    public final void f(final List list) {
        if (!list.contains((Object)this.v)) {
            return;
        }
        final Object y;
        monitorenter(y = this.y);
        Label_0092: {
            while (true) {
                Label_0085: {
                    try {
                        if (this.z != 0) {
                            break Label_0092;
                        }
                        this.z = 1;
                        fs1.e().a(new Throwable[0]);
                        if (this.w.w.g(this.v, null)) {
                            this.w.v.a(this.v, this);
                            break Label_0102;
                        }
                        break Label_0085;
                    }
                    finally {
                        monitorexit(y);
                        fs1.e().a(new Throwable[0]);
                        monitorexit(y);
                        return;
                        this.a();
                        continue;
                    }
                }
                break;
            }
        }
    }
}
