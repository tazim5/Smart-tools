import kotlinx.coroutines.c;
import kotlinx.coroutines.TimeoutCancellationException;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.ContinuationImpl;

public final class rz2 extends jj2 implements Runnable
{
    public final long x;
    
    public rz2(final long x, final ContinuationImpl continuationImpl) {
        super(((Continuation)continuationImpl).getContext(), (Continuation)continuationImpl);
        this.x = x;
    }
    
    public final String O() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.O());
        sb.append("(timeMillis=");
        sb.append(this.x);
        sb.append(')');
        return sb.toString();
    }
    
    public final void run() {
        fv5.b(((z)this).v);
        ((c)this).t((Object)new TimeoutCancellationException(mb.e(this.x, " ms", new StringBuilder("Timed out waiting for ")), this));
    }
}
