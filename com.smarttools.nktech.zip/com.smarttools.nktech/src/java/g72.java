import androidx.datastore.core.DataStore;
import android.content.Context;
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler;
import androidx.datastore.preferences.PreferenceDataStoreDelegateKt;
import kotlin.jvm.internal.PropertyReference1Impl;

public abstract class g72
{
    public static final ao1[] a;
    public static final xd2 b;
    
    static {
        final PropertyReference1Impl propertyReference1Impl = new PropertyReference1Impl((Class)g72.class, "pedometerDataStore", "getPedometerDataStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;");
        le2.a.getClass();
        a = new ao1[] { (ao1)propertyReference1Impl };
        b = PreferenceDataStoreDelegateKt.preferencesDataStore$default("pedometer_prefs", (ReplaceFileCorruptionHandler)null, (jd1)null, (dq0)null, 14, (Object)null);
    }
    
    public static final DataStore a(final Context context) {
        return (DataStore)g72.b.getValue((Object)context, g72.a[0]);
    }
}
