public final class xg5 implements h32
{
    public static final xg5 a;
    public static final u81 b;
    public static final u81 c;
    public static final u81 d;
    public static final u81 e;
    public static final u81 f;
    public static final u81 g;
    public static final u81 h;
    public static final u81 i;
    public static final u81 j;
    public static final u81 k;
    public static final u81 l;
    public static final u81 m;
    public static final u81 n;
    public static final u81 o;
    
    static {
        a = (xg5)new Object();
        b = new u81("appId", mb.l(f83.h((Class)kj3.class, new kg3(1))));
        c = new u81("appVersion", mb.l(f83.h((Class)kj3.class, new kg3(2))));
        d = new u81("firebaseProjectId", mb.l(f83.h((Class)kj3.class, new kg3(3))));
        e = new u81("mlSdkVersion", mb.l(f83.h((Class)kj3.class, new kg3(4))));
        f = new u81("tfliteSchemaVersion", mb.l(f83.h((Class)kj3.class, new kg3(5))));
        g = new u81("gcmSenderId", mb.l(f83.h((Class)kj3.class, new kg3(6))));
        h = new u81("apiKey", mb.l(f83.h((Class)kj3.class, new kg3(7))));
        i = new u81("languages", mb.l(f83.h((Class)kj3.class, new kg3(8))));
        j = new u81("mlSdkInstanceId", mb.l(f83.h((Class)kj3.class, new kg3(9))));
        k = new u81("isClearcutClient", mb.l(f83.h((Class)kj3.class, new kg3(10))));
        l = new u81("isStandaloneMlkit", mb.l(f83.h((Class)kj3.class, new kg3(11))));
        m = new u81("isJsonLogging", mb.l(f83.h((Class)kj3.class, new kg3(12))));
        n = new u81("buildLevel", mb.l(f83.h((Class)kj3.class, new kg3(13))));
        o = new u81("optionalModuleVersion", mb.l(f83.h((Class)kj3.class, new kg3(14))));
    }
    
    public final void a(final Object o, final Object o2) {
        final ty5 ty5 = (ty5)o;
        final i32 i32 = (i32)o2;
        i32.a(xg5.b, (Object)ty5.a);
        i32.a(xg5.c, (Object)ty5.b);
        i32.a(xg5.d, (Object)null);
        i32.a(xg5.e, (Object)ty5.c);
        i32.a(xg5.f, (Object)ty5.d);
        i32.a(xg5.g, (Object)null);
        i32.a(xg5.h, (Object)null);
        i32.a(xg5.i, (Object)ty5.e);
        i32.a(xg5.j, (Object)ty5.f);
        i32.a(xg5.k, (Object)ty5.g);
        i32.a(xg5.l, (Object)ty5.h);
        i32.a(xg5.m, (Object)ty5.i);
        i32.a(xg5.n, (Object)ty5.j);
        i32.a(xg5.o, (Object)ty5.k);
    }
}
