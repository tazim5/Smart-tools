public final class qv4 implements h32
{
    public static final qv4 a;
    
    static {
        a = (qv4)new Object();
        f83.q(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, new og3(1)), 2)), 3)));
    }
}
