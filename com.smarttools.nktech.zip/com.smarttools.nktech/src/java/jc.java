public final class jc implements h32
{
    public static final jc a;
    public static final u81 b;
    public static final u81 c;
    
    static {
        a = (jc)new Object();
        b = u81.b("networkType");
        c = u81.b("mobileSubtype");
    }
    
    public final void a(final Object o, final Object o2) {
        final v12 v12 = (v12)o;
        final i32 i32 = (i32)o2;
        final ae ae = (ae)v12;
        i32.a(jc.b, (Object)ae.a);
        i32.a(jc.c, (Object)ae.b);
    }
}
