import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material.icons.filled.SearchKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;

public final class nn0 implements nd1
{
    public static final nn0 c;
    
    static {
        c = (nn0)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(SearchKt.getSearch(Icons.INSTANCE.getDefault()), (String)null, (Modifier)null, 0L, composer, 48, 12);
        }
        return t43.a;
    }
}
