public final class j51
{
    public final String a;
    public final double b;
    public final double c;
    public final boolean d;
    public final boolean e;
    public final int f;
    public final int g;
    
    public j51(final String a, final double b, final double c, final boolean d, final boolean e, final int f, final int g) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof j51)) {
            return false;
        }
        final j51 j51 = (j51)o;
        return kl1.b(this.a, j51.a) && Double.compare(this.b, j51.b) == 0 && Double.compare(this.c, j51.c) == 0 && this.d == j51.d && this.e == j51.e && this.f == j51.f && this.g == j51.g;
    }
    
    @Override
    public final int hashCode() {
        return Integer.hashCode(this.g) + gs1.b(this.f, vo2.d(vo2.d(vo2.b(this.c, vo2.b(this.b, this.a.hashCode() * 31, 31), 31), 31, this.d), 31, this.e), 31);
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("ExpenseSettings(currencyCode=");
        sb.append(this.a);
        sb.append(", startingBalance=");
        sb.append(this.b);
        sb.append(", monthlyBudget=");
        sb.append(this.c);
        sb.append(", budgetAlertEnabled=");
        sb.append(this.d);
        sb.append(", remindersEnabled=");
        sb.append(this.e);
        sb.append(", reminderHour=");
        sb.append(this.f);
        sb.append(", reminderMinute=");
        sb.append(this.g);
        sb.append(")");
        return sb.toString();
    }
}
