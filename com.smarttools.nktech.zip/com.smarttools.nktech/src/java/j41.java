import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.CancellationException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.Executor;

public final class j41 extends i41 implements qv0
{
    public final Executor c;
    
    public j41(final Executor c) {
        this.c = c;
        if (c instanceof ScheduledThreadPoolExecutor) {
            ((ScheduledThreadPoolExecutor)c).setRemoveOnCancelPolicy(true);
        }
    }
    
    public final nz0 C(final long n, final rz2 rz2, final up0 up0) {
        final Executor c = this.c;
        final boolean b = c instanceof ScheduledExecutorService;
        final ScheduledFuture scheduledFuture = null;
        ScheduledExecutorService scheduledExecutorService;
        if (b) {
            scheduledExecutorService = (ScheduledExecutorService)c;
        }
        else {
            scheduledExecutorService = null;
        }
        ScheduledFuture schedule = scheduledFuture;
        if (scheduledExecutorService != null) {
            try {
                schedule = scheduledExecutorService.schedule((Runnable)rz2, n, TimeUnit.MILLISECONDS);
            }
            catch (final RejectedExecutionException ex) {
                final CancellationException ex2 = new CancellationException("The task was rejected");
                ((Throwable)ex2).initCause((Throwable)ex);
                final rm1 rm1 = (rm1)up0.get((tp0)h26.w);
                schedule = scheduledFuture;
                if (rm1 != null) {
                    rm1.cancel(ex2);
                    schedule = scheduledFuture;
                }
            }
        }
        Object c2;
        if (schedule != null) {
            c2 = new mz0(schedule);
        }
        else {
            c2 = nu0.P.C(n, rz2, up0);
        }
        return (nz0)c2;
    }
    
    public final void F(final long n, final in in) {
        final Executor c = this.c;
        final boolean b = c instanceof ScheduledExecutorService;
        final Object o = null;
        ScheduledExecutorService scheduledExecutorService;
        if (b) {
            scheduledExecutorService = (ScheduledExecutorService)c;
        }
        else {
            scheduledExecutorService = null;
        }
        Object schedule = o;
        if (scheduledExecutorService != null) {
            final mz4 mz4 = new mz4(4, (Object)this, (Object)in);
            try {
                schedule = scheduledExecutorService.schedule((Runnable)mz4, n, TimeUnit.MILLISECONDS);
            }
            catch (final RejectedExecutionException ex) {
                final CancellationException ex2 = new CancellationException("The task was rejected");
                ((Throwable)ex2).initCause((Throwable)ex);
                final rm1 rm1 = (rm1)in.x.get((tp0)h26.w);
                schedule = o;
                if (rm1 != null) {
                    rm1.cancel(ex2);
                    schedule = o;
                }
            }
        }
        if (schedule != null) {
            in.w((o22)new bn(schedule, 0));
            return;
        }
        ((d41)nu0.P).F(n, in);
    }
    
    public final void close() {
        final Executor c = this.c;
        ExecutorService executorService;
        if (c instanceof ExecutorService) {
            executorService = (ExecutorService)c;
        }
        else {
            executorService = null;
        }
        if (executorService != null) {
            executorService.shutdown();
        }
    }
    
    public final void dispatch(final up0 up0, final Runnable runnable) {
        try {
            this.c.execute(runnable);
        }
        catch (final RejectedExecutionException ex) {
            final CancellationException ex2 = new CancellationException("The task was rejected");
            ((Throwable)ex2).initCause((Throwable)ex);
            final rm1 rm1 = (rm1)up0.get((tp0)h26.w);
            if (rm1 != null) {
                rm1.cancel(ex2);
            }
            final zu0 a = hz0.a;
            tu0.c.dispatch(up0, runnable);
        }
    }
    
    public final boolean equals(final Object o) {
        return o instanceof j41 && ((j41)o).c == this.c;
    }
    
    public final int hashCode() {
        return System.identityHashCode((Object)this.c);
    }
    
    public final String toString() {
        return this.c.toString();
    }
}
