import com.smarttools.nktech.navigation.NavRoutes;

public final class w02 extends NavRoutes
{
    public static final w02 a;
    
    static {
        a = (w02)new NavRoutes("home", (lu0)null);
    }
    
    public final boolean equals(final Object o) {
        return this == o || o instanceof w02;
    }
    
    public final int hashCode() {
        return 1235053230;
    }
    
    public final String toString() {
        return "Home";
    }
}
