import androidx.compose.runtime.State;
import androidx.compose.ui.graphics.Color$Companion;
import java.util.Iterator;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$HorizontalOrVertical;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.graphics.Color;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.semantics.Role;
import androidx.compose.foundation.ClickableKt;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.layout.RowScope;
import com.smarttools.nktech.features.tools.games.c;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import android.content.Context;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.MutableIntState;

public final class vr0 implements nd1
{
    public final MutableIntState P;
    public final MutableIntState Q;
    public final MutableIntState R;
    public final MutableIntState S;
    public final MutableIntState T;
    public final MutableIntState U;
    public final MutableIntState V;
    public final MutableState W;
    public final MutableState X;
    public final MutableState Y;
    public final MutableState Z;
    public final dq0 a0;
    public final Context b0;
    public final MutableState c;
    public final MutableState c0;
    public final MutableState d0;
    public final MutableIntState e0;
    public final MutableIntState f0;
    public final MutableState g0;
    public final MutableState h0;
    public final MutableState i0;
    public final MutableState j0;
    public final MutableState n;
    public final int v;
    public final long w;
    public final int x;
    public final int y;
    public final MutableState z;
    
    public vr0(final MutableState c, final MutableState n, final int v, final long w, final int x, final int y, final MutableState z, final MutableIntState p28, final MutableIntState q, final MutableIntState r, final MutableIntState s, final MutableIntState t, final MutableIntState u, final MutableIntState v2, final MutableState w2, final MutableState x2, final MutableState y2, final MutableState z2, final dq0 a0, final Context b0, final MutableState c2, final MutableState d0, final MutableIntState e0, final MutableIntState f0, final MutableState g0, final MutableState h0, final MutableState i0, final MutableState j0) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p28;
        this.Q = q;
        this.R = r;
        this.S = s;
        this.T = t;
        this.U = u;
        this.V = v2;
        this.W = w2;
        this.X = x2;
        this.Y = y2;
        this.Z = z2;
        this.a0 = a0;
        this.b0 = b0;
        this.c0 = c2;
        this.d0 = d0;
        this.e0 = e0;
        this.f0 = f0;
        this.g0 = g0;
        this.h0 = h0;
        this.i0 = i0;
        this.j0 = j0;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final Arrangement instance = Arrangement.INSTANCE;
            final float n = 12;
            final Arrangement$HorizontalOrVertical spacedBy-0680j_4 = instance.spacedBy-0680j_4(Dp.constructor-impl(n));
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy((Arrangement$Vertical)spacedBy-0680j_4, companion2.getStart(), composer, 6);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final MutableState c = this.c;
            final boolean booleanValue = (boolean)((State)c).getValue();
            final MutableState n2 = this.n;
            final MutableState y = this.Y;
            if (booleanValue) {
                composer.startReplaceGroup(993874007);
                String s;
                if (((State)n2).getValue()) {
                    s = "Wide (1 penalty) + batsman runs";
                }
                else {
                    s = "Wide (no penalty) + batsman runs";
                }
                TextKt.Text--4IGK_g(s, (Modifier)null, MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant-0d7_KjU(), TextUnitKt.getSp(13), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 3072, 0, 131058);
                final float n3 = 8;
                final MeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy((Arrangement$Vertical)instance.spacedBy-0680j_4(Dp.constructor-impl(n3)), companion2.getStart(), composer, 6);
                final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
                final id1 constructor2 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor2);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl2 = Updater.constructor-impl(composer);
                final nd1 b2 = ap.b(companion3, constructor-impl2, columnMeasurePolicy2, constructor-impl2, currentCompositionLocalMap2);
                if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                    l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
                }
                Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
                final Modifier fillMaxWidth$default2 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
                final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl(n3)), companion2.getTop(), composer, 6);
                final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default2);
                final id1 constructor3 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor3);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl3 = Updater.constructor-impl(composer);
                final nd1 b3 = ap.b(companion3, constructor-impl3, rowMeasurePolicy, constructor-impl3, currentCompositionLocalMap3);
                if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                    l3.i(currentCompositeKeyHash3, constructor-impl3, currentCompositeKeyHash3, b3);
                }
                Updater.set-impl(constructor-impl3, (Object)materializeModifier3, companion3.getSetModifier());
                final RowScopeInstance instance3 = RowScopeInstance.INSTANCE;
                composer.startReplaceGroup(1934924676);
                final Iterator iterator = ((Iterable)ur.f((Object[])new Integer[] { 0, 1, 2 })).iterator();
                MutableState z;
                MutableIntState p2;
                MutableIntState q;
                MutableIntState r;
                MutableIntState s2;
                MutableIntState e0;
                MutableIntState f0;
                MutableState j0;
                int v;
                String s3;
                long n4;
                int x;
                int y2;
                MutableIntState t;
                MutableIntState u;
                MutableIntState v2;
                MutableState w;
                MutableState x2;
                MutableState z2;
                dq0 a0;
                Context b4;
                MutableState c2;
                MutableState d0;
                MutableState g0;
                MutableState h0;
                MutableState i0;
                while (true) {
                    final boolean hasNext = iterator.hasNext();
                    z = this.z;
                    p2 = this.P;
                    q = this.Q;
                    r = this.R;
                    s2 = this.S;
                    e0 = this.e0;
                    f0 = this.f0;
                    j0 = this.j0;
                    v = this.v;
                    s3 = "Wd +";
                    n4 = this.w;
                    x = this.x;
                    y2 = this.y;
                    t = this.T;
                    u = this.U;
                    v2 = this.V;
                    w = this.W;
                    x2 = this.X;
                    z2 = this.Z;
                    a0 = this.a0;
                    b4 = this.b0;
                    c2 = this.c0;
                    d0 = this.d0;
                    g0 = this.g0;
                    h0 = this.h0;
                    i0 = this.i0;
                    if (!hasNext) {
                        break;
                    }
                    final int intValue = ((Number)iterator.next()).intValue();
                    final int n5 = v + intValue;
                    if (intValue == 0) {
                        n4 = com.smarttools.nktech.features.tools.games.c.f;
                    }
                    final Modifier$Companion companion4 = Modifier.Companion;
                    final Modifier padding-VpY3zN4$default = PaddingKt.padding-VpY3zN4$default(ClickableKt.clickable-XHw0xAI$default(BackgroundKt.background-bw27NRU$default(ap.d(RowScope.weight$default((RowScope)instance3, (Modifier)companion4, 1.0f, false, 2, (Object)null), n), n4, (Shape)null, 2, (Object)null), false, (String)null, (Role)null, (id1)new ur0(intValue, x, y2, z, p2, q, r, s2, t, u, v2, w, x2, n2, y, z2, a0, b4, c2, d0, e0, f0, c, g0, h0, i0, j0, 0), 7, (Object)null), 0.0f, Dp.constructor-impl((float)14), 1, (Object)null);
                    final Alignment$Companion companion5 = Alignment.Companion;
                    final MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(companion5.getCenter(), false);
                    final int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap4 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier4 = ComposedModifierKt.materializeModifier(composer, padding-VpY3zN4$default);
                    final ComposeUiNode$Companion companion6 = ComposeUiNode.Companion;
                    final id1 constructor4 = companion6.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor4);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl4 = Updater.constructor-impl(composer);
                    final nd1 b5 = ap.b(companion6, constructor-impl4, maybeCachedBoxMeasurePolicy, constructor-impl4, currentCompositionLocalMap4);
                    if (constructor-impl4.getInserting() || !kl1.b(constructor-impl4.rememberedValue(), (Object)currentCompositeKeyHash4)) {
                        l3.i(currentCompositeKeyHash4, constructor-impl4, currentCompositeKeyHash4, b5);
                    }
                    Updater.set-impl(constructor-impl4, (Object)materializeModifier4, companion6.getSetModifier());
                    final BoxScopeInstance instance4 = BoxScopeInstance.INSTANCE;
                    final MeasurePolicy columnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), companion5.getCenterHorizontally(), composer, 48);
                    final int currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap5 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier5 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion4);
                    final id1 constructor5 = companion6.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor5);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl5 = Updater.constructor-impl(composer);
                    final nd1 b6 = ap.b(companion6, constructor-impl5, columnMeasurePolicy3, constructor-impl5, currentCompositionLocalMap5);
                    if (constructor-impl5.getInserting() || !kl1.b(constructor-impl5.rememberedValue(), (Object)currentCompositeKeyHash5)) {
                        l3.i(currentCompositeKeyHash5, constructor-impl5, currentCompositeKeyHash5, b6);
                    }
                    Updater.set-impl(constructor-impl5, (Object)materializeModifier5, companion6.getSetModifier());
                    final ColumnScopeInstance instance5 = ColumnScopeInstance.INSTANCE;
                    String c3;
                    if (intValue == 0) {
                        c3 = "Wide";
                    }
                    else {
                        c3 = e8.c(intValue, "Wd +");
                    }
                    final Color$Companion companion7 = Color.Companion;
                    TextKt.Text--4IGK_g(c3, (Modifier)null, companion7.getWhite-0d7_KjU(), TextUnitKt.getSp(15), (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 200064, 0, 131026);
                    String s4;
                    if (n5 != 1) {
                        s4 = "s";
                    }
                    else {
                        s4 = "";
                    }
                    final StringBuilder sb = new StringBuilder("= ");
                    sb.append(n5);
                    sb.append(" run");
                    sb.append(s4);
                    TextKt.Text--4IGK_g(sb.toString(), (Modifier)null, Color.copy-wmQWz5c$default(companion7.getWhite-0d7_KjU(), 0.8f, 0.0f, 0.0f, 0.0f, 14, (Object)null), TextUnitKt.getSp(11), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 3456, 0, 131058);
                    composer.endNode();
                    composer.endNode();
                }
                composer.endReplaceGroup();
                composer.endNode();
                final Modifier fillMaxWidth$default3 = SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null);
                final MeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy((Arrangement$Horizontal)Arrangement.INSTANCE.spacedBy-0680j_4(Dp.constructor-impl(n3)), Alignment.Companion.getTop(), composer, 6);
                final int currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap6 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier6 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default3);
                final ComposeUiNode$Companion companion8 = ComposeUiNode.Companion;
                final id1 constructor6 = companion8.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor6);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl6 = Updater.constructor-impl(composer);
                final nd1 b7 = ap.b(companion8, constructor-impl6, rowMeasurePolicy2, constructor-impl6, currentCompositionLocalMap6);
                if (constructor-impl6.getInserting() || !kl1.b(constructor-impl6.rememberedValue(), (Object)currentCompositeKeyHash6)) {
                    l3.i(currentCompositeKeyHash6, constructor-impl6, currentCompositeKeyHash6, b7);
                }
                Updater.set-impl(constructor-impl6, (Object)materializeModifier6, companion8.getSetModifier());
                final RowScopeInstance instance6 = RowScopeInstance.INSTANCE;
                composer.startReplaceGroup(1934988855);
                final Iterator iterator2 = ((Iterable)ur.f((Object[])new Integer[] { 3, 4, 6 })).iterator();
                while (iterator2.hasNext()) {
                    final int intValue2 = ((Number)iterator2.next()).intValue();
                    long n6;
                    if (intValue2 != 4) {
                        if (intValue2 != 6) {
                            n6 = n4;
                        }
                        else {
                            n6 = com.smarttools.nktech.features.tools.games.c.d;
                        }
                    }
                    else {
                        n6 = com.smarttools.nktech.features.tools.games.c.c;
                    }
                    final Modifier$Companion companion9 = Modifier.Companion;
                    final Modifier padding-VpY3zN4$default2 = PaddingKt.padding-VpY3zN4$default(ClickableKt.clickable-XHw0xAI$default(BackgroundKt.background-bw27NRU$default(ap.d(RowScope.weight$default((RowScope)instance6, (Modifier)companion9, 1.0f, false, 2, (Object)null), n), n6, (Shape)null, 2, (Object)null), false, (String)null, (Role)null, (id1)new ur0(intValue2, x, y2, z, p2, q, r, s2, t, u, v2, w, x2, n2, y, z2, a0, b4, c2, d0, e0, f0, c, g0, h0, i0, j0, 1), 7, (Object)null), 0.0f, Dp.constructor-impl((float)14), 1, (Object)null);
                    final Alignment$Companion companion10 = Alignment.Companion;
                    final MeasurePolicy maybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(companion10.getCenter(), false);
                    final int currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap7 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier7 = ComposedModifierKt.materializeModifier(composer, padding-VpY3zN4$default2);
                    final ComposeUiNode$Companion companion11 = ComposeUiNode.Companion;
                    final id1 constructor7 = companion11.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor7);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl7 = Updater.constructor-impl(composer);
                    final nd1 b8 = ap.b(companion11, constructor-impl7, maybeCachedBoxMeasurePolicy2, constructor-impl7, currentCompositionLocalMap7);
                    if (constructor-impl7.getInserting() || !kl1.b(constructor-impl7.rememberedValue(), (Object)currentCompositeKeyHash7)) {
                        l3.i(currentCompositeKeyHash7, constructor-impl7, currentCompositeKeyHash7, b8);
                    }
                    Updater.set-impl(constructor-impl7, (Object)materializeModifier7, companion11.getSetModifier());
                    final BoxScopeInstance instance7 = BoxScopeInstance.INSTANCE;
                    final MeasurePolicy columnMeasurePolicy4 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), companion10.getCenterHorizontally(), composer, 48);
                    final int currentCompositeKeyHash8 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap8 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier8 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion9);
                    final id1 constructor8 = companion11.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor8);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl8 = Updater.constructor-impl(composer);
                    final nd1 b9 = ap.b(companion11, constructor-impl8, columnMeasurePolicy4, constructor-impl8, currentCompositionLocalMap8);
                    if (constructor-impl8.getInserting() || !kl1.b(constructor-impl8.rememberedValue(), (Object)currentCompositeKeyHash8)) {
                        l3.i(currentCompositeKeyHash8, constructor-impl8, currentCompositeKeyHash8, b9);
                    }
                    Updater.set-impl(constructor-impl8, (Object)materializeModifier8, companion11.getSetModifier());
                    final ColumnScopeInstance instance8 = ColumnScopeInstance.INSTANCE;
                    final String c4 = e8.c(intValue2, s3);
                    final Color$Companion companion12 = Color.Companion;
                    TextKt.Text--4IGK_g(c4, (Modifier)null, companion12.getWhite-0d7_KjU(), TextUnitKt.getSp(15), (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 200064, 0, 131026);
                    TextKt.Text--4IGK_g(xg.e(v + intValue2, "= ", " runs"), (Modifier)null, Color.copy-wmQWz5c$default(companion12.getWhite-0d7_KjU(), 0.8f, 0.0f, 0.0f, 0.0f, 14, (Object)null), TextUnitKt.getSp(11), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 3456, 0, 131058);
                    composer.endNode();
                    composer.endNode();
                }
                composer.endReplaceGroup();
                composer.endNode();
                composer.endNode();
                if (((State)n2).getValue()) {
                    TextKt.Text--4IGK_g("Wd = 1 penalty run + batsman runs", (Modifier)null, Color.copy-wmQWz5c$default(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant-0d7_KjU(), 0.6f, 0.0f, 0.0f, 0.0f, 14, (Object)null), TextUnitKt.getSp(11), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 3078, 0, 131058);
                }
                composer.endReplaceGroup();
            }
            else {
                composer.startReplaceGroup(998560401);
                final StringBuilder sb2 = new StringBuilder("Wide will");
                if (((State)n2).getValue()) {
                    sb2.append(" add 1 run");
                }
                if (!(boolean)((State)y).getValue()) {
                    if (((State)n2).getValue()) {
                        sb2.append(" and");
                    }
                    sb2.append(" count as legal ball");
                }
                else {
                    sb2.append(" (re-ball)");
                }
                TextKt.Text--4IGK_g(sb2.toString(), (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 0, 0, 131070);
                composer.endReplaceGroup();
            }
            composer.endNode();
        }
        return t43.a;
    }
}
