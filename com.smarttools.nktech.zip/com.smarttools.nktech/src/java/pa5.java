import com.google.android.gms.internal.ads.b5;
import com.google.android.gms.common.internal.BaseGmsClient;
import com.google.android.gms.common.ConnectionResult;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.internal.ads.zzfoy;
import android.os.Bundle;
import android.os.Binder;
import android.os.Looper;
import android.content.Context;
import com.google.android.gms.internal.ads.s2;
import com.google.android.gms.common.internal.BaseGmsClient$BaseOnConnectionFailedListener;
import com.google.android.gms.common.internal.BaseGmsClient$BaseConnectionCallbacks;

public final class pa5 implements BaseGmsClient$BaseConnectionCallbacks, BaseGmsClient$BaseOnConnectionFailedListener
{
    public final za5 a;
    public final s2 b;
    public final Object c;
    public boolean d;
    public boolean e;
    
    public pa5(final Context context, final Looper looper, final s2 b) {
        this.c = new Object();
        this.d = false;
        this.e = false;
        this.b = b;
        this.a = new za5(context, looper, (BaseGmsClient$BaseConnectionCallbacks)this, (BaseGmsClient$BaseOnConnectionFailedListener)this, 12800000);
    }
    
    public final void a() {
        final Object c;
        monitorenter(c = this.c);
        Label_0036: {
            try {
                if (!((BaseGmsClient)this.a).isConnected() && !((BaseGmsClient)this.a).isConnecting()) {
                    break Label_0036;
                }
                break Label_0036;
            }
            finally {
                monitorexit(c);
                ((BaseGmsClient)this.a).disconnect();
                Binder.flushPendingCommands();
                monitorexit(c);
            }
        }
    }
    
    public final void onConnected(final Bundle bundle) {
        final Object c;
        monitorenter(c = this.c);
        Label_0025: {
            try {
                if (this.e) {
                    monitorexit(c);
                    return;
                }
                break Label_0025;
            }
            finally {
                goto Label_0094;
                this.e = true;
                try {
                    final ab5 ab5 = (ab5)((BaseGmsClient)this.a).getService();
                    final zzfoy zzfoy = new zzfoy(1, ((b5)this.b).d());
                    final Parcel zza = ((go3)ab5).zza();
                    io3.c(zza, (Parcelable)zzfoy);
                    ((go3)ab5).zzbi(2, zza);
                }
                catch (final Exception ex) {}
                finally {
                    this.a();
                }
            }
        }
    }
    
    public final void onConnectionFailed(final ConnectionResult connectionResult) {
    }
    
    public final void onConnectionSuspended(final int n) {
    }
}
