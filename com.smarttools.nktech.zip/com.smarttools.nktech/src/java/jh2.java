public abstract class jh2 implements mt2
{
}
