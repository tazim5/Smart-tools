public final class lf3
{
    public byte[] a;
    public int b;
    public int c;
    public int d;
    
    public lf3() {
        this.a = ec5.f;
    }
    
    public lf3(final int d, final byte[] a) {
        this.a = a;
        this.d = d;
    }
    
    public lf3(final byte[] a, final int c, final int b) {
        this.a = a;
        this.c = c;
        this.b = b;
        this.d = 0;
        this.n();
    }
    
    public int a() {
        return (this.d - this.b) * 8 - this.c;
    }
    
    public int b(final int n) {
        this.d += n;
        int n2 = 0;
        int d;
        int n3;
        byte[] a;
        while (true) {
            d = this.d;
            n3 = 2;
            a = this.a;
            if (d <= 8) {
                break;
            }
            d -= 8;
            this.d = d;
            final int c = this.c;
            n2 |= (a[c] & 0xFF) << d;
            if (!this.p(c + 1)) {
                n3 = 1;
            }
            this.c = c + n3;
        }
        final int c2 = this.c;
        final byte b = a[c2];
        if (d == 8) {
            this.d = 0;
            if (!this.p(c2 + 1)) {
                n3 = 1;
            }
            this.c = c2 + n3;
        }
        this.n();
        return -1 >>> 32 - n & (n2 | (b & 0xFF) >> 8 - d);
    }
    
    public int c() {
        final int l = this.l();
        int n = 1;
        if (l % 2 == 0) {
            n = -1;
        }
        return (l + 1) / 2 * n;
    }
    
    public int d(final int n) {
        final int c = this.c;
        final int d = this.d;
        int n2 = c + 1;
        int i = Math.min(n, 8 - d);
        final byte[] a = this.a;
        int n3 = (a[c] & 0xFF) >> this.d & 255 >> 8 - i;
        while (i < n) {
            n3 |= (a[n2] & 0xFF) << i;
            i += 8;
            ++n2;
        }
        this.e(n);
        return n3 & -1 >>> 32 - n;
    }
    
    public void e(int d) {
        final int c = this.c;
        final int n = d / 8;
        final int c2 = c + n;
        this.c = c2;
        final int d2 = d - n * 8 + this.d;
        this.d = d2;
        int c3 = c2;
        d = d2;
        if (d2 > 7) {
            c3 = c2 + 1;
            this.c = c3;
            d = d2 - 8;
            this.d = d;
        }
        boolean b2;
        final boolean b = b2 = false;
        Label_0111: {
            if (c3 >= 0) {
                final int b3 = this.b;
                if (c3 >= b3) {
                    b2 = b;
                    if (c3 != b3) {
                        break Label_0111;
                    }
                    b2 = b;
                    if (d != 0) {
                        break Label_0111;
                    }
                }
                b2 = true;
            }
        }
        aq3.k(b2);
    }
    
    public int f(final int n) {
        if (n == 0) {
            return 0;
        }
        this.c += n;
        int n2 = 0;
        int c;
        while (true) {
            c = this.c;
            if (c <= 8) {
                break;
            }
            c -= 8;
            this.c = c;
            n2 |= (this.a[this.b++] & 0xFF) << c;
        }
        final byte[] a = this.a;
        final int b = this.b;
        final byte b2 = a[b];
        if (c == 8) {
            this.c = 0;
            this.b = b + 1;
        }
        this.u();
        return -1 >>> 32 - n & (n2 | (b2 & 0xFF) >> 8 - c);
    }
    
    public void g() {
        int d = this.d;
        int n = 1;
        ++d;
        this.d = d;
        if (d == 8) {
            this.d = 0;
            final int c = this.c;
            if (this.p(c + 1)) {
                n = 2;
            }
            this.c = c + n;
        }
        this.n();
    }
    
    public boolean h() {
        final byte b = this.a[this.c];
        final int d = this.d;
        this.e(1);
        return 0x1 == ((b & 0xFF) >> d & 0x1);
    }
    
    public void i() {
        if (this.c == 0) {
            return;
        }
        this.c = 0;
        ++this.b;
        this.u();
    }
    
    public void j(int n) {
        final int c = this.c;
        final int n2 = n / 8;
        final int c2 = c + n2;
        this.c = c2;
        final int d = n - n2 * 8 + this.d;
        this.d = d;
        n = c;
        if (d > 7) {
            this.c = c2 + 1;
            this.d = d - 8;
            n = c;
        }
        while (true) {
            final int n3 = n + 1;
            if (n3 > this.c) {
                break;
            }
            n = n3;
            if (!this.p(n3)) {
                continue;
            }
            ++this.c;
            n = n3 + 2;
        }
        this.n();
    }
    
    public boolean k() {
        final byte b = this.a[this.c];
        final int d = this.d;
        this.g();
        return (b & 128 >> d) != 0x0;
    }
    
    public int l() {
        int b = 0;
        int n = 0;
        while (!this.k()) {
            ++n;
        }
        if (n > 0) {
            b = this.b(n);
        }
        return (1 << n) - 1 + b;
    }
    
    public void m(int c, final byte[] array) {
        int n = 0;
        int n2;
        while (true) {
            n2 = c >> 3;
            if (n >= n2) {
                break;
            }
            final byte[] a = this.a;
            final int b = this.b;
            final int b2 = b + 1;
            this.b = b2;
            final byte b3 = a[b];
            final int c2 = this.c;
            final byte b4 = (byte)(b3 << c2);
            array[n] = b4;
            array[n] = (byte)((a[b2] & 0xFF) >> 8 - c2 | b4);
            ++n;
        }
        final int n3 = c & 0x7;
        if (n3 == 0) {
            return;
        }
        final byte b5 = (byte)(array[n2] & 255 >> n3);
        array[n2] = b5;
        final int c3 = this.c;
        byte b6 = b5;
        c = c3;
        if (c3 + n3 > 8) {
            final byte[] a2 = this.a;
            c = this.b++;
            final byte b7 = (byte)(b5 | (a2[c] & 0xFF) << c3);
            array[n2] = b7;
            c = c3 - 8;
            b6 = b7;
        }
        c += n3;
        this.c = c;
        final byte[] a3 = this.a;
        final int b8 = this.b;
        array[n2] = (byte)((byte)((0xFF & a3[b8]) >> 8 - c << 8 - n3) | b6);
        if (c == 8) {
            this.c = 0;
            this.b = b8 + 1;
        }
        this.u();
    }
    
    public void n() {
        final int c = this.c;
        boolean b2;
        final boolean b = b2 = false;
        Label_0045: {
            if (c >= 0) {
                final int b3 = this.b;
                if (c >= b3) {
                    b2 = b;
                    if (c != b3) {
                        break Label_0045;
                    }
                    b2 = b;
                    if (this.d != 0) {
                        break Label_0045;
                    }
                }
                b2 = true;
            }
        }
        aq3.k(b2);
    }
    
    public void o(final f85 f85) {
        final byte[] a = f85.a;
        final int c = f85.c;
        this.a = a;
        this.b = 0;
        this.c = 0;
        this.d = c;
        this.q(f85.b * 8);
    }
    
    public boolean p(final int n) {
        if (n >= 2 && n < this.b) {
            final byte[] a = this.a;
            if (a[n] == 3 && a[n - 2] == 0 && a[n - 1] == 0) {
                return true;
            }
        }
        return false;
    }
    
    public void q(final int n) {
        final int b = n / 8;
        this.b = b;
        this.c = n - b * 8;
        this.u();
    }
    
    public void r() {
        final int c = this.c + 1;
        this.c = c;
        if (c == 8) {
            this.c = 0;
            ++this.b;
        }
        this.u();
    }
    
    public void s(int c) {
        final int b = this.b;
        final int n = c / 8;
        final int b2 = b + n;
        this.b = b2;
        c = c - n * 8 + this.c;
        this.c = c;
        if (c > 7) {
            this.b = b2 + 1;
            this.c = c - 8;
        }
        this.u();
    }
    
    public boolean t() {
        final byte b = this.a[this.b];
        final int c = this.c;
        this.r();
        return (b & 128 >> c) != 0x0;
    }
    
    public void u() {
        final int b = this.b;
        boolean b3;
        final boolean b2 = b3 = false;
        Label_0045: {
            if (b >= 0) {
                final int d = this.d;
                if (b >= d) {
                    b3 = b2;
                    if (b != d) {
                        break Label_0045;
                    }
                    b3 = b2;
                    if (this.c != 0) {
                        break Label_0045;
                    }
                }
                b3 = true;
            }
        }
        aq3.k(b3);
    }
}
