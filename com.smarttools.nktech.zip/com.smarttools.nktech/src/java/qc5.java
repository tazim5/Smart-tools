public final class qc5 extends oc5
{
    public final gw2 n;
    public final oc5 v;
    public final uc5 w;
    
    public qc5(final uc5 w, final gw2 gw2, final gw2 n, final oc5 v) {
        this.w = w;
        this.n = n;
        this.v = v;
        super(gw2);
    }
    
    public final void a() {
        final Object f;
        monitorenter(f = this.w.f);
        Label_0098: {
            try {
                final uc5 w = this.w;
                final gw2 n = this.n;
                w.e.add((Object)n);
                n.a.j((i42)new mw4(17, (Object)w, (Object)n));
                if (this.w.k.getAndIncrement() > 0) {
                    this.w.b.d("Already connected to the service.", new Object[0]);
                }
                break Label_0098;
            }
            finally {
                monitorexit(f);
                uc5.b(this.w, this.v);
                monitorexit(f);
            }
        }
    }
}
