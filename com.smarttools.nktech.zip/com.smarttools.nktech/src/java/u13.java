import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.snapshots.SnapshotStateMap;
import kotlinx.coroutines.flow.p;

public final class u13
{
    public final p a;
    public final be2 b;
    public final SnapshotStateMap c;
    
    public u13() {
        final p a = it3.a((Object)null);
        this.a = a;
        this.b = new be2((iz1)a);
        this.c = SnapshotStateKt.mutableStateMapOf();
    }
}
