public interface hw5
{
}
