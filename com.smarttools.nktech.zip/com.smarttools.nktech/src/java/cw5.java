import java.util.ArrayList;

public abstract class cw5
{
    public static final Object a(Object o, final Object o2) {
        if (o == null) {
            o = o2;
        }
        else if (o instanceof ArrayList) {
            ((ArrayList)o).add(o2);
        }
        else {
            final ArrayList list = new ArrayList(4);
            list.add(o);
            list.add(o2);
            o = list;
        }
        return o;
    }
}
