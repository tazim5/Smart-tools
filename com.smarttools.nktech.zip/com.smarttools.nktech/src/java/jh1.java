import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.nio.charset.Charset;
import java.util.Arrays;

public final class jh1
{
    public static final String[] b;
    public static final int[][] c;
    public static final int[][] d;
    public static final int[][] e;
    public final byte[] a;
    
    static {
        b = new String[] { "UPPER", "LOWER", "DIGIT", "MIXED", "PUNCT" };
        c = new int[][] { { 0, 327708, 327710, 327709, 656318 }, { 590318, 0, 327710, 327709, 656318 }, { 262158, 590300, 0, 590301, 932798 }, { 327709, 327708, 656318, 0, 327710 }, { 327711, 656380, 656382, 656381, 0 } };
        (d = new int[5][256])[0][32] = 1;
        for (int i = 65; i <= 90; ++i) {
            jh1.d[0][i] = i - 63;
        }
        jh1.d[1][32] = 1;
        for (int j = 97; j <= 122; ++j) {
            jh1.d[1][j] = j - 95;
        }
        jh1.d[2][32] = 1;
        for (int k = 48; k <= 57; ++k) {
            jh1.d[2][k] = k - 46;
        }
        final int[] array = jh1.d[2];
        array[44] = 12;
        array[46] = 13;
        for (int l = 0; l < 28; ++l) {
            jh1.d[3][(new int[] { 0, 32, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 27, 28, 29, 30, 31, 64, 92, 94, 95, 96, 124, 126, 127 })[l]] = l;
        }
        for (int n = 0; n < 31; ++n) {
            final int n2 = (new int[] { 0, 13, 0, 0, 0, 0, 33, 39, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 58, 59, 60, 61, 62, 63, 91, 93, 123, 125 })[n];
            if (n2 > 0) {
                jh1.d[4][n2] = n;
            }
        }
        final int[][] array2 = e = new int[6][6];
        for (int length = array2.length, n3 = 0; n3 < length; ++n3) {
            Arrays.fill(array2[n3], -1);
        }
        final int[][] e2 = jh1.e;
        e2[0][4] = 0;
        final int[] array3 = e2[1];
        array3[array3[4] = 0] = 28;
        e2[3][4] = 0;
        final int[] array4 = e2[2];
        array4[array4[4] = 0] = 15;
    }
    
    public jh1(final byte[] a, final Charset charset) {
        this.a = a;
    }
    
    public static LinkedList a(final LinkedList list) {
        final LinkedList list2 = new LinkedList();
    Label_0015:
        for (final gr2 gr2 : list) {
            final Iterator iterator2 = ((Deque)list2).iterator();
            while (iterator2.hasNext()) {
                final gr2 gr3 = (gr2)iterator2.next();
                if (gr3.c(gr2)) {
                    continue Label_0015;
                }
                if (!gr2.c(gr3)) {
                    continue;
                }
                iterator2.remove();
            }
            list2.addFirst((Object)gr2);
        }
        return list2;
    }
}
