import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zze;

public final class b64 extends go3 implements d64
{
    public final void P0(final zze zze) {
        final Parcel zza = this.zza();
        io3.c(zza, (Parcelable)zze);
        this.zzbi(5, zza);
    }
    
    public final void W0(final x54 x54) {
        final Parcel zza = this.zza();
        io3.e(zza, (IInterface)x54);
        this.zzbi(3, zza);
    }
    
    public final void r(final int n) {
        final Parcel zza = this.zza();
        zza.writeInt(n);
        this.zzbi(4, zza);
    }
    
    public final void zze() {
        this.zzbi(7, this.zza());
    }
    
    public final void zzf() {
        this.zzbi(6, this.zza());
    }
    
    public final void zzg() {
        this.zzbi(2, this.zza());
    }
    
    public final void zzj() {
        this.zzbi(1, this.zza());
    }
}
