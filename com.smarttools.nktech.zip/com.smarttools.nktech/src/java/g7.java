import android.database.Cursor;
import java.util.HashSet;
import com.google.android.gms.ads.internal.zzt;
import java.util.LinkedHashMap;
import android.text.TextUtils;
import java.util.concurrent.ArrayBlockingQueue;
import android.os.Parcel;
import android.os.RemoteException;
import java.util.Iterator;
import android.os.ConditionVariable;
import android.util.Log;

public final class g7 implements Runnable
{
    public final int c;
    public final Object n;
    
    private final void b() {
        final t83 t83 = (t83)this.n;
        final Object a;
        monitorenter(a = t83.a);
        Label_0033: {
            try {
                if (!t83.b()) {
                    monitorexit(a);
                    return;
                }
                break Label_0033;
            }
            finally {
                monitorexit(a);
                Label_0067: {
                    t83.c = 1;
                }
                t83.e();
                monitorexit(a);
                return;
                Log.e("WakeLock", String.valueOf((Object)t83.j).concat(" ** IS FORCE-RELEASED ON TIMEOUT **"));
                t83.d();
                iftrue(Label_0067:)(t83.b());
                monitorexit(a);
            }
        }
    }
    
    private final void c() {
        final Object v;
        monitorenter(v = ((nm3)this.n).V);
        Label_0116: {
            try {
                if (((nm3)this.n).W) {
                    break Label_0116;
                }
                ((nm3)this.n).W = true;
                monitorexit(v);
                try {
                    nm3.b((nm3)this.n);
                }
                catch (final Exception ex) {
                    ((nm3)this.n).y.b(2023, -1L, ex);
                }
                final Object v2 = ((nm3)this.n).V;
                synchronized (v2) {
                    ((nm3)this.n).W = false;
                }
            }
            finally {
                monitorexit(v);
                monitorexit(v);
            }
        }
    }
    
    private final void d() {
        if (((om3)this.n).b != null) {
            return;
        }
        final ConditionVariable c;
        monitorenter(c = om3.c);
        Label_0045: {
            try {
                if (((om3)this.n).b != null) {
                    monitorexit(c);
                    return;
                }
                break Label_0045;
            }
            finally {
                while (true) {
                    while (true) {
                        boolean booleanValue = false;
                        Label_0116: {
                            break Label_0116;
                            try {
                                om3.d = db5.a(((om3)this.n).a.a, "ADSHIELD");
                                Label_0092: {
                                    ((om3)this.n).b = booleanValue;
                                }
                                om3.c.open();
                                monitorexit(c);
                                return;
                                monitorexit(c);
                            }
                            finally {
                                final boolean b;
                                booleanValue = b;
                            }
                        }
                        iftrue(Label_0092:)(!booleanValue);
                        continue;
                    }
                    final boolean b = false;
                    try {
                        final boolean booleanValue = (boolean)cs3.b2.k();
                    }
                    catch (final IllegalStateException ex) {
                        final boolean booleanValue = false;
                    }
                    continue;
                }
            }
        }
    }
    
    private final void e() {
        final Object v;
        monitorenter(v = ((xo3)this.n).v);
        while (true) {
            yo3 yo3 = null;
            while (true) {
                Label_0105: {
                    try {
                        final xo3 xo3 = (xo3)this.n;
                        if (xo3.w && xo3.x) {
                            xo3.w = false;
                            d94.zze("App went background");
                            for (final yo3 yo4 : ((xo3)this.n).y) {
                                yo3 = yo4;
                                final boolean b = false;
                                yo4.zza(b);
                            }
                            break Label_0110;
                        }
                        break Label_0105;
                    }
                    finally {
                        final Iterator iterator2;
                        final Iterator iterator = iterator2;
                        monitorexit(v);
                        monitorexit(v);
                        return;
                        d94.zze("App is still foreground");
                        continue;
                    }
                }
                break;
            }
            try {
                final yo3 yo4 = yo3;
                final boolean b = false;
                yo4.zza(b);
                continue;
            }
            catch (final Exception ex) {}
            break;
        }
    }
    
    private final void f() {
        final g9 g9 = (g9)this.n;
        final g9 g10;
        monitorenter(g10 = g9);
        try {
            try {
                final y7 y7 = (y7)g9.w;
                if (y7.c) {
                    final lo3 lo3 = (lo3)y7.n;
                    final byte[] array = (byte[])g9.v;
                    final jo3 jo3 = (jo3)lo3;
                    final Parcel zza = ((go3)jo3).zza();
                    zza.writeByteArray(array);
                    ((go3)jo3).zzbi(5, zza);
                    final jo3 jo4 = (jo3)((y7)g9.w).n;
                    final Parcel zza2 = ((go3)jo4).zza();
                    zza2.writeInt(0);
                    ((go3)jo4).zzbi(6, zza2);
                    final lo3 lo4 = (lo3)((y7)g9.w).n;
                    final int n = g9.n;
                    final jo3 jo5 = (jo3)lo4;
                    final Parcel zza3 = ((go3)jo5).zza();
                    zza3.writeInt(n);
                    ((go3)jo5).zzbi(7, zza3);
                    final jo3 jo6 = (jo3)((y7)g9.w).n;
                    final Parcel zza4 = ((go3)jo6).zza();
                    zza4.writeIntArray((int[])null);
                    ((go3)jo6).zzbi(4, zza4);
                    final jo3 jo7 = (jo3)((y7)g9.w).n;
                    ((go3)jo7).zzbi(3, ((go3)jo7).zza());
                }
                monitorexit(g10);
            }
            finally {
                monitorexit(g10);
            }
        }
        catch (final RemoteException ex) {}
    }
    
    private final void g() {
        final vb3 vb3 = (vb3)this.n;
        try {
            while (true) {
                final hs3 hs3 = (hs3)((ArrayBlockingQueue)vb3.a).take();
                final pe2 a = hs3.a();
                if (!TextUtils.isEmpty((CharSequence)a.n)) {
                    final LinkedHashMap linkedHashMap = (LinkedHashMap)vb3.b;
                    final Object c = hs3.c;
                    synchronized (c) {
                        zzt.zzo().b();
                        final LinkedHashMap b = hs3.b;
                        monitorexit(c);
                        vb3.q(vb3.o(linkedHashMap, b), a);
                    }
                }
            }
        }
        catch (final InterruptedException ex) {
            d94.zzk("CsiReporter:reporter interrupted", (Throwable)ex);
        }
    }
    
    public HashSet a() {
        final HashSet set = new HashSet();
        final Cursor g = ((ng2)((ol1)this.n).c).g((nt2)new dh5("SELECT * FROM room_table_modification_log WHERE invalidated = 1;", 2));
        Label_0092: {
            try {
                while (g.moveToNext()) {
                    set.add((Object)g.getInt(0));
                }
            }
            finally {
                break Label_0092;
            }
            g.close();
            final HashSet set2;
            if (!set2.isEmpty()) {
                ((ol1)this.n).f.a0();
            }
            return set2;
        }
        g.close();
    }
    
    public final void run() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: lstore          5
        //     3: iconst_0       
        //     4: istore_2       
        //     5: aconst_null    
        //     6: astore          19
        //     8: aload_0        
        //     9: getfield        g7.c:I
        //    12: tableswitch {
        //                0: 2899
        //                1: 2617
        //                2: 2128
        //                3: 2097
        //                4: 2085
        //                5: 2074
        //                6: 2049
        //                7: 2028
        //                8: 2017
        //                9: 2005
        //               10: 1990
        //               11: 1943
        //               12: 1560
        //               13: 1538
        //               14: 1471
        //               15: 1435
        //               16: 1430
        //               17: 1425
        //               18: 1420
        //               19: 1409
        //               20: 1229
        //               21: 1217
        //               22: 1212
        //               23: 1201
        //               24: 1196
        //               25: 1191
        //               26: 1159
        //               27: 1148
        //               28: 1130
        //          default: 144
        //        }
        //   144: aload_0        
        //   145: getfield        g7.n:Ljava/lang/Object;
        //   148: checkcast       Lhb4;
        //   151: astore          24
        //   153: aload           24
        //   155: getfield        hb4.x:Ljava/lang/String;
        //   158: invokestatic    hb4.t:(Ljava/lang/String;)Ljava/lang/String;
        //   161: astore          19
        //   163: ldc_w           "error"
        //   166: astore          22
        //   168: getstatic       cs3.r:Lur3;
        //   171: astore          20
        //   173: invokestatic    com/google/android/gms/ads/internal/client/zzba.zzc:()Las3;
        //   176: aload           20
        //   178: invokevirtual   as3.a:(Lur3;)Ljava/lang/Object;
        //   181: checkcast       Ljava/lang/Long;
        //   184: invokevirtual   java/lang/Long.longValue:()J
        //   187: ldc2_w          1000
        //   190: lmul           
        //   191: lstore          7
        //   193: getstatic       cs3.q:Lur3;
        //   196: astore          20
        //   198: invokestatic    com/google/android/gms/ads/internal/client/zzba.zzc:()Las3;
        //   201: aload           20
        //   203: invokevirtual   as3.a:(Lur3;)Ljava/lang/Object;
        //   206: checkcast       Ljava/lang/Integer;
        //   209: invokevirtual   java/lang/Integer.intValue:()I
        //   212: i2l            
        //   213: lstore          11
        //   215: getstatic       cs3.D1:Lur3;
        //   218: astore          20
        //   220: invokestatic    com/google/android/gms/ads/internal/client/zzba.zzc:()Las3;
        //   223: aload           20
        //   225: invokevirtual   as3.a:(Lur3;)Ljava/lang/Object;
        //   228: checkcast       Ljava/lang/Boolean;
        //   231: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   234: istore          18
        //   236: aload           24
        //   238: dup            
        //   239: astore          28
        //   241: monitorenter   
        //   242: invokestatic    com/google/android/gms/ads/internal/zzt.zzB:()Lcom/google/android/gms/common/util/Clock;
        //   245: invokeinterface com/google/android/gms/common/util/Clock.currentTimeMillis:()J
        //   250: aload           24
        //   252: getfield        hb4.Q:J
        //   255: lsub           
        //   256: lload           7
        //   258: lcmp           
        //   259: ifgt            873
        //   262: aload           24
        //   264: getfield        hb4.y:Z
        //   267: ifne            828
        //   270: aload           24
        //   272: getfield        hb4.z:Z
        //   275: ifeq            284
        //   278: aload           28
        //   280: monitorexit    
        //   281: goto            1106
        //   284: aload           24
        //   286: getfield        hb4.w:Lcom/google/android/gms/internal/ads/n1;
        //   289: getfield        com/google/android/gms/internal/ads/n1.z:Lv26;
        //   292: astore          20
        //   294: aload           20
        //   296: ifnull          304
        //   299: iconst_1       
        //   300: istore_2       
        //   301: goto            306
        //   304: iconst_0       
        //   305: istore_2       
        //   306: iload_2        
        //   307: ifeq            783
        //   310: aload           20
        //   312: invokevirtual   v26.w:()J
        //   315: lstore          13
        //   317: lload           13
        //   319: lconst_0       
        //   320: lcmp           
        //   321: ifle            728
        //   324: aload           24
        //   326: getfield        hb4.w:Lcom/google/android/gms/internal/ads/n1;
        //   329: getfield        com/google/android/gms/internal/ads/n1.z:Lv26;
        //   332: invokevirtual   v26.u:()J
        //   335: lstore          15
        //   337: lload           15
        //   339: aload           24
        //   341: getfield        hb4.R:J
        //   344: lcmp           
        //   345: ifeq            580
        //   348: lload           15
        //   350: lconst_0       
        //   351: lcmp           
        //   352: ifle            361
        //   355: iconst_1       
        //   356: istore          17
        //   358: goto            364
        //   361: iconst_0       
        //   362: istore          17
        //   364: aload           24
        //   366: getfield        hb4.x:Ljava/lang/String;
        //   369: astore          25
        //   371: iload           18
        //   373: ifeq            416
        //   376: aload           24
        //   378: getfield        hb4.w:Lcom/google/android/gms/internal/ads/n1;
        //   381: astore          20
        //   383: aload           20
        //   385: getfield        com/google/android/gms/internal/ads/n1.a0:Llb4;
        //   388: ifnull          405
        //   391: aload           20
        //   393: getfield        com/google/android/gms/internal/ads/n1.a0:Llb4;
        //   396: getfield        lb4.W:Z
        //   399: ifeq            405
        //   402: goto            421
        //   405: aload           20
        //   407: getfield        com/google/android/gms/internal/ads/n1.S:I
        //   410: i2l            
        //   411: lstore          5
        //   413: goto            421
        //   416: ldc2_w          -1
        //   419: lstore          5
        //   421: iload           18
        //   423: ifeq            439
        //   426: aload           24
        //   428: getfield        hb4.w:Lcom/google/android/gms/internal/ads/n1;
        //   431: invokevirtual   com/google/android/gms/internal/ads/n1.u:()J
        //   434: lstore          7
        //   436: goto            444
        //   439: ldc2_w          -1
        //   442: lstore          7
        //   444: iload           18
        //   446: ifeq            462
        //   449: aload           24
        //   451: getfield        hb4.w:Lcom/google/android/gms/internal/ads/n1;
        //   454: invokevirtual   com/google/android/gms/internal/ads/n1.p:()J
        //   457: lstore          9
        //   459: goto            467
        //   462: ldc2_w          -1
        //   465: lstore          9
        //   467: getstatic       com/google/android/gms/internal/ads/n1.c0:Ljava/util/concurrent/atomic/AtomicInteger;
        //   470: invokevirtual   java/util/concurrent/atomic/AtomicInteger.get:()I
        //   473: istore_3       
        //   474: getstatic       com/google/android/gms/internal/ads/n1.d0:Ljava/util/concurrent/atomic/AtomicInteger;
        //   477: invokevirtual   java/util/concurrent/atomic/AtomicInteger.get:()I
        //   480: istore_2       
        //   481: getstatic       z84.b:Llb5;
        //   484: astore          26
        //   486: new             Lbb4;
        //   489: astore          27
        //   491: aload           19
        //   493: astore          23
        //   495: aload           22
        //   497: astore          21
        //   499: aload           23
        //   501: astore          20
        //   503: aload           27
        //   505: aload           24
        //   507: aload           25
        //   509: aload           19
        //   511: lload           15
        //   513: lload           13
        //   515: lload           5
        //   517: lload           7
        //   519: lload           9
        //   521: iload           17
        //   523: iload_3        
        //   524: iload_2        
        //   525: invokespecial   bb4.<init>:(Leb4;Ljava/lang/String;Ljava/lang/String;JJJJJZII)V
        //   528: aload           22
        //   530: astore          21
        //   532: aload           23
        //   534: astore          20
        //   536: aload           26
        //   538: aload           27
        //   540: invokevirtual   android/os/Handler.post:(Ljava/lang/Runnable;)Z
        //   543: pop            
        //   544: aload           22
        //   546: astore          21
        //   548: aload           23
        //   550: astore          20
        //   552: aload           24
        //   554: lload           15
        //   556: putfield        hb4.R:J
        //   559: goto            580
        //   562: astore          23
        //   564: aload           21
        //   566: astore          22
        //   568: aload           20
        //   570: astore          19
        //   572: goto            982
        //   575: astore          23
        //   577: goto            982
        //   580: aload           19
        //   582: astore          23
        //   584: lload           15
        //   586: lload           13
        //   588: lcmp           
        //   589: iflt            684
        //   592: aload           22
        //   594: astore          21
        //   596: aload           23
        //   598: astore          20
        //   600: aload           24
        //   602: getfield        hb4.x:Ljava/lang/String;
        //   605: astore          19
        //   607: aload           22
        //   609: astore          21
        //   611: aload           23
        //   613: astore          20
        //   615: getstatic       z84.b:Llb5;
        //   618: astore          25
        //   620: aload           22
        //   622: astore          21
        //   624: aload           23
        //   626: astore          20
        //   628: new             Lku2;
        //   631: astore          26
        //   633: aload           22
        //   635: astore          21
        //   637: aload           23
        //   639: astore          20
        //   641: aload           26
        //   643: aload           24
        //   645: aload           19
        //   647: aload           23
        //   649: lload           13
        //   651: invokespecial   ku2.<init>:(Leb4;Ljava/lang/String;Ljava/lang/String;J)V
        //   654: aload           22
        //   656: astore          21
        //   658: aload           23
        //   660: astore          20
        //   662: aload           25
        //   664: aload           26
        //   666: invokevirtual   android/os/Handler.post:(Ljava/lang/Runnable;)Z
        //   669: pop            
        //   670: aload           22
        //   672: astore          21
        //   674: aload           23
        //   676: astore          20
        //   678: aload           28
        //   680: monitorexit    
        //   681: goto            1106
        //   684: aload           22
        //   686: astore          21
        //   688: aload           23
        //   690: astore          20
        //   692: aload           24
        //   694: getfield        hb4.w:Lcom/google/android/gms/internal/ads/n1;
        //   697: getfield        com/google/android/gms/internal/ads/n1.S:I
        //   700: i2l            
        //   701: lload           11
        //   703: lcmp           
        //   704: iflt            728
        //   707: lload           15
        //   709: lconst_0       
        //   710: lcmp           
        //   711: ifle            728
        //   714: aload           22
        //   716: astore          21
        //   718: aload           23
        //   720: astore          20
        //   722: aload           28
        //   724: monitorexit    
        //   725: goto            1106
        //   728: aload           22
        //   730: astore          21
        //   732: aload           19
        //   734: astore          20
        //   736: aload           28
        //   738: monitorexit    
        //   739: getstatic       cs3.s:Lur3;
        //   742: astore          19
        //   744: invokestatic    com/google/android/gms/ads/internal/client/zzba.zzc:()Las3;
        //   747: aload           19
        //   749: invokevirtual   as3.a:(Lur3;)Ljava/lang/Object;
        //   752: checkcast       Ljava/lang/Long;
        //   755: invokevirtual   java/lang/Long.longValue:()J
        //   758: lstore          5
        //   760: getstatic       com/google/android/gms/ads/internal/util/zzt.zza:Llb5;
        //   763: new             Lg7;
        //   766: dup            
        //   767: aload           24
        //   769: bipush          29
        //   771: invokespecial   g7.<init>:(Ljava/lang/Object;I)V
        //   774: lload           5
        //   776: invokevirtual   android/os/Handler.postDelayed:(Ljava/lang/Runnable;J)Z
        //   779: pop            
        //   780: goto            1129
        //   783: ldc_w           "exoPlayerReleased"
        //   786: astore          22
        //   788: aload           22
        //   790: astore          21
        //   792: aload           19
        //   794: astore          20
        //   796: new             Ljava/io/IOException;
        //   799: astore          23
        //   801: aload           22
        //   803: astore          21
        //   805: aload           19
        //   807: astore          20
        //   809: aload           23
        //   811: ldc_w           "ExoPlayer was released during preloading."
        //   814: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   817: aload           22
        //   819: astore          21
        //   821: aload           19
        //   823: astore          20
        //   825: aload           23
        //   827: athrow         
        //   828: ldc_w           "externalAbort"
        //   831: astore          22
        //   833: aload           22
        //   835: astore          21
        //   837: aload           19
        //   839: astore          20
        //   841: new             Ljava/io/IOException;
        //   844: astore          23
        //   846: aload           22
        //   848: astore          21
        //   850: aload           19
        //   852: astore          20
        //   854: aload           23
        //   856: ldc_w           "Abort requested before buffering finished. "
        //   859: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   862: aload           22
        //   864: astore          21
        //   866: aload           19
        //   868: astore          20
        //   870: aload           23
        //   872: athrow         
        //   873: ldc_w           "downloadTimeout"
        //   876: astore          22
        //   878: aload           22
        //   880: astore          21
        //   882: aload           19
        //   884: astore          20
        //   886: new             Ljava/io/IOException;
        //   889: astore          23
        //   891: aload           22
        //   893: astore          21
        //   895: aload           19
        //   897: astore          20
        //   899: new             Ljava/lang/StringBuilder;
        //   902: astore          25
        //   904: aload           22
        //   906: astore          21
        //   908: aload           19
        //   910: astore          20
        //   912: aload           25
        //   914: ldc_w           "Timeout reached. Limit: "
        //   917: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   920: aload           22
        //   922: astore          21
        //   924: aload           19
        //   926: astore          20
        //   928: aload           25
        //   930: lload           7
        //   932: invokevirtual   java/lang/StringBuilder.append:(J)Ljava/lang/StringBuilder;
        //   935: pop            
        //   936: aload           22
        //   938: astore          21
        //   940: aload           19
        //   942: astore          20
        //   944: aload           25
        //   946: ldc_w           " ms"
        //   949: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   952: pop            
        //   953: aload           22
        //   955: astore          21
        //   957: aload           19
        //   959: astore          20
        //   961: aload           23
        //   963: aload           25
        //   965: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   968: invokespecial   java/io/IOException.<init>:(Ljava/lang/String;)V
        //   971: aload           22
        //   973: astore          21
        //   975: aload           19
        //   977: astore          20
        //   979: aload           23
        //   981: athrow         
        //   982: aload           22
        //   984: astore          21
        //   986: aload           19
        //   988: astore          20
        //   990: aload           28
        //   992: monitorexit    
        //   993: aload           23
        //   995: athrow         
        //   996: astore          20
        //   998: goto            1006
        //  1001: astore          20
        //  1003: goto            998
        //  1006: aload           24
        //  1008: getfield        hb4.x:Ljava/lang/String;
        //  1011: astore          25
        //  1013: aload           20
        //  1015: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //  1018: astore          23
        //  1020: new             Ljava/lang/StringBuilder;
        //  1023: dup            
        //  1024: ldc_w           "Failed to preload url "
        //  1027: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //  1030: astore          21
        //  1032: aload           21
        //  1034: aload           25
        //  1036: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1039: pop            
        //  1040: aload           21
        //  1042: ldc_w           " Exception: "
        //  1045: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1048: pop            
        //  1049: aload           21
        //  1051: aload           23
        //  1053: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1056: pop            
        //  1057: aload           21
        //  1059: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1062: invokestatic    d94.zzj:(Ljava/lang/String;)V
        //  1065: invokestatic    com/google/android/gms/ads/internal/zzt.zzo:()Lp84;
        //  1068: ldc_w           "VideoStreamExoPlayerCache.preload"
        //  1071: aload           20
        //  1073: invokevirtual   p84.f:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //  1076: aload           24
        //  1078: invokevirtual   hb4.release:()V
        //  1081: aload           22
        //  1083: aload           20
        //  1085: invokestatic    hb4.u:(Ljava/lang/String;Ljava/lang/Exception;)Ljava/lang/String;
        //  1088: astore          20
        //  1090: aload           24
        //  1092: aload           24
        //  1094: getfield        hb4.x:Ljava/lang/String;
        //  1097: aload           19
        //  1099: aload           22
        //  1101: aload           20
        //  1103: invokevirtual   eb4.l:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //  1106: invokestatic    com/google/android/gms/ads/internal/zzt.zzy:()Lza4;
        //  1109: astore          19
        //  1111: aload           24
        //  1113: getfield        hb4.P:Lwa4;
        //  1116: astore          20
        //  1118: aload           19
        //  1120: getfield        za4.c:Ljava/util/ArrayList;
        //  1123: aload           20
        //  1125: invokevirtual   java/util/ArrayList.remove:(Ljava/lang/Object;)Z
        //  1128: pop            
        //  1129: return         
        //  1130: invokestatic    com/google/android/gms/ads/internal/zzt.zzy:()Lza4;
        //  1133: getfield        za4.c:Ljava/util/ArrayList;
        //  1136: aload_0        
        //  1137: getfield        g7.n:Ljava/lang/Object;
        //  1140: checkcast       Lwa4;
        //  1143: invokevirtual   java/util/ArrayList.remove:(Ljava/lang/Object;)Z
        //  1146: pop            
        //  1147: return         
        //  1148: aload_0        
        //  1149: getfield        g7.n:Ljava/lang/Object;
        //  1152: checkcast       Ly94;
        //  1155: invokevirtual   y94.x:()V
        //  1158: return         
        //  1159: aload_0        
        //  1160: getfield        g7.n:Ljava/lang/Object;
        //  1163: checkcast       Lky3;
        //  1166: astore          19
        //  1168: aload           19
        //  1170: getfield        ky3.a:Lfy3;
        //  1173: ifnonnull       1179
        //  1176: goto            1190
        //  1179: aload           19
        //  1181: getfield        ky3.a:Lfy3;
        //  1184: invokevirtual   com/google/android/gms/common/internal/BaseGmsClient.disconnect:()V
        //  1187: invokestatic    android/os/Binder.flushPendingCommands:()V
        //  1190: return         
        //  1191: aload_0        
        //  1192: invokespecial   g7.g:()V
        //  1195: return         
        //  1196: aload_0        
        //  1197: invokespecial   g7.f:()V
        //  1200: return         
        //  1201: aload_0        
        //  1202: getfield        g7.n:Ljava/lang/Object;
        //  1205: checkcast       Lzp3;
        //  1208: invokestatic    zp3.b:(Lzp3;)V
        //  1211: return         
        //  1212: aload_0        
        //  1213: invokespecial   g7.e:()V
        //  1216: return         
        //  1217: aload_0        
        //  1218: getfield        g7.n:Ljava/lang/Object;
        //  1221: checkcast       Lpo3;
        //  1224: iconst_3       
        //  1225: invokevirtual   po3.c:(I)V
        //  1228: return         
        //  1229: aload_0        
        //  1230: getfield        g7.n:Ljava/lang/Object;
        //  1233: checkcast       Lzn3;
        //  1236: astore          19
        //  1238: aload           19
        //  1240: getfield        zn3.a:Ldn3;
        //  1243: astore          21
        //  1245: aload           21
        //  1247: getfield        dn3.c:Ldalvik/system/DexClassLoader;
        //  1250: astore          20
        //  1252: aload           21
        //  1254: getfield        dn3.e:[B
        //  1257: astore          23
        //  1259: aload           19
        //  1261: getfield        zn3.b:Ljava/lang/String;
        //  1264: astore          22
        //  1266: aload           21
        //  1268: getfield        dn3.d:Lxg1;
        //  1271: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //  1274: pop            
        //  1275: aload           22
        //  1277: aload           23
        //  1279: invokestatic    xg1.v:(Ljava/lang/String;[B)[B
        //  1282: astore          21
        //  1284: new             Ljava/lang/String;
        //  1287: astore          22
        //  1289: aload           22
        //  1291: aload           21
        //  1293: ldc_w           "UTF-8"
        //  1296: invokespecial   java/lang/String.<init>:([BLjava/lang/String;)V
        //  1299: aload           20
        //  1301: aload           22
        //  1303: invokevirtual   java/lang/ClassLoader.loadClass:(Ljava/lang/String;)Ljava/lang/Class;
        //  1306: astore          20
        //  1308: aload           20
        //  1310: ifnull          1400
        //  1313: aload           19
        //  1315: getfield        zn3.a:Ldn3;
        //  1318: astore          23
        //  1320: aload           23
        //  1322: getfield        dn3.e:[B
        //  1325: astore          21
        //  1327: aload           19
        //  1329: getfield        zn3.c:Ljava/lang/String;
        //  1332: astore          22
        //  1334: aload           23
        //  1336: getfield        dn3.d:Lxg1;
        //  1339: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //  1342: pop            
        //  1343: aload           22
        //  1345: aload           21
        //  1347: invokestatic    xg1.v:(Ljava/lang/String;[B)[B
        //  1350: astore          21
        //  1352: new             Ljava/lang/String;
        //  1355: astore          22
        //  1357: aload           22
        //  1359: aload           21
        //  1361: ldc_w           "UTF-8"
        //  1364: invokespecial   java/lang/String.<init>:([BLjava/lang/String;)V
        //  1367: aload           19
        //  1369: aload           20
        //  1371: aload           22
        //  1373: aload           19
        //  1375: getfield        zn3.e:[Ljava/lang/Class;
        //  1378: invokevirtual   java/lang/Class.getMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //  1381: putfield        zn3.d:Ljava/lang/reflect/Method;
        //  1384: goto            1400
        //  1387: astore          20
        //  1389: aload           19
        //  1391: getfield        zn3.f:Ljava/util/concurrent/CountDownLatch;
        //  1394: invokevirtual   java/util/concurrent/CountDownLatch.countDown:()V
        //  1397: aload           20
        //  1399: athrow         
        //  1400: aload           19
        //  1402: getfield        zn3.f:Ljava/util/concurrent/CountDownLatch;
        //  1405: invokevirtual   java/util/concurrent/CountDownLatch.countDown:()V
        //  1408: return         
        //  1409: aload_0        
        //  1410: getfield        g7.n:Ljava/lang/Object;
        //  1413: checkcast       Lhn3;
        //  1416: invokevirtual   hn3.c:()V
        //  1419: return         
        //  1420: aload_0        
        //  1421: invokespecial   g7.d:()V
        //  1424: return         
        //  1425: aload_0        
        //  1426: invokespecial   g7.c:()V
        //  1429: return         
        //  1430: aload_0        
        //  1431: invokespecial   g7.b:()V
        //  1434: return         
        //  1435: aload_0        
        //  1436: getfield        g7.n:Ljava/lang/Object;
        //  1439: checkcast       Landroidx/appcompat/widget/Toolbar;
        //  1442: getfield        androidx/appcompat/widget/Toolbar.c:Landroidx/appcompat/widget/ActionMenuView;
        //  1445: astore          19
        //  1447: aload           19
        //  1449: ifnull          1470
        //  1452: aload           19
        //  1454: getfield        androidx/appcompat/widget/ActionMenuView.d0:Lp2;
        //  1457: astore          19
        //  1459: aload           19
        //  1461: ifnull          1470
        //  1464: aload           19
        //  1466: invokevirtual   p2.k:()Z
        //  1469: pop            
        //  1470: return         
        //  1471: aload_0        
        //  1472: getfield        g7.n:Ljava/lang/Object;
        //  1475: checkcast       Ler1;
        //  1478: getfield        er1.a:Ljava/lang/Object;
        //  1481: astore          19
        //  1483: aload           19
        //  1485: dup            
        //  1486: astore          29
        //  1488: monitorenter   
        //  1489: aload_0        
        //  1490: getfield        g7.n:Ljava/lang/Object;
        //  1493: checkcast       Ler1;
        //  1496: getfield        er1.f:Ljava/lang/Object;
        //  1499: astore          20
        //  1501: aload_0        
        //  1502: getfield        g7.n:Ljava/lang/Object;
        //  1505: checkcast       Ler1;
        //  1508: getstatic       er1.k:Ljava/lang/Object;
        //  1511: putfield        er1.f:Ljava/lang/Object;
        //  1514: aload           29
        //  1516: monitorexit    
        //  1517: aload_0        
        //  1518: getfield        g7.n:Ljava/lang/Object;
        //  1521: checkcast       Ler1;
        //  1524: aload           20
        //  1526: invokevirtual   er1.h:(Ljava/lang/Object;)V
        //  1529: return         
        //  1530: astore          20
        //  1532: aload           29
        //  1534: monitorexit    
        //  1535: aload           20
        //  1537: athrow         
        //  1538: aload_0        
        //  1539: getfield        g7.n:Ljava/lang/Object;
        //  1542: checkcast       Lpq1;
        //  1545: astore          19
        //  1547: aload           19
        //  1549: aconst_null    
        //  1550: putfield        pq1.n:Ljava/util/ArrayList;
        //  1553: aload           19
        //  1555: aconst_null    
        //  1556: putfield        pq1.c:Ljava/util/ArrayList;
        //  1559: return         
        //  1560: aload_0        
        //  1561: getfield        g7.n:Ljava/lang/Object;
        //  1564: checkcast       Lol1;
        //  1567: getfield        ol1.c:Landroidx/work/impl/WorkDatabase_Impl;
        //  1570: getfield        ng2.h:Ljava/util/concurrent/locks/ReentrantReadWriteLock;
        //  1573: invokevirtual   java/util/concurrent/locks/ReentrantReadWriteLock.readLock:()Ljava/util/concurrent/locks/ReentrantReadWriteLock$ReadLock;
        //  1576: astore          23
        //  1578: aload           23
        //  1580: invokeinterface java/util/concurrent/locks/Lock.lock:()V
        //  1585: aload_0        
        //  1586: getfield        g7.n:Ljava/lang/Object;
        //  1589: checkcast       Lol1;
        //  1592: invokevirtual   ol1.a:()Z
        //  1595: istore          17
        //  1597: iload           17
        //  1599: ifne            1612
        //  1602: aload           23
        //  1604: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //  1609: goto            1932
        //  1612: aload_0        
        //  1613: getfield        g7.n:Ljava/lang/Object;
        //  1616: checkcast       Lol1;
        //  1619: getfield        ol1.d:Ljava/util/concurrent/atomic/AtomicBoolean;
        //  1622: iconst_1       
        //  1623: iconst_0       
        //  1624: invokevirtual   java/util/concurrent/atomic/AtomicBoolean.compareAndSet:(ZZ)Z
        //  1627: ifne            1633
        //  1630: goto            1602
        //  1633: aload_0        
        //  1634: getfield        g7.n:Ljava/lang/Object;
        //  1637: checkcast       Lol1;
        //  1640: getfield        ol1.c:Landroidx/work/impl/WorkDatabase_Impl;
        //  1643: getfield        ng2.c:Lmt2;
        //  1646: invokeinterface mt2.u:()Ljc1;
        //  1651: getfield        jc1.n:Ljava/lang/Object;
        //  1654: checkcast       Landroid/database/sqlite/SQLiteDatabase;
        //  1657: invokevirtual   android/database/sqlite/SQLiteDatabase.inTransaction:()Z
        //  1660: ifeq            1666
        //  1663: goto            1602
        //  1666: aload_0        
        //  1667: getfield        g7.n:Ljava/lang/Object;
        //  1670: checkcast       Lol1;
        //  1673: getfield        ol1.c:Landroidx/work/impl/WorkDatabase_Impl;
        //  1676: astore          19
        //  1678: aload           19
        //  1680: getfield        ng2.f:Z
        //  1683: ifeq            1803
        //  1686: aload           19
        //  1688: getfield        ng2.c:Lmt2;
        //  1691: invokeinterface mt2.u:()Ljc1;
        //  1696: astore          24
        //  1698: aload           24
        //  1700: invokevirtual   jc1.a:()V
        //  1703: aload_0        
        //  1704: invokevirtual   g7.a:()Ljava/util/HashSet;
        //  1707: astore          19
        //  1709: aload           24
        //  1711: invokevirtual   jc1.X:()V
        //  1714: aload           19
        //  1716: astore          20
        //  1718: aload           19
        //  1720: astore          21
        //  1722: aload           24
        //  1724: invokevirtual   jc1.F:()V
        //  1727: goto            1809
        //  1730: astore          19
        //  1732: goto            1933
        //  1735: astore          22
        //  1737: aload           20
        //  1739: astore          19
        //  1741: goto            1819
        //  1744: astore          22
        //  1746: aload           21
        //  1748: astore          19
        //  1750: goto            1819
        //  1753: astore          22
        //  1755: goto            1763
        //  1758: astore          22
        //  1760: aconst_null    
        //  1761: astore          19
        //  1763: aload           19
        //  1765: astore          20
        //  1767: aload           19
        //  1769: astore          21
        //  1771: aload           24
        //  1773: invokevirtual   jc1.F:()V
        //  1776: aload           19
        //  1778: astore          20
        //  1780: aload           19
        //  1782: astore          21
        //  1784: aload           22
        //  1786: athrow         
        //  1787: aconst_null    
        //  1788: astore          19
        //  1790: goto            1819
        //  1793: astore          22
        //  1795: goto            1787
        //  1798: astore          22
        //  1800: goto            1787
        //  1803: aload_0        
        //  1804: invokevirtual   g7.a:()Ljava/util/HashSet;
        //  1807: astore          19
        //  1809: aload           23
        //  1811: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //  1816: goto            1834
        //  1819: ldc_w           "ROOM"
        //  1822: ldc_w           "Cannot run invalidation tracker. Is the db closed?"
        //  1825: aload           22
        //  1827: invokestatic    android/util/Log.e:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //  1830: pop            
        //  1831: goto            1809
        //  1834: aload           19
        //  1836: ifnull          1932
        //  1839: aload           19
        //  1841: invokeinterface java/util/Set.isEmpty:()Z
        //  1846: ifne            1932
        //  1849: aload_0        
        //  1850: getfield        g7.n:Ljava/lang/Object;
        //  1853: checkcast       Lol1;
        //  1856: getfield        ol1.h:Lwh2;
        //  1859: astore          19
        //  1861: aload           19
        //  1863: dup            
        //  1864: astore          29
        //  1866: monitorenter   
        //  1867: aload_0        
        //  1868: getfield        g7.n:Ljava/lang/Object;
        //  1871: checkcast       Lol1;
        //  1874: getfield        ol1.h:Lwh2;
        //  1877: invokevirtual   wh2.iterator:()Ljava/util/Iterator;
        //  1880: checkcast       Lsh2;
        //  1883: astore          20
        //  1885: aload           20
        //  1887: invokevirtual   sh2.hasNext:()Z
        //  1890: ifne            1904
        //  1893: aload           29
        //  1895: monitorexit    
        //  1896: goto            1932
        //  1899: astore          20
        //  1901: goto            1926
        //  1904: aload           20
        //  1906: invokevirtual   sh2.next:()Ljava/lang/Object;
        //  1909: checkcast       Ljava/util/Map$Entry;
        //  1912: invokeinterface java/util/Map$Entry.getValue:()Ljava/lang/Object;
        //  1917: checkcast       Lnl1;
        //  1920: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //  1923: pop            
        //  1924: aconst_null    
        //  1925: athrow         
        //  1926: aload           29
        //  1928: monitorexit    
        //  1929: aload           20
        //  1931: athrow         
        //  1932: return         
        //  1933: aload           23
        //  1935: invokeinterface java/util/concurrent/locks/Lock.unlock:()V
        //  1940: aload           19
        //  1942: athrow         
        //  1943: aload_0        
        //  1944: getfield        g7.n:Ljava/lang/Object;
        //  1947: checkcast       Lw65;
        //  1950: astore          19
        //  1952: aload           19
        //  1954: getfield        w65.w:Ljava/lang/Object;
        //  1957: checkcast       Lng1;
        //  1960: getfield        ng1.c:Ljava/util/concurrent/atomic/AtomicReference;
        //  1963: aconst_null    
        //  1964: invokevirtual   java/util/concurrent/atomic/AtomicReference.getAndSet:(Ljava/lang/Object;)Ljava/lang/Object;
        //  1967: ifnull          1989
        //  1970: aload           19
        //  1972: getfield        w65.n:Ljava/lang/Object;
        //  1975: checkcast       Landroid/os/Handler;
        //  1978: aload           19
        //  1980: getfield        w65.w:Ljava/lang/Object;
        //  1983: checkcast       Lng1;
        //  1986: invokevirtual   android/os/Handler.removeCallbacks:(Ljava/lang/Runnable;)V
        //  1989: return         
        //  1990: aload_0        
        //  1991: getfield        g7.n:Ljava/lang/Object;
        //  1994: checkcast       Lyq1;
        //  1997: iconst_1       
        //  1998: invokeinterface java/util/concurrent/Future.cancel:(Z)Z
        //  2003: pop            
        //  2004: return         
        //  2005: aload_0        
        //  2006: getfield        g7.n:Ljava/lang/Object;
        //  2009: checkcast       Landroidx/fragment/app/m;
        //  2012: invokevirtual   androidx/fragment/app/m.d:()V
        //  2015: aconst_null    
        //  2016: athrow         
        //  2017: aload_0        
        //  2018: getfield        g7.n:Ljava/lang/Object;
        //  2021: checkcast       Landroidx/fragment/app/l;
        //  2024: invokevirtual   androidx/fragment/app/l.startPostponedEnterTransition:()V
        //  2027: return         
        //  2028: aload_0        
        //  2029: getfield        g7.n:Ljava/lang/Object;
        //  2032: checkcast       Lq01;
        //  2035: astore          19
        //  2037: aload           19
        //  2039: aconst_null    
        //  2040: putfield        q01.T:Lg7;
        //  2043: aload           19
        //  2045: invokevirtual   q01.drawableStateChanged:()V
        //  2048: return         
        //  2049: aload_0        
        //  2050: getfield        g7.n:Ljava/lang/Object;
        //  2053: checkcast       Landroidx/fragment/app/i;
        //  2056: astore          19
        //  2058: aload           19
        //  2060: invokestatic    androidx/fragment/app/i.access$100:(Landroidx/fragment/app/i;)Landroid/content/DialogInterface$OnDismissListener;
        //  2063: aload           19
        //  2065: invokestatic    androidx/fragment/app/i.access$000:(Landroidx/fragment/app/i;)Landroid/app/Dialog;
        //  2068: invokeinterface android/content/DialogInterface$OnDismissListener.onDismiss:(Landroid/content/DialogInterface;)V
        //  2073: return         
        //  2074: aload_0        
        //  2075: getfield        g7.n:Ljava/lang/Object;
        //  2078: checkcast       Landroidx/fragment/app/g;
        //  2081: invokevirtual   androidx/fragment/app/f.a:()V
        //  2084: return         
        //  2085: iconst_4       
        //  2086: aload_0        
        //  2087: getfield        g7.n:Ljava/lang/Object;
        //  2090: checkcast       Ljava/util/ArrayList;
        //  2093: invokestatic    bc1.b:(ILjava/util/ArrayList;)V
        //  2096: return         
        //  2097: aload_0        
        //  2098: getfield        g7.n:Ljava/lang/Object;
        //  2101: checkcast       Lbv0;
        //  2104: astore          19
        //  2106: aload           19
        //  2108: getfield        bv0.a:Landroid/view/ViewGroup;
        //  2111: aload           19
        //  2113: getfield        bv0.b:Landroid/view/View;
        //  2116: invokevirtual   android/view/ViewGroup.endViewTransition:(Landroid/view/View;)V
        //  2119: aload           19
        //  2121: getfield        bv0.c:Landroidx/fragment/app/e;
        //  2124: invokevirtual   androidx/fragment/app/f.a:()V
        //  2127: return         
        //  2128: aload_0        
        //  2129: getfield        g7.n:Ljava/lang/Object;
        //  2132: checkcast       Landroidx/work/impl/workers/ConstraintTrackingWorker;
        //  2135: astore          20
        //  2137: aload           20
        //  2139: invokevirtual   androidx/work/ListenableWorker.getInputData:()Lwt0;
        //  2142: getfield        wt0.a:Ljava/util/HashMap;
        //  2145: ldc_w           "androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME"
        //  2148: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //  2151: astore          21
        //  2153: aload           21
        //  2155: instanceof      Ljava/lang/String;
        //  2158: ifeq            2168
        //  2161: aload           21
        //  2163: checkcast       Ljava/lang/String;
        //  2166: astore          19
        //  2168: aload           19
        //  2170: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //  2173: ifeq            2215
        //  2176: invokestatic    fs1.e:()Lfs1;
        //  2179: getstatic       androidx/work/impl/workers/ConstraintTrackingWorker.y:Ljava/lang/String;
        //  2182: ldc_w           "No worker to delegate to."
        //  2185: iconst_0       
        //  2186: anewarray       Ljava/lang/Throwable;
        //  2189: invokevirtual   fs1.d:(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Throwable;)V
        //  2192: new             Lzq1;
        //  2195: dup            
        //  2196: invokespecial   zq1.<init>:()V
        //  2199: astore          19
        //  2201: aload           20
        //  2203: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.w:Landroidx/work/impl/utils/futures/b;
        //  2206: aload           19
        //  2208: invokevirtual   androidx/work/impl/utils/futures/b.j:(Ljava/lang/Object;)Z
        //  2211: pop            
        //  2212: goto            2616
        //  2215: aload           20
        //  2217: invokevirtual   androidx/work/ListenableWorker.getWorkerFactory:()Lcc3;
        //  2220: aload           20
        //  2222: invokevirtual   androidx/work/ListenableWorker.getApplicationContext:()Landroid/content/Context;
        //  2225: aload           19
        //  2227: aload           20
        //  2229: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.c:Landroidx/work/WorkerParameters;
        //  2232: invokevirtual   cc3.a:(Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Landroidx/work/ListenableWorker;
        //  2235: astore          19
        //  2237: aload           20
        //  2239: aload           19
        //  2241: putfield        androidx/work/impl/workers/ConstraintTrackingWorker.x:Landroidx/work/ListenableWorker;
        //  2244: aload           19
        //  2246: ifnonnull       2291
        //  2249: invokestatic    fs1.e:()Lfs1;
        //  2252: astore          19
        //  2254: getstatic       androidx/work/impl/workers/ConstraintTrackingWorker.y:Ljava/lang/String;
        //  2257: astore          21
        //  2259: aload           19
        //  2261: iconst_0       
        //  2262: anewarray       Ljava/lang/Throwable;
        //  2265: invokevirtual   fs1.a:([Ljava/lang/Throwable;)V
        //  2268: new             Lzq1;
        //  2271: dup            
        //  2272: invokespecial   zq1.<init>:()V
        //  2275: astore          19
        //  2277: aload           20
        //  2279: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.w:Landroidx/work/impl/utils/futures/b;
        //  2282: aload           19
        //  2284: invokevirtual   androidx/work/impl/utils/futures/b.j:(Ljava/lang/Object;)Z
        //  2287: pop            
        //  2288: goto            2616
        //  2291: aload           20
        //  2293: invokevirtual   androidx/work/ListenableWorker.getApplicationContext:()Landroid/content/Context;
        //  2296: invokestatic    ob3.b:(Landroid/content/Context;)Lob3;
        //  2299: getfield        ob3.c:Landroidx/work/impl/WorkDatabase;
        //  2302: invokevirtual   androidx/work/impl/WorkDatabase.n:()Lvb3;
        //  2305: aload           20
        //  2307: invokevirtual   androidx/work/ListenableWorker.getId:()Ljava/util/UUID;
        //  2310: invokevirtual   java/util/UUID.toString:()Ljava/lang/String;
        //  2313: invokevirtual   vb3.h:(Ljava/lang/String;)Lub3;
        //  2316: astore          21
        //  2318: aload           21
        //  2320: ifnonnull       2346
        //  2323: new             Lzq1;
        //  2326: dup            
        //  2327: invokespecial   zq1.<init>:()V
        //  2330: astore          19
        //  2332: aload           20
        //  2334: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.w:Landroidx/work/impl/utils/futures/b;
        //  2337: aload           19
        //  2339: invokevirtual   androidx/work/impl/utils/futures/b.j:(Ljava/lang/Object;)Z
        //  2342: pop            
        //  2343: goto            2616
        //  2346: new             Leb3;
        //  2349: dup            
        //  2350: aload           20
        //  2352: invokevirtual   androidx/work/ListenableWorker.getApplicationContext:()Landroid/content/Context;
        //  2355: aload           20
        //  2357: invokevirtual   androidx/work/impl/workers/ConstraintTrackingWorker.getTaskExecutor:()Lhw2;
        //  2360: aload           20
        //  2362: invokespecial   eb3.<init>:(Landroid/content/Context;Lhw2;Ldb3;)V
        //  2365: astore          19
        //  2367: aload           19
        //  2369: aload           21
        //  2371: invokestatic    java/util/Collections.singletonList:(Ljava/lang/Object;)Ljava/util/List;
        //  2374: checkcast       Ljava/util/Collection;
        //  2377: invokevirtual   eb3.b:(Ljava/util/Collection;)V
        //  2380: aload           19
        //  2382: aload           20
        //  2384: invokevirtual   androidx/work/ListenableWorker.getId:()Ljava/util/UUID;
        //  2387: invokevirtual   java/util/UUID.toString:()Ljava/lang/String;
        //  2390: invokevirtual   eb3.a:(Ljava/lang/String;)Z
        //  2393: ifeq            2577
        //  2396: invokestatic    fs1.e:()Lfs1;
        //  2399: astore          19
        //  2401: getstatic       androidx/work/impl/workers/ConstraintTrackingWorker.y:Ljava/lang/String;
        //  2404: astore          21
        //  2406: aload           19
        //  2408: iconst_0       
        //  2409: anewarray       Ljava/lang/Throwable;
        //  2412: invokevirtual   fs1.a:([Ljava/lang/Throwable;)V
        //  2415: aload           20
        //  2417: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.x:Landroidx/work/ListenableWorker;
        //  2420: invokevirtual   androidx/work/ListenableWorker.startWork:()Lyq1;
        //  2423: astore          21
        //  2425: new             Lmz4;
        //  2428: astore          19
        //  2430: aload           19
        //  2432: iconst_2       
        //  2433: aload           20
        //  2435: iconst_0       
        //  2436: aload           21
        //  2438: invokespecial   mz4.<init>:(ILjava/lang/Object;ZLjava/lang/Object;)V
        //  2441: aload           21
        //  2443: aload           19
        //  2445: aload           20
        //  2447: invokevirtual   androidx/work/ListenableWorker.getBackgroundExecutor:()Ljava/util/concurrent/Executor;
        //  2450: invokeinterface yq1.addListener:(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
        //  2455: goto            2616
        //  2458: astore          22
        //  2460: invokestatic    fs1.e:()Lfs1;
        //  2463: astore          21
        //  2465: getstatic       androidx/work/impl/workers/ConstraintTrackingWorker.y:Ljava/lang/String;
        //  2468: astore          19
        //  2470: aload           21
        //  2472: iconst_1       
        //  2473: anewarray       Ljava/lang/Throwable;
        //  2476: dup            
        //  2477: iconst_0       
        //  2478: aload           22
        //  2480: aastore        
        //  2481: invokevirtual   fs1.a:([Ljava/lang/Throwable;)V
        //  2484: aload           20
        //  2486: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.n:Ljava/lang/Object;
        //  2489: astore          19
        //  2491: aload           19
        //  2493: dup            
        //  2494: astore          29
        //  2496: monitorenter   
        //  2497: aload           20
        //  2499: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.v:Z
        //  2502: ifeq            2544
        //  2505: invokestatic    fs1.e:()Lfs1;
        //  2508: iconst_0       
        //  2509: anewarray       Ljava/lang/Throwable;
        //  2512: invokevirtual   fs1.a:([Ljava/lang/Throwable;)V
        //  2515: new             Lar1;
        //  2518: astore          21
        //  2520: aload           21
        //  2522: invokespecial   java/lang/Object.<init>:()V
        //  2525: aload           20
        //  2527: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.w:Landroidx/work/impl/utils/futures/b;
        //  2530: aload           21
        //  2532: invokevirtual   androidx/work/impl/utils/futures/b.j:(Ljava/lang/Object;)Z
        //  2535: pop            
        //  2536: goto            2565
        //  2539: astore          20
        //  2541: goto            2571
        //  2544: new             Lzq1;
        //  2547: astore          21
        //  2549: aload           21
        //  2551: invokespecial   zq1.<init>:()V
        //  2554: aload           20
        //  2556: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.w:Landroidx/work/impl/utils/futures/b;
        //  2559: aload           21
        //  2561: invokevirtual   androidx/work/impl/utils/futures/b.j:(Ljava/lang/Object;)Z
        //  2564: pop            
        //  2565: aload           29
        //  2567: monitorexit    
        //  2568: goto            2616
        //  2571: aload           29
        //  2573: monitorexit    
        //  2574: aload           20
        //  2576: athrow         
        //  2577: invokestatic    fs1.e:()Lfs1;
        //  2580: astore          19
        //  2582: getstatic       androidx/work/impl/workers/ConstraintTrackingWorker.y:Ljava/lang/String;
        //  2585: astore          21
        //  2587: aload           19
        //  2589: iconst_0       
        //  2590: anewarray       Ljava/lang/Throwable;
        //  2593: invokevirtual   fs1.a:([Ljava/lang/Throwable;)V
        //  2596: new             Ljava/lang/Object;
        //  2599: dup            
        //  2600: invokespecial   java/lang/Object.<init>:()V
        //  2603: astore          19
        //  2605: aload           20
        //  2607: getfield        androidx/work/impl/workers/ConstraintTrackingWorker.w:Landroidx/work/impl/utils/futures/b;
        //  2610: aload           19
        //  2612: invokevirtual   androidx/work/impl/utils/futures/b.j:(Ljava/lang/Object;)Z
        //  2615: pop            
        //  2616: return         
        //  2617: aload_0        
        //  2618: getfield        g7.n:Ljava/lang/Object;
        //  2621: checkcast       Lxq1;
        //  2624: astore          21
        //  2626: aload           21
        //  2628: getfield        xq1.W:Z
        //  2631: ifne            2637
        //  2634: goto            2887
        //  2637: aload           21
        //  2639: getfield        xq1.U:Z
        //  2642: istore          17
        //  2644: aload           21
        //  2646: getfield        xq1.c:Lwc;
        //  2649: astore          20
        //  2651: iload           17
        //  2653: ifeq            2697
        //  2656: aload           21
        //  2658: iconst_0       
        //  2659: putfield        xq1.U:Z
        //  2662: invokestatic    android/view/animation/AnimationUtils.currentAnimationTimeMillis:()J
        //  2665: lstore          5
        //  2667: aload           20
        //  2669: lload           5
        //  2671: putfield        wc.e:J
        //  2674: aload           20
        //  2676: ldc2_w          -1
        //  2679: putfield        wc.g:J
        //  2682: aload           20
        //  2684: lload           5
        //  2686: putfield        wc.f:J
        //  2689: aload           20
        //  2691: ldc_w           0.5
        //  2694: putfield        wc.h:F
        //  2697: aload           20
        //  2699: getfield        wc.g:J
        //  2702: lconst_0       
        //  2703: lcmp           
        //  2704: ifle            2729
        //  2707: invokestatic    android/view/animation/AnimationUtils.currentAnimationTimeMillis:()J
        //  2710: aload           20
        //  2712: getfield        wc.g:J
        //  2715: aload           20
        //  2717: getfield        wc.i:I
        //  2720: i2l            
        //  2721: ladd           
        //  2722: lcmp           
        //  2723: ifle            2729
        //  2726: goto            2737
        //  2729: aload           21
        //  2731: invokevirtual   xq1.e:()Z
        //  2734: ifne            2746
        //  2737: aload           21
        //  2739: iconst_0       
        //  2740: putfield        xq1.W:Z
        //  2743: goto            2887
        //  2746: aload           21
        //  2748: getfield        xq1.V:Z
        //  2751: istore          17
        //  2753: aload           21
        //  2755: getfield        xq1.v:Landroid/widget/ListView;
        //  2758: astore          19
        //  2760: iload           17
        //  2762: ifeq            2802
        //  2765: aload           21
        //  2767: iconst_0       
        //  2768: putfield        xq1.V:Z
        //  2771: invokestatic    android/os/SystemClock.uptimeMillis:()J
        //  2774: lstore          5
        //  2776: lload           5
        //  2778: lload           5
        //  2780: iconst_3       
        //  2781: fconst_0       
        //  2782: fconst_0       
        //  2783: iconst_0       
        //  2784: invokestatic    android/view/MotionEvent.obtain:(JJIFFI)Landroid/view/MotionEvent;
        //  2787: astore          22
        //  2789: aload           19
        //  2791: aload           22
        //  2793: invokevirtual   android/view/View.onTouchEvent:(Landroid/view/MotionEvent;)Z
        //  2796: pop            
        //  2797: aload           22
        //  2799: invokevirtual   android/view/MotionEvent.recycle:()V
        //  2802: aload           20
        //  2804: getfield        wc.f:J
        //  2807: lconst_0       
        //  2808: lcmp           
        //  2809: ifeq            2888
        //  2812: invokestatic    android/view/animation/AnimationUtils.currentAnimationTimeMillis:()J
        //  2815: lstore          5
        //  2817: aload           20
        //  2819: lload           5
        //  2821: invokevirtual   wc.a:(J)F
        //  2824: fstore_1       
        //  2825: aload           20
        //  2827: getfield        wc.f:J
        //  2830: lstore          7
        //  2832: aload           20
        //  2834: lload           5
        //  2836: putfield        wc.f:J
        //  2839: lload           5
        //  2841: lload           7
        //  2843: lsub           
        //  2844: l2f            
        //  2845: fload_1        
        //  2846: ldc_w           4.0
        //  2849: fmul           
        //  2850: ldc_w           -4.0
        //  2853: fload_1        
        //  2854: fmul           
        //  2855: fload_1        
        //  2856: fmul           
        //  2857: fadd           
        //  2858: fmul           
        //  2859: aload           20
        //  2861: getfield        wc.d:F
        //  2864: fmul           
        //  2865: f2i            
        //  2866: istore_2       
        //  2867: aload           21
        //  2869: getfield        xq1.Y:Lq01;
        //  2872: iload_2        
        //  2873: invokevirtual   android/widget/AbsListView.scrollListBy:(I)V
        //  2876: getstatic       q73.a:Ljava/lang/reflect/Field;
        //  2879: astore          20
        //  2881: aload           19
        //  2883: aload_0        
        //  2884: invokevirtual   android/view/View.postOnAnimation:(Ljava/lang/Runnable;)V
        //  2887: return         
        //  2888: new             Ljava/lang/RuntimeException;
        //  2891: dup            
        //  2892: ldc_w           "Cannot compute scroll delta before calling start()"
        //  2895: invokespecial   java/lang/RuntimeException.<init>:(Ljava/lang/String;)V
        //  2898: athrow         
        //  2899: aload_0        
        //  2900: getfield        g7.n:Ljava/lang/Object;
        //  2903: checkcast       Landroid/content/Context;
        //  2906: astore          20
        //  2908: aload           20
        //  2910: invokestatic    android/appwidget/AppWidgetManager.getInstance:(Landroid/content/Context;)Landroid/appwidget/AppWidgetManager;
        //  2913: astore          19
        //  2915: aload           19
        //  2917: new             Landroid/content/ComponentName;
        //  2920: dup            
        //  2921: aload           20
        //  2923: ldc_w           Lcom/smarttools/nktech/widgets/AnalogClockWidget;.class
        //  2926: invokespecial   android/content/ComponentName.<init>:(Landroid/content/Context;Ljava/lang/Class;)V
        //  2929: invokevirtual   android/appwidget/AppWidgetManager.getAppWidgetIds:(Landroid/content/ComponentName;)[I
        //  2932: astore          22
        //  2934: aload           22
        //  2936: arraylength    
        //  2937: istore_3       
        //  2938: iload_2        
        //  2939: iload_3        
        //  2940: if_icmpge       2969
        //  2943: aload           22
        //  2945: iload_2        
        //  2946: iaload         
        //  2947: istore          4
        //  2949: getstatic       com/smarttools/nktech/widgets/AnalogClockWidget.a:Landroid/os/Handler;
        //  2952: astore          21
        //  2954: aload           20
        //  2956: aload           19
        //  2958: iload           4
        //  2960: invokestatic    qq.m:(Landroid/content/Context;Landroid/appwidget/AppWidgetManager;I)V
        //  2963: iinc            2, 1
        //  2966: goto            2938
        //  2969: getstatic       com/smarttools/nktech/widgets/AnalogClockWidget.a:Landroid/os/Handler;
        //  2972: aload_0        
        //  2973: ldc2_w          1000
        //  2976: invokevirtual   android/os/Handler.postDelayed:(Ljava/lang/Runnable;J)Z
        //  2979: pop            
        //  2980: return         
        //  2981: astore          20
        //  2983: goto            1400
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  168    242    1001   1006   Ljava/lang/Exception;
        //  242    281    575    580    Any
        //  284    294    575    580    Any
        //  310    317    575    580    Any
        //  324    348    575    580    Any
        //  364    371    575    580    Any
        //  376    402    575    580    Any
        //  405    413    575    580    Any
        //  426    436    575    580    Any
        //  449    459    575    580    Any
        //  467    491    575    580    Any
        //  503    528    562    575    Any
        //  536    544    562    575    Any
        //  552    559    562    575    Any
        //  600    607    562    575    Any
        //  615    620    562    575    Any
        //  628    633    562    575    Any
        //  641    654    562    575    Any
        //  662    670    562    575    Any
        //  678    681    562    575    Any
        //  692    707    562    575    Any
        //  722    725    562    575    Any
        //  736    739    562    575    Any
        //  796    801    562    575    Any
        //  809    817    562    575    Any
        //  825    828    562    575    Any
        //  841    846    562    575    Any
        //  854    862    562    575    Any
        //  870    873    562    575    Any
        //  886    891    562    575    Any
        //  899    904    562    575    Any
        //  912    920    562    575    Any
        //  928    936    562    575    Any
        //  944    953    562    575    Any
        //  961    971    562    575    Any
        //  979    982    562    575    Any
        //  990    993    562    575    Any
        //  993    996    996    998    Ljava/lang/Exception;
        //  1238   1308   2981   2986   Lcom/google/android/gms/internal/ads/zzasn;
        //  1238   1308   2981   2986   Ljava/io/UnsupportedEncodingException;
        //  1238   1308   2981   2986   Ljava/lang/ClassNotFoundException;
        //  1238   1308   2981   2986   Ljava/lang/NoSuchMethodException;
        //  1238   1308   2981   2986   Ljava/lang/NullPointerException;
        //  1238   1308   1387   1400   Any
        //  1313   1384   2981   2986   Lcom/google/android/gms/internal/ads/zzasn;
        //  1313   1384   2981   2986   Ljava/io/UnsupportedEncodingException;
        //  1313   1384   2981   2986   Ljava/lang/ClassNotFoundException;
        //  1313   1384   2981   2986   Ljava/lang/NoSuchMethodException;
        //  1313   1384   2981   2986   Ljava/lang/NullPointerException;
        //  1313   1384   1387   1400   Any
        //  1489   1517   1530   1538   Any
        //  1532   1535   1530   1538   Any
        //  1578   1597   1798   1803   Ljava/lang/IllegalStateException;
        //  1578   1597   1793   1798   Landroid/database/sqlite/SQLiteException;
        //  1578   1597   1730   1735   Any
        //  1612   1630   1798   1803   Ljava/lang/IllegalStateException;
        //  1612   1630   1793   1798   Landroid/database/sqlite/SQLiteException;
        //  1612   1630   1730   1735   Any
        //  1633   1663   1798   1803   Ljava/lang/IllegalStateException;
        //  1633   1663   1793   1798   Landroid/database/sqlite/SQLiteException;
        //  1633   1663   1730   1735   Any
        //  1666   1703   1798   1803   Ljava/lang/IllegalStateException;
        //  1666   1703   1793   1798   Landroid/database/sqlite/SQLiteException;
        //  1666   1703   1730   1735   Any
        //  1703   1709   1758   1763   Any
        //  1709   1714   1753   1758   Any
        //  1722   1727   1744   1753   Ljava/lang/IllegalStateException;
        //  1722   1727   1735   1744   Landroid/database/sqlite/SQLiteException;
        //  1722   1727   1730   1735   Any
        //  1771   1776   1744   1753   Ljava/lang/IllegalStateException;
        //  1771   1776   1735   1744   Landroid/database/sqlite/SQLiteException;
        //  1771   1776   1730   1735   Any
        //  1784   1787   1744   1753   Ljava/lang/IllegalStateException;
        //  1784   1787   1735   1744   Landroid/database/sqlite/SQLiteException;
        //  1784   1787   1730   1735   Any
        //  1803   1809   1798   1803   Ljava/lang/IllegalStateException;
        //  1803   1809   1793   1798   Landroid/database/sqlite/SQLiteException;
        //  1803   1809   1730   1735   Any
        //  1819   1831   1730   1735   Any
        //  1867   1896   1899   1932   Any
        //  1904   1926   1899   1932   Any
        //  1926   1929   1899   1932   Any
        //  2415   2455   2458   2577   Any
        //  2497   2536   2539   2577   Any
        //  2544   2565   2539   2577   Any
        //  2565   2568   2539   2577   Any
        //  2571   2574   2539   2577   Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 1272, Size: 1272
        //     at java.util.ArrayList.get(ArrayList.java:437)
        //     at q5.g.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at q5.g.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2125)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:21)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
