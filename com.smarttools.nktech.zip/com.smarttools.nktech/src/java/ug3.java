public final class ug3 implements yg3, ef3
{
    public final long a;
    public final long b;
    public final int c;
    public final long d;
    public final int e;
    public final long f;
    
    public ug3(long f, final long b, final q93 q93) {
        final int e = q93.e;
        final int b2 = q93.b;
        this.a = f;
        this.b = b;
        int c = b2;
        if (b2 == -1) {
            c = 1;
        }
        this.c = c;
        this.e = e;
        if (f == -1L) {
            this.d = -1L;
            f = -9223372036854775807L;
        }
        else {
            f -= b;
            this.d = f;
            f = Math.max(0L, f) * 8000000L / e;
        }
        this.f = f;
    }
    
    public final df3 a(long n) {
        final long d = this.d;
        final long n2 = lcmp(d, -1L);
        final long b = this.b;
        if (n2 != 0) {
            final int e = this.e;
            final long n3 = e * n / 8000000L;
            final long n4 = this.c;
            long min = n3 / n4 * n4;
            if (n2 != 0) {
                min = Math.min(min, d - n4);
            }
            final long n5 = Math.max(min, 0L) + b;
            final long n6 = Math.max(0L, n5 - b) * 8000000L / e;
            final ff3 ff3 = new ff3(n6, n5);
            if (n2 != 0 && n6 < n) {
                n = n5 + n4;
                if (n < this.a) {
                    return new df3(ff3, new ff3(Math.max(0L, n - b) * 8000000L / e, n));
                }
            }
            return new df3(ff3, ff3);
        }
        final ff3 ff4 = new ff3(0L, b);
        return new df3(ff4, ff4);
    }
    
    public final long b(final long n) {
        return Math.max(0L, n - this.b) * 8000000L / this.e;
    }
    
    public final long zza() {
        return this.f;
    }
    
    public final long zzc() {
        return -1L;
    }
    
    public final boolean zzh() {
        return this.d != -1L;
    }
}
