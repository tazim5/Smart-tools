public final class dq3 extends go3
{
}
