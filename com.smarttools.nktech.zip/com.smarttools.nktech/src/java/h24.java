import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zze;

public final class h24 extends go3 implements i24
{
    public final void B(final zze zze) {
        final Parcel zza = this.zza();
        io3.c(zza, (Parcelable)zze);
        this.zzbi(3, zza);
    }
    
    public final void a(final String s) {
        final Parcel zza = this.zza();
        zza.writeString(s);
        this.zzbi(1, zza);
    }
    
    public final void f(final String s) {
        final Parcel zza = this.zza();
        zza.writeString(s);
        this.zzbi(2, zza);
    }
}
