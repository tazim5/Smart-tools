import kotlin.collections.builders.MapBuilder;
import java.util.Map$Entry;

public final class ht1 implements Map$Entry, on1
{
    public final MapBuilder c;
    public final int n;
    
    public ht1(final MapBuilder c, final int n) {
        this.c = c;
        this.n = n;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (o instanceof Map$Entry) {
            final Map$Entry map$Entry = (Map$Entry)o;
            if (kl1.b(map$Entry.getKey(), this.getKey()) && kl1.b(map$Entry.getValue(), this.getValue())) {
                return true;
            }
        }
        return false;
    }
    
    public final Object getKey() {
        return MapBuilder.a(this.c)[this.n];
    }
    
    public final Object getValue() {
        return MapBuilder.e(this.c)[this.n];
    }
    
    @Override
    public final int hashCode() {
        final Object key = this.getKey();
        int hashCode = 0;
        int hashCode2;
        if (key != null) {
            hashCode2 = key.hashCode();
        }
        else {
            hashCode2 = 0;
        }
        final Object value = this.getValue();
        if (value != null) {
            hashCode = value.hashCode();
        }
        return hashCode2 ^ hashCode;
    }
    
    public final Object setValue(final Object o) {
        final MapBuilder c = this.c;
        c.i();
        final Object[] g = c.g();
        final int n = this.n;
        final Object o2 = g[n];
        g[n] = o;
        return o2;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.getKey());
        sb.append('=');
        sb.append(this.getValue());
        return sb.toString();
    }
}
