import android.graphics.ColorFilter;
import android.graphics.Outline;
import android.graphics.Canvas;
import androidx.appcompat.widget.ActionBarContainer;
import android.graphics.drawable.Drawable;

public final class f2 extends Drawable
{
    public final ActionBarContainer a;
    
    public f2(final ActionBarContainer a) {
        this.a = a;
    }
    
    public final void draw(final Canvas canvas) {
        final ActionBarContainer a = this.a;
        if (a.z) {
            final Drawable y = a.y;
            if (y != null) {
                y.draw(canvas);
            }
        }
        else {
            final Drawable w = a.w;
            if (w != null) {
                w.draw(canvas);
            }
            final Drawable x = a.x;
            if (x != null && a.P) {
                x.draw(canvas);
            }
        }
    }
    
    public final int getOpacity() {
        return 0;
    }
    
    public final void getOutline(final Outline outline) {
        final ActionBarContainer a = this.a;
        if (a.z) {
            if (a.y != null) {
                a.w.getOutline(outline);
            }
        }
        else {
            final Drawable w = a.w;
            if (w != null) {
                w.getOutline(outline);
            }
        }
    }
    
    public final void setAlpha(final int n) {
    }
    
    public final void setColorFilter(final ColorFilter colorFilter) {
    }
}
