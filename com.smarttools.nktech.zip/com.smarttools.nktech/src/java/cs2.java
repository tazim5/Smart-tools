import com.google.android.gms.common.internal.Preconditions;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.concurrent.locks.ReentrantLock;

public final class cs2
{
    public static final ReentrantLock c;
    public static cs2 d;
    public final ReentrantLock a;
    public final SharedPreferences b;
    
    static {
        c = new ReentrantLock();
    }
    
    public cs2(final Context context) {
        this.a = new ReentrantLock();
        this.b = context.getSharedPreferences("com.google.android.gms.signin", 0);
    }
    
    public static cs2 a(final Context context) {
        Preconditions.checkNotNull((Object)context);
        final ReentrantLock c = cs2.c;
        c.lock();
        Label_0052: {
            try {
                if (cs2.d == null) {
                    cs2.d = new cs2(context.getApplicationContext());
                }
            }
            finally {
                break Label_0052;
            }
            final cs2 d = cs2.d;
            c.unlock();
            return d;
        }
        c.unlock();
    }
    
    public static final String d(final String s, final String s2) {
        return az0.f(s, ":", s2);
    }
    
    public final String b(String string) {
        final ReentrantLock a = this.a;
        a.lock();
        try {
            string = this.b.getString(string, (String)null);
            return string;
        }
        finally {
            a.unlock();
        }
    }
    
    public final void c(final String s) {
        final ReentrantLock a = this.a;
        a.lock();
        try {
            this.b.edit().remove(s).apply();
        }
        finally {
            a.unlock();
        }
    }
}
