public abstract class y1 extends cs5
{
}
