import android.os.RemoteException;
import android.os.Bundle;
import android.os.Parcel;

public abstract class zh3 extends em3 implements oi3
{
    @Override
    public final boolean zzb(final int n, final Parcel parcel, final Parcel parcel2, final int n2) throws RemoteException {
        if (n == 1) {
            final Bundle bundle = (Bundle)lm3.a(parcel, Bundle.CREATOR);
            lm3.b(parcel);
            this.zza(bundle);
            return true;
        }
        return false;
    }
}
