import android.view.View;
import androidx.appcompat.widget.SearchView;
import android.widget.Filter$FilterResults;
import android.database.Cursor;
import android.widget.Filter;

public final class mt0 extends Filter
{
    public lt0 a;
    
    public final CharSequence convertResultToString(final Object o) {
        return (CharSequence)((gt2)this.a).c((Cursor)o);
    }
    
    public final Filter$FilterResults performFiltering(final CharSequence charSequence) {
        final gt2 gt2 = (gt2)this.a;
        String string;
        if (charSequence == null) {
            string = "";
        }
        else {
            gt2.getClass();
            string = charSequence.toString();
        }
        final SearchView s = gt2.S;
        while (true) {
            if (((View)s).getVisibility() != 0) {
                break Label_0076;
            }
            if (((View)s).getWindowVisibility() != 0) {
                break Label_0076;
            }
            try {
                Cursor g = gt2.g(gt2.T, string);
                if (g != null) {
                    g.getCount();
                }
                else {
                    g = null;
                }
                final Filter$FilterResults filter$FilterResults = new Filter$FilterResults();
                if (g != null) {
                    filter$FilterResults.count = g.getCount();
                    filter$FilterResults.values = g;
                }
                else {
                    filter$FilterResults.count = 0;
                    filter$FilterResults.values = null;
                }
                return filter$FilterResults;
            }
            catch (final RuntimeException ex) {
                continue;
            }
            break;
        }
    }
    
    public final void publishResults(final CharSequence charSequence, final Filter$FilterResults filter$FilterResults) {
        final lt0 a = this.a;
        final Cursor v = a.v;
        final Object values = filter$FilterResults.values;
        if (values != null && values != v) {
            ((gt2)a).b((Cursor)values);
        }
    }
}
