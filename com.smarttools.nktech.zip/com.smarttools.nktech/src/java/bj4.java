import com.google.android.gms.ads.internal.client.zze;
import com.google.android.gms.internal.ads.zzdif;

public interface bj4
{
    void L(final zzdif p0);
    
    void g(final zze p0);
    
    void zzb();
}
