import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;

public final class s90 implements od1
{
    public static final s90 c;
    
    static {
        c = (s90)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            ap.l((float)8, Modifier.Companion, composer, 6);
        }
        return t43.a;
    }
}
