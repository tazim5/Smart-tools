import java.util.concurrent.Executor;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.internal.ads.e;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.zzt;
import java.util.Iterator;
import java.util.ArrayList;
import com.google.android.gms.internal.ads.l2;

public final class s65
{
    public final l2 a;
    public final e65 b;
    public final gx4 c;
    public final d95 d;
    public final v85 e;
    public final df4 f;
    
    public s65(final gx4 c, final d95 d, final l2 a, final e65 b, final df4 f, final v85 e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.f = f;
        this.e = e;
    }
    
    public final void a(final ArrayList list) {
        final Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            this.b(2, (String)iterator.next());
        }
    }
    
    public final void b(final int n, final String s) {
        if (!this.a.j0) {
            this.d.a(s, this.e);
            return;
        }
        this.c.c(new bl3(n, this.b.b, s, zzt.zzB().currentTimeMillis()));
    }
    
    public final void c(final int n, final ArrayList list) {
        for (final String s : list) {
            Object o;
            if (zzba.zzc().a(cs3.J8)) {
                o = this.f.a(s, zzay.zze());
            }
            else {
                o = com.google.android.gms.internal.ads.e.r((Object)s);
            }
            ((yq1)o).addListener((Runnable)new jg5(0, o, (Object)new ki((Object)this, n, 11)), (Executor)k1.a);
        }
    }
}
