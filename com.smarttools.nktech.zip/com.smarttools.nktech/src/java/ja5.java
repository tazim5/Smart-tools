public final class ja5 implements h32
{
    public static final ja5 a;
    
    static {
        a = (ja5)new Object();
        f83.q(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, new kg3(1)), 2)), 3)), 4)), 5)));
    }
}
