import com.google.android.gms.internal.ads.n3;
import java.util.AbstractCollection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collections;
import com.google.android.gms.internal.ads.zzfwp;
import com.google.android.gms.internal.ads.zzfwu;
import java.util.List;
import com.google.android.gms.internal.ads.o3;

public final class dg5 extends o3
{
    public List X;
    
    public dg5(final zzfwu zzfwu, final boolean b) {
        super((zzfwp)zzfwu, b, true);
        Object emptyList;
        if (((AbstractCollection)zzfwu).isEmpty()) {
            emptyList = Collections.emptyList();
        }
        else {
            final int size = ((AbstractCollection)zzfwu).size();
            cz3.a(size, "initialArraySize");
            emptyList = new ArrayList(size);
        }
        for (int i = 0; i < ((AbstractCollection)zzfwu).size(); ++i) {
            ((List)emptyList).add((Object)null);
        }
        this.X = (List)emptyList;
        this.w();
    }
    
    public final void u(final int n, final Object o) {
        final List x = this.X;
        if (x != null) {
            x.set(n, (Object)new eg5(o));
        }
    }
    
    public final void v() {
        final List x = this.X;
        if (x != null) {
            final int size = x.size();
            cz3.a(size, "initialArraySize");
            final ArrayList list = new ArrayList(size);
            for (final eg5 eg5 : x) {
                Object a;
                if (eg5 != null) {
                    a = eg5.a;
                }
                else {
                    a = null;
                }
                list.add(a);
            }
            ((n3)this).f((Object)Collections.unmodifiableList((List)list));
        }
    }
    
    public final void x(final int n) {
        super.T = null;
        this.X = null;
    }
}
