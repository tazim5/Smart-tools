public interface kt5
{
    boolean zza(final int p0);
}
