import java.util.Map;
import java.util.HashSet;
import java.util.Collection;
import java.util.Map$Entry;
import java.util.Iterator;
import com.google.android.gms.internal.ads.w2;
import java.util.AbstractCollection;

public final class fe5 extends AbstractCollection
{
    public final w2 c;
    
    public fe5(final w2 c) {
        this.c = c;
    }
    
    public final void clear() {
        this.c.clear();
    }
    
    public final boolean contains(final Object o) {
        return ((Map)this.c).containsValue(o);
    }
    
    public final boolean isEmpty() {
        return ((Map)this.c).isEmpty();
    }
    
    public final Iterator iterator() {
        return (Iterator)new oe5(this.c.entrySet().iterator());
    }
    
    public final boolean remove(final Object o) {
        try {
            return super.remove(o);
        }
        catch (final UnsupportedOperationException ex) {
            final w2 c = this.c;
            for (final Map$Entry map$Entry : c.entrySet()) {
                if (ux3.a(o, map$Entry.getValue())) {
                    c.remove(map$Entry.getKey());
                    return true;
                }
            }
            return false;
        }
    }
    
    public final boolean removeAll(final Collection collection) {
        Label_0010: {
            if (collection == null) {
                break Label_0010;
            }
            try {
                return super.removeAll(collection);
                throw null;
            }
            catch (final UnsupportedOperationException ex) {
                final HashSet set = new HashSet();
                final w2 c = this.c;
                for (final Map$Entry map$Entry : c.entrySet()) {
                    if (collection.contains(map$Entry.getValue())) {
                        set.add(map$Entry.getKey());
                    }
                }
                return ((Map)c).keySet().removeAll((Collection)set);
            }
        }
    }
    
    public final boolean retainAll(final Collection collection) {
        Label_0010: {
            if (collection == null) {
                break Label_0010;
            }
            try {
                return super.retainAll(collection);
                throw null;
            }
            catch (final UnsupportedOperationException ex) {
                final HashSet set = new HashSet();
                final w2 c = this.c;
                for (final Map$Entry map$Entry : c.entrySet()) {
                    if (collection.contains(map$Entry.getValue())) {
                        set.add(map$Entry.getKey());
                    }
                }
                return ((Map)c).keySet().retainAll((Collection)set);
            }
        }
    }
    
    public final int size() {
        return this.c.v.size();
    }
}
