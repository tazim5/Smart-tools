import kotlin.Result$Failure;

public abstract class pu5
{
    public static final Object a(final Object o) {
        Object o2 = o;
        if (o instanceof rt) {
            o2 = new Result$Failure(((rt)o).a);
        }
        return o2;
    }
}
