import android.app.Dialog;
import android.view.Window;
import android.view.ViewParent;
import android.app.AlertDialog$Builder;
import android.content.res.Resources;
import android.app.Activity;
import android.view.View$OnClickListener;
import android.widget.RelativeLayout$LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.view.ViewGroup$LayoutParams;
import android.widget.RelativeLayout;
import android.widget.ImageView;
import android.graphics.Bitmap;
import android.view.ViewGroup;
import android.view.View;
import com.google.android.gms.ads.internal.client.zzay;
import android.content.Intent;
import android.content.DialogInterface$OnClickListener;
import com.google.android.gms.ads.impl.R$string;
import android.net.Uri;
import android.webkit.URLUtil;
import android.text.TextUtils;
import com.google.android.gms.common.wrappers.Wrappers;
import java.util.concurrent.Callable;
import android.content.Context;
import com.google.android.gms.ads.internal.util.zzch;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.common.util.CollectionUtils;
import com.google.android.gms.ads.internal.zzb;
import java.util.Map;

public final class kx3 implements hx3
{
    public static final Map w;
    public final zzb c;
    public final r24 n;
    public final zn4 v;
    
    static {
        w = CollectionUtils.mapOfKeyValueArrays((Object[])new String[] { "resize", "playVideo", "storePicture", "createCalendarEvent", "setOrientationProperties", "closeResizedAd", "unload" }, (Object[])new Integer[] { 1, 2, 3, 4, 5, 6, 7 });
    }
    
    public kx3(final zzb c, final r24 n, final zn4 v) {
        this.c = c;
        this.n = n;
        this.v = v;
    }
    
    public final void a(Object o, final Map map) {
        final rb4 rb4 = (rb4)o;
        final int intValue = (int)kx3.w.get((Object)map.get((Object)"a"));
        boolean boolean1 = true;
        Label_0110: {
            if (intValue != 5) {
                Label_3042: {
                    if (intValue != 7) {
                        final zzb c = this.c;
                        if (c.zzc()) {
                            if (intValue != 1) {
                                if (intValue == 3) {
                                    final t24 t24 = new t24(rb4, map);
                                    final Activity x = t24.x;
                                    if (x == null) {
                                        ((il3)t24).k("Activity context is not available");
                                    }
                                    else {
                                        zzt.zzp();
                                        Preconditions.checkNotNull((Object)x, (Object)"Context can not be null");
                                        if ((boolean)zzch.zza((Context)x, (Callable)sr3.b) && Wrappers.packageManager((Context)x).checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
                                            final String s = (String)map.get((Object)"iurl");
                                            if (TextUtils.isEmpty((CharSequence)s)) {
                                                ((il3)t24).k("Image url cannot be empty.");
                                            }
                                            else if (URLUtil.isValidUrl(s)) {
                                                final String lastPathSegment = Uri.parse(s).getLastPathSegment();
                                                zzt.zzp();
                                                if (!TextUtils.isEmpty((CharSequence)lastPathSegment)) {
                                                    if (lastPathSegment.matches("([^\\s]+(\\.(?i)(jpg|png|gif|bmp|webp))$)")) {
                                                        final Resources a = zzt.zzo().a();
                                                        zzt.zzp();
                                                        final AlertDialog$Builder zzJ = com.google.android.gms.ads.internal.util.zzt.zzJ((Context)x);
                                                        String string;
                                                        if (a != null) {
                                                            string = a.getString(R$string.s1);
                                                        }
                                                        else {
                                                            string = "Save image";
                                                        }
                                                        zzJ.setTitle((CharSequence)string);
                                                        String string2;
                                                        if (a != null) {
                                                            string2 = a.getString(R$string.s2);
                                                        }
                                                        else {
                                                            string2 = "Allow Ad to store image in Picture gallery?";
                                                        }
                                                        zzJ.setMessage((CharSequence)string2);
                                                        String string3;
                                                        if (a != null) {
                                                            string3 = a.getString(R$string.s3);
                                                        }
                                                        else {
                                                            string3 = "Accept";
                                                        }
                                                        zzJ.setPositiveButton((CharSequence)string3, (DialogInterface$OnClickListener)new hx4(t24, s, lastPathSegment));
                                                        String string4;
                                                        if (a != null) {
                                                            string4 = a.getString(R$string.s4);
                                                        }
                                                        else {
                                                            string4 = "Decline";
                                                        }
                                                        zzJ.setNegativeButton((CharSequence)string4, (DialogInterface$OnClickListener)new s24((Object)t24, 0));
                                                        ((Dialog)zzJ.create()).show();
                                                        return;
                                                    }
                                                }
                                                ((il3)t24).k("Image type not recognized: ".concat(String.valueOf((Object)lastPathSegment)));
                                            }
                                            else {
                                                ((il3)t24).k("Invalid image url: ".concat(String.valueOf((Object)s)));
                                            }
                                        }
                                        else {
                                            ((il3)t24).k("Feature is not supported by the device.");
                                        }
                                    }
                                    return;
                                }
                                if (intValue == 4) {
                                    final q24 q24 = new q24(rb4, map);
                                    final Activity x2 = q24.x;
                                    if (x2 == null) {
                                        ((il3)q24).k("Activity context is not available.");
                                    }
                                    else {
                                        zzt.zzp();
                                        Preconditions.checkNotNull((Object)x2, (Object)"Context can not be null");
                                        final Intent setType = new Intent("android.intent.action.INSERT").setType("vnd.android.cursor.dir/event");
                                        Preconditions.checkNotNull((Object)setType, (Object)"Intent can not be null");
                                        if (((Context)x2).getPackageManager().queryIntentActivities(setType, 0).isEmpty()) {
                                            ((il3)q24).k("This feature is not available on the device.");
                                        }
                                        else {
                                            zzt.zzp();
                                            final AlertDialog$Builder zzJ2 = com.google.android.gms.ads.internal.util.zzt.zzJ((Context)x2);
                                            final Resources a2 = zzt.zzo().a();
                                            String string5;
                                            if (a2 != null) {
                                                string5 = a2.getString(R$string.s5);
                                            }
                                            else {
                                                string5 = "Create calendar event";
                                            }
                                            zzJ2.setTitle((CharSequence)string5);
                                            String string6;
                                            if (a2 != null) {
                                                string6 = a2.getString(R$string.s6);
                                            }
                                            else {
                                                string6 = "Allow Ad to create a calendar event?";
                                            }
                                            zzJ2.setMessage((CharSequence)string6);
                                            String string7;
                                            if (a2 != null) {
                                                string7 = a2.getString(R$string.s3);
                                            }
                                            else {
                                                string7 = "Accept";
                                            }
                                            zzJ2.setPositiveButton((CharSequence)string7, (DialogInterface$OnClickListener)new p24(q24, 0));
                                            String string8;
                                            if (a2 != null) {
                                                string8 = a2.getString(R$string.s4);
                                            }
                                            else {
                                                string8 = "Decline";
                                            }
                                            zzJ2.setNegativeButton((CharSequence)string8, (DialogInterface$OnClickListener)new p24(q24, 1));
                                            ((Dialog)zzJ2.create()).show();
                                        }
                                    }
                                    return;
                                }
                                if (intValue == 5) {
                                    break Label_0110;
                                }
                                if (intValue == 6) {
                                    this.n.o(true);
                                    return;
                                }
                                if (intValue != 7) {
                                    d94.zzi("Unknown MRAID command called.");
                                    return;
                                }
                                break Label_3042;
                            }
                            else {
                                final r24 n = this.n;
                                final Object t25;
                                monitorenter(t25 = n.T);
                                Label_0757: {
                                    try {
                                        if (n.V == null) {
                                            ((il3)n).k("Not an activity context. Cannot resize.");
                                            monitorexit(t25);
                                            return;
                                        }
                                        break Label_0757;
                                    }
                                    finally {
                                        monitorexit(t25);
                                        Label_1351: {
                                            final String w;
                                            iftrue(Label_1399:)(!w.equals((Object)"bottom-left"));
                                        }
                                        String w;
                                        int n2;
                                        String w2;
                                        int n3;
                                        RelativeLayout$LayoutParams relativeLayout$LayoutParams;
                                        int n4;
                                        int o2;
                                        int o3;
                                        ViewParent parent;
                                        PopupWindow a3;
                                        int[] zzQ;
                                        int n5;
                                        int n6;
                                        int n7;
                                        int n8;
                                        int n9;
                                        int[] zzQ2;
                                        ViewGroup c2;
                                        rb4 u;
                                        Bitmap bitmap;
                                        int[] zzU;
                                        int n10;
                                        int s2;
                                        int n11 = 0;
                                        String w3;
                                        int[] array = null;
                                        int n12 = 0;
                                        int p2 = 0;
                                        int s3;
                                        int[] zzU2;
                                        int n13 = 0;
                                        int n14;
                                        int p3;
                                        int o4;
                                        PopupWindow a4;
                                        Window window;
                                        View decorView;
                                        int o5;
                                        int n15;
                                        int n16;
                                        zn4 z;
                                        int n17;
                                        int n18;
                                        String message;
                                        ViewGroup c3;
                                        Label_1112_Outer:Block_56_Outer:Label_1216_Outer:
                                        while (true) {
                                            Label_1907: {
                                            Label_1216:
                                                while (true) {
                                                Block_54:
                                                    while (true) {
                                                        while (true) {
                                                            Block_46: {
                                                                Label_1660:Block_38_Outer:
                                                                while (true) {
                                                                    Label_1455: {
                                                                        while (true) {
                                                                            Label_2655:Block_40_Outer:Block_84_Outer:Label_1197_Outer:
                                                                            while (true) {
                                                                                while (true) {
                                                                                    Label_1174: {
                                                                                        Label_1493: {
                                                                                            while (true) {
                                                                                                while (true) {
                                                                                                    Label_0883: {
                                                                                                        Label_1401:Label_2515_Outer:Label_2517_Outer:Label_1794_Outer:Block_44_Outer:Block_43_Outer:Block_81_Outer:
                                                                                                        while (true) {
                                                                                                            Block_59: {
                                                                                                                break Block_59;
                                                                                                            Block_90_Outer:
                                                                                                                while (true) {
                                                                                                                    while (true) {
                                                                                                                        Block_89: {
                                                                                                                            while (true) {
                                                                                                                                Block_88: {
                                                                                                                                    while (true) {
                                                                                                                                        Label_1009: {
                                                                                                                                        Block_67:
                                                                                                                                            while (true) {
                                                                                                                                                Block_65: {
                                                                                                                                                    Block_55: {
                                                                                                                                                    Block_87:
                                                                                                                                                        while (true) {
                                                                                                                                                            Label_1047: {
                                                                                                                                                                Label_1794:Block_71_Outer:
                                                                                                                                                                while (true) {
                                                                                                                                                                    Block_73: {
                                                                                                                                                                        while (true) {
                                                                                                                                                                            Block_63: {
                                                                                                                                                                                Label_2143: {
                                                                                                                                                                                    while (true) {
                                                                                                                                                                                        Block_70: {
                                                                                                                                                                                        Block_91_Outer:
                                                                                                                                                                                            while (true) {
                                                                                                                                                                                                while (true) {
                                                                                                                                                                                                    Label_2517:Block_60_Outer:Block_79_Outer:
                                                                                                                                                                                                    while (true) {
                                                                                                                                                                                                        Block_83: {
                                                                                                                                                                                                            while (true) {
                                                                                                                                                                                                                Block_78: {
                                                                                                                                                                                                                Block_86:
                                                                                                                                                                                                                    while (true) {
                                                                                                                                                                                                                        while (true) {
                                                                                                                                                                                                                            while (true) {
                                                                                                                                                                                                                            Label_1873:
                                                                                                                                                                                                                                while (true) {
                                                                                                                                                                                                                                    Block_36: {
                                                                                                                                                                                                                                        while (true) {
                                                                                                                                                                                                                                            while (true) {
                                                                                                                                                                                                                                                Block_58: {
                                                                                                                                                                                                                                                Block_41_Outer:
                                                                                                                                                                                                                                                    while (true) {
                                                                                                                                                                                                                                                        n2 = 2;
                                                                                                                                                                                                                                                        break Label_1401;
                                                                                                                                                                                                                                                        Label_2467:
                                                                                                                                                                                                                                                        iftrue(Label_2515:)(!w2.equals((Object)"bottom-left"));
                                                                                                                                                                                                                                                        break Block_83;
                                                                                                                                                                                                                                                        n3 = -1;
                                                                                                                                                                                                                                                        break Label_2517;
                                                                                                                                                                                                                                                        Label_1300:
                                                                                                                                                                                                                                                        Block_42: {
                                                                                                                                                                                                                                                            while (true) {
                                                                                                                                                                                                                                                                Label_1399: {
                                                                                                                                                                                                                                                                    break Label_1399;
                                                                                                                                                                                                                                                                    Block_85: {
                                                                                                                                                                                                                                                                        Block_80_Outer:Block_72_Outer:
                                                                                                                                                                                                                                                                        while (true) {
                                                                                                                                                                                                                                                                            while (true) {
                                                                                                                                                                                                                                                                                iftrue(Label_1009:)(TextUtils.isEmpty((CharSequence)map.get((Object)"offsetY")));
                                                                                                                                                                                                                                                                                break Block_42;
                                                                                                                                                                                                                                                                                zzt.zzp();
                                                                                                                                                                                                                                                                                n.Q = com.google.android.gms.ads.internal.util.zzt.zzN((String)map.get((Object)"offsetX"));
                                                                                                                                                                                                                                                                                continue Block_41_Outer;
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            Label_0841:
                                                                                                                                                                                                                                                                            iftrue(Label_0883:)(TextUtils.isEmpty((CharSequence)map.get((Object)"width")));
                                                                                                                                                                                                                                                                            Label_0925: {
                                                                                                                                                                                                                                                                                while (true) {
                                                                                                                                                                                                                                                                                    while (true) {
                                                                                                                                                                                                                                                                                        Block_39: {
                                                                                                                                                                                                                                                                                            break Block_39;
                                                                                                                                                                                                                                                                                            n3 = 1;
                                                                                                                                                                                                                                                                                            break Label_2517;
                                                                                                                                                                                                                                                                                            Label_2614:
                                                                                                                                                                                                                                                                                            relativeLayout$LayoutParams.addRule(13);
                                                                                                                                                                                                                                                                                            break Label_2655;
                                                                                                                                                                                                                                                                                            n4 = 0;
                                                                                                                                                                                                                                                                                            break Label_1794;
                                                                                                                                                                                                                                                                                            n3 = 5;
                                                                                                                                                                                                                                                                                            break Label_2517;
                                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                                        zzt.zzp();
                                                                                                                                                                                                                                                                                        n.S = com.google.android.gms.ads.internal.util.zzt.zzN((String)map.get((Object)"width"));
                                                                                                                                                                                                                                                                                        break Label_0883;
                                                                                                                                                                                                                                                                                        Label_1925:
                                                                                                                                                                                                                                                                                        zzay.zzb();
                                                                                                                                                                                                                                                                                        o2 = z84.o(n.S, (Context)n.V);
                                                                                                                                                                                                                                                                                        zzay.zzb();
                                                                                                                                                                                                                                                                                        o3 = z84.o(n.P, (Context)n.V);
                                                                                                                                                                                                                                                                                        parent = ((View)n.U).getParent();
                                                                                                                                                                                                                                                                                        iftrue(Label_2990:)(parent == null || !(parent instanceof ViewGroup));
                                                                                                                                                                                                                                                                                        break Block_78;
                                                                                                                                                                                                                                                                                        Label_2419:
                                                                                                                                                                                                                                                                                        iftrue(Label_2515:)(!w2.equals((Object)"top-center"));
                                                                                                                                                                                                                                                                                        continue Block_72_Outer;
                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                    Label_2138:
                                                                                                                                                                                                                                                                                    a3.dismiss();
                                                                                                                                                                                                                                                                                    break Label_2143;
                                                                                                                                                                                                                                                                                    iftrue(Label_1608:)(n2 == 1);
                                                                                                                                                                                                                                                                                    break Block_63;
                                                                                                                                                                                                                                                                                    zzt.zzp();
                                                                                                                                                                                                                                                                                    n.P = com.google.android.gms.ads.internal.util.zzt.zzN((String)map.get((Object)"height"));
                                                                                                                                                                                                                                                                                    break Label_0925;
                                                                                                                                                                                                                                                                                    n5 = zzQ[0];
                                                                                                                                                                                                                                                                                    iftrue(Label_1840:)(n6 >= n5);
                                                                                                                                                                                                                                                                                    Block_74: {
                                                                                                                                                                                                                                                                                        break Block_74;
                                                                                                                                                                                                                                                                                        iftrue(Label_3018:)(n.S < 0 || n.P < 0);
                                                                                                                                                                                                                                                                                        break Block_46;
                                                                                                                                                                                                                                                                                        Label_1335:
                                                                                                                                                                                                                                                                                        iftrue(Label_1399:)(!w.equals((Object)"bottom-right"));
                                                                                                                                                                                                                                                                                        break Block_58;
                                                                                                                                                                                                                                                                                        n2 = 0;
                                                                                                                                                                                                                                                                                        break Label_1401;
                                                                                                                                                                                                                                                                                        Label_1221:
                                                                                                                                                                                                                                                                                        iftrue(Label_1730:)(!n.x);
                                                                                                                                                                                                                                                                                        break Block_55;
                                                                                                                                                                                                                                                                                        Label_2624:
                                                                                                                                                                                                                                                                                        relativeLayout$LayoutParams.addRule(10);
                                                                                                                                                                                                                                                                                        relativeLayout$LayoutParams.addRule(14);
                                                                                                                                                                                                                                                                                        break Label_2655;
                                                                                                                                                                                                                                                                                        Label_2499:
                                                                                                                                                                                                                                                                                        iftrue(Label_2515:)(!w2.equals((Object)"center"));
                                                                                                                                                                                                                                                                                        break Block_85;
                                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                                    break Label_1873;
                                                                                                                                                                                                                                                                                    iftrue(Label_1216:)(n7 < 0 || n7 + 50 > n8 || n9 < zzQ2[0]);
                                                                                                                                                                                                                                                                                    break Block_70;
                                                                                                                                                                                                                                                                                    n.c0 = c2;
                                                                                                                                                                                                                                                                                    zzt.zzp();
                                                                                                                                                                                                                                                                                    u = n.U;
                                                                                                                                                                                                                                                                                    ((View)u).setDrawingCacheEnabled(true);
                                                                                                                                                                                                                                                                                    bitmap = Bitmap.createBitmap(((View)u).getDrawingCache());
                                                                                                                                                                                                                                                                                    ((View)u).setDrawingCacheEnabled(false);
                                                                                                                                                                                                                                                                                    (n.X = new ImageView((Context)n.V)).setImageBitmap(bitmap);
                                                                                                                                                                                                                                                                                    n.W = n.U.zzO();
                                                                                                                                                                                                                                                                                    n.c0.addView((View)n.X);
                                                                                                                                                                                                                                                                                    break Label_2143;
                                                                                                                                                                                                                                                                                    Label_1730:
                                                                                                                                                                                                                                                                                    zzt.zzp();
                                                                                                                                                                                                                                                                                    zzU = com.google.android.gms.ads.internal.util.zzt.zzU(n.V);
                                                                                                                                                                                                                                                                                    zzt.zzp();
                                                                                                                                                                                                                                                                                    zzQ = com.google.android.gms.ads.internal.util.zzt.zzQ(n.V);
                                                                                                                                                                                                                                                                                    n10 = zzU[0];
                                                                                                                                                                                                                                                                                    n4 = n.y + n.Q;
                                                                                                                                                                                                                                                                                    n6 = n.z + n.R;
                                                                                                                                                                                                                                                                                    iftrue(Label_1797:)(n4 >= 0);
                                                                                                                                                                                                                                                                                    continue Label_1794_Outer;
                                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                                Label_3004:
                                                                                                                                                                                                                                                                                ((il3)n).k("Activity context is not ready, cannot get window or decor view.");
                                                                                                                                                                                                                                                                                monitorexit(t25);
                                                                                                                                                                                                                                                                                return;
                                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                                            iftrue(Label_0967:)(TextUtils.isEmpty((CharSequence)map.get((Object)"offsetX")));
                                                                                                                                                                                                                                                                            continue Block_80_Outer;
                                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    n3 = 2;
                                                                                                                                                                                                                                                                    break Label_2517;
                                                                                                                                                                                                                                                                    Label_2597:
                                                                                                                                                                                                                                                                    relativeLayout$LayoutParams.addRule(12);
                                                                                                                                                                                                                                                                    relativeLayout$LayoutParams.addRule(9);
                                                                                                                                                                                                                                                                    break Label_2655;
                                                                                                                                                                                                                                                                    Label_1512:
                                                                                                                                                                                                                                                                    n7 = n.y + n.Q + (s2 >> 1) - 25;
                                                                                                                                                                                                                                                                    n11 = n.z;
                                                                                                                                                                                                                                                                    break Label_1493;
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                n2 = -1;
                                                                                                                                                                                                                                                                break Label_1401;
                                                                                                                                                                                                                                                                relativeLayout$LayoutParams.addRule(10);
                                                                                                                                                                                                                                                                relativeLayout$LayoutParams.addRule(11);
                                                                                                                                                                                                                                                                break Label_2655;
                                                                                                                                                                                                                                                                n.w = w3;
                                                                                                                                                                                                                                                                continue Block_60_Outer;
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                            Label_2641:
                                                                                                                                                                                                                                                            relativeLayout$LayoutParams.addRule(10);
                                                                                                                                                                                                                                                            relativeLayout$LayoutParams.addRule(9);
                                                                                                                                                                                                                                                            break Label_2655;
                                                                                                                                                                                                                                                            n2 = 4;
                                                                                                                                                                                                                                                            break Label_1401;
                                                                                                                                                                                                                                                            n3 = 0;
                                                                                                                                                                                                                                                            break Label_2517;
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        zzt.zzp();
                                                                                                                                                                                                                                                        n.R = com.google.android.gms.ads.internal.util.zzt.zzN((String)map.get((Object)"offsetY"));
                                                                                                                                                                                                                                                        break Label_1009;
                                                                                                                                                                                                                                                        ((il3)n).k("Resize location out of screen or close button is not visible.");
                                                                                                                                                                                                                                                        monitorexit(t25);
                                                                                                                                                                                                                                                        return;
                                                                                                                                                                                                                                                        iftrue(Label_0784:)(n.U.zzO() != null);
                                                                                                                                                                                                                                                        break Block_36;
                                                                                                                                                                                                                                                        array = new int[] { n4, n5 };
                                                                                                                                                                                                                                                        break Label_1907;
                                                                                                                                                                                                                                                        iftrue(Label_1468:)(n2 == 5);
                                                                                                                                                                                                                                                        break Block_67;
                                                                                                                                                                                                                                                        Label_1608:
                                                                                                                                                                                                                                                        n7 = n.y + n.Q + (s2 >> 1) - 25;
                                                                                                                                                                                                                                                        n12 = n.z;
                                                                                                                                                                                                                                                        break Label_1455;
                                                                                                                                                                                                                                                        n.x = Boolean.parseBoolean((String)map.get((Object)"allowOffscreen"));
                                                                                                                                                                                                                                                        break Label_1047;
                                                                                                                                                                                                                                                        Label_1383:
                                                                                                                                                                                                                                                        iftrue(Label_1399:)(!w.equals((Object)"center"));
                                                                                                                                                                                                                                                        continue Label_2515_Outer;
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    Label_1695:
                                                                                                                                                                                                                                                    array = new int[] { n.y + n.Q, n.z + n.R };
                                                                                                                                                                                                                                                    break Label_1907;
                                                                                                                                                                                                                                                    Label_1468:
                                                                                                                                                                                                                                                    n7 = n.y + n.Q + s2 - 50;
                                                                                                                                                                                                                                                    n11 = n.z;
                                                                                                                                                                                                                                                    break Label_1493;
                                                                                                                                                                                                                                                    Label_1564:
                                                                                                                                                                                                                                                    n7 = n.y + n.Q + (s2 >> 1) - 25;
                                                                                                                                                                                                                                                    n9 = n.z + n.R + (p2 >> 1) - 25;
                                                                                                                                                                                                                                                    continue Label_1660;
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                n2 = 5;
                                                                                                                                                                                                                                                iftrue(Label_1638:)(n2 == 0);
                                                                                                                                                                                                                                                continue Block_40_Outer;
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            n3 = 4;
                                                                                                                                                                                                                                            break Label_2517;
                                                                                                                                                                                                                                            Label_1319:
                                                                                                                                                                                                                                            iftrue(Label_1399:)(!w.equals((Object)"bottom-center"));
                                                                                                                                                                                                                                            continue Block_84_Outer;
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        Label_1797:
                                                                                                                                                                                                                                        s3 = n.S;
                                                                                                                                                                                                                                        iftrue(Label_1822:)(n4 + s3 <= n10);
                                                                                                                                                                                                                                        break Block_73;
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                    ((il3)n).k("Webview is not yet available, size is not set.");
                                                                                                                                                                                                                                    monitorexit(t25);
                                                                                                                                                                                                                                    return;
                                                                                                                                                                                                                                    zzt.zzp();
                                                                                                                                                                                                                                    zzU2 = com.google.android.gms.ads.internal.util.zzt.zzU(n.V);
                                                                                                                                                                                                                                    zzt.zzp();
                                                                                                                                                                                                                                    zzQ2 = com.google.android.gms.ads.internal.util.zzt.zzQ(n.V);
                                                                                                                                                                                                                                    n8 = zzU2[0];
                                                                                                                                                                                                                                    n13 = zzU2[1];
                                                                                                                                                                                                                                    s2 = n.S;
                                                                                                                                                                                                                                    iftrue(Label_1898:)(s2 < 50 || s2 > n8);
                                                                                                                                                                                                                                    break Label_1174;
                                                                                                                                                                                                                                    Label_1542:
                                                                                                                                                                                                                                    n7 = n.y + n.Q;
                                                                                                                                                                                                                                    n11 = n.z;
                                                                                                                                                                                                                                    break Label_1493;
                                                                                                                                                                                                                                    n2 = 1;
                                                                                                                                                                                                                                    continue Label_1401;
                                                                                                                                                                                                                                    iftrue(Label_2641:)(n3 == 0);
                                                                                                                                                                                                                                    break Block_86;
                                                                                                                                                                                                                                    n5 = n14 - p3;
                                                                                                                                                                                                                                    continue Label_1873;
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                Label_1840:
                                                                                                                                                                                                                                p3 = n.P;
                                                                                                                                                                                                                                n14 = zzQ[1];
                                                                                                                                                                                                                                n5 = n6;
                                                                                                                                                                                                                                iftrue(Label_1873:)(n6 + p3 <= n14);
                                                                                                                                                                                                                                continue Block_71_Outer;
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                            Label_1822:
                                                                                                                                                                                                                            continue Label_1794;
                                                                                                                                                                                                                            Label_2416:
                                                                                                                                                                                                                            continue Label_2517_Outer;
                                                                                                                                                                                                                        }
                                                                                                                                                                                                                        Label_1367:
                                                                                                                                                                                                                        iftrue(Label_1399:)(!w.equals((Object)"top-left"));
                                                                                                                                                                                                                        continue Block_79_Outer;
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                    iftrue(Label_2624:)(n3 == 1);
                                                                                                                                                                                                                    break Block_87;
                                                                                                                                                                                                                    break Label_1216;
                                                                                                                                                                                                                    ((il3)n).k("Is interstitial. Cannot resize an interstitial.");
                                                                                                                                                                                                                    monitorexit(t25);
                                                                                                                                                                                                                    return;
                                                                                                                                                                                                                    iftrue(Label_1542:)(n2 == 3);
                                                                                                                                                                                                                    break Block_65;
                                                                                                                                                                                                                }
                                                                                                                                                                                                                c2 = (ViewGroup)parent;
                                                                                                                                                                                                                c2.removeView((View)n.U);
                                                                                                                                                                                                                a3 = n.a0;
                                                                                                                                                                                                                iftrue(Label_2138:)(a3 != null);
                                                                                                                                                                                                                continue Block_91_Outer;
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                        n3 = 3;
                                                                                                                                                                                                        continue Label_2517;
                                                                                                                                                                                                    }
                                                                                                                                                                                                    iftrue(Label_2563:)(n3 == 5);
                                                                                                                                                                                                    continue Block_44_Outer;
                                                                                                                                                                                                }
                                                                                                                                                                                                Label_2451:
                                                                                                                                                                                                iftrue(Label_2515:)(!w2.equals((Object)"bottom-right"));
                                                                                                                                                                                                continue Block_40_Outer;
                                                                                                                                                                                            }
                                                                                                                                                                                            Label_3018:
                                                                                                                                                                                            ((il3)n).k("Invalid width and height options. Cannot resize.");
                                                                                                                                                                                            monitorexit(t25);
                                                                                                                                                                                            return;
                                                                                                                                                                                        }
                                                                                                                                                                                        iftrue(Label_1695:)(n9 + 50 <= zzQ2[1]);
                                                                                                                                                                                        continue Label_1216_Outer;
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                                ((View)(n.b0 = new RelativeLayout((Context)n.V))).setBackgroundColor(0);
                                                                                                                                                                                ((View)n.b0).setLayoutParams(new ViewGroup$LayoutParams(o2, o3));
                                                                                                                                                                                zzt.zzp();
                                                                                                                                                                                (n.a0 = new PopupWindow((View)n.b0, o2, o3, false)).setOutsideTouchable(false);
                                                                                                                                                                                n.a0.setTouchable(true);
                                                                                                                                                                                n.a0.setClippingEnabled(n.x ^ true);
                                                                                                                                                                                ((ViewGroup)n.b0).addView((View)n.U, -1, -1);
                                                                                                                                                                                n.Y = new LinearLayout((Context)n.V);
                                                                                                                                                                                zzay.zzb();
                                                                                                                                                                                o4 = z84.o(50, (Context)n.V);
                                                                                                                                                                                zzay.zzb();
                                                                                                                                                                                relativeLayout$LayoutParams = new RelativeLayout$LayoutParams(o4, z84.o(50, (Context)n.V));
                                                                                                                                                                                w2 = n.w;
                                                                                                                                                                                switch([Lq5.b0;@3878e42)(w2.hashCode());
                                                                                                                                                                            }
                                                                                                                                                                            iftrue(Label_1564:)(n2 == 2);
                                                                                                                                                                            continue Block_90_Outer;
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                    n4 = n10 - s3;
                                                                                                                                                                    continue Label_1794;
                                                                                                                                                                }
                                                                                                                                                            }
                                                                                                                                                            w3 = (String)map.get((Object)"customClosePosition");
                                                                                                                                                            iftrue(Label_1073:)(TextUtils.isEmpty((CharSequence)w3));
                                                                                                                                                            continue Block_84_Outer;
                                                                                                                                                        }
                                                                                                                                                        iftrue(Label_2614:)(n3 == 2);
                                                                                                                                                        break Block_88;
                                                                                                                                                    }
                                                                                                                                                    w = n.w;
                                                                                                                                                    switch([Lq5.b0;@af3b48b)(w.hashCode());
                                                                                                                                                }
                                                                                                                                                iftrue(Label_1512:)(n2 == 4);
                                                                                                                                                continue Block_43_Outer;
                                                                                                                                            }
                                                                                                                                            n7 = n.y + n.Q + s2 - 50;
                                                                                                                                            n12 = n.z;
                                                                                                                                            break Label_1455;
                                                                                                                                        }
                                                                                                                                        iftrue(Label_1047:)(TextUtils.isEmpty((CharSequence)map.get((Object)"allowOffscreen")));
                                                                                                                                        continue Block_81_Outer;
                                                                                                                                    }
                                                                                                                                    Label_1889:
                                                                                                                                    d94.zzj("Height is too small or too large.");
                                                                                                                                    break Label_1216;
                                                                                                                                    iftrue(Label_1221:)(p2 != n13 || s2 != n8);
                                                                                                                                    break Block_54;
                                                                                                                                }
                                                                                                                                iftrue(Label_2597:)(n3 == 3);
                                                                                                                                break Block_89;
                                                                                                                                Label_0784:
                                                                                                                                iftrue(Label_0814:)(!n.U.zzO().b());
                                                                                                                                continue Block_90_Outer;
                                                                                                                            }
                                                                                                                            Label_2990:
                                                                                                                            ((il3)n).k("Webview is detached, probably in the middle of a resize or expand.");
                                                                                                                            monitorexit(t25);
                                                                                                                            return;
                                                                                                                        }
                                                                                                                        iftrue(Label_2580:)(n3 == 4);
                                                                                                                        continue Label_1197_Outer;
                                                                                                                    }
                                                                                                                    Label_2435:
                                                                                                                    iftrue(Label_2515:)(!w2.equals((Object)"bottom-center"));
                                                                                                                    continue Label_1112_Outer;
                                                                                                                }
                                                                                                            }
                                                                                                            n2 = 3;
                                                                                                            continue Label_1401;
                                                                                                        }
                                                                                                        Label_1898:
                                                                                                        d94.zzj("Width is too small or too large.");
                                                                                                        break Label_1216;
                                                                                                        Label_2563:
                                                                                                        relativeLayout$LayoutParams.addRule(12);
                                                                                                        relativeLayout$LayoutParams.addRule(11);
                                                                                                        ((View)n.Y).setOnClickListener((View$OnClickListener)new a13((Object)n, 2));
                                                                                                        ((View)n.Y).setContentDescription((CharSequence)"Close button");
                                                                                                        ((ViewGroup)n.b0).addView((View)n.Y, (ViewGroup$LayoutParams)relativeLayout$LayoutParams);
                                                                                                        try {
                                                                                                            a4 = n.a0;
                                                                                                            decorView = window.getDecorView();
                                                                                                            zzay.zzb();
                                                                                                            o5 = z84.o(array[0], (Context)n.V);
                                                                                                            zzay.zzb();
                                                                                                            a4.showAtLocation(decorView, 0, o5, z84.o(array[1], (Context)n.V));
                                                                                                            n15 = array[0];
                                                                                                            n16 = array[1];
                                                                                                            z = n.Z;
                                                                                                            if (z != null) {
                                                                                                                ((er4)z.n).c.t0((gl4)k26.P);
                                                                                                            }
                                                                                                            n.U.B(new e11(1, o2, o3));
                                                                                                            n17 = array[0];
                                                                                                            n18 = array[1];
                                                                                                            zzt.zzp();
                                                                                                            ((il3)n).m(n17, n18 - com.google.android.gms.ads.internal.util.zzt.zzQ(n.V)[0], n.S, n.P);
                                                                                                            ((il3)n).n("resized");
                                                                                                            monitorexit(t25);
                                                                                                        }
                                                                                                        catch (final RuntimeException ex) {
                                                                                                            message = ((Throwable)ex).getMessage();
                                                                                                            o = new StringBuilder("Cannot show popup window: ");
                                                                                                            ((StringBuilder)o).append(message);
                                                                                                            ((il3)n).k(((StringBuilder)o).toString());
                                                                                                            ((ViewGroup)n.b0).removeView((View)n.U);
                                                                                                            c3 = n.c0;
                                                                                                            if (c3 != null) {
                                                                                                                c3.removeView((View)n.X);
                                                                                                                n.c0.addView((View)n.U);
                                                                                                                n.U.B(n.W);
                                                                                                            }
                                                                                                            monitorexit(t25);
                                                                                                        }
                                                                                                        return;
                                                                                                    }
                                                                                                    iftrue(Label_0925:)(TextUtils.isEmpty((CharSequence)map.get((Object)"height")));
                                                                                                    continue Block_84_Outer;
                                                                                                }
                                                                                                array = null;
                                                                                                break Label_1907;
                                                                                                ((il3)n).k("Cannot resize an expanded banner.");
                                                                                                monitorexit(t25);
                                                                                                return;
                                                                                                Label_2483:
                                                                                                iftrue(Label_2515:)(!w2.equals((Object)"top-left"));
                                                                                                continue Label_1112_Outer;
                                                                                            }
                                                                                            Label_1638:
                                                                                            n7 = n.y + n.Q;
                                                                                            n12 = n.z;
                                                                                            break Label_1455;
                                                                                        }
                                                                                        n9 = n11 + n.R + p2 - 50;
                                                                                        continue Label_1660;
                                                                                    }
                                                                                    p2 = n.P;
                                                                                    iftrue(Label_1889:)(p2 < 50 || p2 > n13);
                                                                                    continue Block_38_Outer;
                                                                                }
                                                                                Label_2580:
                                                                                relativeLayout$LayoutParams.addRule(12);
                                                                                relativeLayout$LayoutParams.addRule(14);
                                                                                continue Label_2655;
                                                                            }
                                                                            Label_0814:
                                                                            iftrue(Label_0841:)(!n.U.U());
                                                                            continue;
                                                                        }
                                                                    }
                                                                    n9 = n12 + n.R;
                                                                    continue Label_1660;
                                                                }
                                                            }
                                                            window = n.V.getWindow();
                                                            iftrue(Label_3004:)(window == null || window.getDecorView() == null);
                                                            continue Block_56_Outer;
                                                        }
                                                        Label_1303:
                                                        iftrue(Label_1399:)(!w.equals((Object)"top-center"));
                                                        continue Label_1216_Outer;
                                                    }
                                                    d94.zzj("Cannot resize to a full-screen ad.");
                                                    continue Label_1216;
                                                }
                                            }
                                            iftrue(Label_1925:)(array != null);
                                            continue;
                                        }
                                    }
                                }
                            }
                        }
                        c.zzb((String)null);
                        return;
                    }
                }
                ((er4)this.v.n).m.zza();
                return;
            }
        }
        int n19 = 14;
        final String s4 = (String)map.get((Object)"forceOrientation");
        if (map.containsKey((Object)"allowOrientationChange")) {
            boolean1 = Boolean.parseBoolean((String)map.get((Object)"allowOrientationChange"));
        }
        if (rb4 == null) {
            d94.zzj("AdWebView is null");
            return;
        }
        if ("portrait".equalsIgnoreCase(s4)) {
            n19 = 7;
        }
        else if ("landscape".equalsIgnoreCase(s4)) {
            n19 = 6;
        }
        else if (boolean1) {
            n19 = -1;
        }
        rb4.S(n19);
    }
}
