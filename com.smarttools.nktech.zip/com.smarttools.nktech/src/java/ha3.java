import android.animation.TimeInterpolator;
import android.view.animation.Interpolator;

public abstract class ha3
{
    public float a;
    public final Interpolator b;
    public final long c;
    
    public ha3(final Interpolator b, final long c) {
        this.b = b;
        this.c = c;
    }
    
    public long a() {
        return this.c;
    }
    
    public float b() {
        final Interpolator b = this.b;
        if (b != null) {
            return ((TimeInterpolator)b).getInterpolation(this.a);
        }
        return this.a;
    }
    
    public void c(final float a) {
        this.a = a;
    }
}
