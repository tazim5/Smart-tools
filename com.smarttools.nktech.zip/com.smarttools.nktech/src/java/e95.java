public abstract class e95
{
}
