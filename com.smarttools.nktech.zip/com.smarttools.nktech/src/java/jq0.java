import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.material3.IconButtonColors;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.RowScope;
import android.content.Context;

public final class jq0 implements od1
{
    public final int c;
    public final Context n;
    public final String v;
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        switch (this.c) {
            default: {
                final RowScope rowScope = (RowScope)o;
                final Composer composer = (Composer)o2;
                if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                }
                else {
                    IconButtonKt.IconButton((id1)new cb(this.n, 2, this.v), (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)i10.c, composer, 196608, 30);
                }
                return t43.a;
            }
            case 0: {
                final RowScope rowScope2 = (RowScope)o;
                final Composer composer2 = (Composer)o2;
                if ((((Number)o3).intValue() & 0x51) == 0x10 && composer2.getSkipping()) {
                    composer2.skipToGroupEnd();
                }
                else {
                    IconButtonKt.IconButton((id1)new cb(this.n, 1, this.v), (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)xz.c, composer2, 196608, 30);
                }
                return t43.a;
            }
        }
    }
}
