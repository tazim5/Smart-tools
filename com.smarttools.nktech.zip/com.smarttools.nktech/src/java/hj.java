import androidx.concurrent.futures.b;

public interface hj
{
    Object o(final b p0);
}
