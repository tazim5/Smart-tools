import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;

public final class fa0 implements nd1
{
    public static final fa0 c;
    
    static {
        c = (fa0)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            TextKt.Text--4IGK_g("No Credits Available", SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), 0L, 0L, (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, TextAlign.box-impl(TextAlign.Companion.getCenter-e0LSkKk()), 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196662, 0, 130524);
        }
        return t43.a;
    }
}
