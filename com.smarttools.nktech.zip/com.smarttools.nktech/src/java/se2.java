import kotlinx.coroutines.internal.a;

public final class se2
{
    public final a a;
    
    public se2(final a a) {
        this.a = a;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("Removed[");
        sb.append((Object)this.a);
        sb.append(']');
        return sb.toString();
    }
}
