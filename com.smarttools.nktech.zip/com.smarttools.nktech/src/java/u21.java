import java.util.Set;

public abstract class u21
{
    public static Set<int[]> a() {
        return (Set<int[]>)mv5.a();
    }
}
