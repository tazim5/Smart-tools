import androidx.compose.runtime.State;
import androidx.compose.runtime.Composer$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.SelectableChipElevation;
import androidx.compose.material3.SelectableChipColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ChipKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableState;

public final class r6 implements nd1
{
    public final MutableState c;
    
    public r6(final MutableState c) {
        this.c = c;
    }
    
    public final Object invoke(Object o, Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            TextKt.Text--4IGK_g("Tone:", (Modifier)null, 0L, TextUnitKt.getSp(13), (FontStyle)null, FontWeight.Companion.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 199686, 0, 131030);
            final Modifier$Companion companion = Modifier.Companion;
            final float n = 8;
            ap.l(n, companion, composer, 6);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), Alignment.Companion.getTop(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
            final ComposeUiNode$Companion companion2 = ComposeUiNode.Companion;
            final id1 constructor = companion2.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion2, constructor-impl, rowMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion2.getSetModifier());
            final RowScopeInstance instance = RowScopeInstance.INSTANCE;
            final MutableState c = this.c;
            final boolean b2 = kl1.b((Object)((State)c).getValue(), (Object)"casual");
            composer.startReplaceGroup(-1213231513);
            o2 = composer.rememberedValue();
            final Composer$Companion companion3 = Composer.Companion;
            if ((o = o2) == companion3.getEmpty()) {
                o = new m4(c, 10);
                composer.updateRememberedValue(o);
            }
            final id1 id1 = (id1)o;
            composer.endReplaceGroup();
            ChipKt.FilterChip(b2, id1, (nd1)xv.a, (Modifier)null, false, (nd1)null, (nd1)null, (Shape)null, (SelectableChipColors)null, (SelectableChipElevation)null, (BorderStroke)null, (MutableInteractionSource)null, composer, 432, 0, 4088);
            SpacerKt.Spacer(SizeKt.width-3ABfNKs((Modifier)companion, Dp.constructor-impl(n)), composer, 6);
            final boolean b3 = kl1.b((Object)((State)c).getValue(), (Object)"professional");
            composer.startReplaceGroup(-1213223187);
            o2 = composer.rememberedValue();
            if ((o = o2) == companion3.getEmpty()) {
                o = new m4(c, 11);
                composer.updateRememberedValue(o);
            }
            final id1 id2 = (id1)o;
            composer.endReplaceGroup();
            ChipKt.FilterChip(b3, id2, (nd1)xv.b, (Modifier)null, false, (nd1)null, (nd1)null, (Shape)null, (SelectableChipColors)null, (SelectableChipElevation)null, (BorderStroke)null, (MutableInteractionSource)null, composer, 432, 0, 4088);
            composer.endNode();
        }
        return t43.a;
    }
}
