import com.google.android.gms.internal.ads.l2;
import android.view.View;
import android.content.pm.PackageInfo;
import android.content.pm.ApplicationInfo;
import java.util.Map;
import org.json.JSONObject;
import com.google.android.gms.ads.internal.util.zzbq;
import com.google.android.gms.internal.ads.w1;
import com.google.android.gms.ads.internal.zzt;
import android.content.pm.PackageManager$NameNotFoundException;
import com.google.android.gms.common.wrappers.Wrappers;
import android.content.Context;
import com.google.android.gms.common.util.Clock;
import java.util.Set;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.internal.ads.zzbwa;

public final class j74 implements ls5
{
    public final int a;
    public final Object b;
    public final ts5 c;
    
    public mw4 a() {
        return new mw4(1, (Object)new ww4(((cd4)this.b).b.a()), (Object)((ks5)this.c).zzb());
    }
    
    public final Object zzb() {
        switch (this.a) {
            default: {
                return new z65(((xc4)this.b).a(), ((wc4)this.c).b());
            }
            case 28: {
                ((xc4)this.b).a();
                ep5.c((Object)((zzbwa)((k45)this.c).b.v).w);
                final i94 a = k1.a;
                ep5.c((Object)a);
                return new b25(a, 5);
            }
            case 27: {
                final i94 a2 = k1.a;
                ep5.c((Object)a2);
                return new j15(a2, ((xc4)this.b).a(), (Set)this.c.zzb());
            }
            case 26: {
                final cd4 cd4 = (cd4)this.b;
                final i94 a3 = k1.a;
                ep5.c((Object)a3);
                return new i25((m35)new e25(a3, cd4.b.a(), 4), (long)us3.a.k(), (Clock)((ks5)this.c).zzb());
            }
            case 25: {
                final cd4 cd5 = (cd4)this.b;
                final i94 a4 = k1.a;
                ep5.c((Object)a4);
                return new i25((m35)new e25(a4, cd5.b.a(), 1), 10000L, (Clock)((ks5)this.c).zzb());
            }
            case 24: {
                final yw4 yw4 = (yw4)((ks5)this.b).zzb();
                final j74 j74 = (j74)this.c;
                return new xr4(yw4, (zw4)new b0(((j74)j74.b).a(), ((wc4)j74.c).a()));
            }
            case 23: {
                return new b0(((j74)this.b).a(), ((wc4)this.c).a());
            }
            case 22: {
                return new xw4(((rf4)this.b).b(), ((wc4)this.c).a());
            }
            case 21: {
                return this.a();
            }
            case 20: {
                return new tw4(((rs5)this.b).b(), (h85)((ks5)this.c).zzb());
            }
            case 19: {
                final i94 a5 = k1.a;
                ep5.c((Object)a5);
                final ue4 ue4 = (ue4)this.b;
                final i94 b = k1.b;
                ep5.c((Object)b);
                return new m14((Object)a5, (Object)new m14((Object)b, (Object)a5, (Object)((fd4)ue4.b).c(), 16, false), (Object)((ks5)this.c).zzb(), 17, false);
            }
            case 18: {
                final i94 b2 = k1.b;
                ep5.c((Object)b2);
                final i94 a6 = k1.a;
                ep5.c((Object)a6);
                return new f44((Object)b2, (Object)a6, (Object)((fd4)this.b).b(), (Object)ks5.a(this.c));
            }
            case 17: {
                final Map a7 = ((js5)this.b).a;
                final i94 a8 = k1.a;
                ep5.c((Object)a8);
                return new hv4(a7, a8, (lk4)new xo1(((xi4)this.c).b.b()));
            }
            case 16: {
                final Context context = (Context)((ks5)this.b).zzb();
                final ApplicationInfo a9 = ((qr4)this.c).a();
                PackageInfo packageInfo;
                try {
                    packageInfo = Wrappers.packageManager(context).getPackageInfo(a9.packageName, 0);
                }
                catch (final PackageManager$NameNotFoundException ex) {
                    packageInfo = null;
                }
                return packageInfo;
            }
            case 15: {
                final i94 b3 = k1.b;
                ep5.c((Object)b3);
                final i94 a10 = k1.a;
                ep5.c((Object)a10);
                final Context context2 = (Context)((qr4)this.b).b.zzb();
                final cv4 cv4 = new cv4();
                cv4.f = new q44(context2, zzt.zzt().zzb(), cv4, cv4);
                return new b23((Object)b3, (Object)a10, (Object)cv4, (Object)ks5.a(this.c));
            }
            case 14: {
                return new ts4((wd4)((ms5)this.b).a, new qk4((Object)((dd4)this.c).b.a, 3));
            }
            case 13: {
                return new xr4((mq3)((ks5)this.b).zzb(), ((ns5)this.c).a());
            }
            case 12: {
                return new nr4(w65.O(((cd4)this.b).b.a()), (mr4)((ks5)this.c).zzb());
            }
            case 11: {
                final w1 v = (w1)((s15)this.b).zzb();
                final do4 a11 = ((ue4)this.c).a();
                final ho3 ho3 = new ho3("com.google.android.gms.ads.internal.instream.client.IInstreamAd");
                synchronized (a11) {
                    final View o = a11.o;
                    monitorexit(a11);
                    ((aq4)ho3).c = o;
                    ((aq4)ho3).n = a11.i();
                    ((aq4)ho3).v = v;
                    ((aq4)ho3).w = false;
                    ((aq4)ho3).x = false;
                    if (a11.l() != null) {
                        a11.l().f0((aq4)ho3);
                    }
                    return ho3;
                }
            }
            case 10: {
                final i94 a12 = k1.a;
                ep5.c((Object)a12);
                return new m14((Object)a12, (Object)((qp4)this.b).a(), (Object)new il3(23, (Object)a12, (Object)((qp4)((ue4)this.c).b).a()), 11, false);
            }
            case 9: {
                final zzbq zzbq = (zzbq)((ts5)this.b).zzb();
                final Clock clock = (Clock)((ks5)this.c).zzb();
                final i94 a13 = k1.a;
                ep5.c((Object)a13);
                return new hp4(zzbq, clock, (pg5)a13);
            }
            case 8: {
                final l2 a14 = ((nh4)this.b).a();
                final JSONObject jsonObject = (JSONObject)((on4)this.c).b.n;
                ep5.c((Object)jsonObject);
                return new eo4(a14, jsonObject);
            }
            case 7: {
                final Set b4 = ((rs5)this.c).b();
                final il4 il4 = (il4)this.b;
                if (il4.p == null) {
                    il4.p = (zi4)new xo1(b4);
                }
                final zi4 p = il4.p;
                ep5.c((Object)p);
                return p;
            }
            case 6: {
                return new ek4(((rs5)this.b).b(), ((nh4)this.c).a());
            }
            case 5: {
                ((xc4)this.c).a();
                final Context a15 = ((pi4)this.b).a;
                ep5.c((Object)a15);
                return a15;
            }
            case 4: {
                final String s = (String)((ks5)this.c).zzb();
                wx4 f = ((pi4)this.b).f;
                if (f == null) {
                    f = new wx4(s);
                }
                return f;
            }
            case 3: {
                return ((y64)this.b).e(((rs5)this.c).b());
            }
            case 2: {
                return new ff4(((nh4)this.b).a(), ((wc4)this.c).b());
            }
            case 1: {
                return new oe4(((ns5)this.b).a(), ((ns5)this.c).a());
            }
            case 0: {
                final Context context3 = (Context)((ms5)this.b).a;
                final x64 x64 = (x64)this.c;
                return new i74(context3, new il3(7, (Object)x64.c.a, (Object)x64.b.zzb()));
            }
        }
    }
}
