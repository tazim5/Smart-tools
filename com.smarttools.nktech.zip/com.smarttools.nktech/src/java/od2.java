public final class od2
{
    public final long a;
    public final long b;
    public final long c;
    public final float d;
    public final boolean e;
    public final long f;
    
    public od2(final long a, final long b, final long c, final float d, final boolean e, final long f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof od2)) {
            return false;
        }
        final od2 od2 = (od2)o;
        return this.a == od2.a && this.b == od2.b && this.c == od2.c && Float.compare(this.d, od2.d) == 0 && this.e == od2.e && this.f == od2.f;
    }
    
    @Override
    public final int hashCode() {
        return Long.hashCode(this.f) + vo2.d(g91.a((Long.hashCode(this.c) + (Long.hashCode(this.b) + Long.hashCode(this.a) * 31) * 31) * 31, 31, this.d), 31, this.e);
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("RamData(totalRam=");
        sb.append(this.a);
        sb.append(", availableRam=");
        sb.append(this.b);
        sb.append(", usedRam=");
        sb.append(this.c);
        sb.append(", usagePercent=");
        sb.append(this.d);
        sb.append(", lowMemory=");
        sb.append(this.e);
        sb.append(", threshold=");
        return mb.e(this.f, ")", sb);
    }
}
