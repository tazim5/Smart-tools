import kotlinx.coroutines.sync.b;

public final class ek2 extends b implements dk2
{
}
