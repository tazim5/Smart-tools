import com.google.android.gms.common.internal.Objects;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import com.google.android.gms.common.util.Base64Utils;
import java.nio.charset.Charset;
import java.util.concurrent.atomic.AtomicReference;
import com.google.android.gms.common.api.internal.BackgroundDetector$BackgroundStateChangeListener;
import android.app.Application;
import com.google.android.gms.common.util.PlatformVersion;
import com.google.android.gms.common.util.ProcessUtils;
import com.google.android.gms.common.api.internal.BackgroundDetector;
import java.util.concurrent.Executor;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.FirebaseCommonRegistrar;
import java.util.Collection;
import java.util.ArrayList;
import com.google.firebase.concurrent.UiExecutor;
import com.google.firebase.components.ComponentDiscoveryService;
import android.os.Trace;
import com.google.firebase.provider.FirebaseInitProvider;
import com.google.android.gms.common.internal.Preconditions;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import android.content.Context;

public final class o91
{
    public static final Object j;
    public static final sa k;
    public final Context a;
    public final String b;
    public final w91 c;
    public final qu d;
    public final AtomicBoolean e;
    public final AtomicBoolean f;
    public final wo1 g;
    public final dc2 h;
    public final CopyOnWriteArrayList i;
    
    static {
        j = new Object();
        k = (sa)new un2(0);
    }
    
    public o91(final Context context, final String s, final w91 w91) {
        final AtomicBoolean e = new AtomicBoolean(false);
        this.e = e;
        this.f = new AtomicBoolean();
        final CopyOnWriteArrayList i = new CopyOnWriteArrayList();
        this.i = i;
        new CopyOnWriteArrayList();
        this.a = (Context)Preconditions.checkNotNull((Object)context);
        this.b = Preconditions.checkNotEmpty(s);
        this.c = (w91)Preconditions.checkNotNull((Object)w91);
        final le c = FirebaseInitProvider.c;
        Trace.beginSection("Firebase");
        Trace.beginSection("ComponentDiscovery");
        final ArrayList p3 = new en4(17, (Object)context, (Object)new tm3((Object)ComponentDiscoveryService.class, 6)).p();
        Trace.endSection();
        Trace.beginSection("Runtime");
        final UiExecutor c2 = UiExecutor.c;
        final ArrayList list = new ArrayList();
        final ArrayList list2 = new ArrayList();
        list.addAll((Collection)p3);
        list.add((Object)new lu((Object)new FirebaseCommonRegistrar(), 1));
        list.add((Object)new lu((Object)new ExecutorsRegistrar(), 1));
        list2.add((Object)ut.c((Object)context, (Class)Context.class, new Class[0]));
        list2.add((Object)ut.c((Object)this, (Class)o91.class, new Class[0]));
        list2.add((Object)ut.c((Object)w91, (Class)w91.class, new Class[0]));
        final uf5 uf5 = new uf5(25);
        if (e63.a(context) && FirebaseInitProvider.n.get()) {
            list2.add((Object)ut.c((Object)c, (Class)le.class, new Class[0]));
        }
        final qu d = new qu((Executor)c2, list, list2, (nu)uf5);
        this.d = d;
        Trace.endSection();
        this.g = new wo1((dc2)new pu(2, (Object)this, (Object)context));
        this.h = ((ju)d).c((Class)su0.class);
        final l91 l91 = new l91(this);
        this.a();
        if (e.get()) {
            BackgroundDetector.getInstance().isInBackground();
        }
        i.add((Object)l91);
        Trace.endSection();
    }
    
    public static o91 b() {
        final Object j;
        monitorenter(j = o91.j);
        Label_0047: {
            try {
                final o91 o91 = (o91)((un2)o91.k).get((Object)"[DEFAULT]");
                if (o91 != null) {
                    ((su0)o91.h.get()).b();
                    monitorexit(j);
                    return o91;
                }
                break Label_0047;
            }
            finally {
                monitorexit(j);
                final StringBuilder sb = new StringBuilder("Default FirebaseApp is not initialized in this process ");
                sb.append(ProcessUtils.getMyProcessName());
                sb.append(". Make sure to call FirebaseApp.initializeApp(Context) first.");
                throw new IllegalStateException(sb.toString());
            }
        }
    }
    
    public static o91 e(Context applicationContext, final w91 w91) {
        final AtomicReference a = m91.a;
        Label_0087: {
            if (PlatformVersion.isAtLeastIceCreamSandwich()) {
                if (applicationContext.getApplicationContext() instanceof Application) {
                    final Application application = (Application)applicationContext.getApplicationContext();
                    final AtomicReference a2 = m91.a;
                    if (a2.get() == null) {
                        final Object o = new Object();
                        while (!a2.compareAndSet((Object)null, o)) {
                            if (a2.get() != null) {
                                break Label_0087;
                            }
                        }
                        BackgroundDetector.initialize(application);
                        BackgroundDetector.getInstance().addListener((BackgroundDetector$BackgroundStateChangeListener)o);
                    }
                }
            }
        }
        if (applicationContext.getApplicationContext() != null) {
            applicationContext = applicationContext.getApplicationContext();
        }
        final Object j = o91.j;
        synchronized (j) {
            final sa k = o91.k;
            final boolean containsKey = ((un2)k).containsKey((Object)"[DEFAULT]");
            final StringBuilder sb = new StringBuilder();
            sb.append("FirebaseApp name ");
            sb.append("[DEFAULT]");
            sb.append(" already exists!");
            Preconditions.checkState(containsKey ^ true, (Object)sb.toString());
            Preconditions.checkNotNull((Object)applicationContext, (Object)"Application context cannot be null.");
            final o91 o2 = new o91(applicationContext, "[DEFAULT]", w91);
            ((un2)k).put((Object)"[DEFAULT]", (Object)o2);
            monitorexit(j);
            o2.d();
            return o2;
        }
    }
    
    public final void a() {
        Preconditions.checkState(this.f.get() ^ true, (Object)"FirebaseApp was deleted");
    }
    
    public final String c() {
        final StringBuilder sb = new StringBuilder();
        this.a();
        sb.append(Base64Utils.encodeUrlSafeNoPadding(this.b.getBytes(Charset.defaultCharset())));
        sb.append("+");
        this.a();
        sb.append(Base64Utils.encodeUrlSafeNoPadding(this.c.b.getBytes(Charset.defaultCharset())));
        return sb.toString();
    }
    
    public final void d() {
        final Context a = this.a;
        if (!e63.a(a)) {
            this.a();
            final AtomicReference b = n91.b;
            if (b.get() == null) {
                final n91 n91 = new n91(a);
                while (!b.compareAndSet((Object)null, (Object)n91)) {
                    if (b.get() != null) {
                        return;
                    }
                }
                a.registerReceiver((BroadcastReceiver)n91, new IntentFilter("android.intent.action.USER_UNLOCKED"));
            }
        }
        else {
            this.a();
            this.a();
            this.d.h("[DEFAULT]".equals((Object)this.b));
            ((su0)this.h.get()).b();
        }
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (!(o instanceof o91)) {
            return false;
        }
        final o91 o2 = (o91)o;
        o2.a();
        return this.b.equals((Object)o2.b);
    }
    
    @Override
    public final int hashCode() {
        return this.b.hashCode();
    }
    
    @Override
    public final String toString() {
        return Objects.toStringHelper((Object)this).add("name", (Object)this.b).add("options", (Object)this.c).toString();
    }
}
