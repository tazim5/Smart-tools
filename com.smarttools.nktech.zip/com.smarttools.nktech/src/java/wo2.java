import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.material3.IconKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.draw.ScaleKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.State;

public final class wo2 implements nd1
{
    public final boolean c;
    public final eh n;
    public final State v;
    public final State w;
    
    public wo2(final boolean c, final eh n, final State v, final State w) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final eh n = this.n;
            ImageVector imageVector;
            if (this.c) {
                imageVector = n.c;
            }
            else {
                imageVector = n.d;
            }
            IconKt.Icon-ww6aTOc(imageVector, n.b, ScaleKt.scale(SizeKt.size-3ABfNKs((Modifier)Modifier.Companion, Dp.constructor-impl((float)24)), ((Number)this.v.getValue()).floatValue()), ((Color)this.w.getValue()).unbox-impl(), composer, 0, 0);
        }
        return t43.a;
    }
}
