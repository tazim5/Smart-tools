public final class k85
{
    public final String a;
    public final String b;
    
    public k85(final String a, final String b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof k85)) {
            return false;
        }
        final k85 k85 = (k85)o;
        return this.a.equals((Object)k85.a) && this.b.equals((Object)k85.b);
    }
    
    @Override
    public final int hashCode() {
        return String.valueOf((Object)this.a).concat(String.valueOf((Object)this.b)).hashCode();
    }
}
