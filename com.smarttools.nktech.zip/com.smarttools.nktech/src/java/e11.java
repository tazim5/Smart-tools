import com.google.android.gms.ads.internal.client.zzq;

public final class e11
{
    public int a;
    public int b;
    public int c;
    
    public e11() {
        this.a = 0;
        this.b = 0;
        this.c = 0;
    }
    
    public e11(final int a, final int c, final int b) {
        this.a = a;
        this.c = c;
        this.b = b;
    }
    
    public static e11 a(final zzq zzq) {
        if (zzq.zzd) {
            return new e11(3, 0, 0);
        }
        if (zzq.zzi) {
            return new e11(2, 0, 0);
        }
        if (zzq.zzh) {
            return new e11(0, 0, 0);
        }
        return new e11(1, zzq.zzf, zzq.zzc);
    }
    
    public boolean b() {
        return this.a == 3;
    }
}
