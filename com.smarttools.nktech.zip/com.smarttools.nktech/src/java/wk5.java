public final class wk5
{
    public final to5 a;
    public final xk5 b;
    
    public wk5(final to5 a, final xk5 b) {
        this.b = b;
        this.a = a;
    }
}
