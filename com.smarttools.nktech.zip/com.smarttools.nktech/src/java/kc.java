public final class kc
{
    public final boolean a;
    public boolean b;
    
    public kc(final eq5 eq5, final int n) {
        switch (n) {
            default: {
                this.a = eq5.d((Class)ti1.class);
                this.b = (bx0.a.f((Class)nq0.class) != null);
                return;
            }
            case 1: {
                boolean a = false;
                this.b = false;
                if (eq5.f((Class)lc.class) != null) {
                    a = true;
                }
                this.a = a;
            }
        }
    }
}
