public abstract class as5
{
    public static void f(final int n, final Object[] array) {
        for (int i = 0; i < n; ++i) {
            if (array[i] == null) {
                throw new NullPointerException(e8.c(i, "at index "));
            }
        }
    }
    
    public abstract boolean a(final a1 p0, final w0 p1, final w0 p2);
    
    public abstract boolean b(final a1 p0, final Object p1, final Object p2);
    
    public abstract boolean c(final a1 p0, final z0 p1, final z0 p2);
    
    public abstract void d(final z0 p0, final z0 p1);
    
    public abstract void e(final z0 p0, final Thread p1);
}
