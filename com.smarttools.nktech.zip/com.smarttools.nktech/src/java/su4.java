import java.nio.ByteOrder;
import java.nio.ByteBuffer;

public interface su4
{
    public static final ByteBuffer a = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder());
    
    kt4 a(final kt4 p0);
    
    void b(final ByteBuffer p0);
    
    ByteBuffer zzb();
    
    void zzc();
    
    void zzd();
    
    void zzf();
    
    boolean zzg();
    
    boolean zzh();
}
