public interface j12
{
    b83 getViewModelStore(final String p0);
}
