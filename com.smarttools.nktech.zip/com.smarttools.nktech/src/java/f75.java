public final class f75
{
    public final e75 a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    
    public f75() {
        this.a = (e75)new Object();
    }
}
