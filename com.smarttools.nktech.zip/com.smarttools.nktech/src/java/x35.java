import com.google.android.gms.ads.internal.util.zze;
import org.json.JSONException;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.util.zzbw;
import org.json.JSONObject;
import com.google.android.gms.ads.identifier.AdvertisingIdClient$Info;

public final class x35 implements l35
{
    public final AdvertisingIdClient$Info a;
    public final String b;
    public final dk c;
    
    public x35(final AdvertisingIdClient$Info a, final String b, final dk c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final void a(final Object o) {
        final dk c = this.c;
        final JSONObject jsonObject = (JSONObject)o;
        Label_0163: {
            JSONObject zzf;
            try {
                zzf = zzbw.zzf(jsonObject, "pii");
                final AdvertisingIdClient$Info a = this.a;
                if (a != null && !TextUtils.isEmpty((CharSequence)a.getId())) {
                    zzf.put("rdid", (Object)a.getId());
                    zzf.put("is_lat", a.isLimitAdTrackingEnabled());
                    zzf.put("idtype", (Object)"adid");
                    final String s = (String)c.n;
                    final long c2 = c.c;
                    if (s != null && c2 >= 0L) {
                        zzf.put("paidv1_id_android_3p", (Object)s);
                        zzf.put("paidv1_creation_time_android_3p", c2);
                    }
                    return;
                }
            }
            catch (final JSONException ex) {
                break Label_0163;
            }
            final String b = this.b;
            if (b != null) {
                zzf.put("pdid", (Object)b);
                zzf.put("pdidtype", (Object)"ssaid");
            }
            return;
        }
        final JSONException ex;
        zze.zzb("Failed putting Ad ID.", (Throwable)ex);
    }
}
