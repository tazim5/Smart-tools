public final class e55
{
    public final String a;
    
    public e55(final String a) {
        this.a = a;
    }
}
