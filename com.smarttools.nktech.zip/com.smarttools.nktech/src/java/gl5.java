import android.view.View;
import com.google.android.gms.internal.ads.l2;
import com.google.android.gms.ads.internal.client.zzcb;
import java.util.concurrent.ScheduledExecutorService;
import com.google.android.gms.ads.admanager.AppEventListener;
import java.security.InvalidAlgorithmParameterException;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.internal.ads.zzfio;
import com.google.android.gms.internal.ads.zzefq;
import com.google.android.gms.internal.ads.zzfli;
import android.webkit.WebView;
import com.google.android.gms.internal.ads.zzflk;
import com.google.android.gms.internal.ads.zzflo;
import com.google.android.gms.internal.ads.zzefp;
import android.text.TextUtils;
import java.io.IOException;
import android.os.Bundle;
import java.util.Collection;
import androidx.camera.core.ImageCaptureException;
import java.io.FileDescriptor;
import android.os.ParcelFileDescriptor;
import java.io.Closeable;
import android.net.Uri;
import com.smarttools.nktech.features.tools.common.d;
import android.media.ExifInterface;
import com.google.android.gms.ads.internal.client.zzl;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import com.google.android.gms.internal.ads.zzdzp;
import java.util.concurrent.ExecutionException;
import com.google.android.gms.internal.ads.zzdxn;
import com.google.android.gms.internal.ads.zzbwa;
import com.google.android.gms.internal.ads.e;
import android.content.ContentValues;
import com.google.android.gms.internal.ads.n0;
import java.util.ArrayList;
import android.database.sqlite.SQLiteDatabase;
import java.security.GeneralSecurityException;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.android.gms.ads.internal.client.zzba;
import android.graphics.PorterDuffColorFilter;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff$Mode;
import android.graphics.drawable.Drawable;
import android.graphics.Shader$TileMode;
import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.Bitmap$Config;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.LayerDrawable;
import android.content.res.ColorStateList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import android.view.Surface;
import android.media.ImageReader;
import java.util.Objects;
import java.util.concurrent.Executor;
import android.util.Size;
import com.google.android.gms.internal.ads.zzgss;
import com.google.android.gms.internal.ads.zzgrl;
import com.google.android.gms.internal.ads.zzgve;
import java.util.LinkedHashSet;
import androidx.camera.core.impl.utils.executor.b;
import java.io.File;
import android.location.Location;
import com.google.android.gms.internal.ads.e2;
import com.google.android.gms.ads.internal.zza;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.zzcbt;
import android.content.Context;
import com.google.android.gms.ads.internal.zzf;

public final class gl5 implements jl5, qi1, bg5, zzf, n55
{
    public final int c;
    public Object n = n;
    public Object v = v;
    public Object w = w;
    public Object x = x;
    public Object y = y;
    public Object z = z;
    
    public gl5(final int c) {
        switch (this.c = c) {
            default: {
                this.n = new int[] { 2131165261, 2131165259, 2131165185 };
                this.v = new int[] { 2131165209, 2131165244, 2131165216, 2131165211, 2131165212, 2131165215, 2131165214 };
                this.w = new int[] { 2131165258, 2131165260, 2131165202, 2131165254, 2131165255, 2131165256, 2131165257 };
                this.x = new int[] { 2131165234, 2131165200, 2131165233 };
                this.y = new int[] { 2131165252, 2131165262 };
                this.z = new int[] { 2131165188, 2131165194, 2131165189, 2131165195 };
                return;
            }
            case 18: {
                this.z = null;
                this.n = null;
                this.v = null;
                this.w = null;
                this.x = null;
                this.y = ji5.x;
            }
        }
    }
    
    public gl5(final Context w, final zzcbt x, final mq3 v, final mw4 mw4, final String n, final i85 y) {
        this.c = 12;
        this.w = w;
        this.x = x;
        this.v = v;
        this.n = n;
        this.y = y;
        this.z = zzt.zzo().c();
    }
    
    public gl5(final Location v, final Context w, final String n, final e6 x, final String y, final if1 z) {
        this.c = 5;
        this.v = v;
        this.w = w;
        this.n = n;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public gl5(final Location v, final File w, final Context x, final String n, final e6 y, final if1 z) {
        this.c = 6;
        this.v = v;
        this.w = w;
        this.x = x;
        this.n = n;
        this.y = y;
        this.z = z;
    }
    
    public gl5(final b n) {
        this.c = 3;
        this.v = new Object();
        this.w = new LinkedHashSet();
        this.x = new LinkedHashSet();
        this.y = new LinkedHashSet();
        this.z = new cm(this);
        this.n = n;
    }
    
    public gl5(final String n, final zzgve w, final zzgrl x, final zzgss y, final Integer z) {
        this.c = 0;
        this.n = n;
        this.v = pl5.a(n);
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public gl5(final mw4 v, final m14 w, final m86 x, final String n, final pg5 z) {
        this.c = 16;
        this.v = v;
        this.w = w;
        this.x = x;
        this.n = n;
        this.z = z;
    }
    
    public gl5(final nd4 v, final Context w, final m14 x, final n65 n) {
        this.c = 15;
        this.v = v;
        this.w = w;
        this.x = x;
        this.n = n;
        this.y = v.c();
        n.q = (s05)x.v;
    }
    
    public gl5(final o91 n, final wv1 v, final dc2 x, final dc2 y, final r91 z) {
        this.c = 4;
        n.a();
        final wg2 w = new wg2(n.a);
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public gl5(final si1 n, final Size size, final boolean b) {
        this.c = 7;
        cz5.a();
        this.n = n;
        final jk jk = (jk)((yd2)n).a(z53.G, (Object)null);
        if (jk == null) {
            final StringBuilder sb = new StringBuilder("Implementation is missing option unpacker for ");
            sb.append((String)((yd2)n).a(dw2.A, (Object)n.toString()));
            throw new IllegalStateException(sb.toString());
        }
        final on on = new on();
        jk.a(n, on);
        this.v = on.d();
        final l44 w = new l44(1);
        this.w = w;
        final qf1 x = new qf1(17, false);
        this.x = x;
        final Executor executor = (Executor)((yd2)n).a(nm1.u, (Object)wt5.c());
        Objects.requireNonNull((Object)executor);
        final oa2 y = new oa2(executor);
        this.y = y;
        final int m = n.m();
        final Integer n2 = (Integer)((yd2)n).a(si1.x, (Object)null);
        int intValue;
        if (n2 != null) {
            intValue = n2;
        }
        else {
            intValue = 256;
        }
        if (((yd2)n).a(si1.y, (Object)null) == null) {
            final m11 m2 = new m11();
            final m11 m3 = new m11();
            final fd fd = new fd(size, m, intValue, b, m2, m3);
            this.z = fd;
            final fd fd2 = (fd)w.y;
            final boolean b2 = false;
            jy5.e("CaptureNode does not support recreation yet.", fd2 == null && w.w == null);
            w.y = fd;
            Object o;
            Object b3;
            if (!b) {
                o = new zv1(size.getWidth(), size.getHeight(), m, 4);
                fd.a = (gl)((zv1)o).n;
                b3 = new rn(w, 0);
            }
            else {
                o = new qf1(new y7(ImageReader.newInstance(size.getWidth(), size.getHeight(), m, 4)));
                b3 = new um(1, (Object)w, o);
            }
            final Surface h = ((vj1)o).h();
            Objects.requireNonNull((Object)h);
            boolean b4 = b2;
            if (fd.b == null) {
                b4 = true;
            }
            jy5.e("The surface is already set.", b4);
            fd.b = new ak1(h, size, m);
            w.w = new oh2((vj1)o);
            ((vj1)o).i((uj1)new h3((Object)w, 8), (Executor)wt5.d());
            m2.b = b3;
            m3.b = new rn(w, 1);
            final m11 m4 = new m11();
            final m11 m5 = new m11();
            w.x = new gd(m4, m5, m, intValue);
            m4.b = new wn2(x, 0);
            m5.b = new wn2(x, 1);
            final m11 m6 = new m11();
            final fe fe = new fe(m6, m, intValue);
            x.v = fe;
            y.b = fe;
            m6.b = new ma2((Object)y, 0);
            y.c = new la2(0);
            y.d = new eq5(y.j, 9);
            y.g = new k26(28);
            y.e = new h26(24);
            y.f = new e36(28);
            y.h = new qq(29);
            if (m == 35 || y.k) {
                y.i = new c96(28);
            }
            return;
        }
        throw new ClassCastException();
    }
    
    public gl5(final wi4 n, final fj4 v, final gm4 w, final bm4 x, final qf4 y) {
        this.c = 14;
        this.z = new AtomicBoolean(false);
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
    }
    
    public gl5(final z75 z, final Object v, final String n, final yq1 w, final List x, final yq1 y) {
        this.c = 17;
        this.z = z;
        this.v = v;
        this.n = n;
        this.w = w;
        this.x = x;
        this.y = y;
    }
    
    public static boolean b(final int n, final int[] array) {
        for (int length = array.length, i = 0; i < length; ++i) {
            if (array[i] == n) {
                return true;
            }
        }
        return false;
    }
    
    public static ColorStateList f(final int n, final Context context) {
        final int c = ly2.c(2130903132, context);
        return new ColorStateList(new int[][] { ly2.b, ly2.d, ly2.c, ly2.f }, new int[] { ly2.b(2130903130, context), zs.b(c, n), zs.b(c, n), n });
    }
    
    public static LayerDrawable i(final if2 if2, final Context context, int dimensionPixelSize) {
        dimensionPixelSize = context.getResources().getDimensionPixelSize(dimensionPixelSize);
        final Drawable c = if2.c(context, 2131165248);
        final Drawable c2 = if2.c(context, 2131165249);
        BitmapDrawable bitmapDrawable;
        BitmapDrawable bitmapDrawable2;
        if (c instanceof BitmapDrawable && c.getIntrinsicWidth() == dimensionPixelSize && c.getIntrinsicHeight() == dimensionPixelSize) {
            bitmapDrawable = (BitmapDrawable)c;
            bitmapDrawable2 = new BitmapDrawable(bitmapDrawable.getBitmap());
        }
        else {
            final Bitmap bitmap = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap$Config.ARGB_8888);
            final Canvas canvas = new Canvas(bitmap);
            c.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
            c.draw(canvas);
            bitmapDrawable = new BitmapDrawable(bitmap);
            bitmapDrawable2 = new BitmapDrawable(bitmap);
        }
        bitmapDrawable2.setTileModeX(Shader$TileMode.REPEAT);
        BitmapDrawable bitmapDrawable3;
        if (c2 instanceof BitmapDrawable && c2.getIntrinsicWidth() == dimensionPixelSize && c2.getIntrinsicHeight() == dimensionPixelSize) {
            bitmapDrawable3 = (BitmapDrawable)c2;
        }
        else {
            final Bitmap bitmap2 = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap$Config.ARGB_8888);
            final Canvas canvas2 = new Canvas(bitmap2);
            c2.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
            c2.draw(canvas2);
            bitmapDrawable3 = new BitmapDrawable(bitmap2);
        }
        final LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { (Drawable)bitmapDrawable, (Drawable)bitmapDrawable3, (Drawable)bitmapDrawable2 });
        layerDrawable.setId(0, 16908288);
        layerDrawable.setId(1, 16908303);
        layerDrawable.setId(2, 16908301);
        return layerDrawable;
    }
    
    public static void n(final Drawable drawable, final int n, PorterDuff$Mode b) {
        final int[] a = wz0.a;
        final Drawable mutate = drawable.mutate();
        PorterDuff$Mode b2 = b;
        if (b == null) {
            b2 = d9.b;
        }
        b = d9.b;
        synchronized (d9.class) {
            final PorterDuffColorFilter e = if2.e(n, b2);
            monitorexit(d9.class);
            mutate.setColorFilter((ColorFilter)e);
        }
    }
    
    public static gl5 s(final String s, final zzgve zzgve, final zzgrl zzgrl, final zzgss zzgss, final Integer n) {
        if (zzgss == zzgss.w) {
            if (n != null) {
                throw new GeneralSecurityException("Keys with output prefix type raw should not have an id requirement.");
            }
        }
        else if (n == null) {
            throw new GeneralSecurityException("Keys with output prefix type different from raw should have an id requirement.");
        }
        return new gl5(s, zzgve, zzgrl, zzgss, n);
    }
    
    public static final void w(final SQLiteDatabase sqLiteDatabase, final ArrayList list) {
        final int size = list.size();
        int i = 0;
        long n = 0L;
        while (i < size) {
            final n0 n2 = (n0)list.get(i);
            long b = n;
            if (n2.S() == 2) {
                b = n;
                if (n2.B() > n) {
                    b = n2.B();
                }
            }
            ++i;
            n = b;
        }
        if (n != 0L) {
            final ContentValues contentValues = new ContentValues();
            contentValues.put("value", Long.valueOf(n));
            sqLiteDatabase.update("offline_signal_statistics", contentValues, "statistic_name = 'last_successful_request_time'", (String[])null);
        }
    }
    
    public gl5 A(final cg5 cg5) {
        return new gl5((z75)this.z, this.v, (String)this.n, (yq1)this.w, (List)this.x, (yq1)e.y((yq1)this.y, cg5, (Executor)((z75)this.z).a));
    }
    
    public yq1 B(final g75 g75, final mw4 mw4) {
        final oi4 a = g75.a;
        this.y = a;
        if (g75.c != null) {
            if (a.zzf() != null) {
                final r45 e = g75.c.e;
                final l55 zzf = g75.a.zzf();
                e.getClass();
                e.P = (r45)zzf;
            }
            return (yq1)e.r((Object)g75.c);
        }
        a.zzb().g = g75.b;
        return ((mw4)this.v).m(mw4, (am4)null, g75.a);
    }
    
    public ki5 C() {
        if (this.z == null) {
            throw new GeneralSecurityException("AES key size is not set");
        }
        if (this.n == null) {
            throw new GeneralSecurityException("HMAC key size is not set");
        }
        if (this.v == null) {
            throw new GeneralSecurityException("iv size is not set");
        }
        final Integer n = (Integer)this.w;
        if (n == null) {
            throw new GeneralSecurityException("tag size is not set");
        }
        if (this.x != null) {
            final int intValue = n;
            final ii5 ii5 = (ii5)this.x;
            if (ii5 == ii5.v) {
                if (intValue > 20) {
                    throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 20 bytes for SHA1", new Object[] { n }));
                }
            }
            else if (ii5 == ii5.w) {
                if (intValue > 28) {
                    throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 28 bytes for SHA224", new Object[] { n }));
                }
            }
            else if (ii5 == ii5.x) {
                if (intValue > 32) {
                    throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 32 bytes for SHA256", new Object[] { n }));
                }
            }
            else if (ii5 == ii5.y) {
                if (intValue > 48) {
                    throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 48 bytes for SHA384", new Object[] { n }));
                }
            }
            else {
                if (ii5 != ii5.z) {
                    throw new GeneralSecurityException("unknown hash type; must be SHA1, SHA224, SHA256, SHA384 or SHA512");
                }
                if (intValue > 64) {
                    throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; can be at most 64 bytes for SHA512", new Object[] { n }));
                }
            }
            return new ki5((int)this.z, (int)this.n, (int)this.v, (int)this.w, (ji5)this.y, (ii5)this.x);
        }
        throw new GeneralSecurityException("hash type is not set");
    }
    
    public ze5 D(final zzbwa zzbwa, final jv4 jv4, final jv4 jv5, final cg5 cg5) {
        final String w = zzbwa.w;
        zzt.zzp();
        final boolean zzB = com.google.android.gms.ads.internal.util.zzt.zzB(w);
        final i94 i94 = (i94)this.n;
        Object o;
        if (zzB) {
            o = e.p((Throwable)new zzdxn(1));
        }
        else {
            o = e.o(jv4.n(zzbwa), (Class)ExecutionException.class, (cg5)qh4.f, (Executor)i94);
        }
        return e.o((yq1)e.y((yq1)gg5.r((yq1)o), cg5, (Executor)i94), (Class)zzdzp.class, (cg5)new g04((Object)this, (Object)jv5, (Object)zzbwa, (Object)cg5, 2), (Executor)i94);
    }
    
    public gl5 E(final long n, final TimeUnit timeUnit) {
        return new gl5((z75)this.z, this.v, (String)this.n, (yq1)this.w, (List)this.x, e.z((yq1)this.y, n, timeUnit, ((z75)this.z).b));
    }
    
    public void a(final String s, final String s2) {
        final HashMap hashMap = (HashMap)this.y;
        if (hashMap != null) {
            hashMap.put((Object)s, (Object)s2);
            return;
        }
        throw new IllegalStateException("Property \"autoMetadata\" has not been set");
    }
    
    public md c() {
        String s;
        if (this.n == null) {
            s = " transportName";
        }
        else {
            s = "";
        }
        String concat = s;
        if (this.v == null) {
            concat = s.concat(" encodedPayload");
        }
        String f = concat;
        if (this.w == null) {
            f = mb.f(concat, " eventMillis");
        }
        String f2 = f;
        if (this.x == null) {
            f2 = mb.f(f, " uptimeMillis");
        }
        String f3 = f2;
        if (this.y == null) {
            f3 = mb.f(f2, " autoMetadata");
        }
        if (f3.isEmpty()) {
            return new md((String)this.n, (Integer)this.z, (l31)this.v, (long)this.w, (long)this.x, (HashMap)this.y);
        }
        throw new IllegalStateException("Missing required properties:".concat(f3));
    }
    
    public void d() {
        cz5.a();
        final l44 l44 = (l44)this.w;
        l44.getClass();
        cz5.a();
        final fd fd = (fd)l44.y;
        Objects.requireNonNull((Object)fd);
        final oh2 oh2 = (oh2)l44.w;
        Objects.requireNonNull((Object)oh2);
        final ak1 b = fd.b;
        Objects.requireNonNull((Object)b);
        ((lv0)b).a();
        final ak1 b2 = fd.b;
        Objects.requireNonNull((Object)b2);
        uo3.d((yq1)((lv0)b2).e).addListener((Runnable)new ou2((Object)oh2, 6), (Executor)wt5.d());
        this.x.getClass();
        this.y.getClass();
    }
    
    public yq1 e(final mw4 mw4, final am4 am4) {
        monitorenter(this);
        Label_0241: {
            try {
                final pd4 b = am4.b((m55)mw4.v);
                final e55 e55 = new e55((String)this.n);
                switch (b.a) {
                    default: {
                        b.d = e55;
                        break;
                    }
                    case 0: {
                        b.d = e55;
                        break;
                    }
                }
                final oi4 y = (oi4)b.c();
                y.zzg();
                y.zzg();
                final zzl d = y.zzg().d;
                if (d.zzs == null && d.zzx == null) {
                    final o65 zzg = y.zzg();
                    final Object o = e.y((yq1)gg5.r(((m14)this.w).c(mw4, am4, y)), (cg5)new c55(this, mw4, new d55(am4, mw4, zzg.d, zzg.f, (pg5)this.z, zzg.j, (h75)null), am4, y), (Executor)this.z);
                    monitorexit(this);
                    return (yq1)o;
                }
                break Label_0241;
            }
            finally {
                monitorexit(this);
                final Object o;
                return (yq1)o;
                final oi4 y;
                this.y = y;
                o = ((mw4)this.v).m(mw4, am4, y);
                monitorexit(this);
                return (yq1)o;
            }
        }
    }
    
    public void g(uu5 uu5) {
        switch (this.c) {
            default: {
                uu5 = (uu5)this.w;
                final Location location = (Location)this.v;
                if (location != null) {
                    try {
                        final ExifInterface exifInterface = new ExifInterface(((File)uu5).getAbsolutePath());
                        d.n(exifInterface, location);
                        exifInterface.saveAttributes();
                    }
                    catch (final Exception ex) {
                        ((Throwable)ex).printStackTrace();
                    }
                    d.h((Context)this.x, Uri.fromFile((File)uu5), location, (String)this.n);
                }
                ((e6)this.y).invoke((Object)((File)uu5).getAbsolutePath());
                return;
            }
            case 5: {
                final Context context = (Context)this.w;
                uu5 = (uu5)uu5.n;
                if (uu5 != null) {
                    final Location location2 = (Location)this.v;
                    if (location2 != null) {
                        Label_0231: {
                            ParcelFileDescriptor openFileDescriptor = null;
                            Label_0226: {
                                try {
                                    openFileDescriptor = context.getContentResolver().openFileDescriptor((Uri)uu5, "rw");
                                    if (openFileDescriptor != null) {
                                        final ExifInterface exifInterface2 = new(android.media.ExifInterface.class)();
                                        final ExifInterface exifInterface4;
                                        final ExifInterface exifInterface3 = exifInterface4 = exifInterface2;
                                        final ParcelFileDescriptor parcelFileDescriptor = openFileDescriptor;
                                        final FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                                        new ExifInterface(fileDescriptor);
                                        final ExifInterface exifInterface5 = exifInterface3;
                                        final Location location3 = location2;
                                        d.n(exifInterface5, location3);
                                        final ExifInterface exifInterface6 = exifInterface3;
                                        exifInterface6.saveAttributes();
                                        final ParcelFileDescriptor parcelFileDescriptor2 = openFileDescriptor;
                                        final Throwable t = null;
                                        hu5.a((Closeable)parcelFileDescriptor2, t);
                                    }
                                    break Label_0231;
                                }
                                catch (final Exception openFileDescriptor) {
                                    break Label_0226;
                                }
                                try {
                                    final ExifInterface exifInterface2 = new(android.media.ExifInterface.class)();
                                    final ExifInterface exifInterface4;
                                    final ExifInterface exifInterface3 = exifInterface4 = exifInterface2;
                                    final ParcelFileDescriptor parcelFileDescriptor = openFileDescriptor;
                                    final FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                                    new ExifInterface(fileDescriptor);
                                    final ExifInterface exifInterface5 = exifInterface3;
                                    final Location location3 = location2;
                                    d.n(exifInterface5, location3);
                                    final ExifInterface exifInterface6 = exifInterface3;
                                    exifInterface6.saveAttributes();
                                    final ParcelFileDescriptor parcelFileDescriptor2 = openFileDescriptor;
                                    final Throwable t = null;
                                    hu5.a((Closeable)parcelFileDescriptor2, t);
                                    break Label_0231;
                                }
                                finally {
                                    try {}
                                    finally {
                                        final Throwable t2;
                                        hu5.a((Closeable)openFileDescriptor, t2);
                                    }
                                }
                            }
                            ((Throwable)openFileDescriptor).printStackTrace();
                        }
                        d.h(context, (Uri)uu5, location2, (String)this.n);
                    }
                }
                String string;
                if (uu5 == null || (string = ((Uri)uu5).toString()) == null) {
                    string = (String)this.y;
                }
                ((e6)this.x).invoke((Object)string);
            }
        }
    }
    
    public o76 h(final o76 o76) {
        return o76.d((Executor)new ia(1), (pp0)new h3((Object)this, 14));
    }
    
    public void j(final ImageCaptureException ex) {
        switch (this.c) {
            default: {
                ((if1)this.z).invoke(xg.g("Capture failed: ", ((Throwable)ex).getMessage()));
                return;
            }
            case 5: {
                ((if1)this.z).invoke(xg.g("Capture failed: ", ((Throwable)ex).getMessage()));
            }
        }
    }
    
    public ArrayList k() {
        final Object v;
        final ArrayList list;
        Object v2;
        synchronized (v = this.v) {
            list = new ArrayList();
            monitorenter(v2 = this.v);
            final ArrayList list2 = new(java.util.ArrayList.class)();
            final ArrayList list4;
            final ArrayList list3 = list4 = list2;
            final gl5 gl5 = this;
            final Object o = gl5.w;
            final LinkedHashSet set = (LinkedHashSet)o;
            new ArrayList((Collection)set);
            final Object o2 = v2;
            monitorexit(o2);
            final ArrayList list5 = list;
            final ArrayList list6 = list3;
            list5.addAll((Collection)list6);
            final gl5 gl6 = this;
            final Object o3 = gl6.v;
            final Object o4 = v2 = o3;
            monitorenter(o4);
            final ArrayList list7 = new(java.util.ArrayList.class)();
            final ArrayList list9;
            final ArrayList list8 = list9 = list7;
            final gl5 gl7 = this;
            final Object o5 = gl7.y;
            final LinkedHashSet set2 = (LinkedHashSet)o5;
            new ArrayList((Collection)set2);
            final Object o6 = v2;
            monitorexit(o6);
            final ArrayList list10 = list;
            final ArrayList list11 = list8;
            list10.addAll((Collection)list11);
            return list;
        }
        try {
            final ArrayList list2 = new(java.util.ArrayList.class)();
            final ArrayList list4;
            final ArrayList list3 = list4 = list2;
            final gl5 gl5 = this;
            final Object o = gl5.w;
            final LinkedHashSet set = (LinkedHashSet)o;
            new ArrayList((Collection)set);
            final Object o2 = v2;
            monitorexit(o2);
            final ArrayList list5 = list;
            final ArrayList list6 = list3;
            list5.addAll((Collection)list6);
            final gl5 gl6 = this;
            final Object o3 = gl6.v;
            final Object o4 = v2 = o3;
            synchronized (o4) {
                final ArrayList list7 = new(java.util.ArrayList.class)();
                final ArrayList list9;
                final ArrayList list8 = list9 = list7;
                final gl5 gl7 = this;
                final Object o5 = gl7.y;
                final LinkedHashSet set2 = (LinkedHashSet)o5;
                new ArrayList((Collection)set2);
                final Object o6 = v2;
                monitorexit(o6);
                final ArrayList list10 = list;
                final ArrayList list11 = list8;
                list10.addAll((Collection)list11);
                return list;
            }
        }
        finally {}
    }
    
    public ColorStateList l(final int n, final Context context) {
        if (n == 2131165205) {
            return ps5.a(2131034133, context);
        }
        if (n == 2131165251) {
            return ps5.a(2131034136, context);
        }
        if (n == 2131165250) {
            final int[][] array = new int[3][];
            final int[] array2 = new int[3];
            final ColorStateList d = ly2.d(2130903138, context);
            if (d != null && d.isStateful()) {
                final int[] b = ly2.b;
                array[0] = b;
                array2[0] = d.getColorForState(b, 0);
                array[1] = ly2.e;
                array2[1] = ly2.c(2130903131, context);
                array[2] = ly2.f;
                array2[2] = d.getDefaultColor();
            }
            else {
                array[0] = ly2.b;
                array2[0] = ly2.b(2130903138, context);
                array[1] = ly2.e;
                array2[1] = ly2.c(2130903131, context);
                array[2] = ly2.f;
                array2[2] = ly2.c(2130903138, context);
            }
            return new ColorStateList(array, array2);
        }
        if (n == 2131165193) {
            return f(ly2.c(2130903130, context), context);
        }
        if (n == 2131165187) {
            return f(0, context);
        }
        if (n == 2131165192) {
            return f(ly2.c(2130903128, context), context);
        }
        if (n == 2131165246 || n == 2131165247) {
            return ps5.a(2131034135, context);
        }
        if (b(n, (int[])this.v)) {
            return ly2.d(2130903133, context);
        }
        if (b(n, (int[])this.y)) {
            return ps5.a(2131034132, context);
        }
        if (b(n, (int[])this.z)) {
            return ps5.a(2131034131, context);
        }
        if (n == 2131165243) {
            return ps5.a(2131034134, context);
        }
        return null;
    }
    
    public void m(final Bundle p0, final String p1, final String p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc_w           "scope"
        //     4: aload_3        
        //     5: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //     8: aload_1        
        //     9: ldc_w           "sender"
        //    12: aload_2        
        //    13: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //    16: aload_1        
        //    17: ldc_w           "subtype"
        //    20: aload_2        
        //    21: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //    24: aload_0        
        //    25: getfield        gl5.n:Ljava/lang/Object;
        //    28: checkcast       Lo91;
        //    31: astore_2       
        //    32: aload_2        
        //    33: invokevirtual   o91.a:()V
        //    36: aload_1        
        //    37: ldc_w           "gmp_app_id"
        //    40: aload_2        
        //    41: getfield        o91.c:Lw91;
        //    44: getfield        w91.b:Ljava/lang/String;
        //    47: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //    50: aload_0        
        //    51: getfield        gl5.v:Ljava/lang/Object;
        //    54: checkcast       Lwv1;
        //    57: astore_3       
        //    58: aload_3        
        //    59: dup            
        //    60: astore          10
        //    62: monitorenter   
        //    63: aload_3        
        //    64: getfield        wv1.n:I
        //    67: ifne            118
        //    70: aload_3        
        //    71: getfield        wv1.c:Ljava/lang/Object;
        //    74: checkcast       Landroid/content/Context;
        //    77: invokevirtual   android/content/Context.getPackageManager:()Landroid/content/pm/PackageManager;
        //    80: ldc_w           "com.google.android.gms"
        //    83: iconst_0       
        //    84: invokevirtual   android/content/pm/PackageManager.getPackageInfo:(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
        //    87: astore_2       
        //    88: goto            99
        //    91: astore_2       
        //    92: aload_2        
        //    93: invokevirtual   java/lang/Object.toString:()Ljava/lang/String;
        //    96: pop            
        //    97: aconst_null    
        //    98: astore_2       
        //    99: aload_2        
        //   100: ifnull          118
        //   103: aload_3        
        //   104: aload_2        
        //   105: getfield        android/content/pm/PackageInfo.versionCode:I
        //   108: putfield        wv1.n:I
        //   111: goto            118
        //   114: astore_1       
        //   115: goto            584
        //   118: aload_3        
        //   119: getfield        wv1.n:I
        //   122: istore          4
        //   124: aload           10
        //   126: monitorexit    
        //   127: aload_1        
        //   128: ldc_w           "gmsv"
        //   131: iload           4
        //   133: invokestatic    java/lang/Integer.toString:(I)Ljava/lang/String;
        //   136: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   139: aload_1        
        //   140: ldc_w           "osv"
        //   143: getstatic       android/os/Build$VERSION.SDK_INT:I
        //   146: invokestatic    java/lang/Integer.toString:(I)Ljava/lang/String;
        //   149: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   152: aload_1        
        //   153: ldc_w           "app_ver"
        //   156: aload_0        
        //   157: getfield        gl5.v:Ljava/lang/Object;
        //   160: checkcast       Lwv1;
        //   163: invokevirtual   wv1.a:()Ljava/lang/String;
        //   166: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   169: aload_0        
        //   170: getfield        gl5.v:Ljava/lang/Object;
        //   173: checkcast       Lwv1;
        //   176: astore_2       
        //   177: aload_2        
        //   178: dup            
        //   179: astore          11
        //   181: monitorenter   
        //   182: aload_2        
        //   183: getfield        wv1.x:Ljava/lang/Object;
        //   186: checkcast       Ljava/lang/String;
        //   189: ifnonnull       203
        //   192: aload_2        
        //   193: invokevirtual   wv1.m:()V
        //   196: goto            203
        //   199: astore_1       
        //   200: goto            579
        //   203: aload_2        
        //   204: getfield        wv1.x:Ljava/lang/Object;
        //   207: checkcast       Ljava/lang/String;
        //   210: astore_3       
        //   211: aload           11
        //   213: monitorexit    
        //   214: aload_1        
        //   215: ldc_w           "app_ver_name"
        //   218: aload_3        
        //   219: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   222: aload_0        
        //   223: getfield        gl5.n:Ljava/lang/Object;
        //   226: checkcast       Lo91;
        //   229: astore_2       
        //   230: aload_2        
        //   231: invokevirtual   o91.a:()V
        //   234: aload_2        
        //   235: getfield        o91.b:Ljava/lang/String;
        //   238: astore_2       
        //   239: ldc_w           "SHA-1"
        //   242: invokestatic    java/security/MessageDigest.getInstance:(Ljava/lang/String;)Ljava/security/MessageDigest;
        //   245: aload_2        
        //   246: invokevirtual   java/lang/String.getBytes:()[B
        //   249: invokevirtual   java/security/MessageDigest.digest:([B)[B
        //   252: bipush          11
        //   254: invokestatic    android/util/Base64.encodeToString:([BI)Ljava/lang/String;
        //   257: astore_2       
        //   258: goto            266
        //   261: astore_2       
        //   262: ldc_w           "[HASH-ERROR]"
        //   265: astore_2       
        //   266: aload_1        
        //   267: ldc_w           "firebase-app-name-hash"
        //   270: aload_2        
        //   271: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   274: aload_0        
        //   275: getfield        gl5.z:Ljava/lang/Object;
        //   278: checkcast       Lr91;
        //   281: checkcast       Lcom/google/firebase/installations/a;
        //   284: invokevirtual   com/google/firebase/installations/a.d:()Lo76;
        //   287: invokestatic    az5.a:(Lfw2;)Ljava/lang/Object;
        //   290: checkcast       Lud;
        //   293: getfield        ud.a:Ljava/lang/String;
        //   296: astore_2       
        //   297: aload_2        
        //   298: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   301: ifne            331
        //   304: aload_1        
        //   305: ldc_w           "Goog-Firebase-Installations-Auth"
        //   308: aload_2        
        //   309: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   312: goto            331
        //   315: astore_2       
        //   316: goto            320
        //   319: astore_2       
        //   320: ldc_w           "FirebaseMessaging"
        //   323: ldc_w           "Failed to get FIS auth token"
        //   326: aload_2        
        //   327: invokestatic    android/util/Log.e:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //   330: pop            
        //   331: aload_1        
        //   332: ldc_w           "appid"
        //   335: aload_0        
        //   336: getfield        gl5.z:Ljava/lang/Object;
        //   339: checkcast       Lr91;
        //   342: checkcast       Lcom/google/firebase/installations/a;
        //   345: invokevirtual   com/google/firebase/installations/a.c:()Lo76;
        //   348: invokestatic    az5.a:(Lfw2;)Ljava/lang/Object;
        //   351: checkcast       Ljava/lang/String;
        //   354: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   357: aload_1        
        //   358: ldc_w           "cliv"
        //   361: ldc_w           "fcm-24.0.0"
        //   364: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   367: aload_0        
        //   368: getfield        gl5.y:Ljava/lang/Object;
        //   371: checkcast       Ldc2;
        //   374: invokeinterface dc2.get:()Ljava/lang/Object;
        //   379: checkcast       Lzg1;
        //   382: astore_2       
        //   383: aload_0        
        //   384: getfield        gl5.x:Ljava/lang/Object;
        //   387: checkcast       Ldc2;
        //   390: invokeinterface dc2.get:()Ljava/lang/Object;
        //   395: checkcast       Liv0;
        //   398: astore          8
        //   400: aload_2        
        //   401: ifnull          578
        //   404: aload           8
        //   406: ifnull          578
        //   409: aload_2        
        //   410: checkcast       Lsu0;
        //   413: astore_3       
        //   414: aload_3        
        //   415: dup            
        //   416: astore          10
        //   418: monitorenter   
        //   419: invokestatic    java/lang/System.currentTimeMillis:()J
        //   422: lstore          6
        //   424: aload_3        
        //   425: getfield        su0.a:Lpu;
        //   428: invokevirtual   pu.get:()Ljava/lang/Object;
        //   431: checkcast       Lah1;
        //   434: astore_2       
        //   435: aload_2        
        //   436: dup            
        //   437: astore          11
        //   439: monitorenter   
        //   440: aload_2        
        //   441: lload           6
        //   443: invokevirtual   ah1.g:(J)Z
        //   446: istore          5
        //   448: aload           11
        //   450: monitorexit    
        //   451: iload           5
        //   453: ifeq            524
        //   456: aload_2        
        //   457: dup            
        //   458: astore          11
        //   460: monitorenter   
        //   461: aload_2        
        //   462: invokestatic    java/lang/System.currentTimeMillis:()J
        //   465: invokevirtual   ah1.d:(J)Ljava/lang/String;
        //   468: astore          9
        //   470: aload_2        
        //   471: getfield        ah1.a:Landroid/content/SharedPreferences;
        //   474: invokeinterface android/content/SharedPreferences.edit:()Landroid/content/SharedPreferences$Editor;
        //   479: ldc_w           "last-used-date"
        //   482: aload           9
        //   484: invokeinterface android/content/SharedPreferences$Editor.putString:(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
        //   489: invokeinterface android/content/SharedPreferences$Editor.commit:()Z
        //   494: pop            
        //   495: aload_2        
        //   496: aload           9
        //   498: invokevirtual   ah1.f:(Ljava/lang/String;)V
        //   501: aload           11
        //   503: monitorexit    
        //   504: getstatic       com/google/firebase/heartbeatinfo/HeartBeatInfo$HeartBeat.n:Lcom/google/firebase/heartbeatinfo/HeartBeatInfo$HeartBeat;
        //   507: astore_2       
        //   508: aload           10
        //   510: monitorexit    
        //   511: goto            531
        //   514: astore_1       
        //   515: goto            573
        //   518: astore_1       
        //   519: aload           11
        //   521: monitorexit    
        //   522: aload_1        
        //   523: athrow         
        //   524: getstatic       com/google/firebase/heartbeatinfo/HeartBeatInfo$HeartBeat.c:Lcom/google/firebase/heartbeatinfo/HeartBeatInfo$HeartBeat;
        //   527: astore_2       
        //   528: aload           10
        //   530: monitorexit    
        //   531: aload_2        
        //   532: getstatic       com/google/firebase/heartbeatinfo/HeartBeatInfo$HeartBeat.c:Lcom/google/firebase/heartbeatinfo/HeartBeatInfo$HeartBeat;
        //   535: if_acmpeq       578
        //   538: aload_1        
        //   539: ldc_w           "Firebase-Client-Log-Type"
        //   542: aload_2        
        //   543: invokevirtual   com/google/firebase/heartbeatinfo/HeartBeatInfo$HeartBeat.a:()I
        //   546: invokestatic    java/lang/Integer.toString:(I)Ljava/lang/String;
        //   549: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   552: aload_1        
        //   553: ldc_w           "Firebase-Client"
        //   556: aload           8
        //   558: invokevirtual   iv0.a:()Ljava/lang/String;
        //   561: invokevirtual   android/os/BaseBundle.putString:(Ljava/lang/String;Ljava/lang/String;)V
        //   564: goto            578
        //   567: astore_1       
        //   568: aload           11
        //   570: monitorexit    
        //   571: aload_1        
        //   572: athrow         
        //   573: aload           10
        //   575: monitorexit    
        //   576: aload_1        
        //   577: athrow         
        //   578: return         
        //   579: aload           11
        //   581: monitorexit    
        //   582: aload_1        
        //   583: athrow         
        //   584: aload           10
        //   586: monitorexit    
        //   587: aload_1        
        //   588: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                                     
        //  -----  -----  -----  -----  ---------------------------------------------------------
        //  63     70     114    589    Any
        //  70     88     91     99     Landroid/content/pm/PackageManager$NameNotFoundException;
        //  70     88     114    589    Any
        //  92     97     114    589    Any
        //  103    111    114    589    Any
        //  118    124    114    589    Any
        //  182    196    199    584    Any
        //  203    211    199    584    Any
        //  239    258    261    266    Ljava/security/NoSuchAlgorithmException;
        //  274    312    319    320    Ljava/util/concurrent/ExecutionException;
        //  274    312    315    319    Ljava/lang/InterruptedException;
        //  419    440    514    578    Any
        //  440    448    567    573    Any
        //  448    451    514    578    Any
        //  456    461    514    578    Any
        //  461    501    518    524    Any
        //  501    508    514    578    Any
        //  519    522    518    524    Any
        //  522    524    514    578    Any
        //  524    528    514    578    Any
        //  568    571    567    573    Any
        //  571    573    514    578    Any
        //  573    576    514    578    Any
        //  579    582    199    584    Any
        //  584    587    114    589    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0524:
        //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
        //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public o76 o(Bundle ex, final String s, final String s2) {
        try {
            this.m((Bundle)ex, s, s2);
            final wg2 wg2 = (wg2)this.w;
            final p76 c = wg2.c;
            final int a = c.a();
            final zy0 w = zy0.w;
            if (a < 12000000) {
                if (c.b() != 0) {
                    ex = (ExecutionException)wg2.a((Bundle)ex).k((Executor)w, (pp0)new m36(5, (Object)wg2, (Object)ex));
                    return (o76)ex;
                }
                ex = (ExecutionException)az5.d((Exception)new IOException("MISSING_INSTANCEID_SERVICE"));
                return (o76)ex;
            }
            final a76 a2 = a76.a(wg2.b);
            synchronized (a2) {
                final int n = a2.a++;
                monitorexit(a2);
                ex = (ExecutionException)a2.b(new t46(n, 1, (Bundle)ex, 1)).d((Executor)w, (pp0)h26.x);
                return (o76)ex;
            }
        }
        catch (final ExecutionException ex) {}
        catch (final InterruptedException ex2) {}
        return az5.d((Exception)ex);
    }
    
    public Object p() {
        if (TextUtils.isEmpty((CharSequence)"Google")) {
            throw new IllegalArgumentException("Name is null or empty");
        }
        final String s = (String)this.n;
        if (!TextUtils.isEmpty((CharSequence)s)) {
            final pe2 pe2 = new pe2(4, "Google", s);
            final zzflo o = va2.o("javascript");
            final zzefp zzefp = (zzefp)this.v;
            final zzflk l = va2.l(zzefp.toString());
            final zzflo v = zzflo.v;
            Object o2 = null;
            if (o == v) {
                d94.zzj("Omid html session error; Unable to parse impression owner: javascript");
            }
            else if (l == null) {
                d94.zzj("Omid html session error; Unable to parse creative type: ".concat(String.valueOf((Object)zzefp)));
            }
            else {
                final String s2 = (String)this.w;
                final zzflo o3 = va2.o(s2);
                if (l == zzflk.w && o3 == v) {
                    d94.zzj("Omid html session error; Video events owner unknown for video creative: ".concat(String.valueOf((Object)s2)));
                }
                else {
                    final j13 j13 = new j13(pe2, (WebView)this.x, (String)this.y, zzfli.c);
                    final b23 d = b23.d(l, va2.n(((zzefq)this.z).toString()), o, o3);
                    if (!jr5.a.n) {
                        throw new IllegalStateException("Method called before OM SDK activation");
                    }
                    o2 = new f95(d, j13);
                }
            }
            return o2;
        }
        throw new IllegalArgumentException("Version is null or empty");
    }
    
    public u75 r() {
        final z75 z75 = (z75)this.z;
        final Object v = this.v;
        String a;
        if ((a = (String)this.n) == null) {
            z75.getClass();
            a = ((zzfio)v).a();
        }
        final u75 u75 = new u75(v, a, (yq1)this.y);
        ((xo1)z75.c).t0((gl4)new ur4((Object)u75, 8));
        final mz4 mz4 = new mz4(21, (Object)this, (Object)u75);
        final i94 f = k1.f;
        ((yq1)this.w).addListener((Runnable)mz4, (Executor)f);
        u75.addListener((Runnable)new jg5(0, (Object)u75, (Object)new mw4(11, (Object)this, false, (Object)u75)), (Executor)f);
        return u75;
    }
    
    public void t(final int n) {
        if (n != 16 && n != 24 && n != 32) {
            throw new InvalidAlgorithmParameterException(String.format("Invalid key size %d; only 16-byte, 24-byte and 32-byte AES keys are supported", new Object[] { n }));
        }
        this.z = n;
    }
    
    public boolean u(final zzl a, final String s, final nq3 nq3, final b15 b15) {
        zzt.zzp();
        final Context n = (Context)this.w;
        final boolean zzG = com.google.android.gms.ads.internal.util.zzt.zzG(n);
        final nd4 nd4 = (nd4)this.v;
        if (zzG && a.zzs == null) {
            d94.zzg("Failed to load the ad because app ID is missing.");
            nd4.a().execute((Runnable)new d15(this, 0));
            return false;
        }
        if (s == null) {
            d94.zzg("Ad unit ID should not be null for NativeAdLoader.");
            nd4.a().execute((Runnable)new d15(this, 1));
            return false;
        }
        yr3.b(n, a.zzf);
        if ((boolean)zzba.zzc().a(cs3.R7) && a.zzf) {
            ((qt4)nd4.x.zzb()).e(true);
        }
        final c15 c15 = (c15)nq3;
        final n65 n2 = (n65)this.n;
        n2.a = a;
        n2.m = c15.b;
        final o65 a2 = n2.a();
        final o85 c16 = ls3.c(n, it3.c(a2), 8, a);
        final m14 m14 = (m14)this.x;
        final s05 s2 = (s05)m14.v;
        final zzcb n3 = a2.n;
        if (n3 != null) {
            s2.h(n3);
        }
        final nd4 c17 = nd4.c;
        final gl5 gl5 = new gl5(9, false);
        gl5.n = n;
        gl5.v = a2;
        final pi4 pi4 = new pi4(gl5);
        final hl4 hl4 = new hl4();
        hl4.c((AppEventListener)s2, nd4.a());
        final gd4 gd4 = new gd4(c17, new eq5((Object)null, 26), new en4(0, (Object)m14.n, (Object)s2.g()), new il4(hl4), pi4, new ur4(4), (o55)null, (e55)null);
        v85 v86;
        if (ws3.c.k()) {
            final v85 v85 = (v85)gd4.e.zzb();
            v85.h(8);
            v85.b(a.zzp);
            v86 = v85;
        }
        else {
            v86 = null;
        }
        ((y65)nd4.F.zzb()).b(1);
        final i94 a3 = k1.a;
        ep5.c((Object)a3);
        final ScheduledExecutorService scheduledExecutorService = (ScheduledExecutorService)nd4.f.zzb();
        final rh4 rh4 = (rh4)gd4.n1.zzb();
        final u75 a4 = rh4.a((yq1)rh4.b());
        final mh4 z = new mh4((pg5)a3, scheduledExecutorService, a4);
        this.z = z;
        a4.addListener((Runnable)new jg5(0, (Object)a4, (Object)new lh4(z, new l44((Object)this, (Object)b15, (Object)v86, (Object)c16, (Object)gd4, 9, false), 0)), (Executor)a3);
        return true;
    }
    
    public void v(final int n) {
        if (n >= 16) {
            this.n = n;
            return;
        }
        throw new InvalidAlgorithmParameterException(String.format("Invalid key size in bytes %d; HMAC key must be at least 16 bytes", new Object[] { n }));
    }
    
    public void x(final int n) {
        if (n >= 12 && n <= 16) {
            this.v = n;
            return;
        }
        throw new GeneralSecurityException(String.format("Invalid IV size in bytes %d; IV size must be between 12 and 16 bytes", new Object[] { n }));
    }
    
    public gl5 y(final s75 s75) {
        return this.A((cg5)new dx3((Object)s75, 25));
    }
    
    public void z(final int n) {
        if (n >= 10) {
            this.w = n;
            return;
        }
        throw new GeneralSecurityException(String.format("Invalid tag size in bytes %d; must be at least 10 bytes", new Object[] { n }));
    }
    
    public yq1 zza() {
        zzt.zzz();
        final dc4 a = ac4.a((Context)this.v, new e11(0, 0, 0), "", false, false, (rm3)this.w, (qs3)null, (zzcbt)this.x, (am4)null, (zza)this.y, new mq3(), (l2)null, (e65)null, (e2)this.z);
        final eq3 eq3 = new eq3((Object)a);
        final fc4 c = a.c;
        c.U.z = (nc4)new uu5((Object)eq3, 23);
        c.loadUrl((String)this.n);
        return (yq1)eq3;
    }
    
    public void zza(final View view) {
        synchronized (this) {
            if (!((AtomicBoolean)this.z).compareAndSet(false, true)) {
                return;
            }
            ((qf4)this.y).zzq();
            ((bm4)this.x).u0(view);
        }
    }
    
    public void zzb() {
        if (((AtomicBoolean)this.z).get()) {
            ((wi4)this.n).onAdClicked();
        }
    }
    
    public void zzc() {
        if (((AtomicBoolean)this.z).get()) {
            ((fj4)this.v).zza();
            final gm4 gm4 = (gm4)this.w;
            synchronized (gm4) {
                gm4.t0((gl4)h26.T);
            }
        }
    }
    
    public Object zzd() {
        monitorenter(this);
        while (true) {
            try {
                final oi4 oi4 = (oi4)this.y;
                monitorexit(this);
                return oi4;
                monitorexit(this);
                throw;
            }
            finally {
                continue;
            }
            break;
        }
    }
}
