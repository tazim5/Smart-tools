import com.google.android.gms.common.internal.Preconditions;
import java.util.concurrent.Executor;

public final class gw2
{
    public final o76 a;
    
    public gw2() {
        this.a = new o76();
    }
    
    public gw2(final uu5 uu5) {
        this.a = new o76();
        final zn4 zn4 = new zn4((Object)this, 21);
        uu5.getClass();
        ((o76)uu5.n).c((Executor)iw2.a, (m42)new uu5((Object)zn4, 14));
    }
    
    public final void a(final Exception ex) {
        this.a.m(ex);
    }
    
    public final void b(final Object o) {
        this.a.n(o);
    }
    
    public final boolean c(final Exception f) {
        final o76 a = this.a;
        a.getClass();
        Preconditions.checkNotNull((Object)f, (Object)"Exception must not be null");
        final Object a2;
        monitorenter(a2 = a.a);
        Label_0050: {
            try {
                if (a.c) {
                    monitorexit(a2);
                    return false;
                }
                break Label_0050;
            }
            finally {
                monitorexit(a2);
                return;
                a.c = true;
                a.f = f;
                monitorexit(a2);
                a.b.n((fw2)a);
                b = true;
                return b;
            }
        }
    }
    
    public final void d(final Object o) {
        this.a.p(o);
    }
}
