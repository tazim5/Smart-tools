public final class rn4 implements ls5
{
    public final int a;
    public final ue4 b;
    
    public final Object zzb() {
        switch (this.a) {
            default: {
                return new tq4(this.b.a());
            }
            case 0: {
                return new qn4(this.b.a());
            }
        }
    }
}
