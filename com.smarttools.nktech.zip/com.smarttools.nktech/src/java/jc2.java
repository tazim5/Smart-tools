import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.material3.IconButtonColors;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.material3.TopAppBarScrollBehavior;
import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.Composer;

public final class jc2 implements nd1
{
    public final int c;
    public final ro2 n;
    
    public final Object invoke(final Object o, final Object o2) {
        switch (this.c) {
            default: {
                final Composer composer = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                }
                else {
                    AppBarKt.TopAppBar-GHTll3U((nd1)od0.a, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(-1350968874, true, (Object)new jc2(this.n, 0), composer, 54), (od1)null, 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer, 390, 186);
                }
                return t43.a;
            }
            case 0: {
                final Composer composer2 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer2.getSkipping()) {
                    composer2.skipToGroupEnd();
                }
                else {
                    IconButtonKt.IconButton((id1)this.n, (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)od0.b, composer2, 196608, 30);
                }
                return t43.a;
            }
        }
    }
}
