import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zze;
import android.os.Parcel;
import android.os.IBinder;

public final class f64 extends go3 implements h64
{
    public f64(final IBinder binder) {
        super(binder, "com.google.android.gms.ads.internal.rewarded.client.IRewardedAdLoadCallback");
    }
    
    public final void zze(final int n) {
        final Parcel zza = this.zza();
        zza.writeInt(n);
        this.zzbi(2, zza);
    }
    
    public final void zzf(final zze zze) {
        final Parcel zza = this.zza();
        io3.c(zza, (Parcelable)zze);
        this.zzbi(3, zza);
    }
    
    public final void zzg() {
        this.zzbi(1, this.zza());
    }
}
