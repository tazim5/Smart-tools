import com.google.android.gms.ads.internal.client.zze;
import android.os.IInterface;

public interface w14 extends IInterface
{
    void a(final String p0);
    
    void zzf(final zze p0);
    
    void zzg();
}
