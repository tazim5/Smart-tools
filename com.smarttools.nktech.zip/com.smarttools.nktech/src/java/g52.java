public final class g52 implements dc2
{
    public static final kk c;
    public static final ou d;
    public kk a;
    public volatile dc2 b;
    
    static {
        c = new kk(29);
        d = new ou(6);
    }
    
    public final Object get() {
        return this.b.get();
    }
}
