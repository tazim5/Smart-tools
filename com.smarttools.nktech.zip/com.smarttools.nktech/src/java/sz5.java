public abstract class sz5
{
    public static final double a(final long n) {
        return (n >>> 11) * (double)2048 + (n & 0x7FFL);
    }
}
