import java.util.Locale;

public abstract class vn5
{
    public static final byte[] a;
    public static final String[] b;
    
    static {
        a = new byte[] { 0, 0, 0, 1 };
        b = new String[] { "", "A", "B", "C" };
    }
    
    public static String a(final byte[] array) {
        final int length = array.length;
        final StringBuilder sb = new StringBuilder(length + length);
        for (final byte b : array) {
            sb.append("0123456789abcdef".charAt((b & 0xFF) >> 4));
            sb.append("0123456789abcdef".charAt(b & 0xF));
        }
        return sb.toString();
    }
    
    public static String b(int n, int i, int n2, int n3, final boolean b, final int[] array) {
        final String s = vn5.b[n];
        char c;
        if (!b) {
            c = 'L';
        }
        else {
            c = 'H';
        }
        final StringBuilder sb = new StringBuilder(String.format(Locale.US, "hvc1.%s%d.%X.%c%d", new Object[] { s, i, n2, c, n3 }));
        n = 6;
        while (true) {
            n2 = (i = 0);
            if (n <= 0) {
                break;
            }
            n3 = n - 1;
            i = n2;
            if (array[n3] != 0) {
                break;
            }
            n = n3;
        }
        while (i < n) {
            sb.append(String.format(".%02X", new Object[] { array[i] }));
            ++i;
        }
        return sb.toString();
    }
}
