public abstract class vo5
{
    public static final int a = 0;
}
