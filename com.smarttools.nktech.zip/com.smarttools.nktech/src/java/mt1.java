import java.util.Iterator;
import java.util.List;
import kotlin.sequences.a;
import kotlin.text.Regex;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.text.PlatformSpanStyle;
import androidx.compose.ui.graphics.Shadow;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.style.TextGeometricTransform;
import androidx.compose.ui.text.style.BaselineShift;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontSynthesis;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.SpanStyle;
import androidx.compose.ui.text.font.FontWeight;
import kotlin.text.c;
import androidx.compose.ui.text.AnnotatedString$Builder;
import androidx.compose.ui.text.AnnotatedString;

public abstract class mt1
{
    public static final AnnotatedString a(final String s) {
        final AnnotatedString$Builder annotatedString$Builder = new AnnotatedString$Builder(0, 1, (lu0)null);
        final List d = c.D((CharSequence)s, new String[] { "\n" }, 0, 6);
        final Iterator iterator = ((Iterable)d).iterator();
        int n = 0;
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            if (n < 0) {
                ur.k();
                throw null;
            }
            final String s2 = (String)next;
            final String string = c.L((CharSequence)s2).toString();
            Label_0523: {
                if (string.startsWith("###")) {
                    final int pushStyle = annotatedString$Builder.pushStyle(new SpanStyle(0L, 0L, FontWeight.Companion.getBold(), (FontStyle)null, (FontSynthesis)null, (FontFamily)null, (String)null, 0L, (BaselineShift)null, (TextGeometricTransform)null, (LocaleList)null, 0L, (TextDecoration)null, (Shadow)null, (PlatformSpanStyle)null, (DrawStyle)null, 65531, (lu0)null));
                    try {
                        annotatedString$Builder.append(c.L((CharSequence)c.x(string, "###")).toString());
                        break Label_0523;
                    }
                    finally {
                        annotatedString$Builder.pop(pushStyle);
                    }
                }
                if (string.startsWith("##")) {
                    final int pushStyle2 = annotatedString$Builder.pushStyle(new SpanStyle(0L, 0L, FontWeight.Companion.getBold(), (FontStyle)null, (FontSynthesis)null, (FontFamily)null, (String)null, 0L, (BaselineShift)null, (TextGeometricTransform)null, (LocaleList)null, 0L, (TextDecoration)null, (Shadow)null, (PlatformSpanStyle)null, (DrawStyle)null, 65531, (lu0)null));
                    try {
                        annotatedString$Builder.append(c.L((CharSequence)c.x(string, "##")).toString());
                        break Label_0523;
                    }
                    finally {
                        annotatedString$Builder.pop(pushStyle2);
                    }
                }
                if (string.startsWith("#")) {
                    final int pushStyle3 = annotatedString$Builder.pushStyle(new SpanStyle(0L, 0L, FontWeight.Companion.getBold(), (FontStyle)null, (FontSynthesis)null, (FontFamily)null, (String)null, 0L, (BaselineShift)null, (TextGeometricTransform)null, (LocaleList)null, 0L, (TextDecoration)null, (Shadow)null, (PlatformSpanStyle)null, (DrawStyle)null, 65531, (lu0)null));
                    try {
                        annotatedString$Builder.append(c.L((CharSequence)c.x(string, "#")).toString());
                        break Label_0523;
                    }
                    finally {
                        annotatedString$Builder.pop(pushStyle3);
                    }
                }
                final List h = a.h((pk2)Regex.b(new Regex("\\*\\*(.*?)\\*\\*"), s2));
                if (h.isEmpty()) {
                    annotatedString$Builder.append(s2);
                }
                else {
                    final Iterator iterator2 = h.iterator();
                    int pushStyle4 = 0;
                    while (iterator2.hasNext()) {
                        final qt1 qt1 = (qt1)iterator2.next();
                        if (((al1)qt1.b()).c > pushStyle4) {
                            annotatedString$Builder.append(s2.substring(pushStyle4, ((al1)qt1.b()).c));
                        }
                        pushStyle4 = annotatedString$Builder.pushStyle(new SpanStyle(0L, 0L, FontWeight.Companion.getBold(), (FontStyle)null, (FontSynthesis)null, (FontFamily)null, (String)null, 0L, (BaselineShift)null, (TextGeometricTransform)null, (LocaleList)null, 0L, (TextDecoration)null, (Shadow)null, (PlatformSpanStyle)null, (DrawStyle)null, 65531, (lu0)null));
                        try {
                            annotatedString$Builder.append((String)((pt1)qt1.a()).get(1));
                            annotatedString$Builder.pop(pushStyle4);
                            pushStyle4 = ((al1)qt1.b()).n + 1;
                            continue;
                        }
                        finally {
                            annotatedString$Builder.pop(pushStyle4);
                        }
                        break;
                    }
                    if (pushStyle4 < s2.length()) {
                        annotatedString$Builder.append(s2.substring(pushStyle4));
                    }
                }
            }
            if (n < d.size() - 1) {
                annotatedString$Builder.append("\n");
            }
            ++n;
        }
        return annotatedString$Builder.toAnnotatedString();
    }
}
