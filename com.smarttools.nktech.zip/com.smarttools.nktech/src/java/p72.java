public final class p72 implements lp2
{
    public final zh c;
    public final uh n;
    public zj2 v;
    public int w;
    public boolean x;
    public long y;
    
    public p72(final zh c) {
        this.c = c;
        final uh b = c.b();
        this.n = b;
        final zj2 c2 = b.c;
        this.v = c2;
        int b2;
        if (c2 != null) {
            b2 = c2.b;
        }
        else {
            b2 = -1;
        }
        this.w = b2;
    }
    
    public final void close() {
        this.x = true;
    }
    
    @Override
    public final long read(final uh uh, long min) {
        final long n = lcmp(min, 0L);
        if (n < 0) {
            throw new IllegalArgumentException(gs1.i("byteCount < 0: ", min).toString());
        }
        if (this.x) {
            throw new IllegalStateException("closed");
        }
        final zj2 v = this.v;
        final uh n2 = this.n;
        if (v != null) {
            final zj2 c = n2.c;
            if (v != c || this.w != c.b) {
                throw new IllegalStateException("Peek source is invalid because upstream source was used");
            }
        }
        if (n == 0) {
            return 0L;
        }
        if (!this.c.E(this.y + 1L)) {
            return -1L;
        }
        if (this.v == null) {
            final zj2 c2 = n2.c;
            if (c2 != null) {
                this.v = c2;
                this.w = c2.b;
            }
        }
        min = Math.min(min, n2.n - this.y);
        this.n.p(this.y, uh, min);
        this.y += min;
        return min;
    }
    
    @Override
    public final qz2 timeout() {
        return this.c.timeout();
    }
}
