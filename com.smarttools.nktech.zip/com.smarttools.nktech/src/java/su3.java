public abstract class su3 extends ho3 implements tu3
{
    public static final int c = 0;
}
