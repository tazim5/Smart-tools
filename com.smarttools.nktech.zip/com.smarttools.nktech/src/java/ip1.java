import androidx.lifecycle.Lifecycle$Event;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import androidx.lifecycle.Lifecycle$State;

public final class ip1 implements np1, fl
{
    public final Object c;
    public final op1 n;
    public final xm v;
    public boolean w;
    
    public ip1(final op1 n, final xm v) {
        this.c = new Object();
        this.w = false;
        this.n = n;
        this.v = v;
        if (n.getLifecycle().getCurrentState().a(Lifecycle$State.w)) {
            v.n();
        }
        else {
            v.r();
        }
        n.getLifecycle().addObserver((np1)this);
    }
    
    public final im a() {
        return (im)this.v.X;
    }
    
    public final void b(final ul ul) {
        final xm v = this.v;
        final Object r;
        monitorenter(r = v.R);
        Label_0074: {
            try {
                final tm3 a = vl.a;
                if (!v.x.isEmpty() && !((pd)((tm3)v.Q).n).equals(a.n)) {
                    throw new IllegalStateException("Need to unbind all use cases before binding with extension enabled");
                }
                break Label_0074;
            }
            finally {
                monitorexit(r);
                while (true) {
                    v.W.getClass();
                    v.c.b(v.Q);
                    monitorexit(r);
                    return;
                    final tm3 a;
                    v.Q = (ul)a;
                    iftrue(Label_0117:)(((yd2)a).a(ul.d, null) != null);
                    continue;
                }
                Label_0117: {
                    throw new ClassCastException();
                }
            }
        }
    }
    
    public final void n(final List p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        ip1.c:Ljava/lang/Object;
        //     4: astore_2       
        //     5: aload_2        
        //     6: dup            
        //     7: astore          6
        //     9: monitorenter   
        //    10: aload_0        
        //    11: getfield        ip1.v:Lxm;
        //    14: astore          4
        //    16: aload           4
        //    18: getfield        xm.R:Ljava/lang/Object;
        //    21: astore_3       
        //    22: aload_3        
        //    23: dup            
        //    24: astore          7
        //    26: monitorenter   
        //    27: new             Ljava/util/LinkedHashSet;
        //    30: astore          5
        //    32: aload           5
        //    34: aload           4
        //    36: getfield        xm.x:Ljava/util/ArrayList;
        //    39: invokespecial   java/util/LinkedHashSet.<init>:(Ljava/util/Collection;)V
        //    42: aload           5
        //    44: aload_1        
        //    45: invokeinterface java/util/Set.addAll:(Ljava/util/Collection;)Z
        //    50: pop            
        //    51: aload           4
        //    53: aload           5
        //    55: iconst_0       
        //    56: invokevirtual   xm.y:(Ljava/util/LinkedHashSet;Z)V
        //    59: aload           7
        //    61: monitorexit    
        //    62: aload           6
        //    64: monitorexit    
        //    65: return         
        //    66: astore_1       
        //    67: goto            97
        //    70: astore_1       
        //    71: goto            92
        //    74: astore_1       
        //    75: new             Landroidx/camera/core/internal/CameraUseCaseAdapter$CameraException;
        //    78: astore          4
        //    80: aload           4
        //    82: aload_1        
        //    83: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //    86: invokespecial   java/lang/Exception.<init>:(Ljava/lang/String;)V
        //    89: aload           4
        //    91: athrow         
        //    92: aload           7
        //    94: monitorexit    
        //    95: aload_1        
        //    96: athrow         
        //    97: aload           6
        //    99: monitorexit    
        //   100: aload_1        
        //   101: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  10     27     66     102    Any
        //  27     51     70     97     Any
        //  51     59     74     92     Ljava/lang/IllegalArgumentException;
        //  51     59     70     97     Any
        //  59     62     70     97     Any
        //  62     65     66     102    Any
        //  75     92     70     97     Any
        //  92     95     70     97     Any
        //  95     97     66     102    Any
        //  97     100    66     102    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 57, Size: 57
        //     at java.util.ArrayList.get(ArrayList.java:437)
        //     at q5.g.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at q5.g.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2125)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:21)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final List o() {
        final Object c = this.c;
        synchronized (c) {
            return Collections.unmodifiableList(this.v.u());
        }
    }
    
    @l42(Lifecycle$Event.ON_DESTROY)
    public void onDestroy(final op1 op1) {
        final Object c = this.c;
        synchronized (c) {
            final xm v = this.v;
            v.w((ArrayList)v.u());
        }
    }
    
    @l42(Lifecycle$Event.ON_PAUSE)
    public void onPause(final op1 op1) {
        this.v.c.h(false);
    }
    
    @l42(Lifecycle$Event.ON_RESUME)
    public void onResume(final op1 op1) {
        this.v.c.h(true);
    }
    
    @l42(Lifecycle$Event.ON_START)
    public void onStart(final op1 op1) {
        final Object c;
        monitorenter(c = this.c);
        Label_0030: {
            try {
                if (!this.w) {
                    this.v.n();
                }
                break Label_0030;
            }
            finally {
                monitorexit(c);
                monitorexit(c);
            }
        }
    }
    
    @l42(Lifecycle$Event.ON_STOP)
    public void onStop(final op1 op1) {
        final Object c;
        monitorenter(c = this.c);
        Label_0030: {
            try {
                if (!this.w) {
                    this.v.r();
                }
                break Label_0030;
            }
            finally {
                monitorexit(c);
                monitorexit(c);
            }
        }
    }
    
    public final void p() {
        final Object c;
        monitorenter(c = this.c);
        Label_0023: {
            try {
                if (this.w) {
                    monitorexit(c);
                    return;
                }
                break Label_0023;
            }
            finally {
                monitorexit(c);
                this.onStop(this.n);
                this.w = true;
                monitorexit(c);
            }
        }
    }
    
    public final void q() {
        final Object c;
        monitorenter(c = this.c);
        Label_0023: {
            try {
                if (!this.w) {
                    monitorexit(c);
                    return;
                }
                break Label_0023;
            }
            finally {
                monitorexit(c);
                while (true) {
                    while (true) {
                        monitorexit(c);
                        return;
                        this.onStart(this.n);
                        continue;
                    }
                    this.w = false;
                    iftrue(Label_0057:)(!this.n.getLifecycle().getCurrentState().a(Lifecycle$State.w));
                    continue;
                }
            }
        }
    }
}
