import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material.icons.automirrored.filled.ArrowBackKt;
import androidx.compose.material.icons.Icons$AutoMirrored$Filled;
import androidx.compose.runtime.Composer;

public final class nw implements nd1
{
    public static final nw c;
    
    static {
        c = (nw)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(ArrowBackKt.getArrowBack(Icons$AutoMirrored$Filled.INSTANCE), "Back", (Modifier)null, 0L, composer, 48, 12);
        }
        return t43.a;
    }
}
