import com.google.android.gms.ads.internal.overlay.zzo;

public final class xb4 implements zzo
{
    public final rb4 c;
    public final zzo n;
    
    public xb4(final rb4 c, final zzo n) {
        this.c = c;
        this.n = n;
    }
    
    public final void zzbM() {
    }
    
    public final void zzbp() {
    }
    
    public final void zzbv() {
        final zzo n = this.n;
        if (n != null) {
            n.zzbv();
        }
    }
    
    public final void zzbw() {
        final zzo n = this.n;
        if (n != null) {
            n.zzbw();
        }
        this.c.zzX();
    }
    
    public final void zzby() {
        final zzo n = this.n;
        if (n != null) {
            n.zzby();
        }
    }
    
    public final void zzbz(final int n) {
        final zzo n2 = this.n;
        if (n2 != null) {
            n2.zzbz(n);
        }
        this.c.K();
    }
}
