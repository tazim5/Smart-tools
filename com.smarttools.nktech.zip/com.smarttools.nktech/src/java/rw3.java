import android.os.Handler;
import com.google.android.gms.ads.BaseAdView;
import com.google.android.gms.ads.internal.client.zzbt;
import android.os.Parcel;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.admanager.AppEventListener;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzg;
import com.google.android.gms.ads.admanager.AdManagerAdView;
import android.content.Context;
import com.google.android.gms.ads.internal.client.zzbu;
import com.google.android.gms.ads.formats.OnAdManagerAdViewLoadedListener;

public final class rw3 extends ho3 implements uv3
{
    public final OnAdManagerAdViewLoadedListener c;
    
    public rw3(final OnAdManagerAdViewLoadedListener c) {
        super("com.google.android.gms.ads.internal.formats.client.IOnPublisherAdViewLoadedListener");
        this.c = c;
    }
    
    public final void l0(final zzbu zzbu, final th1 th1) {
        if (zzbu != null) {
            if (th1 != null) {
                final AdManagerAdView adManagerAdView = new AdManagerAdView((Context)n32.F(th1));
                final AppEventListener appEventListener = null;
                Label_0084: {
                    Label_0078: {
                        AdListener zzb = null;
                        Label_0069: {
                            try {
                                if (!(zzbu.zzi() instanceof zzg)) {
                                    break Label_0084;
                                }
                                final zzg zzg = (zzg)zzbu.zzi();
                                if (zzg != null) {
                                    zzb = zzg.zzb();
                                    break Label_0069;
                                }
                            }
                            catch (final RemoteException ex) {
                                break Label_0078;
                            }
                            zzb = null;
                        }
                        ((BaseAdView)adManagerAdView).setAdListener(zzb);
                        break Label_0084;
                    }
                    final RemoteException ex;
                    d94.zzh("", (Throwable)ex);
                    try {
                        if (zzbu.zzj() instanceof vo3) {
                            final vo3 vo3 = (vo3)zzbu.zzj();
                            AppEventListener c = appEventListener;
                            if (vo3 != null) {
                                c = vo3.c;
                            }
                            adManagerAdView.setAppEventListener(c);
                        }
                    }
                    catch (final RemoteException ex2) {
                        d94.zzh("", (Throwable)ex2);
                    }
                }
                ((Handler)z84.b).post((Runnable)new xo0((Object)this, (Object)adManagerAdView, (Object)zzbu, 10, false));
            }
        }
    }
    
    public final boolean zzbK(final int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        if (n == 1) {
            final zzbu zzac = zzbt.zzac(parcel.readStrongBinder());
            final th1 d = n32.D(parcel.readStrongBinder());
            io3.b(parcel);
            this.l0(zzac, d);
            parcel2.writeNoException();
            return true;
        }
        return false;
    }
}
