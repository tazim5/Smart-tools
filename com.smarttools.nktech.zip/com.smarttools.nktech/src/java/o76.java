import com.google.android.gms.tasks.DuplicateTaskCompletionException;
import java.util.concurrent.CancellationException;
import com.google.android.gms.common.internal.Preconditions;
import java.util.concurrent.Executor;

public final class o76 extends fw2
{
    public final Object a;
    public final y7 b;
    public boolean c;
    public volatile boolean d;
    public Object e;
    public Exception f;
    
    public o76() {
        this.a = new Object();
        this.b = new y7(7);
    }
    
    public final o76 a(final Executor executor, final i42 i42) {
        this.b.m((f46)new gr5(executor, i42));
        this.r();
        return this;
    }
    
    public final o76 b(final Executor executor, final k42 k42) {
        this.b.m((f46)new gr5(executor, k42));
        this.r();
        return this;
    }
    
    public final o76 c(final Executor executor, final m42 m42) {
        this.b.m((f46)new gr5(executor, m42));
        this.r();
        return this;
    }
    
    public final o76 d(final Executor executor, final pp0 pp0) {
        final o76 o76 = new o76();
        this.b.m((f46)new vj4(executor, pp0, o76, 0));
        this.r();
        return o76;
    }
    
    public final Exception e() {
        final Object a = this.a;
        synchronized (a) {
            return this.f;
        }
    }
    
    public final Object f() {
        final Object a;
        monitorenter(a = this.a);
        try {
            Preconditions.checkState(this.c, (Object)"Task is not yet complete");
            if (this.d) {
                throw new CancellationException("Task is already canceled.");
            }
            final Exception f = this.f;
            if (f == null) {
                final Object e = this.e;
                monitorexit(a);
                return e;
            }
            throw new RuntimeException((Throwable)f);
        }
        finally {
            monitorexit(a);
            final Exception f;
            throw new RuntimeException((Throwable)f);
        }
    }
    
    public final boolean g() {
        final Object a = this.a;
        synchronized (a) {
            return this.c;
        }
    }
    
    public final boolean h() {
        final Object a;
        monitorenter(a = this.a);
        Label_0053: {
            try {
                final boolean c = this.c;
                boolean b2;
                final boolean b = b2 = false;
                if (!c) {
                    break Label_0053;
                }
                b2 = b;
                if (this.d) {
                    break Label_0053;
                }
                b2 = b;
                if (this.f == null) {
                    b2 = true;
                }
                break Label_0053;
            }
            finally {
                monitorexit(a);
                monitorexit(a);
                return;
            }
        }
    }
    
    public final o76 i(final et2 et2) {
        final lh1 a = iw2.a;
        final o76 o76 = new o76();
        this.b.m((f46)new gr5((Executor)a, et2, o76));
        this.r();
        return o76;
    }
    
    public final o76 j(final i42 i42) {
        this.b.m((f46)new gr5((Executor)iw2.a, i42));
        this.r();
        return this;
    }
    
    public final o76 k(final Executor executor, final pp0 pp0) {
        final o76 o76 = new o76();
        this.b.m((f46)new vj4(executor, pp0, o76, 1));
        this.r();
        return o76;
    }
    
    public final o76 l(final Executor executor, final et2 et2) {
        final o76 o76 = new o76();
        this.b.m((f46)new gr5(executor, et2, o76));
        this.r();
        return o76;
    }
    
    public final void m(final Exception f) {
        Preconditions.checkNotNull((Object)f, (Object)"Exception must not be null");
        final Object a = this.a;
        synchronized (a) {
            this.q();
            this.c = true;
            this.f = f;
            monitorexit(a);
            this.b.n((fw2)this);
        }
    }
    
    public final void n(final Object e) {
        final Object a = this.a;
        synchronized (a) {
            this.q();
            this.c = true;
            this.e = e;
            monitorexit(a);
            this.b.n((fw2)this);
        }
    }
    
    public final void o() {
        final Object a;
        monitorenter(a = this.a);
        Label_0023: {
            try {
                if (this.c) {
                    monitorexit(a);
                    return;
                }
                break Label_0023;
            }
            finally {
                monitorexit(a);
                this.c = true;
                this.d = true;
                monitorexit(a);
                this.b.n((fw2)this);
            }
        }
    }
    
    public final boolean p(final Object e) {
        final Object a;
        monitorenter(a = this.a);
        Label_0024: {
            try {
                if (this.c) {
                    monitorexit(a);
                    return false;
                }
                break Label_0024;
            }
            finally {
                monitorexit(a);
                this.c = true;
                this.e = e;
                monitorexit(a);
                this.b.n((fw2)this);
                return true;
            }
        }
    }
    
    public final void q() {
        if (this.c) {
            final int c = DuplicateTaskCompletionException.c;
            IllegalStateException ex;
            if (this.g()) {
                final Exception e = this.e();
                String concat;
                if (e == null) {
                    if (!this.h()) {
                        if (this.d) {
                            concat = "cancellation";
                        }
                        else {
                            concat = "unknown issue";
                        }
                    }
                    else {
                        concat = "result ".concat(String.valueOf(this.f()));
                    }
                }
                else {
                    concat = "failure";
                }
                ex = new IllegalStateException("Complete with: ".concat(concat), (Throwable)e);
            }
            else {
                ex = new IllegalStateException("DuplicateTaskCompletionException can only be created from completed Task.");
            }
            throw ex;
        }
    }
    
    public final void r() {
        final Object a;
        monitorenter(a = this.a);
        Label_0023: {
            try {
                if (!this.c) {
                    monitorexit(a);
                    return;
                }
                break Label_0023;
            }
            finally {
                monitorexit(a);
                monitorexit(a);
                this.b.n((fw2)this);
            }
        }
    }
}
