public final class t25 implements h32
{
    public static final t25 a;
    
    static {
        a = (t25)new Object();
        f83.q(f83.h((Class)kj3.class, new kg3(1)));
    }
}
