import androidx.concurrent.futures.b;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Delayed;
import android.os.Handler;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.RunnableScheduledFuture;

public final class ng1 implements RunnableScheduledFuture
{
    public final AtomicReference c;
    public final long n;
    public final Callable v;
    public final jj w;
    
    public ng1(final Handler handler, final long n, final Callable v) {
        this.c = new AtomicReference((Object)null);
        this.n = n;
        this.v = v;
        this.w = ft5.a((hj)new w65((Object)this, (Object)handler, (Object)v, 10, false));
    }
    
    public final boolean cancel(final boolean b) {
        return this.w.cancel(b);
    }
    
    public final int compareTo(final Object o) {
        final Delayed delayed = (Delayed)o;
        final TimeUnit milliseconds = TimeUnit.MILLISECONDS;
        return Long.compare(this.getDelay(milliseconds), delayed.getDelay(milliseconds));
    }
    
    public final Object get() {
        return ((a1)this.w.n).get();
    }
    
    public final Object get(final long n, final TimeUnit timeUnit) {
        return ((a1)this.w.n).get(n, timeUnit);
    }
    
    public final long getDelay(final TimeUnit timeUnit) {
        return timeUnit.convert(this.n - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
    }
    
    public final boolean isCancelled() {
        return this.w.isCancelled();
    }
    
    public final boolean isDone() {
        return ((a1)this.w.n).isDone();
    }
    
    public final boolean isPeriodic() {
        return false;
    }
    
    public final void run() {
        final b b = (b)this.c.getAndSet((Object)null);
        if (b != null) {
            try {
                b.a(this.v.call());
            }
            catch (final Exception ex) {
                b.b((Throwable)ex);
            }
        }
    }
}
