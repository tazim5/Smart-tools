import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material.icons.filled.RefreshKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;

public final class ra0 implements nd1
{
    public static final ra0 c;
    
    static {
        c = (ra0)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(RefreshKt.getRefresh(Icons.INSTANCE.getDefault()), "Refresh", (Modifier)null, 0L, composer, 48, 12);
        }
        return t43.a;
    }
}
