import java.util.concurrent.Executor;
import com.google.android.gms.ads.internal.util.zzg;
import com.google.android.gms.common.util.Clock;
import com.google.android.gms.ads.internal.client.zzff;
import com.google.android.gms.ads.internal.util.zzau;
import com.google.android.gms.internal.ads.zzdwm;
import com.google.android.gms.ads.internal.client.zzda;
import android.text.TextUtils;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.ads.internal.client.zzba;
import java.io.IOException;
import android.os.RemoteException;
import java.util.List;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.internal.ads.g2;
import com.google.android.gms.internal.ads.zzcbt;
import android.content.Context;
import com.google.android.gms.internal.ads.n2;
import com.google.android.gms.ads.internal.client.zzcn;

public final class je4 extends zzcn
{
    public final pr4 P;
    public final qt4 Q;
    public final q95 R;
    public final n2 S;
    public final w65 T;
    public final ds3 U;
    public boolean V;
    public final Context c;
    public final zzcbt n;
    public final nr4 v;
    public final sx4 w;
    public final g2 x;
    public final ft4 y;
    public final f74 z;
    
    public je4(final Context c, final zzcbt n, final nr4 v, final sx4 w, final g2 x, final ft4 y, final f74 z, final pr4 p13, final qt4 q, final q95 r, final n2 s, final w65 t, final ds3 u) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p13;
        this.Q = q;
        this.R = r;
        this.S = s;
        this.T = t;
        this.U = u;
        this.V = false;
    }
    
    public final float zze() {
        synchronized (this) {
            return zzt.zzr().zza();
        }
    }
    
    public final String zzf() {
        return this.n.c;
    }
    
    public final List zzg() {
        return (List)this.y.a();
    }
    
    public final void zzh(final String s) {
        this.x.b(s);
    }
    
    public final void zzi() {
        this.y.q = false;
    }
    
    public final void zzj(final boolean b) {
        try {
            final qb5 f = qb5.f(this.c);
            ((mb5)f).f.r((Object)b, "paidv2_publisher_option");
            if (!b) {
                f.g();
            }
        }
        catch (final IOException ex) {
            throw new RemoteException(((Throwable)ex).getMessage());
        }
    }
    
    public final void zzk() {
        monitorenter(this);
        Label_0025: {
            try {
                if (this.V) {
                    d94.zzj("Mobile ads is initialized already.");
                    monitorexit(this);
                    return;
                }
                break Label_0025;
            }
            finally {
                monitorexit(this);
                cs3.a(this.c);
                final ds3 u = this.U;
                final ds3 ds3;
                monitorenter(ds3 = u);
                Label_0082: {
                    try {
                        if (et3.a.k()) {
                            if (!u.a) {
                                u.a = true;
                            }
                        }
                        monitorexit(ds3);
                        break Label_0082;
                    }
                    finally {
                        monitorexit(ds3);
                        pr4 p;
                        g2 x;
                        Block_13_Outer:Block_10_Outer:
                        while (true) {
                            iftrue(Label_0337:)(!(boolean)zzba.zzc().a(cs3.n9));
                            Block_11: {
                                while (true) {
                                    while (true) {
                                        Block_12: {
                                            break Block_12;
                                            Label_0380: {
                                                monitorexit(this);
                                            }
                                            return;
                                            k1.a.execute((Runnable)new ie4(this, 1));
                                            monitorexit(this);
                                            return;
                                            while (true) {
                                                this.Q.c();
                                                iftrue(Label_0298:)(!(boolean)zzba.zzc().a(cs3.g8));
                                                break Block_11;
                                                p = this.P;
                                                p.getClass();
                                                ((zzg)zzt.zzo().c()).zzq((Runnable)new or4(p, 0));
                                                ((Executor)p.c).execute((Runnable)new or4(p, 1));
                                                continue Block_10_Outer;
                                            }
                                        }
                                        k1.a.execute((Runnable)new ie4(this, 2));
                                        Label_0337: {
                                            iftrue(Label_0380:)(!(boolean)zzba.zzc().a(cs3.q2));
                                        }
                                        continue Block_10_Outer;
                                    }
                                    zzt.zzo().e(this.c, this.n);
                                    zzt.zzc().c(this.c);
                                    this.V = true;
                                    this.y.b();
                                    x = this.x;
                                    x.getClass();
                                    ((zzg)zzt.zzo().c()).zzq((Runnable)new i05(x, 1));
                                    ((Executor)x.f).execute((Runnable)new i05(x, 0));
                                    iftrue(Label_0252:)(!(boolean)zzba.zzc().a(cs3.v3));
                                    continue;
                                }
                            }
                            k1.a.execute((Runnable)new ie4(this, 0));
                            continue Block_13_Outer;
                        }
                    }
                }
            }
        }
    }
    
    public final void zzl(String s, final th1 th1) {
        final Context c = this.c;
        cs3.a(c);
        Object zzp = null;
        Label_0065: {
            if (zzba.zzc().a(cs3.z3)) {
                try {
                    zzt.zzp();
                    zzp = com.google.android.gms.ads.internal.util.zzt.zzp(c);
                    break Label_0065;
                }
                catch (final RemoteException ex) {
                    zzt.zzo().g("NonagonMobileAdsSettingManager_AppId", (Throwable)ex);
                }
            }
            zzp = "";
        }
        final boolean empty = TextUtils.isEmpty((CharSequence)zzp);
        int n = 1;
        if (!empty) {
            s = (String)zzp;
        }
        if (!TextUtils.isEmpty((CharSequence)s)) {
            final boolean booleanValue = (boolean)zzba.zzc().a(cs3.u3);
            final ur3 f0 = cs3.F0;
            final boolean booleanValue2 = (boolean)zzba.zzc().a(f0);
            Object o;
            if (zzba.zzc().a(f0)) {
                o = new ae1(14, (Object)this, (Object)n32.F(th1));
            }
            else {
                o = null;
                n = ((booleanValue | booleanValue2) ? 1 : 0);
            }
            if (n != 0) {
                zzt.zza().zza(this.c, this.n, s, (Runnable)o, this.S);
            }
        }
    }
    
    public final void zzm(final zzda zzda) {
        this.Q.d(zzda, zzdwm.n);
    }
    
    public final void zzn(final th1 th1, final String s) {
        if (th1 == null) {
            d94.zzg("Wrapped context is null. Failed to open debug menu.");
            return;
        }
        final Context context = (Context)n32.F(th1);
        if (context == null) {
            d94.zzg("Context is null. Failed to open debug menu.");
            return;
        }
        final zzau zzau = new zzau(context);
        zzau.zzn(s);
        zzau.zzo(this.n.c);
        zzau.zzr();
    }
    
    public final void zzo(final t04 t04) {
        this.T.P(t04);
    }
    
    public final void zzp(final boolean b) {
        synchronized (this) {
            zzt.zzr().zzc(b);
        }
    }
    
    public final void zzq(final float n) {
        synchronized (this) {
            zzt.zzr().zzd(n);
        }
    }
    
    public final void zzr(final String s) {
        monitorenter(this);
        Label_0075: {
            try {
                cs3.a(this.c);
                if (!TextUtils.isEmpty((CharSequence)s) && (boolean)zzba.zzc().a(cs3.u3)) {
                    zzt.zza().zza(this.c, this.n, s, (Runnable)null, this.S);
                    monitorexit(this);
                    return;
                }
                break Label_0075;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzs(final sy3 sy3) {
        final ft4 y = this.y;
        y.getClass();
        y.e.addListener((Runnable)new mz4(16, (Object)y, (Object)sy3), y.j);
    }
    
    public final void zzt(final String g) {
        if (zzba.zzc().a(cs3.r8)) {
            zzt.zzo().g = g;
        }
    }
    
    public final void zzu(final zzff zzff) {
        final f74 z = this.z;
        final Context c = this.c;
        z.getClass();
        final il3 a = y64.d(c).a();
        ((w64)a.v).a(-1, ((Clock)a.n).currentTimeMillis());
        if ((boolean)zzba.zzc().a(cs3.g0) && z.j(c)) {
            if (f74.k(c)) {
                final Object l = z.l;
                synchronized (l) {
                    monitorexit(l);
                }
            }
        }
    }
    
    public final boolean zzv() {
        synchronized (this) {
            return zzt.zzr().zze();
        }
    }
}
