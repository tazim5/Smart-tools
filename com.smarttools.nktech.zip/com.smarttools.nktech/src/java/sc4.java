public abstract class sc4 extends ho3 implements tc4
{
    public static final int c = 0;
}
