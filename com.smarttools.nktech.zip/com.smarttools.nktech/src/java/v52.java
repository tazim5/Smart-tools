public final class v52
{
    public String a;
    public boolean b;
}
