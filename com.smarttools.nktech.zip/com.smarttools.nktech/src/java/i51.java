import androidx.datastore.core.DataStore;
import android.content.Context;
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler;
import androidx.datastore.preferences.PreferenceDataStoreDelegateKt;
import kotlin.jvm.internal.PropertyReference1Impl;

public abstract class i51
{
    public static final ao1[] a;
    public static final xd2 b;
    
    static {
        final PropertyReference1Impl propertyReference1Impl = new PropertyReference1Impl((Class)i51.class, "expenseDataStore", "getExpenseDataStore(Landroid/content/Context;)Landroidx/datastore/core/DataStore;");
        le2.a.getClass();
        a = new ao1[] { (ao1)propertyReference1Impl };
        b = PreferenceDataStoreDelegateKt.preferencesDataStore$default("expense_tracker", (ReplaceFileCorruptionHandler)null, (jd1)null, (dq0)null, 14, (Object)null);
    }
    
    public static final DataStore a(final Context context) {
        return (DataStore)i51.b.getValue((Object)context, i51.a[0]);
    }
}
