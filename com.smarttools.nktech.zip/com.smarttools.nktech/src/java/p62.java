import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.material3.IconButtonColors;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;

public final class p62 implements od1
{
    public final ai2 c;
    public final jd1 n;
    public final boolean v;
    public final jd1 w;
    public final jd1 x;
    
    public p62(final ai2 c, final jd1 n, final boolean v, final jd1 w, final jd1 x) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
    }
    
    public final Object invoke(Object rememberedValue, Object o, final Object o2) {
        final ColumnScope columnScope = (ColumnScope)rememberedValue;
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)16));
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$Vertical top = instance.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.getSpaceBetween(), companion2.getCenterVertically(), composer, 54);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance3 = RowScopeInstance.INSTANCE;
            final ai2 c = this.c;
            TextKt.Text--4IGK_g(c.b, (Modifier)null, 0L, TextUnitKt.getSp(16), (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 199680, 0, 131030);
            composer.startReplaceGroup(-1543493379);
            final jd1 n = this.n;
            final boolean changed = composer.changed((Object)n);
            final boolean changed2 = composer.changed((Object)c);
            o = composer.rememberedValue();
            if ((changed | changed2) || (rememberedValue = o) == Composer.Companion.getEmpty()) {
                rememberedValue = new n62(n, c, 0);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id1 = (id1)rememberedValue;
            composer.endReplaceGroup();
            IconButtonKt.IconButton(id1, (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)fb0.u, composer, 196608, 30);
            composer.endNode();
            composer.startReplaceGroup(732458662);
            final String c2 = c.c;
            if (c2.length() > 0) {
                final String concat = "User: ".concat(c2);
                final MaterialTheme instance4 = MaterialTheme.INSTANCE;
                final int $stable = MaterialTheme.$stable;
                TextKt.Text--4IGK_g(concat, (Modifier)null, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 0, 0, 65530);
            }
            composer.endReplaceGroup();
            SpacerKt.Spacer(SizeKt.height-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)8)), composer, 6);
            final MeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy(instance.getStart(), companion2.getCenterVertically(), composer, 48);
            final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
            final id1 constructor3 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor3);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl3 = Updater.constructor-impl(composer);
            final nd1 b3 = ap.b(companion3, constructor-impl3, rowMeasurePolicy2, constructor-impl3, currentCompositionLocalMap3);
            if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                l3.i(currentCompositeKeyHash3, constructor-impl3, currentCompositeKeyHash3, b3);
            }
            Updater.set-impl(constructor-impl3, (Object)materializeModifier3, companion3.getSetModifier());
            final boolean v = this.v;
            String d;
            if (v) {
                d = c.d;
            }
            else {
                d = "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
            }
            TextKt.Text--4IGK_g(d, RowScope.weight$default((RowScope)instance3, (Modifier)companion, 1.0f, false, 2, (Object)null), 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, TextUnitKt.getSp(1), (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 12582912, 0, 130940);
            composer.startReplaceGroup(-1543464986);
            final jd1 w = this.w;
            final boolean changed3 = composer.changed((Object)w);
            final boolean changed4 = composer.changed((Object)c);
            rememberedValue = composer.rememberedValue();
            if ((changed3 | changed4) || rememberedValue == Composer.Companion.getEmpty()) {
                rememberedValue = new n62(w, c, 1);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id2 = (id1)rememberedValue;
            composer.endReplaceGroup();
            IconButtonKt.IconButton(id2, (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)ComposableLambdaKt.rememberComposableLambda(-1921724616, true, (Object)new o62(v), composer, 54), composer, 196608, 30);
            composer.startReplaceGroup(-1543457436);
            final jd1 x = this.x;
            final boolean changed5 = composer.changed((Object)x);
            final boolean changed6 = composer.changed((Object)c);
            o = composer.rememberedValue();
            if ((changed5 | changed6) || (rememberedValue = o) == Composer.Companion.getEmpty()) {
                rememberedValue = new n62(x, c, 2);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id3 = (id1)rememberedValue;
            composer.endReplaceGroup();
            IconButtonKt.IconButton(id3, (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)fb0.v, composer, 196608, 30);
            composer.endNode();
            composer.startReplaceGroup(732493691);
            final String e = c.e;
            if (e.length() > 0) {
                ap.l((float)4, companion, composer, 6);
                final String concat2 = "Notes: ".concat(e);
                final MaterialTheme instance5 = MaterialTheme.INSTANCE;
                final int $stable2 = MaterialTheme.$stable;
                TextKt.Text--4IGK_g(concat2, (Modifier)null, instance5.getColorScheme(composer, $stable2).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance5.getTypography(composer, $stable2).getBodySmall(), composer, 0, 0, 65530);
            }
            composer.endReplaceGroup();
            composer.endNode();
        }
        return t43.a;
    }
}
