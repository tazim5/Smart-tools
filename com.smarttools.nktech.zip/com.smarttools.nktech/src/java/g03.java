import androidx.compose.runtime.FloatState;
import androidx.compose.runtime.State;
import androidx.compose.runtime.Composer$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.layout.SpacerKt;
import com.smarttools.nktech.features.tools.datetime.y;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.runtime.MutableLongState;
import android.content.Context;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.MutableFloatState;

public final class g03 implements od1
{
    public final MutableFloatState P;
    public final MutableState Q;
    public final Context R;
    public final MutableState S;
    public final MutableState T;
    public final MutableState U;
    public final MutableState V;
    public final MutableLongState W;
    public final MutableLongState X;
    public final MutableState Y;
    public final boolean c;
    public final long n;
    public final boolean v;
    public final long w;
    public final MutableState x;
    public final MutableFloatState y;
    public final MutableFloatState z;
    
    public g03(final boolean c, final long n, final boolean v, final long w, final MutableState x, final MutableFloatState y, final MutableFloatState z, final MutableFloatState p17, final MutableState q, final Context r, final MutableState s, final MutableState t, final MutableState u, final MutableState v2, final MutableLongState w2, final MutableLongState x2, final MutableState y2) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p17;
        this.Q = q;
        this.R = r;
        this.S = s;
        this.T = t;
        this.U = u;
        this.V = v2;
        this.W = w2;
        this.X = x2;
        this.Y = y2;
    }
    
    public final Object invoke(Object o, Object o2, final Object o3) {
        final PaddingValues paddingValues = (PaddingValues)o;
        final Composer composer = (Composer)o2;
        int intValue;
        final int n = intValue = ((Number)o3).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), paddingValues);
            final float n3 = 24;
            final Modifier verticalScroll$default = ScrollKt.verticalScroll$default(PaddingKt.padding-3ABfNKs(padding, Dp.constructor-impl(n3)), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.Companion.getCenterHorizontally(), composer, 48);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, verticalScroll$default);
            final ComposeUiNode$Companion companion2 = ComposeUiNode.Companion;
            final id1 constructor = companion2.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion2, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion2.getSetModifier());
            final ColumnScopeInstance instance = ColumnScopeInstance.INSTANCE;
            final float n4 = 16;
            ap.l(n4, companion, composer, 6);
            final MutableFloatState y = this.y;
            final MutableFloatState z = this.z;
            final MutableFloatState p3 = this.P;
            final boolean c = this.c;
            final MutableState x = this.x;
            if (c || (boolean)((State)x).getValue()) {
                composer.startReplaceGroup(1701364991);
                com.smarttools.nktech.features.tools.datetime.y.f(this.n, (boolean)((State)x).getValue(), composer, 0);
                composer.endReplaceGroup();
            }
            else {
                composer.startReplaceGroup(1701550526);
                final float floatValue = ((FloatState)y).getFloatValue();
                final float floatValue2 = ((FloatState)z).getFloatValue();
                final float floatValue3 = ((FloatState)p3).getFloatValue();
                composer.startReplaceGroup(1578915746);
                o2 = composer.rememberedValue();
                final Composer$Companion companion3 = Composer.Companion;
                if ((o = o2) == companion3.getEmpty()) {
                    o = new cq2(y, 4);
                    composer.updateRememberedValue(o);
                }
                final jd1 jd1 = (jd1)o;
                o2 = fe2.c(composer, 1578917476);
                if ((o = o2) == companion3.getEmpty()) {
                    o = new cq2(z, 5);
                    composer.updateRememberedValue(o);
                }
                final jd1 jd2 = (jd1)o;
                o2 = fe2.c(composer, 1578919268);
                if ((o = o2) == companion3.getEmpty()) {
                    o = new cq2(p3, 6);
                    composer.updateRememberedValue(o);
                }
                final jd1 jd3 = (jd1)o;
                composer.endReplaceGroup();
                com.smarttools.nktech.features.tools.datetime.y.c(floatValue, floatValue2, floatValue3, jd1, jd2, jd3, composer, 224256);
                composer.endReplaceGroup();
            }
            ap.l((float)32, companion, composer, 6);
            final MutableState q = this.Q;
            final boolean booleanValue = (boolean)((State)q).getValue();
            final boolean booleanValue2 = (boolean)((State)x).getValue();
            final long w = this.w;
            final boolean b2 = w > 0L;
            final MutableState u = this.U;
            final MutableState t = this.T;
            final Context r = this.R;
            final f03 f03 = new f03(r, this.S, t, w, u);
            final MutableState v = this.V;
            final fr fr = new fr(2, r, t, v);
            o2 = new fr(3, r, t, v);
            final n5 n5 = new n5(r, this.W, this.X, t, v, this.Y, q);
            o = new fr(4, r, x, t);
            com.smarttools.nktech.features.tools.datetime.y.e(this.v, booleanValue, c, booleanValue2, b2, f03, fr, (fr)o2, n5, (fr)o, composer, 0);
            vo2.m(n3, companion, composer, 6, 1579034247);
            if (!c && !(boolean)((State)x).getValue()) {
                composer.startReplaceGroup(1579037470);
                o2 = composer.rememberedValue();
                if ((o = o2) == Composer.Companion.getEmpty()) {
                    o = new gh2((MutableState)y, (MutableState)z, (MutableState)p3, 1);
                    composer.updateRememberedValue(o);
                }
                final od1 od1 = (od1)o;
                composer.endReplaceGroup();
                com.smarttools.nktech.features.tools.datetime.y.b(od1, composer, 6);
            }
            composer.endReplaceGroup();
            SpacerKt.Spacer(SizeKt.height-3ABfNKs((Modifier)companion, Dp.constructor-impl(n4)), composer, 6);
            b02.a(PaddingKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), 0.0f, Dp.constructor-impl(n4), 0.0f, 0.0f, 13, (Object)null), composer, 6);
            composer.endNode();
        }
        return t43.a;
    }
}
