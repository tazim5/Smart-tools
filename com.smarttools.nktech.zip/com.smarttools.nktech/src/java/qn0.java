import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.internal.ComposableLambda;

public abstract class qn0
{
    public static final ComposableLambda a;
    public static final ComposableLambda b;
    public static final ComposableLambda c;
    public static final ComposableLambda d;
    public static final ComposableLambda e;
    public static final ComposableLambda f;
    
    static {
        a = ComposableLambdaKt.composableLambdaInstance(-1455342381, false, (Object)pl0.W);
        b = ComposableLambdaKt.composableLambdaInstance(225126514, false, (Object)mn0.c);
        c = ComposableLambdaKt.composableLambdaInstance(-417129932, false, (Object)pl0.X);
        d = ComposableLambdaKt.composableLambdaInstance(1941915506, false, (Object)nn0.c);
        e = ComposableLambdaKt.composableLambdaInstance(-288899218, false, (Object)on0.c);
        f = ComposableLambdaKt.composableLambdaInstance(-409728400, false, (Object)pn0.c);
    }
}
