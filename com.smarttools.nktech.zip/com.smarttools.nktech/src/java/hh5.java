public final class hh5 implements h32
{
    public static final hh5 a;
    public static final u81 b;
    public static final u81 c;
    public static final u81 d;
    public static final u81 e;
    public static final u81 f;
    public static final u81 g;
    public static final u81 h;
    public static final u81 i;
    public static final u81 j;
    public static final u81 k;
    public static final u81 l;
    public static final u81 m;
    public static final u81 n;
    public static final u81 o;
    
    static {
        a = (hh5)new Object();
        b = new u81("appId", mb.l(f83.i((Class)yj3.class, new og3(1))));
        c = new u81("appVersion", mb.l(f83.i((Class)yj3.class, new og3(2))));
        d = new u81("firebaseProjectId", mb.l(f83.i((Class)yj3.class, new og3(3))));
        e = new u81("mlSdkVersion", mb.l(f83.i((Class)yj3.class, new og3(4))));
        f = new u81("tfliteSchemaVersion", mb.l(f83.i((Class)yj3.class, new og3(5))));
        g = new u81("gcmSenderId", mb.l(f83.i((Class)yj3.class, new og3(6))));
        h = new u81("apiKey", mb.l(f83.i((Class)yj3.class, new og3(7))));
        i = new u81("languages", mb.l(f83.i((Class)yj3.class, new og3(8))));
        j = new u81("mlSdkInstanceId", mb.l(f83.i((Class)yj3.class, new og3(9))));
        k = new u81("isClearcutClient", mb.l(f83.i((Class)yj3.class, new og3(10))));
        l = new u81("isStandaloneMlkit", mb.l(f83.i((Class)yj3.class, new og3(11))));
        m = new u81("isJsonLogging", mb.l(f83.i((Class)yj3.class, new og3(12))));
        n = new u81("buildLevel", mb.l(f83.i((Class)yj3.class, new og3(13))));
        o = new u81("optionalModuleVersion", mb.l(f83.i((Class)yj3.class, new og3(14))));
    }
    
    public final void a(final Object o, final Object o2) {
        final oz5 oz5 = (oz5)o;
        final i32 i32 = (i32)o2;
        i32.a(hh5.b, (Object)oz5.a);
        i32.a(hh5.c, (Object)oz5.b);
        i32.a(hh5.d, (Object)null);
        i32.a(hh5.e, (Object)oz5.c);
        i32.a(hh5.f, (Object)oz5.d);
        i32.a(hh5.g, (Object)null);
        i32.a(hh5.h, (Object)null);
        i32.a(hh5.i, (Object)oz5.e);
        i32.a(hh5.j, (Object)oz5.f);
        i32.a(hh5.k, (Object)oz5.g);
        i32.a(hh5.l, (Object)oz5.h);
        i32.a(hh5.m, (Object)oz5.i);
        i32.a(hh5.n, (Object)oz5.j);
        i32.a(hh5.o, (Object)oz5.k);
    }
}
