import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.material3.IconKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.material.icons.filled.AudioFileKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.RowScope;

public final class jv implements od1
{
    public static final jv c;
    
    static {
        c = (jv)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final RowScope rowScope = (RowScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final ImageVector audioFile = AudioFileKt.getAudioFile(Icons.INSTANCE.getDefault());
            final Modifier$Companion companion = Modifier.Companion;
            IconKt.Icon-ww6aTOc(audioFile, (String)null, SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)18)), 0L, composer, 432, 8);
            gs1.o((float)6, companion, composer, 6);
            TextKt.Text--4IGK_g("Pick Another", (Modifier)null, 0L, TextUnitKt.getSp(13), (FontStyle)null, FontWeight.Companion.getSemiBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 199686, 0, 131030);
        }
        return t43.a;
    }
}
