import java.util.ArrayDeque;
import com.google.android.gms.common.internal.Preconditions;
import java.util.Deque;

public final class xh2 implements Runnable
{
    public final int c;
    public final Runnable n;
    
    public final void run() {
        switch (this.c) {
            default: {
                final Deque deque = (Deque)mx1.n.get();
                Preconditions.checkNotNull((Object)deque);
                Runnable n = this.n;
                deque.add((Object)n);
                if (deque.size() <= 1) {
                    do {
                        n.run();
                        deque.removeFirst();
                    } while ((n = (Runnable)deque.peekFirst()) != null);
                }
                return;
            }
            case 3: {
                mx1.n.set((Object)new ArrayDeque());
                this.n.run();
                return;
            }
            case 2: {
                this.n.run();
                return;
            }
            case 1: {
                this.n.run();
                return;
            }
            case 0: {
                try {
                    this.n.run();
                }
                catch (final Exception ex) {
                    cx5.b("Executor", "Background execution failure.", ex);
                }
            }
        }
    }
    
    @Override
    public String toString() {
        switch (this.c) {
            default: {
                return super.toString();
            }
            case 1: {
                return this.n.toString();
            }
        }
    }
}
