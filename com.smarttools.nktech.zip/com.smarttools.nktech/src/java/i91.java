import java.util.Iterator;
import kotlin.jvm.internal.Lambda;

public final class i91 implements pk2
{
    public final int a;
    public final jd1 b;
    public final Object c;
    
    public i91(final id1 id1, final jd1 b) {
        this.a = 1;
        this.c = id1;
        this.b = b;
    }
    
    public i91(final qv2 c, final jd1 b) {
        this.a = 0;
        this.c = c;
        this.b = b;
    }
    
    public final Iterator iterator() {
        switch (this.a) {
            default: {
                return (Iterator)new ie1(this);
            }
            case 0: {
                return (Iterator)new h91(this);
            }
        }
    }
}
