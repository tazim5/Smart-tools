import androidx.compose.runtime.State;
import androidx.compose.runtime.IntState;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.Alignment$Horizontal;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.foundation.lazy.grid.LazyGridState;
import androidx.compose.foundation.lazy.grid.GridCells;
import androidx.compose.foundation.lazy.grid.LazyGridDslKt;
import androidx.compose.foundation.lazy.grid.GridCells$Fixed;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material.icons.filled.ImageKt;
import androidx.compose.material.icons.filled.VideoLibraryKt;
import androidx.compose.material.icons.filled.FolderOpenKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.CardElevation;
import androidx.compose.material3.CardColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.CardKt;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.material3.TabRowKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import android.content.Context;
import java.util.List;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.MutableState;

public final class lr2 implements od1
{
    public final dq0 P;
    public final MutableState Q;
    public final MutableIntState c;
    public final List n;
    public final MutableState v;
    public final ft1 w;
    public final ft1 x;
    public final MutableState y;
    public final Context z;
    
    public lr2(final MutableIntState c, final List n, final MutableState v, final ft1 w, final ft1 x, final MutableState y, final Context z, final dq0 p9, final MutableState q) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p9;
        this.Q = q;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final PaddingValues paddingValues = (PaddingValues)o;
        final Composer composer = (Composer)o2;
        int intValue;
        final int n = intValue = ((Number)o3).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), paddingValues);
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$Vertical top = instance.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final MutableIntState c = this.c;
            TabRowKt.TabRow-pAZo6Ak(((IntState)c).getIntValue(), (Modifier)null, 0L, 0L, (od1)null, (nd1)null, (nd1)ComposableLambdaKt.rememberComposableLambda(161209715, true, (Object)new w8(c, 6), composer, 54), composer, 1572864, 62);
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default(ColumnScope.weight$default((ColumnScope)instance2, (Modifier)companion, 1.0f, false, 2, (Object)null), 0.0f, 1, (Object)null);
            final MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getTopStart(), false);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, maybeCachedBoxMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final BoxScopeInstance instance3 = BoxScopeInstance.INSTANCE;
            if (((IntState)c).getIntValue() != 2 && !(boolean)((State)this.v).getValue()) {
                composer.startReplaceGroup(-2103580626);
                final Modifier fillMaxSize$default = SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null);
                final MeasurePolicy maybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getCenter(), false);
                final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, fillMaxSize$default);
                final id1 constructor3 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor3);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl3 = Updater.constructor-impl(composer);
                final nd1 b3 = ap.b(companion3, constructor-impl3, maybeCachedBoxMeasurePolicy2, constructor-impl3, currentCompositionLocalMap3);
                if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                    l3.i(currentCompositeKeyHash3, constructor-impl3, currentCompositeKeyHash3, b3);
                }
                Updater.set-impl(constructor-impl3, (Object)materializeModifier3, companion3.getSetModifier());
                CardKt.ElevatedCard(PaddingKt.padding-3ABfNKs(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)32)), (Shape)RoundedCornerShapeKt.RoundedCornerShape-0680j_4(Dp.constructor-impl((float)24)), (CardColors)null, (CardElevation)null, (od1)ComposableLambdaKt.rememberComposableLambda(641510697, true, (Object)new kr2(this.w, this.x), composer, 54), composer, 24582, 12);
                composer.endNode();
                composer.endReplaceGroup();
            }
            else if (((State)this.y).getValue()) {
                composer.startReplaceGroup(-2101190433);
                final Modifier fillMaxSize$default2 = SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null);
                final MeasurePolicy maybeCachedBoxMeasurePolicy3 = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getCenter(), false);
                final int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap4 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier4 = ComposedModifierKt.materializeModifier(composer, fillMaxSize$default2);
                final id1 constructor4 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor4);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl4 = Updater.constructor-impl(composer);
                final nd1 b4 = ap.b(companion3, constructor-impl4, maybeCachedBoxMeasurePolicy3, constructor-impl4, currentCompositionLocalMap4);
                if (constructor-impl4.getInserting() || !kl1.b(constructor-impl4.rememberedValue(), (Object)currentCompositeKeyHash4)) {
                    l3.i(currentCompositeKeyHash4, constructor-impl4, currentCompositeKeyHash4, b4);
                }
                Updater.set-impl(constructor-impl4, (Object)materializeModifier4, companion3.getSetModifier());
                ProgressIndicatorKt.CircularProgressIndicator-LxG7B9w((Modifier)null, 0L, 0.0f, 0L, 0, composer, 0, 31);
                composer.endNode();
                composer.endReplaceGroup();
            }
            else {
                final List n3 = this.n;
                if (n3.isEmpty()) {
                    composer.startReplaceGroup(-2100917881);
                    final Modifier fillMaxSize$default3 = SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null);
                    final MeasurePolicy maybeCachedBoxMeasurePolicy4 = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getCenter(), false);
                    final int currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap5 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier5 = ComposedModifierKt.materializeModifier(composer, fillMaxSize$default3);
                    final id1 constructor5 = companion3.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor5);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl5 = Updater.constructor-impl(composer);
                    final nd1 b5 = ap.b(companion3, constructor-impl5, maybeCachedBoxMeasurePolicy4, constructor-impl5, currentCompositionLocalMap5);
                    if (constructor-impl5.getInserting() || !kl1.b(constructor-impl5.rememberedValue(), (Object)currentCompositeKeyHash5)) {
                        l3.i(currentCompositeKeyHash5, constructor-impl5, currentCompositeKeyHash5, b5);
                    }
                    Updater.set-impl(constructor-impl5, (Object)materializeModifier5, companion3.getSetModifier());
                    final Alignment$Horizontal centerHorizontally = companion2.getCenterHorizontally();
                    final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)32));
                    final MeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(instance.getTop(), centerHorizontally, composer, 48);
                    final int currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap6 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier6 = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
                    final id1 constructor6 = companion3.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor6);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl6 = Updater.constructor-impl(composer);
                    final nd1 b6 = ap.b(companion3, constructor-impl6, columnMeasurePolicy2, constructor-impl6, currentCompositionLocalMap6);
                    if (constructor-impl6.getInserting() || !kl1.b(constructor-impl6.rememberedValue(), (Object)currentCompositeKeyHash6)) {
                        l3.i(currentCompositeKeyHash6, constructor-impl6, currentCompositeKeyHash6, b6);
                    }
                    Updater.set-impl(constructor-impl6, (Object)materializeModifier6, companion3.getSetModifier());
                    final int intValue2 = ((IntState)c).getIntValue();
                    ImageVector imageVector;
                    if (intValue2 != 0) {
                        if (intValue2 != 1) {
                            imageVector = FolderOpenKt.getFolderOpen(Icons.INSTANCE.getDefault());
                        }
                        else {
                            imageVector = VideoLibraryKt.getVideoLibrary(Icons.INSTANCE.getDefault());
                        }
                    }
                    else {
                        imageVector = ImageKt.getImage(Icons.INSTANCE.getDefault());
                    }
                    final Modifier size-3ABfNKs = SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)64));
                    final MaterialTheme instance4 = MaterialTheme.INSTANCE;
                    final int $stable = MaterialTheme.$stable;
                    IconKt.Icon-ww6aTOc(imageVector, (String)null, size-3ABfNKs, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), composer, 432, 0);
                    final int intValue3 = ((IntState)c).getIntValue();
                    String s;
                    if (intValue3 != 0) {
                        if (intValue3 != 1) {
                            s = "No saved statuses";
                        }
                        else {
                            s = "No videos found";
                        }
                    }
                    else {
                        s = "No images found";
                    }
                    TextKt.Text--4IGK_g(s, PaddingKt.padding-qDBjuR0$default((Modifier)companion, 0.0f, Dp.constructor-impl((float)16), 0.0f, 0.0f, 13, (Object)null), instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getTitleMedium(), composer, 48, 0, 65528);
                    String s2;
                    if (((IntState)c).getIntValue() == 2) {
                        s2 = "Download some statuses first";
                    }
                    else {
                        s2 = "View WhatsApp statuses first";
                    }
                    TextKt.Text--4IGK_g(s2, PaddingKt.padding-qDBjuR0$default((Modifier)companion, 0.0f, Dp.constructor-impl((float)8), 0.0f, 0.0f, 13, (Object)null), instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, TextAlign.box-impl(TextAlign.Companion.getCenter-e0LSkKk()), 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 48, 0, 65016);
                    e8.i(composer);
                }
                else {
                    composer.startReplaceGroup(-2099500933);
                    final GridCells$Fixed gridCells$Fixed = new GridCells$Fixed(3);
                    final float n4 = 8;
                    LazyGridDslKt.LazyVerticalGrid((GridCells)gridCells$Fixed, SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), (LazyGridState)null, PaddingKt.PaddingValues-0680j_4(Dp.constructor-impl(n4)), false, (Arrangement$Vertical)instance.spacedBy-0680j_4(Dp.constructor-impl(n4)), (Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl(n4)), (FlingBehavior)null, false, (jd1)new s51((Object)n3, (Object)this.z, (Object)c, (Object)this.P, (Object)this.Q, 11), composer, 1772592, 404);
                    composer.endReplaceGroup();
                }
            }
            composer.endNode();
            b02.a(PaddingKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), 0.0f, Dp.constructor-impl((float)8), 0.0f, 0.0f, 13, (Object)null), composer, 6);
            composer.endNode();
        }
        return t43.a;
    }
}
