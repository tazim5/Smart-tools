public final class me4 implements h32
{
    public static final me4 a;
    
    static {
        a = (me4)new Object();
        f83.q(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, new kg3(1)), 2)), 3)), 4)), 5)));
    }
}
