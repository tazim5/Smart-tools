public final class ao2 extends co2
{
    public final String a;
    
    public ao2(final String a) {
        this.a = a;
    }
    
    @Override
    public final boolean equals(final Object o) {
        return this == o || (o instanceof ao2 && kl1.b((Object)this.a, (Object)((ao2)o).a));
    }
    
    @Override
    public final int hashCode() {
        return this.a.hashCode();
    }
    
    @Override
    public final String toString() {
        return ap.h(new StringBuilder("Error(message="), this.a, ")");
    }
}
