import java.util.ArrayList;
import java.util.Collection;
import android.content.Context;

public final class eb3
{
    public static final int d = 0;
    public final db3 a;
    public final vo0[] b;
    public final Object c;
    
    static {
        fs1.g("WorkConstraintsTracker");
    }
    
    public eb3(Context applicationContext, final hw2 hw2, final db3 a) {
        applicationContext = applicationContext.getApplicationContext();
        this.a = a;
        this.b = new vo0[] { (vo0)new zf((yo0)b23.b(applicationContext, hw2).c, 0), (vo0)new zf((yo0)b23.b(applicationContext, hw2).n, 1), (vo0)new zf((yo0)b23.b(applicationContext, hw2).w, 4), (vo0)new zf((yo0)b23.b(applicationContext, hw2).v, 2), (vo0)new zf((yo0)b23.b(applicationContext, hw2).v, 3), new vo0((yo0)b23.b(applicationContext, hw2).v), new vo0((yo0)b23.b(applicationContext, hw2).v) };
        this.c = new Object();
    }
    
    public final boolean a(final String s) {
        final Object c;
        monitorenter(c = this.c);
        while (true) {
            Label_0088: {
                try {
                    final vo0[] b = this.b;
                    final int length = b.length;
                    final int n = 0;
                    if (n >= length) {
                        break Label_0088;
                    }
                    final vo0 vo0 = b[n];
                    final Object b2 = vo0.b;
                    if (b2 != null && vo0.b(b2) && vo0.a.contains((Object)s)) {
                        fs1.e().a(new Throwable[0]);
                        monitorexit(c);
                        return false;
                    }
                    break Label_0088;
                }
                finally {
                    monitorexit(c);
                    monitorexit(c);
                    return true;
                    int n = 0;
                    ++n;
                    continue;
                }
            }
            break;
        }
    }
    
    public final void b(final Collection collection) {
        final Object c;
        monitorenter(c = this.c);
        Label_0074: {
            try {
                final vo0[] b = this.b;
                final int length = b.length;
                final int n = 0;
                for (final vo0 vo0 : b) {
                    if (vo0.d != null) {
                        vo0.d(vo0.d = null, vo0.b);
                    }
                }
                break Label_0074;
            }
            finally {
                monitorexit(c);
                while (true) {
                    int n3 = 0;
                    Block_6: {
                        while (true) {
                            int n2 = 0;
                            vo0 vo2 = null;
                        Block_8:
                            while (true) {
                                final vo0[] b2;
                                vo2 = b2[n2];
                                iftrue(Label_0156:)(vo2.d == this);
                                break Block_8;
                                final int length2;
                                iftrue(Label_0162:)(n2 >= length2);
                                continue;
                            }
                            vo2.d(vo2.d = this, vo2.b);
                            Label_0156: {
                                ++n2;
                            }
                            continue;
                            final int length3;
                            iftrue(Label_0110:)(n3 >= length3);
                            break Block_6;
                            Label_0110:
                            final vo0[] b2 = this.b;
                            final int length2 = b2.length;
                            final int n;
                            n2 = n;
                            continue;
                        }
                        Label_0162: {
                            monitorexit(c);
                        }
                        return;
                    }
                    final vo0[] b3;
                    b3[n3].c((Collection)collection);
                    ++n3;
                    continue;
                    b3 = this.b;
                    final int length3 = b3.length;
                    n3 = 0;
                    continue;
                }
            }
        }
    }
    
    public final void c() {
        final Object c;
        monitorenter(c = this.c);
        Label_0074: {
            try {
                for (final vo0 vo0 : this.b) {
                    final ArrayList a = vo0.a;
                    if (!a.isEmpty()) {
                        a.clear();
                        vo0.c.b(vo0);
                    }
                }
                break Label_0074;
            }
            finally {
                monitorexit(c);
                monitorexit(c);
            }
        }
    }
}
