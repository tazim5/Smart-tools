import androidx.compose.runtime.State;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ButtonKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import com.smarttools.nktech.features.tools.health.g;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;
import androidx.compose.runtime.snapshots.SnapshotStateList;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.MutableLongState;
import androidx.compose.runtime.MutableFloatState;
import androidx.compose.runtime.MutableIntState;

public final class hh1 implements od1
{
    public final MutableIntState P;
    public final MutableFloatState Q;
    public final MutableLongState R;
    public final MutableState S;
    public final MutableState T;
    public final MutableState c;
    public final MutableState n;
    public final MutableState v;
    public final ft1 w;
    public final mn2 x;
    public final SnapshotStateList y;
    public final MutableState z;
    
    public hh1(final MutableState c, final MutableState n, final MutableState v, final ft1 w, final mn2 x, final SnapshotStateList y, final MutableState z, final MutableIntState p12, final MutableFloatState q, final MutableLongState r, final MutableState s, final MutableState t) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p12;
        this.Q = q;
        this.R = r;
        this.S = s;
        this.T = t;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final MutableState c = this.c;
            final g g = new g(c, this.n, this.v, this.w, this.x, this.y, this.z, this.P, this.Q, this.R, this.S, this.T);
            final Modifier height-3ABfNKs = SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)52));
            final RoundedCornerShape roundedCornerShape-0680j_4 = RoundedCornerShapeKt.RoundedCornerShape-0680j_4(Dp.constructor-impl((float)16));
            final ButtonDefaults instance = ButtonDefaults.INSTANCE;
            composer.startReplaceGroup(343873408);
            long n;
            if (((State)c).getValue()) {
                n = ColorKt.Color(4294198070L);
            }
            else {
                n = MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getPrimary-0d7_KjU();
            }
            composer.endReplaceGroup();
            ButtonKt.Button((id1)g, height-3ABfNKs, false, (Shape)roundedCornerShape-0680j_4, instance.buttonColors-ro_MJ88(n, 0L, 0L, 0L, composer, ButtonDefaults.$stable << 12, 14), (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)ComposableLambdaKt.rememberComposableLambda(-753101456, true, (Object)new gh1(c), composer, 54), composer, 805306416, 484);
        }
        return t43.a;
    }
}
