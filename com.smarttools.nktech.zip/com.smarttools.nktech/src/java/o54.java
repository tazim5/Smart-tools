import android.os.IBinder;

public final class o54 extends go3 implements p54
{
    public o54(final IBinder binder) {
        super(binder, "com.google.android.gms.ads.internal.reward.client.IRewardedVideoAdListener");
    }
}
