import androidx.compose.runtime.MutableFloatState;
import android.content.Context;
import android.os.HandlerThread;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.DisposableEffectResult;

public final class ex1 implements DisposableEffectResult
{
    public final int a;
    public final MutableState b;
    public final MutableState c;
    public final MutableState d;
    public final Object e;
    public final Object f;
    public final MutableState g;
    
    public ex1(final HandlerThread e, final Context f, final MutableState b, final MutableState c, final MutableState d, final MutableState g) {
        this.a = 0;
        this.e = e;
        this.f = f;
        this.b = b;
        this.c = c;
        this.d = d;
        this.g = g;
    }
    
    public ex1(final op1 e, final d3 f, final MutableState b, final MutableState c, final MutableFloatState g, final MutableState d) {
        this.a = 1;
        this.e = e;
        this.f = f;
        this.b = b;
        this.c = c;
        this.g = (MutableState)g;
        this.d = d;
    }
    
    public final void dispose() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        ex1.a:I
        //     4: tableswitch {
        //                0: 90
        //          default: 24
        //        }
        //    24: aload_0        
        //    25: getfield        ex1.e:Ljava/lang/Object;
        //    28: checkcast       Lop1;
        //    31: invokeinterface op1.getLifecycle:()Lhp1;
        //    36: aload_0        
        //    37: getfield        ex1.f:Ljava/lang/Object;
        //    40: checkcast       Ld3;
        //    43: invokevirtual   hp1.removeObserver:(Lnp1;)V
        //    46: aload_0        
        //    47: getfield        ex1.b:Landroidx/compose/runtime/MutableState;
        //    50: astore_3       
        //    51: aload_3        
        //    52: invokeinterface androidx/compose/runtime/State.getValue:()Ljava/lang/Object;
        //    57: checkcast       Ljava/lang/Boolean;
        //    60: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //    63: ifeq            89
        //    66: aload_0        
        //    67: getfield        ex1.g:Landroidx/compose/runtime/MutableState;
        //    70: checkcast       Landroidx/compose/runtime/MutableFloatState;
        //    73: astore_2       
        //    74: aload_0        
        //    75: getfield        ex1.d:Landroidx/compose/runtime/MutableState;
        //    78: astore_1       
        //    79: aload_2        
        //    80: aload_0        
        //    81: getfield        ex1.c:Landroidx/compose/runtime/MutableState;
        //    84: aload_3        
        //    85: aload_1        
        //    86: invokestatic    com/smarttools/nktech/features/tools/common/h.d:(Landroidx/compose/runtime/MutableFloatState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
        //    89: return         
        //    90: aload_0        
        //    91: getfield        ex1.b:Landroidx/compose/runtime/MutableState;
        //    94: invokeinterface androidx/compose/runtime/State.getValue:()Ljava/lang/Object;
        //    99: checkcast       Landroid/hardware/camera2/CameraCaptureSession;
        //   102: astore_1       
        //   103: aload_1        
        //   104: ifnull          118
        //   107: aload_1        
        //   108: invokevirtual   android/hardware/camera2/CameraCaptureSession.close:()V
        //   111: goto            118
        //   114: astore_1       
        //   115: goto            142
        //   118: aload_0        
        //   119: getfield        ex1.c:Landroidx/compose/runtime/MutableState;
        //   122: invokeinterface androidx/compose/runtime/State.getValue:()Ljava/lang/Object;
        //   127: checkcast       Landroid/hardware/camera2/CameraDevice;
        //   130: astore_1       
        //   131: aload_1        
        //   132: ifnull          173
        //   135: aload_1        
        //   136: invokevirtual   android/hardware/camera2/CameraDevice.close:()V
        //   139: goto            173
        //   142: aload_1        
        //   143: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //   146: astore_2       
        //   147: new             Ljava/lang/StringBuilder;
        //   150: dup            
        //   151: ldc             "Error closing camera: "
        //   153: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //   156: astore_1       
        //   157: aload_1        
        //   158: aload_2        
        //   159: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   162: pop            
        //   163: ldc             "MirrorScreen"
        //   165: aload_1        
        //   166: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   169: invokestatic    android/util/Log.e:(Ljava/lang/String;Ljava/lang/String;)I
        //   172: pop            
        //   173: aload_0        
        //   174: getfield        ex1.e:Ljava/lang/Object;
        //   177: checkcast       Landroid/os/HandlerThread;
        //   180: astore_1       
        //   181: aload_1        
        //   182: invokevirtual   android/os/HandlerThread.quitSafely:()Z
        //   185: pop            
        //   186: aload_1        
        //   187: invokevirtual   java/lang/Thread.join:()V
        //   190: aload_0        
        //   191: getfield        ex1.f:Ljava/lang/Object;
        //   194: checkcast       Landroid/content/Context;
        //   197: astore_1       
        //   198: aload_1        
        //   199: instanceof      Landroid/app/Activity;
        //   202: ifeq            213
        //   205: aload_1        
        //   206: checkcast       Landroid/app/Activity;
        //   209: astore_1       
        //   210: goto            215
        //   213: aconst_null    
        //   214: astore_1       
        //   215: aload_1        
        //   216: ifnull          244
        //   219: aload_1        
        //   220: invokevirtual   android/app/Activity.getWindow:()Landroid/view/Window;
        //   223: astore_2       
        //   224: aload_2        
        //   225: ifnull          244
        //   228: aload_2        
        //   229: invokevirtual   android/view/Window.getAttributes:()Landroid/view/WindowManager$LayoutParams;
        //   232: astore_1       
        //   233: aload_1        
        //   234: ldc             -1.0
        //   236: putfield        android/view/WindowManager$LayoutParams.screenBrightness:F
        //   239: aload_2        
        //   240: aload_1        
        //   241: invokevirtual   android/view/Window.setAttributes:(Landroid/view/WindowManager$LayoutParams;)V
        //   244: aload_0        
        //   245: getfield        ex1.d:Landroidx/compose/runtime/MutableState;
        //   248: invokeinterface androidx/compose/runtime/State.getValue:()Ljava/lang/Object;
        //   253: checkcast       Landroid/graphics/Bitmap;
        //   256: astore_1       
        //   257: aload_1        
        //   258: ifnull          265
        //   261: aload_1        
        //   262: invokevirtual   android/graphics/Bitmap.recycle:()V
        //   265: aload_0        
        //   266: getfield        ex1.g:Landroidx/compose/runtime/MutableState;
        //   269: invokeinterface androidx/compose/runtime/State.getValue:()Ljava/lang/Object;
        //   274: checkcast       Landroid/graphics/Bitmap;
        //   277: astore_1       
        //   278: aload_1        
        //   279: ifnull          286
        //   282: aload_1        
        //   283: invokevirtual   android/graphics/Bitmap.recycle:()V
        //   286: return         
        //   287: astore_1       
        //   288: goto            190
        //   291: astore_1       
        //   292: goto            244
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                            
        //  -----  -----  -----  -----  --------------------------------
        //  90     103    114    118    Ljava/lang/Exception;
        //  107    111    114    118    Ljava/lang/Exception;
        //  118    131    114    118    Ljava/lang/Exception;
        //  135    139    114    118    Ljava/lang/Exception;
        //  186    190    287    291    Ljava/lang/InterruptedException;
        //  190    210    291    295    Ljava/lang/Exception;
        //  219    224    291    295    Ljava/lang/Exception;
        //  228    244    291    295    Ljava/lang/Exception;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0190:
        //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
        //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
