import android.os.BaseBundle;
import android.os.Bundle;

public final class i35 implements l35
{
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final Long e;
    
    public i35(final String a, final String b, final String c, final String d, final Long e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
}
