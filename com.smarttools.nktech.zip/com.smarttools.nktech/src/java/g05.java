import android.opengl.EGLConfig;
import android.opengl.GLES20;
import android.opengl.EGLSurface;
import android.opengl.EGLDisplay;
import android.opengl.EGLContext;
import com.google.android.gms.internal.ads.zzen;
import android.opengl.EGL14;

public abstract class g05
{
    public static int a() throws zzen {
        final int[] array = { 0 };
        EGL14.eglQueryContext(EGL14.eglGetDisplay(0), EGL14.eglGetCurrentContext(), 12440, array, 0);
        bq3.a();
        return array[0];
    }
    
    public static EGLContext b(EGLContext eglCreateContext, final EGLDisplay eglDisplay, final int n, final int[] array) throws zzen {
        eglCreateContext = EGL14.eglCreateContext(eglDisplay, l(eglDisplay, array), eglCreateContext, new int[] { 12440, n, 12344 }, 0);
        if (eglCreateContext != null) {
            bq3.a();
            return eglCreateContext;
        }
        EGL14.eglTerminate(eglDisplay);
        throw new Exception(e8.c(n, "eglCreateContext() failed to create a valid context. The device may not support EGL version "));
    }
    
    public static EGLContext c() {
        return EGL14.eglGetCurrentContext();
    }
    
    public static EGLDisplay d() throws zzen {
        final EGLDisplay eglGetDisplay = EGL14.eglGetDisplay(0);
        bq3.b("No EGL display.", eglGetDisplay.equals((Object)EGL14.EGL_NO_DISPLAY) ^ true);
        bq3.b("Error in eglInitialize.", EGL14.eglInitialize(eglGetDisplay, new int[1], 0, new int[1], 0));
        bq3.a();
        return eglGetDisplay;
    }
    
    public static EGLSurface e(final EGLDisplay eglDisplay, final int[] array, final int[] array2) throws zzen {
        final EGLSurface eglCreatePbufferSurface = EGL14.eglCreatePbufferSurface(eglDisplay, l(eglDisplay, array), array2, 0);
        g("Error creating a new EGL Pbuffer surface");
        return eglCreatePbufferSurface;
    }
    
    public static EGLSurface f(final EGLDisplay eglDisplay, final Object o, final int[] array, final int[] array2) throws zzen {
        final EGLSurface eglCreateWindowSurface = EGL14.eglCreateWindowSurface(eglDisplay, l(eglDisplay, array), o, array2, 0);
        g("Error creating a new EGL surface");
        return eglCreateWindowSurface;
    }
    
    public static void g(final String s) throws zzen {
        final int eglGetError = EGL14.eglGetError();
        if (eglGetError == 12288) {
            return;
        }
        throw new Exception(az0.f(s, ", error code: 0x", Integer.toHexString(eglGetError)));
    }
    
    public static void h(final EGLDisplay eglDisplay, final EGLContext eglContext) throws zzen {
        if (eglDisplay == null) {
            return;
        }
        final EGLSurface egl_NO_SURFACE = EGL14.EGL_NO_SURFACE;
        EGL14.eglMakeCurrent(eglDisplay, egl_NO_SURFACE, egl_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
        g("Error releasing context");
        if (eglContext != null) {
            EGL14.eglDestroyContext(eglDisplay, eglContext);
            g("Error destroying context");
        }
        EGL14.eglReleaseThread();
        g("Error releasing thread");
        EGL14.eglTerminate(eglDisplay);
        g("Error terminating display");
    }
    
    public static void i(final EGLDisplay eglDisplay, final EGLSurface eglSurface) throws zzen {
        if (eglDisplay != null) {
            if (eglSurface != null) {
                EGL14.eglDestroySurface(eglDisplay, eglSurface);
                g("Error destroying surface");
            }
        }
    }
    
    public static void j(final EGLDisplay eglDisplay, final EGLContext eglContext, final EGLSurface eglSurface, final int n, final int n2, final int n3) throws zzen {
        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext);
        g("Error making context current");
        final int[] array = { 0 };
        GLES20.glGetIntegerv(36006, array, 0);
        if (array[0] != n) {
            GLES20.glBindFramebuffer(36160, n);
        }
        bq3.a();
        GLES20.glViewport(0, 0, n2, n3);
        bq3.a();
    }
    
    public static boolean k(final String s) {
        final String eglQueryString = EGL14.eglQueryString(EGL14.eglGetDisplay(0), 12373);
        return eglQueryString != null && eglQueryString.contains((CharSequence)s);
    }
    
    private static EGLConfig l(final EGLDisplay eglDisplay, final int[] array) throws zzen {
        final EGLConfig[] array2 = { null };
        if (EGL14.eglChooseConfig(eglDisplay, array, 0, array2, 0, 1, new int[1], 0)) {
            return array2[0];
        }
        throw new Exception("eglChooseConfig failed.");
    }
}
