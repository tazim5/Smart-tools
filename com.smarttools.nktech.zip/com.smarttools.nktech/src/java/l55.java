public interface l55
{
}
