import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class jq5
{
    public static final u65 a;
    
    static {
        a = new u65(5);
    }
    
    public static String a(final String s, final Object... array) {
        final int n = 0;
        int n2 = 0;
        int length;
        while (true) {
            length = array.length;
            if (n2 >= length) {
                break;
            }
            final Object o = array[n2];
            String s2;
            if (o == null) {
                s2 = "null";
            }
            else {
                try {
                    s2 = o.toString();
                }
                catch (final Exception ex) {
                    final StringBuilder sb = new StringBuilder();
                    sb.append(o.getClass().getName());
                    sb.append('@');
                    sb.append(Integer.toHexString(System.identityHashCode(o)));
                    final String string = sb.toString();
                    Logger.getLogger("com.google.common.base.Strings").logp(Level.WARNING, "com.google.common.base.Strings", "lenientToString", "Exception during lenientFormat for ".concat(string), (Throwable)ex);
                    final StringBuilder j = vo2.j("<", string, " threw ");
                    j.append(((Throwable)ex).getClass().getName());
                    j.append(">");
                    s2 = j.toString();
                }
            }
            array[n2] = s2;
            ++n2;
        }
        final StringBuilder sb2 = new StringBuilder(length * 16 + s.length());
        int n3 = 0;
        int n4 = n;
        int length2;
        while (true) {
            length2 = array.length;
            if (n4 >= length2) {
                break;
            }
            final int index = s.indexOf("%s", n3);
            if (index == -1) {
                break;
            }
            sb2.append((CharSequence)s, n3, index);
            sb2.append(array[n4]);
            n3 = index + 2;
            ++n4;
        }
        sb2.append((CharSequence)s, n3, s.length());
        if (n4 < length2) {
            sb2.append(" [");
            final int n5 = n4 + 1;
            sb2.append(array[n4]);
            for (int i = n5; i < array.length; ++i) {
                sb2.append(", ");
                sb2.append(array[i]);
            }
            sb2.append(']');
        }
        return sb2.toString();
    }
}
