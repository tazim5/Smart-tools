public final class b21
{
    public final double a;
    public final double b;
    public final double c;
    public final double d;
    public final double e;
    public final double f;
    public final double g;
    
    public b21(final double a, final double b, final double c, final double d, final double e, final double f, final double g) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof b21)) {
            return false;
        }
        final b21 b21 = (b21)o;
        return Double.compare(this.a, b21.a) == 0 && Double.compare(this.b, b21.b) == 0 && Double.compare(this.c, b21.c) == 0 && Double.compare(this.d, b21.d) == 0 && Double.compare(this.e, b21.e) == 0 && Double.compare(this.f, b21.f) == 0 && Double.compare(this.g, b21.g) == 0;
    }
    
    @Override
    public final int hashCode() {
        return Double.hashCode(this.g) + vo2.b(this.f, vo2.b(this.e, vo2.b(this.d, vo2.b(this.c, vo2.b(this.b, Double.hashCode(this.a) * 31, 31), 31), 31), 31), 31);
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("ElectricityResult(powerWatts=");
        sb.append(this.a);
        sb.append(", totalHours=");
        sb.append(this.b);
        sb.append(", costPerUnit=");
        sb.append(this.c);
        sb.append(", energyKwh=");
        sb.append(this.d);
        sb.append(", totalCost=");
        sb.append(this.e);
        sb.append(", dailyCost=");
        sb.append(this.f);
        sb.append(", monthlyCost=");
        sb.append(this.g);
        sb.append(")");
        return sb.toString();
    }
}
