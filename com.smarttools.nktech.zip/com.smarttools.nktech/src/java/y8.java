import androidx.compose.ui.text.style.TextOverflow$Companion;
import androidx.compose.ui.text.TextStyle;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Vertical;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.style.TextOverflow;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material.icons.filled.AndroidKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.layout.ContentScale;
import androidx.compose.foundation.ImageKt;
import androidx.compose.ui.graphics.AndroidImageBitmap_androidKt;
import android.graphics.Canvas;
import android.graphics.Bitmap$Config;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.material3.CheckboxColors;
import androidx.compose.material3.CheckboxKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;

public final class y8 implements od1
{
    public final ba c;
    public final u5 n;
    
    public y8(final ba c, final u5 n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object invoke(Object o, Object rememberedValue, final Object o2) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)rememberedValue;
        if ((((Number)o2).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final float n = 12;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs(fillMaxWidth$default, Dp.constructor-impl(n));
            final Alignment$Companion companion2 = Alignment.Companion;
            final Alignment$Vertical centerVertically = companion2.getCenterVertically();
            final Arrangement instance = Arrangement.INSTANCE;
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(instance.getStart(), centerVertically, composer, 48);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, rowMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final RowScopeInstance instance2 = RowScopeInstance.INSTANCE;
            final ba c = this.c;
            final boolean f = c.f;
            composer.startReplaceGroup(681512819);
            final u5 n2 = this.n;
            final boolean changed = composer.changed((Object)n2);
            rememberedValue = composer.rememberedValue();
            if (changed || (o = rememberedValue) == Composer.Companion.getEmpty()) {
                o = new h8((Object)n2, 1);
                composer.updateRememberedValue(o);
            }
            final jd1 jd1 = (jd1)o;
            composer.endReplaceGroup();
            CheckboxKt.Checkbox(f, jd1, (Modifier)null, false, (CheckboxColors)null, (MutableInteractionSource)null, composer, 0, 60);
            final Drawable d = c.d;
            if (d != null) {
                composer.startReplaceGroup(-347833286);
                Bitmap bitmap;
                if (d instanceof BitmapDrawable) {
                    final BitmapDrawable bitmapDrawable = (BitmapDrawable)d;
                    if (bitmapDrawable.getBitmap() == null) {
                        throw new IllegalArgumentException("bitmap is null");
                    }
                    if (48 == bitmapDrawable.getBitmap().getWidth() && 48 == bitmapDrawable.getBitmap().getHeight()) {
                        bitmap = bitmapDrawable.getBitmap();
                    }
                    else {
                        bitmap = Bitmap.createScaledBitmap(bitmapDrawable.getBitmap(), 48, 48, true);
                    }
                }
                else {
                    final Rect bounds = d.getBounds();
                    final int left = bounds.left;
                    final int top = bounds.top;
                    final int right = bounds.right;
                    final int bottom = bounds.bottom;
                    bitmap = Bitmap.createBitmap(48, 48, Bitmap$Config.ARGB_8888);
                    d.setBounds(0, 0, 48, 48);
                    d.draw(new Canvas(bitmap));
                    d.setBounds(left, top, right, bottom);
                }
                ImageKt.Image-5h-nEew(AndroidImageBitmap_androidKt.asImageBitmap(bitmap), (String)null, SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)40)), (Alignment)null, (ContentScale)null, 0.0f, (ColorFilter)null, 0, composer, 440, 248);
                composer.endReplaceGroup();
            }
            else {
                composer.startReplaceGroup(-347601809);
                IconKt.Icon-ww6aTOc(AndroidKt.getAndroid(Icons.INSTANCE.getDefault()), (String)null, SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)40)), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getPrimary-0d7_KjU(), composer, 432, 0);
                composer.endReplaceGroup();
            }
            gs1.o(n, companion, composer, 6);
            final Modifier weight$default = RowScope.weight$default((RowScope)instance2, (Modifier)companion, 1.0f, false, 2, (Object)null);
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(instance.getTop(), companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, weight$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, columnMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final ColumnScopeInstance instance3 = ColumnScopeInstance.INSTANCE;
            final MaterialTheme instance4 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            final TextStyle bodyLarge = instance4.getTypography(composer, $stable).getBodyLarge();
            final FontWeight medium = FontWeight.Companion.getMedium();
            final TextOverflow$Companion companion4 = TextOverflow.Companion;
            TextKt.Text--4IGK_g(c.a, (Modifier)null, 0L, 0L, (FontStyle)null, medium, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, companion4.getEllipsis-gIe3tQ8(), false, 1, 0, (jd1)null, bodyLarge, composer, 196608, 3120, 55262);
            TextKt.Text--4IGK_g(c.b, (Modifier)null, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, companion4.getEllipsis-gIe3tQ8(), false, 1, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 0, 3120, 55290);
            composer.endNode();
            composer.endNode();
        }
        return t43.a;
    }
}
