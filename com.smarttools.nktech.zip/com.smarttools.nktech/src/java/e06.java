import com.google.android.gms.internal.ads.zzcf;

public abstract class e06
{
    public static void a(final String s, final boolean b) {
        if (b) {
            return;
        }
        throw zzcf.a(s, (ArrayIndexOutOfBoundsException)null);
    }
}
