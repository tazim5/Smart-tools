import com.google.firebase.installations.local.PersistedInstallation$RegistrationStatus;

public final class le1 implements jr2
{
    public final g63 a;
    public final gw2 b;
    
    public le1(final g63 a, final gw2 b) {
        this.a = a;
        this.b = b;
    }
    
    public final boolean a(final Exception ex) {
        this.b.c(ex);
        return true;
    }
    
    public final boolean b(final ee ee) {
        if (ee.b != PersistedInstallation$RegistrationStatus.w || this.a.a(ee)) {
            return false;
        }
        final String c = ee.c;
        if (c != null) {
            this.b.b((Object)new ud(ee.e, ee.f, c));
            return true;
        }
        throw new NullPointerException("Null token");
    }
}
