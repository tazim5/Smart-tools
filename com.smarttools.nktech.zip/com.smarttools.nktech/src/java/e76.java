import java.io.IOException;
import com.google.android.gms.internal.ads.zzrj;

public final class e76 implements q76
{
    public final int a;
    public final g76 b;
    
    public e76(final g76 b, final int a) {
        this.b = b;
        this.a = a;
    }
    
    public final int a(final long n) {
        final g76 b = this.b;
        final int a = this.a;
        final boolean w = b.w();
        final int n2 = 0;
        if (w) {
            return n2;
        }
        b.s(a);
        final l76 l76 = b.X[a];
        final boolean p = b.p0;
        final l76 l77;
        monitorenter(l77 = l76);
    Block_10_Outer:
        while (true) {
            try {
                final int q = l76.q;
                final int i = l76.i(q);
                final int q2 = l76.q;
                final int n4 = l76.n;
                final boolean b2 = true;
                if (q2 == n4 || n < l76.l[i]) {
                    break Block_10_Outer;
                }
                if (n > l76.t && p) {
                    final int n3 = n4 - q;
                    monitorexit(l77);
                    break Block_10_Outer;
                }
                final int h = l76.h(i, n4 - q, n, true);
                monitorexit(l77);
                int n3;
                if ((n3 = h) == -1) {
                    n3 = 0;
                }
                break Block_10_Outer;
            }
            finally {
                monitorexit(l77);
                monitorexit(l77);
                continue Block_10_Outer;
                while (true) {
                    int n3 = 0;
                    Label_0245: {
                        try {
                            if (l76.q + n3 <= l76.n) {
                                break Label_0245;
                            }
                            Label_0234: {
                                final boolean b2 = false;
                            }
                            break Label_0245;
                        }
                        finally {
                            final l76 l78;
                            monitorexit(l78);
                            while (true) {
                                b.t(a);
                                n3 = n2;
                                Label_0282: {
                                    return n3;
                                }
                                final boolean b2;
                                aq3.i(b2);
                                l76.q += n3;
                                monitorexit(l78);
                                iftrue(Label_0282:)(n3 != 0);
                                continue;
                            }
                        }
                    }
                    final l76 l78;
                    monitorenter(l78 = l76);
                    iftrue(Label_0234:)(n3 < 0);
                    continue;
                }
            }
            break;
        }
    }
    
    public final int b(final mw4 mw4, final nu5 nu5, int n) {
        final g76 b = this.b;
        final int a = this.a;
        final boolean w = b.w();
        final int n2 = -3;
        if (w) {
            n = n2;
            return n;
        }
        b.s(a);
        final l76 l76 = b.X[a];
        final boolean p3 = b.p0;
        l76.getClass();
        final boolean b2 = (n & 0x2) != 0x0;
        final xo b3 = l76.b;
        final l76 l77;
        monitorenter(l77 = l76);
        Label_0200: {
            try {
                nu5.f = false;
                final int q = l76.q;
                final boolean b4 = q != l76.n;
                final int n3 = -4;
                if (b4) {
                    break Label_0200;
                }
                if (p3 || l76.u) {
                    break Label_0200;
                }
                final ak3 x = l76.x;
                if (x != null && (b2 || x != l76.f)) {
                    break Label_0200;
                }
                break Label_0200;
            }
            finally {
                monitorexit(l77);
                final int q;
                final int n3;
                final ak3 x;
                boolean b5 = false;
                int n4 = 0;
                int n5 = 0;
                int i = 0;
                int n6;
                long g;
                j76 a2;
                int b6;
                ak3 a3;
                j76 a4;
                Label_0624:Block_15_Outer:Block_16_Outer:
                while (true) {
                Block_23:
                    while (true) {
                        Label_0313: {
                            while (true) {
                                Label_0479:Label_0193_Outer:Block_24_Outer:
                                while (true) {
                                Label_0203:
                                    while (true) {
                                        Block_22: {
                                            Label_0225: {
                                                Label_0420: {
                                                    while (true) {
                                                    Label_0605_Outer:
                                                        while (true) {
                                                            while (true) {
                                                                while (true) {
                                                                    while (true) {
                                                                        ((iu0)nu5).b |= Integer.MIN_VALUE;
                                                                        break Label_0420;
                                                                        Label_0310: {
                                                                            b5 = true;
                                                                        }
                                                                        break Label_0313;
                                                                        iftrue(Label_0624:)(n4 != -4);
                                                                        n4 = n3;
                                                                        iftrue(Label_0624:)(((iu0)nu5).a(4));
                                                                        n5 = (n & 0x1);
                                                                        iftrue(Label_0593:)((n & 0x4) != 0x0);
                                                                        break Block_22;
                                                                        n4 = -5;
                                                                        continue Label_0479;
                                                                        ++l76.q;
                                                                        n4 = n3;
                                                                        break Label_0624;
                                                                        n6 = l76.k[i];
                                                                        b5 = false;
                                                                        break Label_0313;
                                                                        g = l76.l[i];
                                                                        nu5.g = g;
                                                                        iftrue(Label_0420:)(g >= l76.r);
                                                                        continue Label_0193_Outer;
                                                                    }
                                                                    l76.k(x, mw4);
                                                                    monitorexit(l77);
                                                                    continue Label_0605_Outer;
                                                                    ((iu0)nu5).b = 4;
                                                                    nu5.g = Long.MIN_VALUE;
                                                                    monitorexit(l77);
                                                                    break Label_0225;
                                                                    Label_0553: {
                                                                        a2 = l76.a;
                                                                    }
                                                                    a2.c = j76.e(a2.c, nu5, l76.b, a2.a);
                                                                    continue Block_15_Outer;
                                                                }
                                                                n4 = n3;
                                                                break Label_0624;
                                                                ((iu0)nu5).b = (0x20000000 | b6);
                                                                continue Block_24_Outer;
                                                            }
                                                            Label_0465: {
                                                                l76.k(a3, mw4);
                                                            }
                                                            monitorexit(l77);
                                                            continue Label_0605_Outer;
                                                        }
                                                        iftrue(Label_0638:)(n4 != -3);
                                                        Block_25: {
                                                            break Block_25;
                                                            monitorexit(l77);
                                                            break Label_0203;
                                                        }
                                                        b.t(a);
                                                        return n4;
                                                        a3 = ((k76)l76.c.l(l76.o + q)).a;
                                                        iftrue(Label_0465:)(b2 || a3 != l76.f);
                                                        break Label_0479;
                                                        nu5.f = true;
                                                        monitorexit(l77);
                                                        break Label_0203;
                                                        Label_0329: {
                                                            b6 = l76.k[i];
                                                        }
                                                        ((iu0)nu5).b = b6;
                                                        iftrue(Label_0382:)(l76.q != l76.n - 1 || (!p3 && !l76.u));
                                                        continue Block_16_Outer;
                                                    }
                                                }
                                                b3.c = l76.j[i];
                                                b3.n = l76.i[i];
                                                b3.v = l76.m[i];
                                                monitorexit(l77);
                                            }
                                            n4 = -4;
                                            continue Label_0479;
                                            Label_0638: {
                                                n = n4;
                                            }
                                            return n;
                                        }
                                        iftrue(Label_0553:)(n5 == 0);
                                        break Block_23;
                                        Label_0593: {
                                            iftrue(Label_0605:)(n5 == 0);
                                        }
                                        continue Block_16_Outer;
                                    }
                                    n4 = -3;
                                    continue Label_0479;
                                }
                                i = l76.i(l76.q);
                                iftrue(Label_0310:)(l76.A == null);
                                continue Block_16_Outer;
                            }
                        }
                        iftrue(Label_0329:)(b5);
                        continue;
                    }
                    a4 = l76.a;
                    j76.e(a4.c, nu5, l76.b, a4.a);
                    n4 = n3;
                    continue Label_0624;
                }
            }
        }
    }
    
    public final void zzd() {
        final g76 b = this.b;
        final bl4 a = b.X[this.a].A;
        if (a != null) {
            throw (zzrj)a.n;
        }
        int n;
        if (b.g0 == 7) {
            n = 6;
        }
        else {
            n = 3;
        }
        final w65 z = b.z;
        final IOException ex = (IOException)z.w;
        if (ex == null) {
            final s86 s86 = (s86)z.v;
            if (s86 != null) {
                final IOException w = s86.w;
                if (w != null) {
                    if (s86.x > n) {
                        throw w;
                    }
                }
            }
            return;
        }
        throw ex;
    }
    
    public final boolean zze() {
        final g76 b = this.b;
        return !b.w() && b.X[this.a].n(b.p0);
    }
}
