import java.util.concurrent.Executor;

public final class vj4 implements f46, m42, k42, h42
{
    public final int c;
    public final Executor n;
    public final pp0 v;
    public final o76 w;
    
    public final void a(final fw2 fw2) {
        switch (this.c) {
            default: {
                this.n.execute((Runnable)new ae1(19, (Object)this, false, (Object)fw2));
                return;
            }
            case 0: {
                this.n.execute((Runnable)new jg5(11, (Object)this, false, (Object)fw2));
            }
        }
    }
    
    public void c() {
        this.w.o();
    }
    
    public void onSuccess(final Object o) {
        this.w.n(o);
    }
    
    public void t(final Exception ex) {
        this.w.m(ex);
    }
}
