import android.os.BaseBundle;
import com.google.android.gms.common.internal.BaseGmsClient$ConnectionProgressReportCallbacks;
import com.google.android.gms.common.internal.BaseGmsClient;
import com.google.android.gms.common.internal.BaseGmsClient$LegacyClientCallbackAdapter;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.IInterface;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.common.internal.IAccountAccessor;
import com.google.android.gms.common.api.GoogleApiClient$OnConnectionFailedListener;
import com.google.android.gms.common.api.GoogleApiClient$ConnectionCallbacks;
import android.os.Looper;
import android.content.Context;
import android.os.Bundle;
import com.google.android.gms.common.internal.ClientSettings;
import com.google.android.gms.common.internal.GmsClient;

public final class kn2 extends GmsClient implements zc3
{
    public final boolean a;
    public final ClientSettings b;
    public final Bundle c;
    public final Integer d;
    
    public kn2(final Context context, final Looper looper, final ClientSettings b, final Bundle c, final GoogleApiClient$ConnectionCallbacks googleApiClient$ConnectionCallbacks, final GoogleApiClient$OnConnectionFailedListener googleApiClient$OnConnectionFailedListener) {
        super(context, looper, 44, b, googleApiClient$ConnectionCallbacks, googleApiClient$OnConnectionFailedListener);
        this.a = true;
        this.b = b;
        this.c = c;
        this.d = b.zab();
    }
    
    public final void a(final IAccountAccessor accountAccessor, final boolean b) {
        try {
            final cd3 cd3 = (cd3)((BaseGmsClient)this).getService();
            final int intValue = (int)Preconditions.checkNotNull((Object)this.d);
            final Parcel zaa = ((rc3)cd3).zaa();
            vc3.d(zaa, (IInterface)accountAccessor);
            zaa.writeInt(intValue);
            zaa.writeInt((int)(b ? 1 : 0));
            ((rc3)cd3).zac(9, zaa);
        }
        catch (final RemoteException ex) {}
    }
    
    public final void b(final uc3 p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "Expecting a valid ISignInCallbacks"
        //     3: invokestatic    com/google/android/gms/common/internal/Preconditions.checkNotNull:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //     6: pop            
        //     7: aload_0        
        //     8: getfield        kn2.b:Lcom/google/android/gms/common/internal/ClientSettings;
        //    11: invokevirtual   com/google/android/gms/common/internal/ClientSettings.getAccountOrDefault:()Landroid/accounts/Account;
        //    14: astore_3       
        //    15: ldc             "<<default account>>"
        //    17: aload_3        
        //    18: getfield        android/accounts/Account.name:Ljava/lang/String;
        //    21: invokevirtual   java/lang/String.equals:(Ljava/lang/Object;)Z
        //    24: ifeq            82
        //    27: aload_0        
        //    28: invokevirtual   com/google/android/gms/common/internal/BaseGmsClient.getContext:()Landroid/content/Context;
        //    31: invokestatic    cs2.a:(Landroid/content/Context;)Lcs2;
        //    34: astore_2       
        //    35: aload_2        
        //    36: ldc             "defaultGoogleSignInAccount"
        //    38: invokevirtual   cs2.b:(Ljava/lang/String;)Ljava/lang/String;
        //    41: astore          4
        //    43: aload           4
        //    45: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //    48: ifeq            54
        //    51: goto            82
        //    54: aload_2        
        //    55: ldc             "googleSignInAccount"
        //    57: aload           4
        //    59: invokestatic    cs2.d:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
        //    62: invokevirtual   cs2.b:(Ljava/lang/String;)Ljava/lang/String;
        //    65: astore_2       
        //    66: aload_2        
        //    67: ifnull          82
        //    70: aload_2        
        //    71: invokestatic    com/google/android/gms/auth/api/signin/GoogleSignInAccount.l:(Ljava/lang/String;)Lcom/google/android/gms/auth/api/signin/GoogleSignInAccount;
        //    74: astore_2       
        //    75: goto            84
        //    78: astore_2       
        //    79: goto            155
        //    82: aconst_null    
        //    83: astore_2       
        //    84: new             Lcom/google/android/gms/common/internal/zat;
        //    87: astore          4
        //    89: aload           4
        //    91: aload_3        
        //    92: aload_0        
        //    93: getfield        kn2.d:Ljava/lang/Integer;
        //    96: invokestatic    com/google/android/gms/common/internal/Preconditions.checkNotNull:(Ljava/lang/Object;)Ljava/lang/Object;
        //    99: checkcast       Ljava/lang/Integer;
        //   102: invokevirtual   java/lang/Integer.intValue:()I
        //   105: aload_2        
        //   106: invokespecial   com/google/android/gms/common/internal/zat.<init>:(Landroid/accounts/Account;ILcom/google/android/gms/auth/api/signin/GoogleSignInAccount;)V
        //   109: aload_0        
        //   110: invokevirtual   com/google/android/gms/common/internal/BaseGmsClient.getService:()Landroid/os/IInterface;
        //   113: checkcast       Lcd3;
        //   116: astore_3       
        //   117: new             Lcom/google/android/gms/signin/internal/zai;
        //   120: astore_2       
        //   121: aload_2        
        //   122: iconst_1       
        //   123: aload           4
        //   125: invokespecial   com/google/android/gms/signin/internal/zai.<init>:(ILcom/google/android/gms/common/internal/zat;)V
        //   128: aload_3        
        //   129: invokevirtual   rc3.zaa:()Landroid/os/Parcel;
        //   132: astore          4
        //   134: aload           4
        //   136: aload_2        
        //   137: invokestatic    vc3.c:(Landroid/os/Parcel;Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;)V
        //   140: aload           4
        //   142: aload_1        
        //   143: invokestatic    vc3.d:(Landroid/os/Parcel;Landroid/os/IInterface;)V
        //   146: aload_3        
        //   147: bipush          12
        //   149: aload           4
        //   151: invokevirtual   rc3.zac:(ILandroid/os/Parcel;)V
        //   154: return         
        //   155: new             Lcom/google/android/gms/signin/internal/zak;
        //   158: astore          4
        //   160: new             Lcom/google/android/gms/common/ConnectionResult;
        //   163: astore_3       
        //   164: aload_3        
        //   165: bipush          8
        //   167: aconst_null    
        //   168: invokespecial   com/google/android/gms/common/ConnectionResult.<init>:(ILandroid/app/PendingIntent;)V
        //   171: aload           4
        //   173: iconst_1       
        //   174: aload_3        
        //   175: aconst_null    
        //   176: invokespecial   com/google/android/gms/signin/internal/zak.<init>:(ILcom/google/android/gms/common/ConnectionResult;Lcom/google/android/gms/common/internal/zav;)V
        //   179: aload_1        
        //   180: aload           4
        //   182: invokeinterface ad3.zab:(Lcom/google/android/gms/signin/internal/zak;)V
        //   187: return         
        //   188: astore_1       
        //   189: ldc             "SignInClientImpl"
        //   191: ldc             "ISignInCallbacks#onSignInComplete should be executed from the same process, unexpected RemoteException."
        //   193: aload_2        
        //   194: invokestatic    android/util/Log.wtf:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
        //   197: pop            
        //   198: return         
        //   199: astore_2       
        //   200: goto            82
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                        
        //  -----  -----  -----  -----  ----------------------------
        //  7      51     78     199    Landroid/os/RemoteException;
        //  54     66     78     199    Landroid/os/RemoteException;
        //  70     75     199    203    Lorg/json/JSONException;
        //  70     75     78     199    Landroid/os/RemoteException;
        //  84     154    78     199    Landroid/os/RemoteException;
        //  155    187    188    199    Landroid/os/RemoteException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0082:
        //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
        //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public final IInterface createServiceInterface(final IBinder binder) {
        Object o;
        if (binder == null) {
            o = null;
        }
        else {
            final IInterface queryLocalInterface = binder.queryLocalInterface("com.google.android.gms.signin.internal.ISignInService");
            if (queryLocalInterface instanceof cd3) {
                o = queryLocalInterface;
            }
            else {
                o = new rc3(binder, "com.google.android.gms.signin.internal.ISignInService");
            }
        }
        return (IInterface)o;
    }
    
    public final Bundle getGetServiceRequestExtraArgs() {
        final ClientSettings b = this.b;
        final boolean equals = ((BaseGmsClient)this).getContext().getPackageName().equals((Object)b.getRealClientPackageName());
        final Bundle c = this.c;
        if (!equals) {
            ((BaseBundle)c).putString("com.google.android.gms.signin.internal.realClientPackageName", b.getRealClientPackageName());
        }
        return c;
    }
    
    public final int getMinApkVersion() {
        return 12451000;
    }
    
    public final String getServiceDescriptor() {
        return "com.google.android.gms.signin.internal.ISignInService";
    }
    
    public final String getStartServiceAction() {
        return "com.google.android.gms.signin.service.START";
    }
    
    public final boolean requiresSignIn() {
        return this.a;
    }
    
    public final void zaa() {
        try {
            final cd3 cd3 = (cd3)((BaseGmsClient)this).getService();
            final int intValue = (int)Preconditions.checkNotNull((Object)this.d);
            final Parcel zaa = ((rc3)cd3).zaa();
            zaa.writeInt(intValue);
            ((rc3)cd3).zac(7, zaa);
        }
        catch (final RemoteException ex) {}
    }
    
    public final void zab() {
        ((BaseGmsClient)this).connect((BaseGmsClient$ConnectionProgressReportCallbacks)new BaseGmsClient$LegacyClientCallbackAdapter((BaseGmsClient)this));
    }
}
