import java.nio.Buffer;
import java.nio.ByteOrder;
import java.nio.ByteBuffer;
import android.util.Pair;
import java.io.RandomAccessFile;

public abstract class w06
{
    public static Pair a(final RandomAccessFile randomAccessFile, int i) {
        final long length = randomAccessFile.length();
        if (length >= 22L) {
            final ByteBuffer allocate = ByteBuffer.allocate((int)Math.min((long)i, -22L + length) + 22);
            allocate.order(ByteOrder.LITTLE_ENDIAN);
            final long n = length - ((Buffer)allocate).capacity();
            randomAccessFile.seek(n);
            randomAccessFile.readFully(allocate.array(), allocate.arrayOffset(), ((Buffer)allocate).capacity());
            b(allocate);
            i = ((Buffer)allocate).capacity();
            Label_0166: {
                if (i >= 22) {
                    final int n2 = i - 22;
                    int min;
                    int n3;
                    for (min = Math.min(n2, 65535), i = 0; i < min; ++i) {
                        n3 = n2 - i;
                        if (allocate.getInt(n3) == 101010256 && (char)allocate.getShort(n3 + 20) == i) {
                            i = n3;
                            break Label_0166;
                        }
                    }
                }
                i = -1;
            }
            if (i != -1) {
                allocate.position(i);
                final ByteBuffer slice = allocate.slice();
                slice.order(ByteOrder.LITTLE_ENDIAN);
                return Pair.create((Object)slice, (Object)(n + i));
            }
        }
        return null;
    }
    
    public static void b(final ByteBuffer byteBuffer) {
        if (byteBuffer.order() == ByteOrder.LITTLE_ENDIAN) {
            return;
        }
        throw new IllegalArgumentException("ByteBuffer byte order must be little endian");
    }
}
