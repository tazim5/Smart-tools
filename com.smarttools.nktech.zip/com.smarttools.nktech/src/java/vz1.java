public final class vz1
{
    public final String a;
    public final d02 b;
    
    public vz1(final String a, final d02 b) {
        this.a = a;
        this.b = b;
    }
}
