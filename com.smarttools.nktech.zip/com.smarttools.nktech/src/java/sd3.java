import android.os.Bundle;
import android.os.IInterface;

public interface sd3 extends IInterface
{
    void zza(final Bundle p0);
}
