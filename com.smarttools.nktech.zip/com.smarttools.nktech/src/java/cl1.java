public final class cl1 extends al1
{
    public static final cl1 w;
    
    static {
        w = (cl1)new al1(1, 0, 1);
    }
    
    public final boolean d(final int n) {
        return super.c <= n && n <= super.n;
    }
    
    public final boolean equals(final Object o) {
        if (o instanceof cl1) {
            if (!this.isEmpty() || !((cl1)o).isEmpty()) {
                final cl1 cl1 = (cl1)o;
                if (super.c != cl1.c || super.n != cl1.n) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    public final int hashCode() {
        int n;
        if (this.isEmpty()) {
            n = -1;
        }
        else {
            n = super.c * 31 + super.n;
        }
        return n;
    }
    
    public final boolean isEmpty() {
        return super.c > super.n;
    }
    
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(super.c);
        sb.append("..");
        sb.append(super.n);
        return sb.toString();
    }
}
