import com.google.android.gms.ads.internal.util.zzg;
import com.google.android.gms.ads.internal.client.zze;
import java.util.concurrent.Executor;
import com.google.android.gms.internal.ads.k1;
import android.os.Bundle;
import java.util.Collections;
import com.google.android.gms.internal.ads.zzfio;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.util.zzj;

public final class xw4 implements pj4, aj4
{
    public static final Object v;
    public static int w;
    public final zzj c;
    public final ax4 n;
    
    static {
        v = new Object();
    }
    
    public xw4(final ax4 n, final zzj c) {
        this.n = n;
        this.c = c;
    }
    
    public final void a(final boolean b) {
        if (zzba.zzc().a(cs3.r5)) {
            if (!((zzg)this.c).zzQ()) {
                final Object v = xw4.v;
                synchronized (v) {
                    final int w = xw4.w;
                    final int intValue = (int)zzba.zzc().a(cs3.s5);
                    monitorexit(v);
                    if (w < intValue) {
                        final ax4 n = this.n;
                        final mi4 d = n.d;
                        d.l.zza();
                        final u75 r = new gl5(d.a, (Object)zzfio.c, (String)null, (yq1)z75.d, Collections.emptyList(), (yq1)d.i.a((Object)new Bundle())).r();
                        r.addListener((Runnable)new jg5(0, (Object)r, (Object)new tg((Object)n, b)), (Executor)k1.f);
                        synchronized (v) {
                            ++xw4.w;
                        }
                    }
                }
            }
        }
    }
    
    public final void x(final zze zze) {
        this.a(false);
    }
    
    public final void zzr() {
        this.a(true);
    }
}
