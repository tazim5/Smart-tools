public interface zn1 extends ao1, jd1
{
    Object get(final Object p0);
    
    Object getDelegate(final Object p0);
    
    yn1 getGetter();
}
