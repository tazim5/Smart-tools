import java.util.concurrent.atomic.AtomicBoolean;

public abstract class lp1
{
    public static final AtomicBoolean a;
    
    static {
        a = new AtomicBoolean(false);
    }
}
