import java.lang.ref.Reference;
import com.google.android.gms.ads.BaseAdView;
import android.os.BaseBundle;
import android.widget.TextView;
import android.content.res.Resources;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.impl.R$string;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.ads.nativead.NativeAdView;
import android.view.View;
import android.widget.LinearLayout;
import android.view.ViewGroup;
import java.util.concurrent.Executor;
import com.google.android.gms.ads.internal.client.zzdn;
import com.google.android.gms.ads.ResponseInfo;
import android.os.RemoteException;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.LoadAdError;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdRequest$Builder;
import android.os.Bundle;
import com.google.android.gms.ads.AdRequest;
import java.lang.ref.WeakReference;
import android.content.Context;
import java.util.HashMap;
import com.google.android.gms.ads.internal.client.zzdi;

public final class cu4 extends zzdi
{
    public final HashMap c;
    public final Context n;
    public final WeakReference v;
    public final st4 w;
    public final i94 x;
    public qt4 y;
    
    public cu4(final Context n, final WeakReference v, final st4 w, final i94 x) {
        this.c = new HashMap();
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
    }
    
    public static AdRequest h1() {
        final Bundle bundle = new Bundle();
        ((BaseBundle)bundle).putString("request_origin", "inspector_ooct");
        final AdRequest$Builder adRequest$Builder = new AdRequest$Builder();
        adRequest$Builder.addNetworkExtrasBundle((Class)AdMobAdapter.class, bundle);
        return adRequest$Builder.build();
    }
    
    public static String i1(final Object o) {
        ResponseInfo responseInfo;
        if (o instanceof LoadAdError) {
            responseInfo = ((LoadAdError)o).getResponseInfo();
        }
        else if (o instanceof AppOpenAd) {
            responseInfo = ((AppOpenAd)o).getResponseInfo();
        }
        else if (o instanceof InterstitialAd) {
            responseInfo = ((InterstitialAd)o).getResponseInfo();
        }
        else if (o instanceof RewardedAd) {
            responseInfo = ((RewardedAd)o).getResponseInfo();
        }
        else if (o instanceof RewardedInterstitialAd) {
            responseInfo = ((RewardedInterstitialAd)o).getResponseInfo();
        }
        else if (o instanceof AdView) {
            responseInfo = ((BaseAdView)o).getResponseInfo();
        }
        else {
            if (!(o instanceof NativeAd)) {
                return "";
            }
            responseInfo = ((NativeAd)o).getResponseInfo();
        }
        if (responseInfo == null) {
            return "";
        }
        final zzdn zzc = responseInfo.zzc();
        if (zzc == null) {
            return "";
        }
        try {
            return zzc.zzh();
        }
        catch (final RemoteException ex) {
            return "";
        }
    }
    
    public final void f1(final String s, final Object o, final String s2) {
        synchronized (this) {
            this.c.put((Object)s, o);
            this.j1(i1(o), s2);
        }
    }
    
    public final Context g1() {
        Context n;
        if ((n = (Context)((Reference)this.v).get()) == null) {
            n = this.n;
        }
        return n;
    }
    
    public final void j1(final String s, String s2) {
        monitorenter(this);
        try {
            try {
                final m94 a = this.y.a(s);
                final bu4 bu4 = new bu4(this, s2, 0);
                final i94 x = this.x;
                s2 = (String)new jg5(0, (Object)a, (Object)bu4);
                ((yq1)a).addListener((Runnable)s2, (Executor)x);
                monitorexit(this);
            }
            finally {
                monitorexit(this);
            }
        }
        catch (final NullPointerException ex) {}
    }
    
    public final void k1(final String s, String s2) {
        monitorenter(this);
        try {
            try {
                final m94 a = this.y.a(s);
                final bu4 bu4 = new bu4(this, s2, 1);
                final i94 x = this.x;
                s2 = (String)new jg5(0, (Object)a, (Object)bu4);
                ((yq1)a).addListener((Runnable)s2, (Executor)x);
                monitorexit(this);
            }
            finally {
                monitorexit(this);
            }
        }
        catch (final NullPointerException ex) {}
    }
    
    public final void zze(String s, final th1 th1, final th1 th2) {
        final Context context = (Context)n32.F(th1);
        final ViewGroup viewGroup = (ViewGroup)n32.F(th2);
        if (context != null) {
            if (viewGroup != null) {
                final HashMap c = this.c;
                final Object value = c.get((Object)s);
                if (value != null) {
                    c.remove((Object)s);
                }
                if (value instanceof AdView) {
                    final AdView adView = (AdView)value;
                    final LinearLayout linearLayout = new LinearLayout(context);
                    ((View)linearLayout).setTag((Object)"layout");
                    du4.b((View)linearLayout, -1, -1);
                    linearLayout.setGravity(17);
                    ((ViewGroup)linearLayout).addView((View)adView);
                    ((View)adView).setTag((Object)"ad_view");
                    viewGroup.addView((View)linearLayout);
                    return;
                }
                if (value instanceof NativeAd) {
                    final NativeAd nativeAd = (NativeAd)value;
                    final NativeAdView nativeAdView = new NativeAdView(context);
                    ((View)nativeAdView).setTag((Object)"ad_view_tag");
                    du4.b((View)nativeAdView, -1, -1);
                    viewGroup.addView((View)nativeAdView);
                    final LinearLayout linearLayout2 = new LinearLayout(context);
                    ((View)linearLayout2).setTag((Object)"layout_tag");
                    linearLayout2.setOrientation(1);
                    du4.b((View)linearLayout2, -1, -1);
                    ((View)linearLayout2).setBackgroundColor(-1);
                    ((ViewGroup)nativeAdView).addView((View)linearLayout2);
                    final Resources a = zzt.zzo().a();
                    if (a == null) {
                        s = "Headline";
                    }
                    else {
                        s = a.getString(R$string.native_headline);
                    }
                    ((ViewGroup)linearLayout2).addView((View)du4.a(context, s, 16973894, -9210245, 0.0f, "headline_header_tag"));
                    final TextView a2 = du4.a(context, ny3.b(nativeAd.getHeadline()), 16973892, -16777216, 12.0f, "headline_tag");
                    nativeAdView.setHeadlineView((View)a2);
                    ((ViewGroup)linearLayout2).addView((View)a2);
                    if (a == null) {
                        s = "Body";
                    }
                    else {
                        s = a.getString(R$string.native_body);
                    }
                    ((ViewGroup)linearLayout2).addView((View)du4.a(context, s, 16973894, -9210245, 0.0f, "body_header_tag"));
                    final TextView a3 = du4.a(context, ny3.b(nativeAd.getBody()), 16973892, -16777216, 12.0f, "body_tag");
                    nativeAdView.setBodyView((View)a3);
                    ((ViewGroup)linearLayout2).addView((View)a3);
                    if (a == null) {
                        s = "Media View";
                    }
                    else {
                        s = a.getString(R$string.native_media_view);
                    }
                    ((ViewGroup)linearLayout2).addView((View)du4.a(context, s, 16973894, -9210245, 0.0f, "media_view_header_tag"));
                    final MediaView mediaView = new MediaView(context);
                    ((View)mediaView).setTag((Object)"media_view_tag");
                    nativeAdView.setMediaView(mediaView);
                    ((ViewGroup)linearLayout2).addView((View)mediaView);
                    nativeAdView.setNativeAd(nativeAd);
                }
            }
        }
    }
}
