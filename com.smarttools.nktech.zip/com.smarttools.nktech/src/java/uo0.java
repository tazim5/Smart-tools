import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;

public final class uo0 implements pk2
{
    public final AtomicReference a;
    
    public uo0(final pk2 pk2) {
        this.a = new AtomicReference((Object)pk2);
    }
    
    public final Iterator iterator() {
        final pk2 pk2 = (pk2)this.a.getAndSet((Object)null);
        if (pk2 != null) {
            return pk2.iterator();
        }
        throw new IllegalStateException("This sequence can be consumed only once.");
    }
}
