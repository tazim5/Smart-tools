import com.google.android.gms.internal.ads.t3;
import java.util.Map;
import java.util.Collections;
import java.util.HashMap;
import java.security.GeneralSecurityException;
import com.google.android.gms.internal.ads.y4;

public abstract class cm5
{
    static {
        new yl5();
        final int a = y4.a;
        try {
            a();
        }
        catch (final GeneralSecurityException ex) {
            throw new ExceptionInInitializerError((Throwable)ex);
        }
    }
    
    public static void a() {
        th5.c((qh5)gm5.a);
        final uk5 b = uk5.b;
        b.c(gm5.b);
        th5.c((qh5)ai5.c);
        th5.b((lk5)new yl5());
        final oe4 a = km5.a;
        final vk5 b2 = vk5.b;
        b2.f(km5.c);
        b2.e(km5.d);
        b2.d(km5.e);
        b2.c(km5.f);
        b.c(yl5.d);
        b.c(yl5.e);
        final tk5 b3 = tk5.b;
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"HMAC_SHA256_128BITTAG", (Object)jm5.a);
        final y64 y64 = new y64();
        y64.b(32);
        y64.c(16);
        final am5 e = am5.e;
        y64.w = e;
        final zl5 d = zl5.d;
        y64.v = d;
        hashMap.put((Object)"HMAC_SHA256_128BITTAG_RAW", (Object)y64.g());
        final y64 y65 = new y64();
        y65.b(32);
        y65.c(32);
        final am5 b4 = am5.b;
        y65.w = b4;
        y65.v = d;
        hashMap.put((Object)"HMAC_SHA256_256BITTAG", (Object)y65.g());
        final y64 y66 = new y64();
        y66.b(32);
        y66.c(32);
        y66.w = e;
        y66.v = d;
        hashMap.put((Object)"HMAC_SHA256_256BITTAG_RAW", (Object)y66.g());
        final y64 y67 = new y64();
        y67.b(64);
        y67.c(16);
        y67.w = b4;
        final zl5 f = zl5.f;
        y67.v = f;
        hashMap.put((Object)"HMAC_SHA512_128BITTAG", (Object)y67.g());
        final y64 y68 = new y64();
        y68.b(64);
        y68.c(16);
        y68.w = e;
        y68.v = f;
        hashMap.put((Object)"HMAC_SHA512_128BITTAG_RAW", (Object)y68.g());
        final y64 y69 = new y64();
        y69.b(64);
        y69.c(32);
        y69.w = b4;
        y69.v = f;
        hashMap.put((Object)"HMAC_SHA512_256BITTAG", (Object)y69.g());
        final y64 y70 = new y64();
        y70.b(64);
        y70.c(32);
        y70.w = e;
        y70.v = f;
        hashMap.put((Object)"HMAC_SHA512_256BITTAG_RAW", (Object)y70.g());
        hashMap.put((Object)"HMAC_SHA512_512BITTAG", (Object)jm5.b);
        final y64 y71 = new y64();
        y71.b(64);
        y71.c(64);
        y71.w = e;
        y71.v = f;
        hashMap.put((Object)"HMAC_SHA512_512BITTAG_RAW", (Object)y71.g());
        b3.c(Collections.unmodifiableMap((Map)hashMap));
        qk5.b.a((pk5)ei5.e, (Class)bm5.class);
        if (dk5.a()) {
            return;
        }
        th5.b(new lk5((Class)t3.class, new fi5[] { new fi5((Class)lh5.class, 9) }));
        b2.f(tl5.a);
        b2.e(tl5.b);
        b2.d(tl5.c);
        b2.c(tl5.d);
        b.c(rl5.d);
        b.c(rl5.e);
        final HashMap hashMap2 = new HashMap();
        final sl5 c = jm5.c;
        hashMap2.put((Object)"AES_CMAC", (Object)c);
        hashMap2.put((Object)"AES256_CMAC", (Object)c);
        final ph5 ph5 = new ph5();
        ph5.l(32);
        ph5.m(16);
        ph5.c = vi5.Q;
        hashMap2.put((Object)"AES256_CMAC_RAW", (Object)ph5.r());
        b3.c(Collections.unmodifiableMap((Map)hashMap2));
    }
}
