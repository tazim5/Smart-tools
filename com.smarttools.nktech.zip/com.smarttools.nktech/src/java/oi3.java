import android.os.Bundle;
import android.os.IInterface;

public interface oi3 extends IInterface
{
    void zza(final Bundle p0);
}
