import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.runtime.Composer;

public final class qh0 implements nd1
{
    public static final qh0 c;
    
    static {
        c = (qh0)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            TextKt.Text--4IGK_g("Spirit Level", (Modifier)null, 0L, 0L, (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196614, 0, 131038);
        }
        return t43.a;
    }
}
