import com.google.android.gms.internal.ads.l2;

public interface xx4
{
    void a(final k65 p0, final l2 p1, final tx4 p2);
    
    Object b(final k65 p0, final l2 p1, final tx4 p2);
}
