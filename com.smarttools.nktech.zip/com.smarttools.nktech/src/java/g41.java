import android.os.Build$VERSION;
import android.os.Build;

public class g41 implements gd2
{
    public static boolean a() {
        return "SAMSUNG".equalsIgnoreCase(Build.BRAND) && "J7XELTE".equalsIgnoreCase(Build.DEVICE) && Build$VERSION.SDK_INT >= 27;
    }
    
    public static boolean b() {
        return "SAMSUNG".equalsIgnoreCase(Build.BRAND) && "ON7XELTE".equalsIgnoreCase(Build.DEVICE) && Build$VERSION.SDK_INT >= 27;
    }
}
