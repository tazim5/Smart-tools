public final class jp4 implements h32
{
    public static final jp4 a;
    
    static {
        a = (jp4)new Object();
        f83.q(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, new kg3(1)), 2)), 3)));
    }
}
