import java.util.Iterator;
import android.util.Range;
import android.hardware.camera2.CameraCaptureSession$CaptureCallback;
import android.util.ArrayMap;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashSet;

public class jk
{
    public static final jk a;
    
    static {
        a = (jk)new Object();
    }
    
    public void a(final si1 si1, final on on) {
        final pn pn = (pn)((yd2)si1).a(z53.E, null);
        i52 i52 = i52.v;
        final id j = pn.i;
        final HashSet set = new HashSet();
        final dz1 d = dz1.d();
        final Range e = me.e;
        final ArrayList list = new ArrayList();
        final jz1 a = jz1.a();
        final ArrayList list2 = new ArrayList((Collection)set);
        final i52 b = i52.b(d);
        final ArrayList list3 = new ArrayList((Collection)list);
        final nv2 b2 = nv2.b;
        final ArrayMap arrayMap = new ArrayMap();
        final ArrayMap a2 = a.a;
        for (final String s : a2.keySet()) {
            arrayMap.put((Object)s, a2.get((Object)s));
        }
        final nv2 nv2 = new nv2(arrayMap);
        int c = -1;
        new pn(list2, b, -1, e, list3, false, nv2, null);
        if (pn != null) {
            on.a((Collection)pn.e);
            i52 = pn.b;
            c = pn.c;
        }
        on.b = dz1.k(i52);
        new(cl.class)();
        on.c = (int)((no0)si1).a(cl.w, c);
        on.b(new nn((CameraCaptureSession$CaptureCallback)((no0)si1).a(cl.P, new CameraCaptureSession$CaptureCallback())));
        on.c((no0)new pe1((Object)i52.b(bl.c((no0)si1).n), 5));
    }
}
