import org.json.JSONObject;

public final class on4 implements ls5
{
    public final int a;
    public final il3 b;
    
    public final Object zzb() {
        switch (this.a) {
            default: {
                final oq4 oq4 = (oq4)this.b.v;
                ep5.c((Object)oq4);
                return oq4;
            }
            case 0: {
                final JSONObject jsonObject = (JSONObject)this.b.n;
                ep5.c((Object)jsonObject);
                return jsonObject;
            }
        }
    }
}
