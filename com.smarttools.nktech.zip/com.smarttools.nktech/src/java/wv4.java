import java.nio.Buffer;
import java.nio.ByteOrder;
import com.google.android.gms.internal.ads.zzdx;
import java.nio.ShortBuffer;
import java.nio.ByteBuffer;

public final class wv4 implements su4
{
    public int b;
    public float c;
    public float d;
    public kt4 e;
    public kt4 f;
    public kt4 g;
    public kt4 h;
    public boolean i;
    public sv4 j;
    public ByteBuffer k;
    public ShortBuffer l;
    public ByteBuffer m;
    public long n;
    public long o;
    public boolean p;
    
    public final kt4 a(final kt4 e) {
        if (e.c == 2) {
            int n;
            if ((n = this.b) == -1) {
                n = e.a;
            }
            this.e = e;
            final kt4 f = new kt4(n, e.b, 2);
            this.f = f;
            this.i = true;
            return f;
        }
        throw new zzdx(e);
    }
    
    public final void b(final ByteBuffer byteBuffer) {
        if (!((Buffer)byteBuffer).hasRemaining()) {
            return;
        }
        final sv4 j = this.j;
        j.getClass();
        final ShortBuffer shortBuffer = byteBuffer.asShortBuffer();
        final int remaining = ((Buffer)byteBuffer).remaining();
        this.n += remaining;
        final int remaining2 = ((Buffer)shortBuffer).remaining();
        final int b = j.b;
        final int n = remaining2 / b;
        final int n2 = n * b;
        shortBuffer.get(j.j = j.f(j.j, j.k, n), j.k * b, (n2 + n2) / 2);
        j.k += n;
        j.e();
        byteBuffer.position(((Buffer)byteBuffer).position() + remaining);
    }
    
    public final ByteBuffer zzb() {
        final sv4 j = this.j;
        if (j != null) {
            final int m = j.m;
            final int b = j.b;
            final int n = m * b;
            final int n2 = n + n;
            if (n2 > 0) {
                if (((Buffer)this.k).capacity() < n2) {
                    final ByteBuffer order = ByteBuffer.allocateDirect(n2).order(ByteOrder.nativeOrder());
                    this.k = order;
                    this.l = order.asShortBuffer();
                }
                else {
                    this.k.clear();
                    this.l.clear();
                }
                final ShortBuffer l = this.l;
                final int min = Math.min(((Buffer)l).remaining() / b, j.m);
                final int n3 = min * b;
                l.put(j.l, 0, n3);
                final int i = j.m - min;
                j.m = i;
                final short[] k = j.l;
                System.arraycopy((Object)k, n3, (Object)k, 0, i * b);
                this.o += n2;
                this.k.limit(n2);
                this.m = this.k;
            }
        }
        final ByteBuffer m2 = this.m;
        this.m = su4.a;
        return m2;
    }
    
    public final void zzc() {
        if (this.zzg()) {
            final kt4 e = this.e;
            this.g = e;
            final kt4 f = this.f;
            this.h = f;
            if (this.i) {
                this.j = new sv4(this.c, e.a, this.d, e.b, f.a);
            }
            else {
                final sv4 j = this.j;
                if (j != null) {
                    j.k = 0;
                    j.m = 0;
                    j.o = 0;
                    j.p = 0;
                    j.q = 0;
                    j.r = 0;
                    j.s = 0;
                    j.t = 0;
                    j.u = 0;
                    j.v = 0;
                }
            }
        }
        this.m = su4.a;
        this.n = 0L;
        this.o = 0L;
        this.p = false;
    }
    
    public final void zzd() {
        final sv4 j = this.j;
        if (j != null) {
            final int k = j.k;
            final float n = (float)k;
            final int m = j.m;
            final float n2 = (float)j.o;
            final float c = j.c;
            final float d = j.d;
            final int i = m + (int)((n / (c / d) + n2) / (j.e * d) + 0.5f);
            final int h = j.h;
            final int n3 = h + h;
            j.j = j.f(j.j, k, n3 + k);
            int n4 = 0;
            while (true) {
                final int b = j.b;
                if (n4 >= n3 * b) {
                    break;
                }
                j.j[b * k + n4] = 0;
                ++n4;
            }
            j.k += n3;
            j.e();
            if (j.m > i) {
                j.m = i;
            }
            j.k = 0;
            j.r = 0;
            j.o = 0;
        }
        this.p = true;
    }
    
    public final void zzf() {
        this.c = 1.0f;
        this.d = 1.0f;
        final kt4 e = kt4.e;
        this.e = e;
        this.f = e;
        this.g = e;
        this.h = e;
        final ByteBuffer a = su4.a;
        this.k = a;
        this.l = a.asShortBuffer();
        this.m = a;
        this.b = -1;
        this.i = false;
        this.j = null;
        this.n = 0L;
        this.o = 0L;
        this.p = false;
    }
    
    public final boolean zzg() {
        final int a = this.f.a;
        boolean b = false;
        if (a != -1) {
            if (Math.abs(this.c - 1.0f) < 1.0E-4f && Math.abs(this.d - 1.0f) < 1.0E-4f) {
                if (this.f.a != this.e.a) {
                    return true;
                }
                b = b;
            }
            else {
                b = true;
            }
        }
        return b;
    }
    
    public final boolean zzh() {
        final boolean p = this.p;
        boolean b = false;
        if (p) {
            final sv4 j = this.j;
            if (j != null) {
                final int n = j.m * j.b;
                if (n + n == 0) {
                    return true;
                }
                b = b;
            }
            else {
                b = true;
            }
        }
        return b;
    }
}
