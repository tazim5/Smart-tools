import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import com.smarttools.nktech.features.home.presentation.d;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;
import com.smarttools.nktech.core.data.datastore.r;
import android.content.Context;
import java.util.List;
import com.smarttools.nktech.b;
import com.smarttools.nktech.core.data.model.Tool;

public final class sx1 implements od1
{
    public final Tool c;
    public final long n;
    public final b v;
    public final List w;
    public final dq0 x;
    public final Context y;
    public final r z;
    
    public sx1(final Tool c, final long n, final b v, final List w, final dq0 x, final Context y, final r z) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    public final Object invoke(Object o, Object rememberedValue, final Object o2) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)rememberedValue;
        if ((((Number)o2).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Tool c = this.c;
            final String name = c.getName();
            final String description = c.getDescription();
            final ImageVector icon = c.getIcon();
            composer.startReplaceGroup(-1633937504);
            final b v = this.v;
            final boolean changed = composer.changed((Object)v);
            final boolean changed2 = composer.changed((Object)c);
            rememberedValue = composer.rememberedValue();
            if ((changed | changed2) || (o = rememberedValue) == Composer.Companion.getEmpty()) {
                o = new d5(17, (Object)v, (Object)c);
                composer.updateRememberedValue(o);
            }
            final id1 id1 = (id1)o;
            composer.endReplaceGroup();
            by1.b(name, description, icon, this.n, id1, this.w.contains((Object)c.getId()), (id1)new d(this.w, this.c, this.x, this.y, this.z), PaddingKt.padding-VpY3zN4(SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)16), Dp.constructor-impl((float)4)), composer, 12582912, 0);
        }
        return t43.a;
    }
}
