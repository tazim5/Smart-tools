import androidx.compose.runtime.State;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ButtonKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import android.content.Context;
import androidx.compose.runtime.MutableState;

public final class ij1 implements od1
{
    public final MutableState c;
    public final MutableState n;
    public final Context v;
    public final MutableState w;
    public final MutableState x;
    
    public ij1(final MutableState c, final MutableState n, final Context v, final MutableState w, final MutableState x) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
    }
    
    public final Object invoke(Object o, Object rememberedValue, final Object o2) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)rememberedValue;
        if ((((Number)o2).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)16));
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$Vertical top = instance.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final FontWeight bold = FontWeight.Companion.getBold();
            final MaterialTheme instance3 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            TextKt.Text--4IGK_g("\u2713 Saved!", (Modifier)null, instance3.getColorScheme(composer, $stable).getPrimary-0d7_KjU(), 0L, (FontStyle)null, bold, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196614, 0, 131034);
            TextKt.Text--4IGK_g((String)((State)this.c).getValue(), (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getBodySmall(), composer, 0, 0, 65534);
            ap.l((float)12, companion, composer, 6);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl((float)8)), companion2.getTop(), composer, 6);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance4 = RowScopeInstance.INSTANCE;
            final MutableState w = this.w;
            final MutableState n = this.n;
            final Context v = this.v;
            ButtonKt.OutlinedButton((id1)new fr(n, v, w), (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)l60.j, composer, 805306368, 510);
            ButtonKt.OutlinedButton((id1)new of(n, v, 8), (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)l60.k, composer, 805306368, 510);
            composer.startReplaceGroup(-917477824);
            rememberedValue = composer.rememberedValue();
            if ((o = rememberedValue) == Composer.Companion.getEmpty()) {
                o = new ff1(this.x, 12);
                composer.updateRememberedValue(o);
            }
            final id1 id1 = (id1)o;
            composer.endReplaceGroup();
            ButtonKt.OutlinedButton(id1, (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)l60.l, composer, 805306374, 510);
            composer.endNode();
            composer.endNode();
        }
        return t43.a;
    }
}
