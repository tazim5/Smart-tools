public abstract class on3
{
    public static final int[] n;
    public final int c;
    
    static {
        n = new int[] { 4, 6, 6, 8, 8, 8, 8, 8, 8, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12 };
    }
    
    public static void b(final qg qg, int n, final int n2) {
        for (int i = 0; i < n2; i += 2) {
            int n4;
            final int n3 = n4 = n - i;
            while (true) {
                final int n5 = n + i;
                if (n4 > n5) {
                    break;
                }
                qg.f(n4, n3);
                qg.f(n4, n5);
                qg.f(n3, n4);
                qg.f(n5, n4);
                ++n4;
            }
        }
        final int n6 = n - n2;
        qg.f(n6, n6);
        final int n7 = n6 + 1;
        qg.f(n7, n6);
        qg.f(n6, n7);
        n += n2;
        qg.f(n, n6);
        qg.f(n, n7);
        qg.f(n, n - 1);
    }
    
    public static pg c(int i, final int n, final pg pg) {
        final int n2 = pg.n / n;
        je1 je1;
        if (n != 4) {
            if (n != 6) {
                if (n != 8) {
                    if (n != 10) {
                        if (n != 12) {
                            throw new IllegalArgumentException(e8.c(n, "Unsupported word size "));
                        }
                        je1 = je1.h;
                    }
                    else {
                        je1 = je1.i;
                    }
                }
                else {
                    je1 = je1.n;
                }
            }
            else {
                je1 = je1.j;
            }
        }
        else {
            je1 = je1.k;
        }
        final qf1 qf1 = new qf1(je1);
        final int n3 = i / n;
        final int[] array = new int[n3];
        final int n4 = pg.n / n;
        final int n5 = 0;
        for (int j = 0; j < n4; ++j) {
            int k = 0;
            int n6 = 0;
            while (k < n) {
                int n7;
                if (pg.d(j * n + k)) {
                    n7 = 1 << n - k - 1;
                }
                else {
                    n7 = 0;
                }
                n6 |= n7;
                ++k;
            }
            array[j] = n6;
        }
        qf1.p(n3 - n2, array);
        final pg pg2 = new pg();
        pg2.b(0, i % n);
        for (i = n5; i < n3; ++i) {
            pg2.b(array[i], n);
        }
        return pg2;
    }
    
    public static pg d(final pg pg, final int n) {
        final pg pg2 = new pg();
        final int n2 = pg.n;
        final int n3 = (1 << n) - 2;
        for (int i = 0; i < n2; i += n) {
            int j = 0;
            int n4 = 0;
            while (j < n) {
                final int n5 = i + j;
                int n6 = 0;
                Label_0078: {
                    if (n5 < n2) {
                        n6 = n4;
                        if (!pg.d(n5)) {
                            break Label_0078;
                        }
                    }
                    n6 = (n4 | 1 << n - 1 - j);
                }
                ++j;
                n4 = n6;
            }
            final int n7 = n4 & n3;
            if (n7 == n3) {
                pg2.b(n7, n);
            }
            else {
                if (n7 != 0) {
                    pg2.b(n4, n);
                    continue;
                }
                pg2.b(n4 | 0x1, n);
            }
            --i;
        }
        return pg2;
    }
    
    @Override
    public String toString() {
        switch (this.c) {
            default: {
                return super.toString();
            }
            case 2: {
                return ((i45)this).v.toString();
            }
        }
    }
}
