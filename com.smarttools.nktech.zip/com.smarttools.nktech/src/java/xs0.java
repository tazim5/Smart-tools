import androidx.compose.runtime.internal.ComposableLambda;
import java.util.Iterator;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.material3.MenuItemColors;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.AndroidMenu_androidKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.runtime.MutableState;
import java.util.List;

public final class xs0 implements od1
{
    public final int c;
    public final List n;
    public final MutableState v;
    public final MutableState w;
    public final MutableState x;
    
    public final Object invoke(Object o, Object o2, final Object o3) {
        switch (this.c) {
            default: {
                final ColumnScope columnScope = (ColumnScope)o;
                final Composer composer = (Composer)o2;
                if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                }
                else {
                    composer.startReplaceGroup(-1800135306);
                    final List n = this.n;
                    for (final ss0 ss0 : (Iterable)n) {
                        final ComposableLambda rememberComposableLambda = ComposableLambdaKt.rememberComposableLambda(-1771017656, true, (Object)new ws0(ss0, 1), composer, 54);
                        composer.startReplaceGroup(-1901526237);
                        final boolean changed = composer.changed((Object)ss0);
                        o2 = composer.rememberedValue();
                        if (changed || (o = o2) == Composer.Companion.getEmpty()) {
                            o = new vs0(ss0, this.v, this.w, this.x, 1);
                            composer.updateRememberedValue(o);
                        }
                        final id1 id1 = (id1)o;
                        composer.endReplaceGroup();
                        AndroidMenu_androidKt.DropdownMenuItem((nd1)rememberComposableLambda, id1, (Modifier)null, (nd1)null, (nd1)null, false, (MenuItemColors)null, (PaddingValues)null, (MutableInteractionSource)null, composer, 6, 508);
                    }
                    composer.endReplaceGroup();
                    if (n.isEmpty()) {
                        AndroidMenu_androidKt.DropdownMenuItem((nd1)c10.h, (id1)new rr0(15), (Modifier)null, (nd1)null, (nd1)null, false, (MenuItemColors)null, (PaddingValues)null, (MutableInteractionSource)null, composer, 54, 508);
                    }
                }
                return t43.a;
            }
            case 0: {
                final ColumnScope columnScope2 = (ColumnScope)o;
                final Composer composer2 = (Composer)o2;
                if ((((Number)o3).intValue() & 0x51) == 0x10 && composer2.getSkipping()) {
                    composer2.skipToGroupEnd();
                }
                else {
                    composer2.startReplaceGroup(-1800259236);
                    final List n2 = this.n;
                    for (final ss0 ss2 : (Iterable)n2) {
                        final ComposableLambda rememberComposableLambda2 = ComposableLambdaKt.rememberComposableLambda(-1537833441, true, (Object)new ws0(ss2, 0), composer2, 54);
                        composer2.startReplaceGroup(-1901650167);
                        final boolean changed2 = composer2.changed((Object)ss2);
                        o2 = composer2.rememberedValue();
                        if (changed2 || (o = o2) == Composer.Companion.getEmpty()) {
                            o = new vs0(ss2, this.v, this.w, this.x, 0);
                            composer2.updateRememberedValue(o);
                        }
                        final id1 id2 = (id1)o;
                        composer2.endReplaceGroup();
                        AndroidMenu_androidKt.DropdownMenuItem((nd1)rememberComposableLambda2, id2, (Modifier)null, (nd1)null, (nd1)null, false, (MenuItemColors)null, (PaddingValues)null, (MutableInteractionSource)null, composer2, 6, 508);
                    }
                    composer2.endReplaceGroup();
                    if (n2.isEmpty()) {
                        AndroidMenu_androidKt.DropdownMenuItem((nd1)c10.e, (id1)new rr0(15), (Modifier)null, (nd1)null, (nd1)null, false, (MenuItemColors)null, (PaddingValues)null, (MutableInteractionSource)null, composer2, 54, 508);
                    }
                }
                return t43.a;
            }
        }
    }
}
