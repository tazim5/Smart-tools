import android.view.WindowInsetsAnimation$Bounds;
import android.view.View;
import java.util.Collections;
import android.view.WindowInsets;
import android.os.Build$VERSION;
import android.view.animation.Interpolator;
import android.view.WindowInsetsAnimation;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import android.view.WindowInsetsAnimation$Callback;

public final class fa3 extends WindowInsetsAnimation$Callback
{
    public final aa3 a;
    public List b;
    public ArrayList c;
    public final HashMap d;
    
    public fa3(final aa3 a) {
        super(a.getDispatchMode());
        this.d = new HashMap();
        this.a = a;
    }
    
    public final ia3 a(final WindowInsetsAnimation windowInsetsAnimation) {
        ia3 ia3;
        if ((ia3 = (ia3)this.d.get((Object)windowInsetsAnimation)) == null) {
            ia3 = new ia3(0, (Interpolator)null, 0L);
            if (Build$VERSION.SDK_INT >= 30) {
                ia3.a = new ga3(windowInsetsAnimation);
            }
            this.d.put((Object)windowInsetsAnimation, (Object)ia3);
        }
        return ia3;
    }
    
    public final void onEnd(final WindowInsetsAnimation windowInsetsAnimation) {
        this.a.onEnd(this.a(windowInsetsAnimation));
        this.d.remove((Object)windowInsetsAnimation);
    }
    
    public final void onPrepare(final WindowInsetsAnimation windowInsetsAnimation) {
        this.a.onPrepare(this.a(windowInsetsAnimation));
    }
    
    public final WindowInsets onProgress(final WindowInsets windowInsets, final List list) {
        final ArrayList c = this.c;
        if (c == null) {
            final ArrayList c2 = new ArrayList(list.size());
            this.c = c2;
            this.b = Collections.unmodifiableList((List)c2);
        }
        else {
            c.clear();
        }
        for (int i = list.size() - 1; i >= 0; --i) {
            final WindowInsetsAnimation l = l1.l(list.get(i));
            final ia3 a = this.a(l);
            a.a.c(l1.y(l));
            this.c.add((Object)a);
        }
        return this.a.onProgress(wa3.c((View)null, windowInsets), this.b).b();
    }
    
    public final WindowInsetsAnimation$Bounds onStart(final WindowInsetsAnimation windowInsetsAnimation, final WindowInsetsAnimation$Bounds windowInsetsAnimation$Bounds) {
        final z93 onStart = this.a.onStart(this.a(windowInsetsAnimation), new z93(windowInsetsAnimation$Bounds));
        onStart.getClass();
        l1.p();
        return l1.j(onStart.a.d(), onStart.b.d());
    }
}
