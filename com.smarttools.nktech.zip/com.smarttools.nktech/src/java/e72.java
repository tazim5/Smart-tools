import androidx.compose.runtime.State;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.material3.IconKt;
import androidx.compose.material.icons.filled.PictureAsPdfKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.runtime.MutableState;

public final class e72 implements od1
{
    public final MutableState c;
    
    public e72(final MutableState c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final RowScope rowScope = (RowScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) != 0x10 || !composer.getSkipping()) {
            if (((State)this.c).getValue()) {
                composer.startReplaceGroup(-544340303);
                final Modifier$Companion companion = Modifier.Companion;
                ProgressIndicatorKt.CircularProgressIndicator-LxG7B9w(SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)24)), MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnPrimary-0d7_KjU(), Dp.constructor-impl((float)2), 0L, 0, composer, 390, 24);
                gs1.o((float)12, companion, composer, 6);
                TextKt.Text--4IGK_g("Creating PDF...", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 6, 0, 131070);
                composer.endReplaceGroup();
            }
            else {
                composer.startReplaceGroup(-544108640);
                IconKt.Icon-ww6aTOc(PictureAsPdfKt.getPictureAsPdf(Icons.INSTANCE.getDefault()), (String)null, (Modifier)null, 0L, composer, 48, 12);
                gs1.o((float)12, Modifier.Companion, composer, 6);
                TextKt.Text--4IGK_g("Create PDF", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 6, 0, 131070);
                composer.endReplaceGroup();
            }
        }
        else {
            composer.skipToGroupEnd();
        }
        return t43.a;
    }
}
