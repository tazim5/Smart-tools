import java.util.Collections;
import java.util.WeakHashMap;
import java.util.Map;

public abstract class m63
{
    public static final Map a;
    
    static {
        a = Collections.synchronizedMap((Map)new WeakHashMap());
    }
}
