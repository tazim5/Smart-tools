import kotlin.Result;
import kotlin.Result$Failure;
import kotlin.coroutines.jvm.internal.BaseContinuationImpl;

public abstract class cr2
{
    public static final int a = 0;
    
    static {
        final Exception ex = new Exception();
        final String simpleName = pc3.class.getSimpleName();
        final StackTraceElement stackTraceElement = ((Throwable)ex).getStackTrace()[0];
        new StackTraceElement("_COROUTINE.".concat(simpleName), "_", stackTraceElement.getFileName(), stackTraceElement.getLineNumber());
        Object o = null;
        try {
            BaseContinuationImpl.class.getCanonicalName();
        }
        finally {
            final Throwable t;
            o = new Result$Failure(t);
        }
        if (Result.a(o) != null) {
            o = "kotlin.coroutines.jvm.internal.BaseContinuationImpl";
        }
        final String s = (String)o;
        Object o2 = null;
        try {
            cr2.class.getCanonicalName();
        }
        finally {
            final Throwable t2;
            o2 = new Result$Failure(t2);
        }
        if (Result.a(o2) != null) {
            o2 = "kotlinx.coroutines.internal.StackTraceRecoveryKt";
        }
        final String s2 = (String)o2;
    }
}
