import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.internal.ComposableLambda;

public abstract class ei0
{
    public static final ComposableLambda a;
    public static final ComposableLambda b;
    public static final ComposableLambda c;
    public static final ComposableLambda d;
    
    static {
        a = ComposableLambdaKt.composableLambdaInstance(-1123557917, false, (Object)af0.i0);
        b = ComposableLambdaKt.composableLambdaInstance(72617124, false, (Object)bi0.c);
        c = ComposableLambdaKt.composableLambdaInstance(-1736861284, false, (Object)ci0.c);
        d = ComposableLambdaKt.composableLambdaInstance(234724293, false, (Object)di0.c);
    }
}
