import androidx.compose.runtime.IntState;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.CardElevation;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import java.util.List;
import androidx.compose.runtime.internal.ComposableLambda;
import androidx.compose.runtime.Composer$Companion;
import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.material3.ScaffoldKt;
import androidx.compose.runtime.State;
import java.text.NumberFormat;
import java.util.Locale;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.SnapshotMutationPolicy;
import androidx.compose.runtime.SnapshotStateKt;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.SnapshotIntStateKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.ui.Alignment$Vertical;
import androidx.compose.ui.text.input.KeyboardType$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.layout.Arrangement$HorizontalOrVertical;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.SegmentedButtonKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.input.PlatformImeOptions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.text.input.KeyboardType;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.runtime.Composer;

public abstract class o81
{
    public static final void a(final String s, final String s2, final String s3, final int n, final int n2, final jd1 jd1, final jd1 jd2, final jd1 jd3, final jd1 jd4, final jd1 jd5, final Composer composer, final int n3) {
        final Composer startRestartGroup = composer.startRestartGroup(1937476825);
        int n5;
        if ((n3 & 0xE) == 0x0) {
            int n4;
            if (startRestartGroup.changed((Object)s)) {
                n4 = 4;
            }
            else {
                n4 = 2;
            }
            n5 = (n4 | n3);
        }
        else {
            n5 = n3;
        }
        int n6 = n5;
        if ((n3 & 0x70) == 0x0) {
            int n7;
            if (startRestartGroup.changed((Object)s2)) {
                n7 = 32;
            }
            else {
                n7 = 16;
            }
            n6 = (n5 | n7);
        }
        int n8 = n6;
        if ((n3 & 0x380) == 0x0) {
            int n9;
            if (startRestartGroup.changed((Object)s3)) {
                n9 = 256;
            }
            else {
                n9 = 128;
            }
            n8 = (n6 | n9);
        }
        int n10 = n8;
        if ((n3 & 0x1C00) == 0x0) {
            int n11;
            if (startRestartGroup.changed(n)) {
                n11 = 2048;
            }
            else {
                n11 = 1024;
            }
            n10 = (n8 | n11);
        }
        int n12 = n10;
        if ((0xE000 & n3) == 0x0) {
            int n13;
            if (startRestartGroup.changed(n2)) {
                n13 = 16384;
            }
            else {
                n13 = 8192;
            }
            n12 = (n10 | n13);
        }
        int n15;
        if ((0x70000 & n3) == 0x0) {
            int n14;
            if (startRestartGroup.changedInstance((Object)jd1)) {
                n14 = 131072;
            }
            else {
                n14 = 65536;
            }
            n15 = (n12 | n14);
        }
        else {
            n15 = n12;
        }
        if ((0x380000 & n3) == 0x0) {
            int n16;
            if (startRestartGroup.changedInstance((Object)jd2)) {
                n16 = 1048576;
            }
            else {
                n16 = 524288;
            }
            n15 |= n16;
        }
        int n17 = n15;
        if ((n3 & 0x1C00000) == 0x0) {
            int n18;
            if (startRestartGroup.changedInstance((Object)jd3)) {
                n18 = 8388608;
            }
            else {
                n18 = 4194304;
            }
            n17 = (n15 | n18);
        }
        int n19 = n17;
        if ((n3 & 0xE000000) == 0x0) {
            int n20;
            if (startRestartGroup.changedInstance((Object)jd4)) {
                n20 = 67108864;
            }
            else {
                n20 = 33554432;
            }
            n19 = (n17 | n20);
        }
        int n21 = n19;
        if ((n3 & 0x70000000) == 0x0) {
            int n22;
            if (startRestartGroup.changedInstance((Object)jd5)) {
                n22 = 536870912;
            }
            else {
                n22 = 268435456;
            }
            n21 = (n19 | n22);
        }
        if ((n21 & 0x5B6DB6DB) == 0x12492492 && startRestartGroup.getSkipping()) {
            startRestartGroup.skipToGroupEnd();
        }
        else {
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$HorizontalOrVertical spacedBy-0680j_4 = instance.spacedBy-0680j_4(Dp.constructor-impl((float)12));
            final Modifier$Companion companion = Modifier.Companion;
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy((Arrangement$Vertical)spacedBy-0680j_4, companion2.getStart(), startRestartGroup, 6);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
            final CompositionLocalMap currentCompositionLocalMap = startRestartGroup.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(startRestartGroup, (Modifier)companion);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (startRestartGroup.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            startRestartGroup.startReusableNode();
            if (startRestartGroup.getInserting()) {
                startRestartGroup.createNode(constructor);
            }
            else {
                startRestartGroup.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(startRestartGroup);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final KeyboardType$Companion companion4 = KeyboardType.Companion;
            OutlinedTextFieldKt.OutlinedTextField(s, jd1, SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), false, false, (TextStyle)null, (nd1)u30.f, (nd1)u30.g, (nd1)null, (nd1)null, (nd1)u30.h, (nd1)null, (nd1)null, false, (VisualTransformation)null, new KeyboardOptions(0, (Boolean)null, companion4.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null), (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, startRestartGroup, (n21 & 0xE) | 0xD80180 | (n21 >> 12 & 0x70), 12779526, 0, 8223544);
            OutlinedTextFieldKt.OutlinedTextField(s2, jd2, SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), false, false, (TextStyle)null, (nd1)u30.i, (nd1)u30.j, (nd1)null, (nd1)null, (nd1)null, (nd1)u30.k, (nd1)null, false, (VisualTransformation)null, new KeyboardOptions(0, (Boolean)null, companion4.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null), (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, startRestartGroup, (n21 >> 3 & 0xE) | 0xD80180 | (n21 >> 15 & 0x70), 12779568, 0, 8222520);
            final Arrangement$HorizontalOrVertical spacedBy-0680j_5 = instance.spacedBy-0680j_4(Dp.constructor-impl((float)8));
            final Alignment$Vertical centerVertically = companion2.getCenterVertically();
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)spacedBy-0680j_5, centerVertically, startRestartGroup, 54);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = startRestartGroup.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(startRestartGroup, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (startRestartGroup.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            startRestartGroup.startReusableNode();
            if (startRestartGroup.getInserting()) {
                startRestartGroup.createNode(constructor2);
            }
            else {
                startRestartGroup.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(startRestartGroup);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            OutlinedTextFieldKt.OutlinedTextField(s3, jd3, RowScope.weight$default((RowScope)RowScopeInstance.INSTANCE, (Modifier)companion, 1.0f, false, 2, (Object)null), false, false, (TextStyle)null, (nd1)u30.l, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, false, (VisualTransformation)null, new KeyboardOptions(0, (Boolean)null, companion4.getNumber-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null), (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, startRestartGroup, (n21 >> 6 & 0xE) | 0x180000 | (n21 >> 18 & 0x70), 12779520, 0, 8224696);
            SegmentedButtonKt.SingleChoiceSegmentedButtonRow-uFdPcIQ((Modifier)null, 0.0f, (od1)ComposableLambdaKt.rememberComposableLambda(-1495349878, true, (Object)new i81(n, 0, jd4), startRestartGroup, 54), startRestartGroup, 384, 3);
            startRestartGroup.endNode();
            TextKt.Text--4IGK_g("Compounding Frequency", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, MaterialTheme.INSTANCE.getTypography(startRestartGroup, MaterialTheme.$stable).getLabelLarge(), startRestartGroup, 6, 0, 65534);
            SegmentedButtonKt.SingleChoiceSegmentedButtonRow-uFdPcIQ(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), 0.0f, (od1)ComposableLambdaKt.rememberComposableLambda(890518958, true, (Object)new i81(n2, 1, jd5), startRestartGroup, 54), startRestartGroup, 390, 2);
            startRestartGroup.endNode();
        }
        final ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope((nd1)new g81(s, s2, s3, n, n2, jd1, jd2, jd3, jd4, jd5, n3));
        }
    }
    
    public static final void b(final so2 so2, Modifier modifier, final Composer composer, final int n) {
        final Composer startRestartGroup = composer.startRestartGroup(1467882923);
        int n3;
        if ((n & 0xE) == 0x0) {
            int n2;
            if (startRestartGroup.changedInstance((Object)so2)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            n3 = (n2 | n);
        }
        else {
            n3 = n;
        }
        final int n4 = n3 | 0x30;
        if ((n4 & 0x5B) == 0x12 && startRestartGroup.getSkipping()) {
            startRestartGroup.skipToGroupEnd();
        }
        else {
            final Object companion = Modifier.Companion;
            startRestartGroup.startReplaceGroup(-1640718389);
            final Object rememberedValue = startRestartGroup.rememberedValue();
            final Composer$Companion companion2 = Composer.Companion;
            MutableIntState mutableIntState;
            if ((mutableIntState = (MutableIntState)rememberedValue) == companion2.getEmpty()) {
                mutableIntState = SnapshotIntStateKt.mutableIntStateOf(0);
                startRestartGroup.updateRememberedValue((Object)mutableIntState);
            }
            final MutableIntState mutableIntState2 = mutableIntState;
            Object o;
            if ((o = fe2.c(startRestartGroup, -1640715287)) == companion2.getEmpty()) {
                o = SnapshotStateKt.mutableStateOf$default((Object)"", (SnapshotMutationPolicy)null, 2, (Object)null);
                startRestartGroup.updateRememberedValue(o);
            }
            final MutableState mutableState = (MutableState)o;
            Object o2;
            if ((o2 = fe2.c(startRestartGroup, -1640713687)) == companion2.getEmpty()) {
                o2 = SnapshotStateKt.mutableStateOf$default((Object)"", (SnapshotMutationPolicy)null, 2, (Object)null);
                startRestartGroup.updateRememberedValue(o2);
            }
            final MutableState mutableState2 = (MutableState)o2;
            Object o3;
            if ((o3 = fe2.c(startRestartGroup, -1640712023)) == companion2.getEmpty()) {
                o3 = SnapshotStateKt.mutableStateOf$default((Object)"", (SnapshotMutationPolicy)null, 2, (Object)null);
                startRestartGroup.updateRememberedValue(o3);
            }
            final MutableState mutableState3 = (MutableState)o3;
            Object o4;
            if ((o4 = fe2.c(startRestartGroup, -1640710229)) == companion2.getEmpty()) {
                o4 = SnapshotIntStateKt.mutableIntStateOf(0);
                startRestartGroup.updateRememberedValue(o4);
            }
            final MutableIntState mutableIntState3 = (MutableIntState)o4;
            Object o5;
            if ((o5 = fe2.c(startRestartGroup, -1640707541)) == companion2.getEmpty()) {
                o5 = SnapshotIntStateKt.mutableIntStateOf(0);
                startRestartGroup.updateRememberedValue(o5);
            }
            final MutableIntState mutableIntState4 = (MutableIntState)o5;
            Object o6;
            if ((o6 = fe2.c(startRestartGroup, -1640703927)) == companion2.getEmpty()) {
                o6 = SnapshotStateKt.mutableStateOf$default((Object)"", (SnapshotMutationPolicy)null, 2, (Object)null);
                startRestartGroup.updateRememberedValue(o6);
            }
            final MutableState mutableState4 = (MutableState)o6;
            Object o7;
            if ((o7 = fe2.c(startRestartGroup, -1640702327)) == companion2.getEmpty()) {
                o7 = SnapshotStateKt.mutableStateOf$default((Object)"", (SnapshotMutationPolicy)null, 2, (Object)null);
                startRestartGroup.updateRememberedValue(o7);
            }
            final MutableState mutableState5 = (MutableState)o7;
            Object o8;
            if ((o8 = fe2.c(startRestartGroup, -1640700663)) == companion2.getEmpty()) {
                o8 = SnapshotStateKt.mutableStateOf$default((Object)"", (SnapshotMutationPolicy)null, 2, (Object)null);
                startRestartGroup.updateRememberedValue(o8);
            }
            final MutableState mutableState6 = (MutableState)o8;
            Object o9;
            if ((o9 = fe2.c(startRestartGroup, -1640697909)) == companion2.getEmpty()) {
                o9 = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
                startRestartGroup.updateRememberedValue(o9);
            }
            final NumberFormat numberFormat = (NumberFormat)o9;
            startRestartGroup.endReplaceGroup();
            final String s = (String)((State)mutableState).getValue();
            final String s2 = (String)((State)mutableState2).getValue();
            final String s3 = (String)((State)mutableState3).getValue();
            final int intValue = ((IntState)mutableIntState3).getIntValue();
            final int intValue2 = ((IntState)mutableIntState4).getIntValue();
            startRestartGroup.startReplaceGroup(-1640692890);
            final boolean changed = startRestartGroup.changed((Object)s);
            final boolean changed2 = startRestartGroup.changed((Object)s2);
            final boolean changed3 = startRestartGroup.changed((Object)s3);
            final boolean changed4 = startRestartGroup.changed(intValue);
            final boolean changed5 = startRestartGroup.changed(intValue2);
            final Object rememberedValue2 = startRestartGroup.rememberedValue();
            State derivedState;
            if ((changed | changed2 | changed3 | changed4 | changed5) || (derivedState = (State)rememberedValue2) == companion2.getEmpty()) {
                derivedState = SnapshotStateKt.derivedStateOf((id1)new t3(mutableState, mutableState2, mutableState3, mutableIntState3, mutableIntState4));
                startRestartGroup.updateRememberedValue((Object)derivedState);
            }
            final State state = derivedState;
            startRestartGroup.endReplaceGroup();
            final String s4 = (String)((State)mutableState4).getValue();
            final String s5 = (String)((State)mutableState5).getValue();
            final String s6 = (String)((State)mutableState6).getValue();
            startRestartGroup.startReplaceGroup(-1640677269);
            final boolean changed6 = startRestartGroup.changed((Object)s4);
            final boolean changed7 = startRestartGroup.changed((Object)s5);
            final boolean changed8 = startRestartGroup.changed((Object)s6);
            final Object rememberedValue3 = startRestartGroup.rememberedValue();
            State derivedState2;
            if ((changed6 | changed7 | changed8) || (derivedState2 = (State)rememberedValue3) == companion2.getEmpty()) {
                derivedState2 = SnapshotStateKt.derivedStateOf((id1)new ya(mutableState4, mutableState5, mutableState6, 4));
                startRestartGroup.updateRememberedValue((Object)derivedState2);
            }
            final State state2 = derivedState2;
            startRestartGroup.endReplaceGroup();
            ScaffoldKt.Scaffold-TvnljyQ((Modifier)companion, (nd1)ComposableLambdaKt.rememberComposableLambda(1760403303, true, (Object)new a71((Object)so2, mutableState, mutableState2, mutableState3, mutableState4, mutableState5, mutableState6, 1), startRestartGroup, 54), (nd1)null, (nd1)null, (nd1)null, 0, 0L, 0L, (WindowInsets)null, (od1)ComposableLambdaKt.rememberComposableLambda(623193212, true, (Object)new m81(numberFormat, mutableIntState2, mutableState, mutableState2, mutableState3, mutableIntState3, mutableIntState4, state, mutableState4, mutableState5, mutableState6, state2), startRestartGroup, 54), startRestartGroup, (n4 >> 3 & 0xE) | 0x30000030, 508);
            modifier = (Modifier)companion;
        }
        final ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope((nd1)new w11((Object)so2, (Object)modifier, n, 4));
        }
    }
    
    public static final void c(final String s, final String s2, final String s3, final jd1 jd1, final jd1 jd2, final jd1 jd3, Composer startRestartGroup, final int n) {
        startRestartGroup = startRestartGroup.startRestartGroup(-1452490003);
        int n3;
        if ((n & 0xE) == 0x0) {
            int n2;
            if (startRestartGroup.changed((Object)s)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            n3 = (n2 | n);
        }
        else {
            n3 = n;
        }
        if ((n & 0x70) == 0x0) {
            int n4;
            if (startRestartGroup.changed((Object)s2)) {
                n4 = 32;
            }
            else {
                n4 = 16;
            }
            n3 |= n4;
        }
        if ((n & 0x380) == 0x0) {
            int n5;
            if (startRestartGroup.changed((Object)s3)) {
                n5 = 256;
            }
            else {
                n5 = 128;
            }
            n3 |= n5;
        }
        if ((n & 0x1C00) == 0x0) {
            int n6;
            if (startRestartGroup.changedInstance((Object)jd1)) {
                n6 = 2048;
            }
            else {
                n6 = 1024;
            }
            n3 |= n6;
        }
        int n7 = n3;
        if ((0xE000 & n) == 0x0) {
            int n8;
            if (startRestartGroup.changedInstance((Object)jd2)) {
                n8 = 16384;
            }
            else {
                n8 = 8192;
            }
            n7 = (n3 | n8);
        }
        int n9 = n7;
        if ((0x70000 & n) == 0x0) {
            int n10;
            if (startRestartGroup.changedInstance((Object)jd3)) {
                n10 = 131072;
            }
            else {
                n10 = 65536;
            }
            n9 = (n7 | n10);
        }
        if ((0x5B6DB & n9) == 0x12492 && startRestartGroup.getSkipping()) {
            startRestartGroup.skipToGroupEnd();
        }
        else {
            final Arrangement$HorizontalOrVertical spacedBy-0680j_4 = Arrangement.INSTANCE.spacedBy-0680j_4(Dp.constructor-impl((float)12));
            final Modifier$Companion companion = Modifier.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy((Arrangement$Vertical)spacedBy-0680j_4, Alignment.Companion.getStart(), startRestartGroup, 6);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(startRestartGroup, 0);
            final CompositionLocalMap currentCompositionLocalMap = startRestartGroup.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(startRestartGroup, (Modifier)companion);
            final ComposeUiNode$Companion companion2 = ComposeUiNode.Companion;
            final id1 constructor = companion2.getConstructor();
            if (startRestartGroup.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            startRestartGroup.startReusableNode();
            if (startRestartGroup.getInserting()) {
                startRestartGroup.createNode(constructor);
            }
            else {
                startRestartGroup.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(startRestartGroup);
            final nd1 b = ap.b(companion2, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion2.getSetModifier());
            final ColumnScopeInstance instance = ColumnScopeInstance.INSTANCE;
            final KeyboardType$Companion companion3 = KeyboardType.Companion;
            final KeyboardOptions keyboardOptions = new KeyboardOptions(0, (Boolean)null, companion3.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null);
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final ComposableLambda q = u30.q;
            final ComposableLambda r = u30.r;
            final ComposableLambda s4 = u30.s;
            final int n11 = n9 >> 6;
            OutlinedTextFieldKt.OutlinedTextField(s, jd1, fillMaxWidth$default, false, false, (TextStyle)null, (nd1)q, (nd1)r, (nd1)null, (nd1)null, (nd1)s4, (nd1)null, (nd1)null, false, (VisualTransformation)null, keyboardOptions, (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, startRestartGroup, (n9 & 0xE) | 0xD80180 | (n11 & 0x70), 12779526, 0, 8223544);
            OutlinedTextFieldKt.OutlinedTextField(s2, jd2, SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), false, false, (TextStyle)null, (nd1)u30.t, (nd1)u30.u, (nd1)null, (nd1)null, (nd1)null, (nd1)u30.v, (nd1)null, false, (VisualTransformation)null, new KeyboardOptions(0, (Boolean)null, companion3.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null), (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, startRestartGroup, (n9 >> 3 & 0xE) | 0xD80180 | (n9 >> 9 & 0x70), 12779568, 0, 8222520);
            OutlinedTextFieldKt.OutlinedTextField(s3, jd3, SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), false, false, (TextStyle)null, (nd1)u30.w, (nd1)u30.x, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, false, (VisualTransformation)null, new KeyboardOptions(0, (Boolean)null, companion3.getNumber-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null), (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, startRestartGroup, (n11 & 0xE) | 0xD80180 | (n9 >> 12 & 0x70), 12779520, 0, 8224568);
            startRestartGroup.endNode();
        }
        final ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope((nd1)new h81(s, s2, s3, jd1, jd2, jd3, n));
        }
    }
    
    public static final void d(final String s, final List list, final boolean b, final Composer composer, final int n) {
        final Composer startRestartGroup = composer.startRestartGroup(1903132714);
        CardKt.Card(SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), (Shape)RoundedCornerShapeKt.RoundedCornerShape-0680j_4(Dp.constructor-impl((float)16)), CardDefaults.INSTANCE.cardColors-ro_MJ88(MaterialTheme.INSTANCE.getColorScheme(startRestartGroup, MaterialTheme.$stable).getPrimaryContainer-0d7_KjU(), 0L, 0L, 0L, startRestartGroup, CardDefaults.$stable << 12, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(-183692132, true, (Object)new n81(list, s, b), startRestartGroup, 54), startRestartGroup, 196614, 24);
        final ScopeUpdateScope endRestartGroup = startRestartGroup.endRestartGroup();
        if (endRestartGroup != null) {
            endRestartGroup.updateScope((nd1)new px0(s, list, b, n));
        }
    }
}
