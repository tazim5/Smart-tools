import java.util.ArrayList;
import java.util.LinkedHashMap;
import androidx.activity.result.a;

public final class g3 extends b3
{
    public final int a;
    public final a b;
    public final String c;
    public final z2 d;
    
    @Override
    public final void a(final Object o) {
        switch (this.a) {
            default: {
                final a b = this.b;
                final LinkedHashMap b2 = b.b;
                final String c = this.c;
                final Object value = b2.get((Object)c);
                final z2 d = this.d;
                if (value != null) {
                    final int intValue = ((Number)value).intValue();
                    final ArrayList d2 = b.d;
                    d2.add((Object)c);
                    try {
                        b.b(intValue, d, o);
                        return;
                    }
                    catch (final Exception ex) {
                        d2.remove((Object)c);
                        throw ex;
                    }
                }
                final StringBuilder sb = new StringBuilder("Attempting to launch an unregistered ActivityResultLauncher with contract ");
                sb.append((Object)d);
                sb.append(" and input ");
                sb.append(o);
                sb.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
                throw new IllegalStateException(sb.toString().toString());
            }
            case 0: {
                final a b3 = this.b;
                final LinkedHashMap b4 = b3.b;
                final String c2 = this.c;
                final Object value2 = b4.get((Object)c2);
                final z2 d3 = this.d;
                if (value2 != null) {
                    final int intValue2 = ((Number)value2).intValue();
                    final ArrayList d4 = b3.d;
                    d4.add((Object)c2);
                    try {
                        b3.b(intValue2, d3, o);
                        return;
                    }
                    catch (final Exception ex2) {
                        d4.remove((Object)c2);
                        throw ex2;
                    }
                }
                final StringBuilder sb2 = new StringBuilder("Attempting to launch an unregistered ActivityResultLauncher with contract ");
                sb2.append((Object)d3);
                sb2.append(" and input ");
                sb2.append(o);
                sb2.append(". You must ensure the ActivityResultLauncher is registered before calling launch().");
                throw new IllegalStateException(sb2.toString().toString());
            }
        }
    }
}
