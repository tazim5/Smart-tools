import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.ads.internal.client.zzba;
import java.util.HashMap;

public final class bb4 implements Runnable
{
    public final boolean P;
    public final int Q;
    public final int R;
    public final eb4 S;
    public final String c;
    public final String n;
    public final long v;
    public final long w;
    public final long x;
    public final long y;
    public final long z;
    
    public bb4(final eb4 s, final String c, final String n, final long v, final long w, final long x, final long y, final long z, final boolean p11, final int q, final int r) {
        this.S = s;
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p11;
        this.Q = q;
        this.R = r;
    }
    
    public final void run() {
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"event", (Object)"precacheProgress");
        hashMap.put((Object)"src", (Object)this.c);
        hashMap.put((Object)"cachedSrc", (Object)this.n);
        hashMap.put((Object)"bufferedDuration", (Object)Long.toString(this.v));
        hashMap.put((Object)"totalDuration", (Object)Long.toString(this.w));
        if (zzba.zzc().a(cs3.D1)) {
            hashMap.put((Object)"qoeLoadedBytes", (Object)Long.toString(this.x));
            hashMap.put((Object)"qoeCachedBytes", (Object)Long.toString(this.y));
            hashMap.put((Object)"totalBytes", (Object)Long.toString(this.z));
            hashMap.put((Object)"reportTime", (Object)Long.toString(zzt.zzB().currentTimeMillis()));
        }
        String s;
        if (!this.P) {
            s = "0";
        }
        else {
            s = "1";
        }
        hashMap.put((Object)"cacheReady", (Object)s);
        hashMap.put((Object)"playerCount", (Object)Integer.toString(this.Q));
        hashMap.put((Object)"playerPreparedCount", (Object)Integer.toString(this.R));
        eb4.a(this.S, hashMap);
    }
}
