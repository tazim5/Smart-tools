import com.google.android.gms.ads.internal.util.zzg;
import java.util.concurrent.Executor;
import com.google.android.gms.internal.ads.zzfgk;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.internal.ads.y1;
import com.google.android.gms.internal.ads.zzfgh;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.ads.internal.client.zzba;
import android.content.Context;

public final class iy4 implements ls5
{
    public final int a;
    public final ks5 b;
    public final ms5 c;
    public final ks5 d;
    
    public n55 a() {
        switch (this.a) {
            default: {
                final Context context = (Context)this.c.a;
                final a75 a75 = (a75)this.b.zzb();
                final l75 l75 = (l75)this.d.zzb();
                m84 m84;
                if (zzba.zzc().a(cs3.z5)) {
                    m84 = ((zzg)zzt.zzo().c()).zzh();
                }
                else {
                    m84 = ((zzg)zzt.zzo().c()).zzi();
                }
                int n = 0;
                if (m84 != null) {
                    n = n;
                    if (m84.j) {
                        n = 1;
                    }
                }
                Object o;
                if ((int)zzba.zzc().a(cs3.B5) > 0 && (!(boolean)zzba.zzc().a(cs3.y5) || n != 0)) {
                    final k75 a76 = l75.a(zzfgh.c, context, a75, new ur4((Object)new y1(), 7));
                    final mw4 mw4 = new mw4(new qk4(11));
                    final i94 a77 = k1.a;
                    final m14 a78 = a76.a;
                    o = new gl5(mw4, new m14(a78, (pg5)a77), a76.b, ((zzfgk)a78.v).z, (pg5)a77);
                }
                else {
                    o = new qk4(11);
                }
                return (n55)o;
            }
            case 4: {
                final Context context2 = (Context)this.c.a;
                final a75 a79 = (a75)this.b.zzb();
                final l75 l76 = (l75)this.d.zzb();
                m84 m85;
                if (zzba.zzc().a(cs3.z5)) {
                    m85 = ((zzg)zzt.zzo().c()).zzh();
                }
                else {
                    m85 = ((zzg)zzt.zzo().c()).zzi();
                }
                int n2 = 0;
                if (m85 != null) {
                    n2 = n2;
                    if (m85.j) {
                        n2 = 1;
                    }
                }
                Object o2;
                if ((int)zzba.zzc().a(cs3.P5) > 0 && (!(boolean)zzba.zzc().a(cs3.y5) || n2 != 0)) {
                    final k75 a80 = l76.a(zzfgh.v, context2, a79, new ur4((Object)new y1(), 7));
                    final mw4 mw5 = new mw4(new qk4(11));
                    final i94 a81 = k1.a;
                    final m14 a82 = a80.a;
                    o2 = new gl5(mw5, new m14(a82, (pg5)a81), a80.b, ((zzfgk)a82.v).z, (pg5)a81);
                }
                else {
                    o2 = new qk4(11);
                }
                return (n55)o2;
            }
        }
    }
    
    public final Object zzb() {
        switch (this.a) {
            default: {
                return this.a();
            }
            case 4: {
                return this.a();
            }
            case 3: {
                return new oz4((Context)this.b.zzb(), (Executor)this.d.zzb(), (ar4)this.c.a, 1);
            }
            case 2: {
                return new oz4((Context)this.b.zzb(), (Executor)this.d.zzb(), (ar4)this.c.a, 0);
            }
            case 1: {
                return new cy4((Context)this.b.zzb(), (Object)this.c.a, (Executor)this.d.zzb(), 2);
            }
            case 0: {
                return new cy4((Context)this.b.zzb(), (Object)this.c.a, (Executor)this.d.zzb(), 1);
            }
        }
    }
}
