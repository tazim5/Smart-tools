public final class jk5 implements h32
{
    public static final jk5 a;
    
    static {
        a = (jk5)new Object();
        f83.q(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, new og3(1)), 2)), 3)));
    }
}
