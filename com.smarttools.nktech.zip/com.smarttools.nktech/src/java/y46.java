public final class y46
{
    public final Object a;
    
    public y46(final a56 a) {
        this.a = a;
    }
}
