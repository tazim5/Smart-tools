import com.google.android.gms.internal.ads.l2;
import java.util.List;

public final class hm4
{
    public final List a;
    public final d95 b;
    public boolean c;
    
    public hm4(final l2 l2, final d95 b) {
        this.a = l2.q;
        this.b = b;
    }
}
