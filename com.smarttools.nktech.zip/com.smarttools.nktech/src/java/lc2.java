import androidx.compose.runtime.State;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import java.util.List;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.layout.ContentScale;
import androidx.compose.foundation.ImageKt;
import androidx.compose.ui.graphics.AndroidImageBitmap_androidKt;
import android.graphics.Bitmap;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.AspectRatioKt;
import com.smarttools.nktech.features.tools.common.g;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.runtime.MutableState;

public final class lc2 implements od1
{
    public final MutableState c;
    public final MutableState n;
    
    public lc2(final MutableState c, final MutableState n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final List a = g.a;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs(AspectRatioKt.aspectRatio$default(fillMaxWidth$default, ((lr)((State)this.c).getValue()).c, false, 2, (Object)null), Dp.constructor-impl((float)16));
            final MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.Companion.getCenter(), false);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion2 = ComposeUiNode.Companion;
            final id1 constructor = companion2.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion2, constructor-impl, maybeCachedBoxMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion2.getSetModifier());
            final BoxScopeInstance instance = BoxScopeInstance.INSTANCE;
            ImageKt.Image-5h-nEew(AndroidImageBitmap_androidKt.asImageBitmap((Bitmap)((State)this.n).getValue()), "Generated Code", SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), (Alignment)null, (ContentScale)null, 0.0f, (ColorFilter)null, 0, composer, 440, 248);
            composer.endNode();
        }
        return t43.a;
    }
}
