import com.google.android.gms.ads.BaseAdView;
import android.view.View;
import android.os.Bundle;
import android.content.Context;
import android.app.Activity;
import org.json.JSONException;
import com.google.android.gms.ads.internal.util.zzbw;
import org.json.JSONObject;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.internal.zzt;
import android.content.Intent;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.appopen.AppOpenAd$AppOpenAdLoadCallback;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.nativead.NativeAd$OnNativeAdLoadedListener;
import com.google.android.gms.ads.AdLoader$Builder;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback;
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.internal.ads.zzbxc;
import android.text.TextUtils;
import java.util.Map;
import com.google.android.gms.common.internal.Preconditions;

public final class uw3 implements hx3
{
    public final int c;
    public final Object n;
    
    public uw3(final qt4 n) {
        this.c = 5;
        Preconditions.checkNotNull((Object)n, (Object)"The Inspector Manager must not be null");
        this.n = n;
    }
    
    private final void b(final Object o, Map l) {
        if (l == null) {
            return;
        }
        if (!l.containsKey((Object)"extras")) {
            return;
        }
        final boolean containsKey = l.containsKey((Object)"expires");
        long long1 = Long.MAX_VALUE;
        while (true) {
            if (!containsKey) {
                break Label_0056;
            }
            try {
                long1 = Long.parseLong((String)l.get((Object)"expires"));
                final qt4 qt4 = (qt4)this.n;
                l = (Map)l.get((Object)"extras");
                synchronized (qt4) {
                    qt4.l = (String)l;
                    qt4.n = long1;
                    qt4.i();
                }
            }
            catch (final NumberFormatException ex) {
                long1 = long1;
                continue;
            }
            break;
        }
    }
    
    public final void a(Object o, final Map map) {
        switch (this.c) {
            default: {
                final rb4 rb4 = (rb4)o;
                ((zo4)this.n).b.b(map);
                return;
            }
            case 6: {
                this.c(o, map);
                return;
            }
            case 5: {
                this.b(o, map);
                return;
            }
            case 4: {
                final String s = (String)map.get((Object)"action");
                final boolean equals = "grant".equals((Object)s);
                final im4 im4 = (im4)this.n;
                if (equals) {
                    final Object o2 = null;
                    try {
                        final int int1 = Integer.parseInt((String)map.get((Object)"amount"));
                        final String s2 = (String)map.get((Object)"type");
                        o = o2;
                        if (!TextUtils.isEmpty((CharSequence)s2)) {
                            o = new zzbxc(s2, int1);
                        }
                    }
                    catch (final NumberFormatException ex) {
                        d94.zzk("Unable to parse reward amount.", (Throwable)ex);
                        o = o2;
                    }
                    im4.n0((zzbxc)o);
                }
                else if ("video_start".equals((Object)s)) {
                    im4.zzc();
                }
                else if ("video_complete".equals((Object)s)) {
                    im4.zzb();
                }
                return;
            }
            case 3: {
                if (zzba.zzc().a(cs3.p8)) {
                    final String s3 = (String)map.get((Object)"action");
                    final String adUnitId = (String)map.get((Object)"adUnitId");
                    final String s4 = (String)map.get((Object)"redirectUrl");
                    if (!TextUtils.isEmpty((CharSequence)s3) && !TextUtils.isEmpty((CharSequence)adUnitId) && !TextUtils.isEmpty((CharSequence)s4)) {
                        final String s5 = (String)map.get((Object)"format");
                        if (s3.equals((Object)"load")) {
                            if (!TextUtils.isEmpty((CharSequence)s5)) {
                                final cu4 cu4 = (cu4)this.n;
                                final cu4 cu5;
                                monitorenter(cu5 = cu4);
                                int n = 0;
                                AdView adView;
                                AdLoader$Builder adLoader$Builder;
                                Block_36_Outer:Block_34_Outer:
                                while (true) {
                                    Label_0494: {
                                        try {
                                            switch (s5.hashCode()) {
                                                default: {
                                                    break Block_36_Outer;
                                                }
                                                case 1951953708: {
                                                    if (s5.equals((Object)"BANNER")) {
                                                        n = 1;
                                                        break Label_0516;
                                                    }
                                                    break Block_36_Outer;
                                                }
                                                case 1854800829: {
                                                    break Label_0494;
                                                }
                                                case 543046670: {
                                                    break Label_0494;
                                                }
                                                case -428325382: {
                                                    break Label_0494;
                                                }
                                                case -1372958932: {
                                                    break Label_0494;
                                                }
                                                case -1999289321: {
                                                    break Label_0494;
                                                }
                                            }
                                        }
                                        finally {
                                            monitorexit(cu5);
                                        Block_27_Outer:
                                            while (true) {
                                            Block_33:
                                                while (true) {
                                                    Block_29: {
                                                        Block_30: {
                                                            while (true) {
                                                            Block_37:
                                                                while (true) {
                                                                    iftrue(Label_0557:)(n == 5);
                                                                    break Block_37;
                                                                    Label_0598: {
                                                                        RewardedAd.load(cu4.g1(), adUnitId, cu4.h1(), (RewardedAdLoadCallback)new zt4(cu4, adUnitId, s4));
                                                                    }
                                                                    monitorexit(cu5);
                                                                    return;
                                                                    iftrue(Label_0513:)(!s5.equals((Object)"INTERSTITIAL"));
                                                                    break Block_30;
                                                                    iftrue(Label_0638:)(n == 3);
                                                                    Block_35: {
                                                                        break Block_35;
                                                                        Label_0557:
                                                                        RewardedInterstitialAd.load(cu4.g1(), adUnitId, cu4.h1(), (RewardedInterstitialAdLoadCallback)new au4(cu4, adUnitId, s4));
                                                                        monitorexit(cu5);
                                                                        return;
                                                                        iftrue(Label_0513:)(!s5.equals((Object)"APP_OPEN_AD"));
                                                                        break Block_29;
                                                                        n = 5;
                                                                        break Label_0516;
                                                                        iftrue(Label_0513:)(!s5.equals((Object)"NATIVE"));
                                                                        Block_31: {
                                                                            break Block_31;
                                                                            Label_0754:
                                                                            adView = new AdView(cu4.g1());
                                                                            ((BaseAdView)adView).setAdSize(AdSize.BANNER);
                                                                            ((BaseAdView)adView).setAdUnitId(adUnitId);
                                                                            ((BaseAdView)adView).setAdListener((AdListener)new xt4(cu4, adUnitId, adView, s4));
                                                                            ((BaseAdView)adView).loadAd(cu4.h1());
                                                                            monitorexit(cu5);
                                                                            return;
                                                                            iftrue(Label_0754:)(n == 1);
                                                                            break Block_33;
                                                                            Label_0638:
                                                                            adLoader$Builder = new AdLoader$Builder(cu4.g1(), adUnitId);
                                                                            adLoader$Builder.forNativeAd((NativeAd$OnNativeAdLoadedListener)new m14((Object)cu4, (Object)adUnitId, (Object)s4, 14, false));
                                                                            adLoader$Builder.withAdListener((AdListener)new a02(cu4, s4));
                                                                            adLoader$Builder.build().loadAd(cu4.h1());
                                                                            monitorexit(cu5);
                                                                            return;
                                                                        }
                                                                        n = 3;
                                                                        break Label_0516;
                                                                        Label_0814:
                                                                        AppOpenAd.load(cu4.g1(), adUnitId, cu4.h1(), 1, (AppOpenAd$AppOpenAdLoadCallback)new tt4(cu4, adUnitId, s4));
                                                                        monitorexit(cu5);
                                                                        return;
                                                                        iftrue(Label_0513:)(!s5.equals((Object)"REWARDED"));
                                                                        n = 4;
                                                                        break Label_0516;
                                                                    }
                                                                    iftrue(Label_0598:)(n == 4);
                                                                    continue Block_34_Outer;
                                                                }
                                                                monitorexit(cu5);
                                                                return;
                                                                iftrue(Label_0814:)(n == 0);
                                                                continue;
                                                            }
                                                        }
                                                        n = 2;
                                                        continue Block_36_Outer;
                                                    }
                                                    n = 0;
                                                    continue Block_36_Outer;
                                                    n = -1;
                                                    continue Block_36_Outer;
                                                    iftrue(Label_0513:)(!s5.equals((Object)"REWARDED_INTERSTITIAL"));
                                                    continue;
                                                }
                                                iftrue(Label_0713:)(n == 2);
                                                continue Block_27_Outer;
                                            }
                                            Label_0713: {
                                                InterstitialAd.load(cu4.g1(), adUnitId, cu4.h1(), (InterstitialAdLoadCallback)new yt4(cu4, adUnitId, s4));
                                            }
                                            monitorexit(cu5);
                                            return;
                                        }
                                    }
                                    break;
                                }
                            }
                        }
                        if (s3.equals((Object)"show")) {
                            final cu4 cu6 = (cu4)this.n;
                            final cu4 cu7;
                            monitorenter(cu7 = cu6);
                            Label_1017: {
                                try {
                                    final st4 w = cu6.w;
                                    final dc4 w2 = w.w;
                                    Activity a;
                                    if (w2 != null && !w2.c.w()) {
                                        a = w.w.c.c.a;
                                    }
                                    else {
                                        a = null;
                                    }
                                    if (a == null) {
                                        break Label_1017;
                                    }
                                    final Object value = cu6.c.get((Object)adUnitId);
                                    if (value == null) {
                                        break Label_1017;
                                    }
                                    final ur3 q8 = cs3.q8;
                                    if ((boolean)zzba.zzc().a(q8) && !(value instanceof AppOpenAd) && !(value instanceof InterstitialAd) && !(value instanceof RewardedAd) && !(value instanceof RewardedInterstitialAd)) {
                                        break Label_1017;
                                    }
                                    break Label_1017;
                                }
                                finally {
                                    monitorexit(cu7);
                                    final Activity a;
                                    final Object value;
                                Block_50:
                                    while (true) {
                                    Block_52_Outer:
                                        while (true) {
                                            ((RewardedAd)value).show(a, (OnUserEarnedRewardListener)h26.U);
                                            monitorexit(cu7);
                                            return;
                                        Block_49:
                                            while (true) {
                                                ((RewardedInterstitialAd)value).show(a, (OnUserEarnedRewardListener)k26.U);
                                                monitorexit(cu7);
                                                return;
                                                cu6.c.remove((Object)adUnitId);
                                                cu6.k1(cu4.i1(value), s4);
                                                iftrue(Label_1061:)(!(value instanceof AppOpenAd));
                                                break Block_49;
                                                o = new Intent();
                                                final Context g1 = cu6.g1();
                                                ((Intent)o).setClassName(g1, "com.google.android.gms.ads.OutOfContextTestingActivity");
                                                ((Intent)o).putExtra("adUnit", adUnitId);
                                                zzt.zzp();
                                                com.google.android.gms.ads.internal.util.zzt.zzS(g1, (Intent)o);
                                                monitorexit(cu7);
                                                return;
                                                Label_1110: {
                                                    iftrue(Label_1136:)(!(value instanceof RewardedInterstitialAd));
                                                }
                                                continue;
                                            }
                                            ((AppOpenAd)value).show(a);
                                            monitorexit(cu7);
                                            return;
                                            Label_1061: {
                                                iftrue(Label_1084:)(!(value instanceof InterstitialAd));
                                            }
                                            break Block_50;
                                            monitorexit(cu7);
                                            return;
                                            Label_1084:
                                            iftrue(Label_1110:)(!(value instanceof RewardedAd));
                                            continue Block_52_Outer;
                                        }
                                        Label_1136: {
                                            final ur3 q8;
                                            iftrue(Label_1219:)(!(boolean)zzba.zzc().a(q8) || (!(value instanceof AdView) && !(value instanceof NativeAd)));
                                        }
                                        continue;
                                    }
                                    ((InterstitialAd)value).show(a);
                                    monitorexit(cu7);
                                }
                            }
                        }
                    }
                }
                return;
            }
            case 2: {
                o = o;
                final boolean equals2 = "1".equals(map.get((Object)"transparentBackground"));
                final boolean equals3 = "1".equals(map.get((Object)"blur"));
                float float1 = 0.0f;
                try {
                    if (map.get((Object)"blurRadius") != null) {
                        float1 = Float.parseFloat((String)map.get((Object)"blurRadius"));
                    }
                }
                catch (final NumberFormatException ex2) {
                    d94.zzh("Fail to parse float", (Throwable)ex2);
                    float1 = float1;
                }
                final ix3 ix3 = (ix3)this.n;
                synchronized (ix3) {
                    ix3.a = equals2;
                    ix3.d.set(true);
                    monitorexit(ix3);
                    final ix3 ix4 = (ix3)this.n;
                    synchronized (ix4) {
                        ix4.b = equals3;
                        ix4.c = float1;
                        monitorexit(ix3);
                        ((rb4)o).v(equals2);
                    }
                }
            }
            case 1: {
                final String s6 = (String)map.get((Object)"name");
                if (s6 == null) {
                    d94.zzj("App event with no name parameter.");
                }
                else {
                    ((ww3)this.n).f(s6, (String)map.get((Object)"info"));
                }
                return;
            }
            case 0: {
                final vw3 vw3 = (vw3)this.n;
                if (vw3 != null) {
                    if ((o = map.get((Object)"name")) == null) {
                        d94.zzi("Ad metadata with no name parameter.");
                        o = "";
                    }
                    final boolean containsKey = map.containsKey((Object)"info");
                    Bundle zza;
                    final Bundle bundle = zza = null;
                    if (containsKey) {
                        try {
                            zza = zzbw.zza(new JSONObject((String)map.get((Object)"info")));
                        }
                        catch (final JSONException ex3) {
                            d94.zzh("Failed to convert ad metadata to JSON.", (Throwable)ex3);
                            zza = bundle;
                        }
                    }
                    if (zza == null) {
                        d94.zzg("Failed to convert ad metadata to Bundle.");
                    }
                    else {
                        vw3.q((String)o, zza);
                    }
                }
            }
        }
    }
}
