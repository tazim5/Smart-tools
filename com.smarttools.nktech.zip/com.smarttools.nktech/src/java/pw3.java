import com.google.android.gms.ads.formats.NativeCustomTemplateAd$OnCustomTemplateAdLoadedListener;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd;

public final class pw3 extends qv3
{
    public final qw3 c;
    
    public final void J(final gv3 gv3) {
        final qw3 c = this.c;
        final NativeCustomTemplateAd$OnCustomTemplateAdLoadedListener a = c.a;
        synchronized (c) {
            final hv3 c2 = c.c;
            Object o;
            if (c2 != null) {
                o = c2;
            }
            else {
                final hv3 c3 = new hv3(gv3);
                c.c = c3;
                o = c3;
            }
            monitorexit(c);
            a.onCustomTemplateAdLoaded((NativeCustomTemplateAd)o);
        }
    }
}
