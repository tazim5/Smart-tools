import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.internal.ComposableLambda;

public abstract class r70
{
    public static final ComposableLambda a;
    public static final ComposableLambda b;
    public static final ComposableLambda c;
    public static final ComposableLambda d;
    public static final ComposableLambda e;
    public static final ComposableLambda f;
    public static final ComposableLambda g;
    public static final ComposableLambda h;
    
    static {
        a = ComposableLambdaKt.composableLambdaInstance(947280148, false, (Object)t10.m0);
        b = ComposableLambdaKt.composableLambdaInstance(474044498, false, (Object)m70.n);
        c = ComposableLambdaKt.composableLambdaInstance(2054634062, false, (Object)n70.c);
        d = ComposableLambdaKt.composableLambdaInstance(1818016237, false, (Object)m50.k0);
        e = ComposableLambdaKt.composableLambdaInstance(1581398412, false, (Object)m50.l0);
        f = ComposableLambdaKt.composableLambdaInstance(-483683941, false, (Object)o70.c);
        g = ComposableLambdaKt.composableLambdaInstance(1295662010, false, (Object)p70.c);
        h = ComposableLambdaKt.composableLambdaInstance(-1610643511, false, (Object)q70.c);
    }
}
