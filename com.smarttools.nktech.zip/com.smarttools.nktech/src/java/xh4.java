import com.google.android.gms.ads.internal.client.zza;

public final class xh4 implements zza
{
    public final ai4 c;
    public final o65 n;
    
    public xh4(final ai4 c, final o65 n) {
        this.c = c;
        this.n = n;
    }
    
    public final void onAdClicked() {
        final o65 n = this.n;
        final ai4 c = this.c;
        final String f = n.f;
        final Object a;
        monitorenter(a = c.a);
        while (true) {
            Label_0055: {
                try {
                    final Integer n2 = (Integer)c.b.get((Object)f);
                    if (n2 == null) {
                        final Integer n3 = 1;
                        break Label_0065;
                    }
                    break Label_0055;
                }
                finally {
                    monitorexit(a);
                    final Integer n3;
                    c.b.put((Object)f, (Object)n3);
                    monitorexit(a);
                    return;
                    final Integer n2;
                    n3 = n2 + 1;
                    continue;
                }
            }
            break;
        }
    }
}
