public final class oi5 implements h32
{
    public static final oi5 a;
    
    static {
        a = (oi5)new Object();
        f83.q(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, new kg3(1)), 2)), 3)));
    }
}
