import android.content.Context;

public final class xc4 implements ls5
{
    public final vc4 a;
    
    public xc4(final vc4 a) {
        this.a = a;
    }
    
    public final Context a() {
        final Context b = this.a.b;
        ep5.c((Object)b);
        return b;
    }
    
    public final Object zzb() {
        final Context b = this.a.b;
        ep5.c((Object)b);
        return b;
    }
}
