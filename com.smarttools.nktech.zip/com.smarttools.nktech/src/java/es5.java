import java.util.logging.Level;
import java.util.logging.Logger;

public final class es5
{
    public static final u65 c;
    public final int a;
    public final Object b;
    
    static {
        c = new u65(0);
    }
    
    public es5(final String b, final int a) {
        switch (this.a = a) {
            default: {
                this.b = b;
                return;
            }
            case 1: {
                this.b = Logger.getLogger(b);
            }
        }
    }
    
    public static es5 b(final Class clazz) {
        if (System.getProperty("java.vm.name").equalsIgnoreCase("Dalvik")) {
            return new es5(clazz.getSimpleName(), 0);
        }
        return new es5(clazz.getSimpleName(), 1);
    }
    
    public final void a(final String s) {
        switch (this.a) {
            default: {
                ((Logger)this.b).logp(Level.FINE, "com.googlecode.mp4parser.util.JuliLogger", "logDebug", s);
                return;
            }
            case 0: {
                new StringBuilder(String.valueOf((Object)s).length() + (String.valueOf((Object)this.b).length() + 1));
            }
        }
    }
}
