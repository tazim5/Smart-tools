import androidx.work.impl.background.systemalarm.SystemAlarmService;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;

public abstract class wo0 extends BroadcastReceiver
{
    public static final int a = 0;
    
    static {
        fs1.g("ConstraintProxy");
    }
    
    public final void onReceive(final Context context, Intent intent) {
        final fs1 e = fs1.e();
        String.format("onReceive : %s", new Object[] { intent });
        e.a(new Throwable[0]);
        final String w = at.w;
        intent = new Intent(context, (Class)SystemAlarmService.class);
        intent.setAction("ACTION_CONSTRAINTS_CHANGED");
        context.startService(intent);
    }
}
