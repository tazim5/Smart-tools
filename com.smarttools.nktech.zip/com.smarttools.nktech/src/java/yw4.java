public final class yw4
{
    public long a;
    public int b;
    public long c;
    public long d;
    public long e;
    public final Object f;
    public final Object g;
    public final Object h;
    public final Object i;
    public final Object j;
    
    public yw4() {
        this.a = 0L;
        this.b = 0;
        this.c = 0L;
        this.d = 0L;
        this.e = 0L;
        this.f = new Object();
        this.g = new Object();
        this.h = new Object();
        this.i = new Object();
        this.j = new Object();
    }
    
    public final long a() {
        synchronized (this) {
            final Object i = this.i;
            synchronized (i) {
                return this.d;
            }
        }
    }
    
    public final long b() {
        synchronized (this) {
            final Object f = this.f;
            synchronized (f) {
                return this.a;
            }
        }
    }
}
