import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.material.icons.Icons$Filled;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.material.icons.filled.PlayArrowKt;
import androidx.compose.material.icons.filled.PauseKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;

public final class l83 implements nd1
{
    public final boolean c;
    
    public l83(final boolean c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final boolean c = this.c;
            final Icons$Filled default1 = Icons.INSTANCE.getDefault();
            ImageVector imageVector;
            if (c) {
                imageVector = PauseKt.getPause(default1);
            }
            else {
                imageVector = PlayArrowKt.getPlayArrow(default1);
            }
            String s;
            if (c) {
                s = "Pause";
            }
            else {
                s = "Play";
            }
            composer.startReplaceGroup(559689088);
            long n;
            if (c) {
                n = ColorKt.Color(4279286145L);
            }
            else {
                n = MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getPrimary-0d7_KjU();
            }
            composer.endReplaceGroup();
            IconKt.Icon-ww6aTOc(imageVector, s, (Modifier)null, n, composer, 0, 4);
        }
        return t43.a;
    }
}
