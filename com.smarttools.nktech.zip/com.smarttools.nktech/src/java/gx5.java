import android.opengl.Matrix;

public abstract class gx5
{
    public static void a(final float[] array, final float n) {
        Matrix.translateM(array, 0, 0.5f, 0.5f, 0.0f);
        Matrix.rotateM(array, 0, n, 0.0f, 0.0f, 1.0f);
        Matrix.translateM(array, 0, -0.5f, -0.5f, 0.0f);
    }
    
    public static void b(final float[] array) {
        Matrix.translateM(array, 0, 0.0f, 0.5f, 0.0f);
        Matrix.scaleM(array, 0, 1.0f, -1.0f, 1.0f);
        Matrix.translateM(array, 0, 0.0f, -0.5f, 0.0f);
    }
}
