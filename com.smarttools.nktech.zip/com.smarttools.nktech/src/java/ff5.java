import com.google.android.gms.internal.ads.n3;

public final class ff5 implements Runnable
{
    public final n3 c;
    public final yq1 n;
    
    public ff5(final n3 c, final yq1 n) {
        this.c = c;
        this.n = n;
    }
    
    public final void run() {
        if (this.c.c == this) {
            if (n3.y.f(this.c, this, n3.h(this.n))) {
                n3.o(this.c, false);
            }
        }
    }
}
