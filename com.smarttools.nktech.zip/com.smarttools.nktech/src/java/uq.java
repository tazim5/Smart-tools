import java.util.Collections;
import com.google.zxing.BarcodeFormat;
import java.util.Set;

public final class uq extends s42
{
    public static final char[] n;
    public static final char[] v;
    public static final char[] w;
    public static final char x;
    
    static {
        final char[] array;
        final char[] n2 = array = new char[4];
        array[0] = 'A';
        array[1] = 'B';
        array[2] = 'C';
        array[3] = 'D';
        n = n2;
        v = new char[] { 'T', 'N', '*', 'E' };
        w = new char[] { '/', ':', '+', '.' };
        x = n2[0];
    }
    
    public final boolean[] c(String s) {
        final int length = s.length();
        final char x = uq.x;
        if (length < 2) {
            final StringBuilder sb = new StringBuilder();
            sb.append(x);
            sb.append(s);
            sb.append(x);
            s = sb.toString();
        }
        else {
            final char upperCase = Character.toUpperCase(s.charAt(0));
            final char upperCase2 = Character.toUpperCase(s.charAt(s.length() - 1));
            final char[] n = uq.n;
            final boolean f = tq.f(n, upperCase);
            final boolean f2 = tq.f(n, upperCase2);
            final char[] v = uq.v;
            final boolean f3 = tq.f(v, upperCase);
            final boolean f4 = tq.f(v, upperCase2);
            if (f) {
                if (!f2) {
                    throw new IllegalArgumentException("Invalid start/end guards: ".concat(s));
                }
            }
            else if (f3) {
                if (!f4) {
                    throw new IllegalArgumentException("Invalid start/end guards: ".concat(s));
                }
            }
            else {
                if (f2 || f4) {
                    throw new IllegalArgumentException("Invalid start/end guards: ".concat(s));
                }
                final StringBuilder sb2 = new StringBuilder();
                sb2.append(x);
                sb2.append(s);
                sb2.append(x);
                s = sb2.toString();
            }
        }
        int n2 = 20;
        for (int i = 1; i < s.length() - 1; ++i) {
            if (!Character.isDigit(s.charAt(i)) && s.charAt(i) != '-' && s.charAt(i) != '$') {
                if (!tq.f(uq.w, s.charAt(i))) {
                    final StringBuilder sb3 = new StringBuilder("Cannot encode : '");
                    sb3.append(s.charAt(i));
                    sb3.append('\'');
                    throw new IllegalArgumentException(sb3.toString());
                }
                n2 += 10;
            }
            else {
                n2 += 9;
            }
        }
        final boolean[] array = new boolean[s.length() - 1 + n2];
        int j = 0;
        int n3 = 0;
        while (j < s.length()) {
            final char upperCase3 = Character.toUpperCase(s.charAt(j));
            char c = '\0';
            Label_0471: {
                if (j != 0) {
                    c = upperCase3;
                    if (j != s.length() - 1) {
                        break Label_0471;
                    }
                }
                if (upperCase3 != '*') {
                    if (upperCase3 != 'E') {
                        if (upperCase3 != 'N') {
                            if (upperCase3 != 'T') {
                                c = upperCase3;
                            }
                            else {
                                c = 'A';
                            }
                        }
                        else {
                            c = 'B';
                        }
                    }
                    else {
                        c = 'D';
                    }
                }
                else {
                    c = 'C';
                }
            }
            int n4 = 0;
            int n5;
            while (true) {
                final char[] d = tq.d;
                if (n4 >= d.length) {
                    n5 = 0;
                    break;
                }
                if (c == d[n4]) {
                    n5 = tq.e[n4];
                    break;
                }
                ++n4;
            }
            int k = 0;
            int n6 = 0;
            boolean b = true;
            while (k < 7) {
                array[n3] = b;
                ++n3;
                if ((n5 >> 6 - k & 0x1) != 0x0 && n6 != 1) {
                    ++n6;
                }
                else {
                    b ^= true;
                    ++k;
                    n6 = 0;
                }
            }
            int n7 = n3;
            if (j < s.length() - 1) {
                array[n3] = false;
                n7 = n3 + 1;
            }
            ++j;
            n3 = n7;
        }
        return array;
    }
    
    public final Set f() {
        return Collections.singleton((Object)BarcodeFormat.n);
    }
}
