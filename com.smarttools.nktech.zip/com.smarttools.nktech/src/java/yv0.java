import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.Callable;
import java.util.concurrent.ScheduledFuture;
import java.util.List;
import java.util.Collection;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;

public final class yv0 implements ScheduledExecutorService
{
    public final ExecutorService c;
    public final ScheduledExecutorService n;
    
    public yv0(final ExecutorService c, final ScheduledExecutorService n) {
        this.c = c;
        this.n = n;
    }
    
    public final boolean awaitTermination(final long n, final TimeUnit timeUnit) {
        return this.c.awaitTermination(n, timeUnit);
    }
    
    public final void execute(final Runnable runnable) {
        ((Executor)this.c).execute(runnable);
    }
    
    public final List invokeAll(final Collection collection) {
        return this.c.invokeAll(collection);
    }
    
    public final List invokeAll(final Collection collection, final long n, final TimeUnit timeUnit) {
        return this.c.invokeAll(collection, n, timeUnit);
    }
    
    public final Object invokeAny(final Collection collection) {
        return this.c.invokeAny(collection);
    }
    
    public final Object invokeAny(final Collection collection, final long n, final TimeUnit timeUnit) {
        return this.c.invokeAny(collection, n, timeUnit);
    }
    
    public final boolean isShutdown() {
        return this.c.isShutdown();
    }
    
    public final boolean isTerminated() {
        return this.c.isTerminated();
    }
    
    public final ScheduledFuture schedule(final Runnable runnable, final long n, final TimeUnit timeUnit) {
        return (ScheduledFuture)new aw0((zv0)new tv0(this, (Object)runnable, n, timeUnit, 0));
    }
    
    public final ScheduledFuture schedule(final Callable callable, final long n, final TimeUnit timeUnit) {
        return (ScheduledFuture)new aw0((zv0)new tv0(this, (Object)callable, n, timeUnit, 1));
    }
    
    public final ScheduledFuture scheduleAtFixedRate(final Runnable runnable, final long n, final long n2, final TimeUnit timeUnit) {
        return (ScheduledFuture)new aw0((zv0)new vv0(this, runnable, n, n2, timeUnit, 0));
    }
    
    public final ScheduledFuture scheduleWithFixedDelay(final Runnable runnable, final long n, final long n2, final TimeUnit timeUnit) {
        return (ScheduledFuture)new aw0((zv0)new vv0(this, runnable, n, n2, timeUnit, 1));
    }
    
    public final void shutdown() {
        throw new UnsupportedOperationException("Shutting down is not allowed.");
    }
    
    public final List shutdownNow() {
        throw new UnsupportedOperationException("Shutting down is not allowed.");
    }
    
    public final Future submit(final Runnable runnable) {
        return this.c.submit(runnable);
    }
    
    public final Future submit(final Runnable runnable, final Object o) {
        return this.c.submit(runnable, o);
    }
    
    public final Future submit(final Callable callable) {
        return this.c.submit(callable);
    }
}
