import org.json.JSONObject;

public interface sx4
{
    tx4 a(final JSONObject p0, final String p1);
}
