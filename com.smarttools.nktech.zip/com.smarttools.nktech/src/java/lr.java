import com.google.zxing.BarcodeFormat;

public final class lr
{
    public final String a;
    public final BarcodeFormat b;
    public final float c;
    
    public lr(final String a, final BarcodeFormat b, final float c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof lr)) {
            return false;
        }
        final lr lr = (lr)o;
        return kl1.b((Object)this.a, (Object)lr.a) && this.b == lr.b && Float.compare(this.c, lr.c) == 0;
    }
    
    @Override
    public final int hashCode() {
        return Float.hashCode(this.c) + (this.b.hashCode() + this.a.hashCode() * 31) * 31;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("CodeType(name=");
        sb.append(this.a);
        sb.append(", format=");
        sb.append((Object)this.b);
        sb.append(", aspectRatio=");
        sb.append(this.c);
        sb.append(")");
        return sb.toString();
    }
}
