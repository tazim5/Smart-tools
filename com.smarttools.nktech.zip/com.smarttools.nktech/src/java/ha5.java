import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import com.google.android.gms.internal.ads.g;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import android.content.Context;

public final class ha5
{
    public static volatile int e = 1;
    public final Context a;
    public final ExecutorService b;
    public final o76 c;
    public final boolean d;
    
    public ha5(final Context a, final ExecutorService b, final o76 c, final boolean d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public static ha5 a(final Context context, final ExecutorService executorService, final boolean b) {
        final gw2 gw2 = new gw2();
        if (b) {
            ((Executor)executorService).execute((Runnable)new ae1(25, (Object)context, (Object)gw2));
        }
        else {
            ((Executor)executorService).execute((Runnable)new oe3(1, gw2));
        }
        return new ha5(context, executorService, gw2.a, b);
    }
    
    public final void b(final int n, final long n2, final Exception ex) {
        this.d(n, n2, ex, null, null);
    }
    
    public final void c(final int n, final long n2) {
        this.d(n, n2, null, null, null);
    }
    
    public final o76 d(final int n, final long n2, final Exception ex, final String s, final String s2) {
        if (!this.d) {
            return this.c.d((Executor)this.b, (pp0)xg1.Z);
        }
        final Context a = this.a;
        final pl3 v = g.v();
        final String packageName = a.getPackageName();
        ((kp5)v).d();
        g.B((g)((kp5)v).n, packageName);
        ((kp5)v).d();
        g.w((g)((kp5)v).n, n2);
        final int e = ha5.e;
        ((kp5)v).d();
        g.C((g)((kp5)v).n, e);
        if (ex != null) {
            final StringWriter stringWriter = new StringWriter();
            ((Throwable)ex).printStackTrace(new PrintWriter((Writer)stringWriter));
            final String string = stringWriter.toString();
            ((kp5)v).d();
            g.x((g)((kp5)v).n, string);
            final String name = ex.getClass().getName();
            ((kp5)v).d();
            g.y((g)((kp5)v).n, name);
        }
        if (s2 != null) {
            ((kp5)v).d();
            g.z((g)((kp5)v).n, s2);
        }
        if (s != null) {
            ((kp5)v).d();
            g.A((g)((kp5)v).n, s);
        }
        return this.c.d((Executor)this.b, (pp0)new ki((Object)v, n, 12));
    }
}
