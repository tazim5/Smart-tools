import java.io.OutputStream;
import java.io.IOException;
import java.io.Closeable;
import com.google.android.gms.common.util.IOUtils;
import java.io.FileOutputStream;
import android.text.TextUtils;
import java.io.File;

public abstract class ax3
{
    public static final int[] a;
    
    static {
        a = new int[] { 1769172845, 1769172786, 1769172787, 1769172788, 1769172789, 1769172790, 1769172793, 1635148593, 1752589105, 1751479857, 1635135537, 1836069937, 1836069938, 862401121, 862401122, 862417462, 862417718, 862414134, 862414646, 1295275552, 1295270176, 1714714144, 1801741417, 1295275600, 1903435808, 1297305174, 1684175153, 1769172332, 1885955686 };
    }
    
    public static void a(final File file, final boolean b) {
        if (b && file.exists() && !file.isDirectory()) {
            file.delete();
        }
        if (!file.exists()) {
            file.mkdirs();
        }
    }
    
    public static File b(final File file, final String s, final String s2) {
        if (!TextUtils.isEmpty((CharSequence)s) && !TextUtils.isEmpty((CharSequence)s2)) {
            return new File(c(file, s), s2);
        }
        return null;
    }
    
    public static File c(File file, final String s) {
        if (TextUtils.isEmpty((CharSequence)s)) {
            return null;
        }
        file = new File(file, s);
        a(file, false);
        return file;
    }
    
    public static boolean d(final re3 re3, final boolean b) {
        final long zzd = re3.zzd();
        final long n = lcmp(zzd, -1L);
        long n2 = 4096L;
        if (n != 0) {
            if (zzd > 4096L) {
                n2 = n2;
            }
            else {
                n2 = zzd;
            }
        }
        final f85 f85 = new f85(64);
        int n3 = (int)n2;
        int n4 = 0;
        int n5 = 0;
        int n6;
        while (true) {
            n6 = n5;
            if (n4 >= n3) {
                break;
            }
            f85.b(8);
            if (!re3.g(f85.a, 0, 8, true)) {
                final boolean b2 = false;
                return n5 && b == b2;
            }
            final long w = f85.w();
            final int j = f85.j();
            int n7;
            long v;
            if (w == 1L) {
                re3.k(f85.a, 8, 8);
                n7 = 16;
                f85.d(16);
                v = f85.v();
            }
            else {
                v = w;
                if (w == 0L) {
                    final long zzd2 = re3.zzd();
                    v = w;
                    if (zzd2 != -1L) {
                        v = zzd2 - re3.zze() + 8L;
                    }
                }
                n7 = 8;
            }
            final long n8 = n7;
            if (v < n8) {
                return false;
            }
            final int n9 = n4 + n7;
            if (j == 1836019574) {
                int n11;
                final int n10 = n11 = n3 + (int)v;
                if (n != 0) {
                    n11 = n10;
                    if (n10 > zzd) {
                        n11 = (int)zzd;
                    }
                }
                n3 = n11;
                n4 = n9;
            }
            else {
                if (j == 1836019558 || j == 1836475768) {
                    final boolean b2 = true;
                    return n5 && b == b2;
                }
                int n12 = ((j != 1835295092 ^ true) ? 1 : 0) | n5;
                if (n9 + v - n8 >= n3) {
                    n6 = n12;
                    break;
                }
                final int n13 = (int)(v - n8);
                final int n14 = n9 + n13;
                boolean b3;
                if (j == 1718909296) {
                    if (n13 < 8) {
                        return false;
                    }
                    f85.b(n13);
                    re3.k(f85.a, 0, n13);
                    for (int i = 0; i < n13 >> 2; ++i) {
                        if (i != 1) {
                            final int k = f85.j();
                            Label_0448: {
                                if (k >>> 8 != 3368816) {
                                    int n15;
                                    if ((n15 = k) == 1751476579) {
                                        n15 = 1751476579;
                                    }
                                    final int[] a = ax3.a;
                                    for (int l = 0; l < 29; ++l) {
                                        if (a[l] == n15) {
                                            break Label_0448;
                                        }
                                    }
                                    continue;
                                }
                            }
                            n12 = 1;
                            break;
                        }
                        f85.f(4);
                    }
                    if (n12 == 0) {
                        return false;
                    }
                    b3 = (n12 != 0);
                }
                else {
                    b3 = (n12 != 0);
                    if (n13 != 0) {
                        re3.b(n13);
                        b3 = (n12 != 0);
                    }
                }
                n4 = n14;
                n5 = (b3 ? 1 : 0);
            }
        }
        final boolean b2 = false;
        n5 = n6;
        return n5 && b == b2;
    }
    
    public static boolean e(final File file) {
        if (!file.exists()) {
            return true;
        }
        final File[] listFiles = file.listFiles();
        int n3;
        if (listFiles != null) {
            int n = 1;
            int n2 = 0;
            while (true) {
                n3 = n;
                if (n2 >= listFiles.length) {
                    break;
                }
                final File file2 = listFiles[n2];
                if (file2 != null && e(file2) && n != 0) {
                    n = 1;
                }
                else {
                    n = 0;
                }
                ++n2;
            }
        }
        else {
            n3 = 1;
        }
        return file.delete() && n3 != 0;
    }
    
    public static boolean f(final File file, final byte[] array) {
        try {
            final FileOutputStream fileOutputStream = new FileOutputStream(file);
            try {
                fileOutputStream.write(array);
                ((OutputStream)fileOutputStream).flush();
                IOUtils.closeQuietly((Closeable)fileOutputStream);
                return true;
            }
            catch (final IOException ex) {}
        }
        catch (final IOException ex2) {
            goto Label_0050;
        }
    }
}
