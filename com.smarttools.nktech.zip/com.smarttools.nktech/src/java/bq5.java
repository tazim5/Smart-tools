import java.util.List;

public abstract class bq5
{
    public static final zp5 a;
    public static final aq5 b;
    
    static {
        a = (zp5)new Object();
        b = (aq5)new Object();
    }
    
    public abstract List a(final long p0, final Object p1);
    
    public abstract void b(final long p0, final Object p1);
    
    public abstract void c(final Object p0, final long p1, final Object p2);
}
