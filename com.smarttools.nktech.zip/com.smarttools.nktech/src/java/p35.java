public final class p35 implements h32
{
    public static final p35 a;
    
    static {
        a = (p35)new Object();
        f83.q(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, new og3(1)), 2)));
    }
}
