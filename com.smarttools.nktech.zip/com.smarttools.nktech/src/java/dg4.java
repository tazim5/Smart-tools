import android.os.IBinder;
import com.google.android.gms.ads.internal.client.zzdn;
import android.os.IInterface;
import com.google.android.gms.ads.internal.client.zzdf;
import android.os.Parcel;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.ads.internal.client.zzdg;
import android.os.RemoteException;
import android.app.Activity;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzbu;

public final class dg4 extends ho3 implements op3
{
    public final cg4 c;
    public final zzbu n;
    public final r45 v;
    public boolean w;
    public final gs4 x;
    
    public dg4(final cg4 c, final zzbu n, final r45 v, final gs4 x) {
        super("com.google.android.gms.ads.internal.appopen.client.IAppOpenAd");
        this.w = (boolean)zzba.zzc().a(cs3.w0);
        this.c = c;
        this.n = n;
        this.v = v;
        this.x = x;
    }
    
    public final void H0(final th1 th1, final up3 up3) {
        try {
            this.v.w.set((Object)up3);
            this.c.c(this.w, (Activity)n32.F(th1));
        }
        catch (final RemoteException ex) {
            d94.zzl("#007 Could not call remote method.", (Throwable)ex);
        }
    }
    
    public final void b0(final zzdg zzdg) {
        Preconditions.checkMainThread("setOnPaidEventListener must be called on the main UI thread.");
        final r45 v = this.v;
        if (v != null) {
            try {
                if (!zzdg.zzf()) {
                    this.x.b();
                }
            }
            catch (final RemoteException ex) {
                d94.zzf("Error in making CSI ping for reporting paid event callback", (Throwable)ex);
            }
            v.z.set((Object)zzdg);
        }
    }
    
    public final void d1(final boolean w) {
        this.w = w;
    }
    
    public final boolean zzbK(final int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        switch (n) {
            default: {
                return false;
            }
            case 7: {
                final zzdg zzb = zzdf.zzb(parcel.readStrongBinder());
                io3.b(parcel);
                this.b0(zzb);
                parcel2.writeNoException();
                break;
            }
            case 6: {
                final boolean f = io3.f(parcel);
                io3.b(parcel);
                this.w = f;
                parcel2.writeNoException();
                break;
            }
            case 5: {
                final zzdn zzf = this.zzf();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzf);
                break;
            }
            case 4: {
                final th1 d = n32.D(parcel.readStrongBinder());
                final IBinder strongBinder = parcel.readStrongBinder();
                Object o;
                if (strongBinder == null) {
                    o = null;
                }
                else {
                    final IInterface queryLocalInterface = strongBinder.queryLocalInterface("com.google.android.gms.ads.internal.appopen.client.IAppOpenFullScreenContentCallback");
                    if (queryLocalInterface instanceof up3) {
                        o = queryLocalInterface;
                    }
                    else {
                        o = new go3(strongBinder, "com.google.android.gms.ads.internal.appopen.client.IAppOpenFullScreenContentCallback");
                    }
                }
                io3.b(parcel);
                this.H0(d, (up3)o);
                parcel2.writeNoException();
                break;
            }
            case 3: {
                final IBinder strongBinder2 = parcel.readStrongBinder();
                if (strongBinder2 != null) {
                    final IInterface queryLocalInterface2 = strongBinder2.queryLocalInterface("com.google.android.gms.ads.internal.appopen.client.IAppOpenAdPresentationCallback");
                    if (queryLocalInterface2 instanceof sp3) {
                        final sp3 sp3 = (sp3)queryLocalInterface2;
                    }
                }
                io3.b(parcel);
                parcel2.writeNoException();
                break;
            }
            case 2: {
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)this.n);
                break;
            }
        }
        return true;
    }
    
    public final zzdn zzf() {
        if (!(boolean)zzba.zzc().a(cs3.V5)) {
            return null;
        }
        return (zzdn)((dh4)this.c).f;
    }
}
