import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;

public final class lg extends qh
{
    public static final String h;
    
    static {
        h = fs1.g("BatteryNotLowTracker");
    }
    
    public final Object a() {
        final IntentFilter intentFilter = new IntentFilter("android.intent.action.BATTERY_CHANGED");
        final Context b = ((yo0)this).b;
        Object value = null;
        final Intent registerReceiver = b.registerReceiver((BroadcastReceiver)null, intentFilter);
        boolean b2 = false;
        if (registerReceiver == null) {
            fs1.e().d(lg.h, "getInitialState - null intent received", new Throwable[0]);
        }
        else {
            final int intExtra = registerReceiver.getIntExtra("status", -1);
            final float n = registerReceiver.getIntExtra("level", -1) / (float)registerReceiver.getIntExtra("scale", -1);
            if (intExtra == 1 || n > 0.15f) {
                b2 = true;
            }
            value = b2;
        }
        return value;
    }
    
    public final IntentFilter f() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.BATTERY_OKAY");
        intentFilter.addAction("android.intent.action.BATTERY_LOW");
        return intentFilter;
    }
    
    public final void g(final Intent intent) {
        if (intent.getAction() == null) {
            return;
        }
        final fs1 e = fs1.e();
        intent.getAction();
        e.a(new Throwable[0]);
        final String action = intent.getAction();
        action.getClass();
        if (!action.equals((Object)"android.intent.action.BATTERY_OKAY")) {
            if (action.equals((Object)"android.intent.action.BATTERY_LOW")) {
                ((yo0)this).c((Object)Boolean.FALSE);
            }
        }
        else {
            ((yo0)this).c((Object)Boolean.TRUE);
        }
    }
}
