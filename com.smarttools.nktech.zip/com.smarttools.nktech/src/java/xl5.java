public final class xl5 extends dm5
{
    public final bm5 b;
    public final bl4 c;
    public final to5 d;
    
    public xl5(final bm5 b, final bl4 c, final to5 d) {
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final to5 b() {
        return this.d;
    }
}
