import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.IconKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material.icons.filled.PaletteKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;

public final class iz implements od1
{
    public static final iz c;
    
    static {
        c = (iz)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)24));
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.Companion.getCenterHorizontally(), composer, 48);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion2 = ComposeUiNode.Companion;
            final id1 constructor = companion2.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion2, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion2.getSetModifier());
            final ColumnScopeInstance instance = ColumnScopeInstance.INSTANCE;
            final ImageVector palette = PaletteKt.getPalette(Icons.INSTANCE.getDefault());
            final Modifier size-3ABfNKs = SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)40));
            final MaterialTheme instance2 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            IconKt.Icon-ww6aTOc(palette, (String)null, size-3ABfNKs, Color.copy-wmQWz5c$default(instance2.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0.5f, 0.0f, 0.0f, 0.0f, 14, (Object)null), composer, 432, 0);
            ap.l((float)8, companion, composer, 6);
            TextKt.Text--4IGK_g("Add colors to blend", (Modifier)null, instance2.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 6, 0, 131066);
            composer.endNode();
        }
        return t43.a;
    }
}
