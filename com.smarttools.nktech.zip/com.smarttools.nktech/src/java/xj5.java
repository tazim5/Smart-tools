public final class xj5 implements h32
{
    public static final xj5 a;
    
    static {
        a = (xj5)new Object();
        f83.q(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, f83.k(f83.h((Class)kj3.class, new kg3(1)), 2)), 3)));
    }
}
