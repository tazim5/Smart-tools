import java.util.Arrays;
import com.google.zxing.pdf417.decoder.a;
import com.google.zxing.ChecksumException;
import com.google.zxing.FormatException;

public abstract class w52
{
    public static final eq5 a;
    
    static {
        a = new eq5(7);
    }
    
    public static fh a(final rw0 rw0) {
        if (rw0 == null) {
            return null;
        }
        final tf z = rw0.Z();
        final int n = 0;
        final tf[] array = (tf[])((en4)rw0).v;
        final boolean q = rw0.Q;
        final fh fh = (fh)((en4)rw0).n;
        int[] array2;
        if (z == null) {
            array2 = null;
        }
        else {
            uf2 uf2;
            if (q) {
                uf2 = fh.b;
            }
            else {
                uf2 = fh.d;
            }
            uf2 uf3;
            if (q) {
                uf3 = fh.c;
            }
            else {
                uf3 = fh.e;
            }
            int k = ((en4)rw0).K((int)uf2.b);
            final int i = ((en4)rw0).K((int)uf3.b);
            int n2 = 0;
            int max = 1;
            int f = -1;
            int f2;
            while (true) {
                f2 = z.f;
                if (k >= i) {
                    break;
                }
                final tf tf = array[k];
                if (tf != null) {
                    tf.b();
                    final int f3 = tf.f;
                    final int n3 = f3 - f;
                    if (n3 == 0) {
                        ++n2;
                    }
                    else if (n3 == 1) {
                        max = Math.max(max, n2);
                        f = tf.f;
                        n2 = 1;
                    }
                    else if (f3 >= f2) {
                        array[k] = null;
                    }
                    else {
                        n2 = 1;
                        f = f3;
                    }
                }
                ++k;
            }
            final int[] array3 = new int[f2];
            final int length = array.length;
            int n4 = 0;
            while (true) {
                array2 = array3;
                if (n4 >= length) {
                    break;
                }
                final tf tf2 = array[n4];
                if (tf2 != null) {
                    final int f4 = tf2.f;
                    if (f4 < f2) {
                        ++array3[f4];
                    }
                }
                ++n4;
            }
        }
        if (array2 == null) {
            return null;
        }
        final int length2 = array2.length;
        int j = 0;
        int max2 = -1;
        while (j < length2) {
            max2 = Math.max(max2, array2[j]);
            ++j;
        }
        final int length3 = array2.length;
        int n5 = 0;
        int n6 = 0;
        int n7;
        while (true) {
            n7 = n6;
            if (n5 >= length3) {
                break;
            }
            final int n8 = array2[n5];
            n6 += max2 - n8;
            if (n8 > 0) {
                n7 = n6;
                break;
            }
            ++n5;
        }
        int n9;
        int n10;
        for (n9 = 0, n10 = n7; n10 > 0 && array[n9] == null; --n10, ++n9) {}
        int n11 = array2.length - 1;
        int n12 = 0;
        int n13;
        while (true) {
            n13 = n12;
            if (n11 < 0) {
                break;
            }
            final int n14 = array2[n11];
            n12 += max2 - n14;
            if (n14 > 0) {
                n13 = n12;
                break;
            }
            --n11;
        }
        for (int n15 = array.length - 1; n13 > 0 && array[n15] == null; --n13, --n15) {}
        final uf2 b = fh.b;
        final uf2 d = fh.d;
        uf2 uf6;
        uf2 uf7;
        if (n10 > 0) {
            uf2 uf4;
            if (q) {
                uf4 = b;
            }
            else {
                uf4 = d;
            }
            int n16 = (int)uf4.b - n10;
            if (n16 < 0) {
                n16 = n;
            }
            final uf2 uf5 = new uf2(uf4.a, (float)n16);
            if (q) {
                uf6 = d;
                uf7 = uf5;
            }
            else {
                uf7 = b;
                uf6 = uf5;
            }
        }
        else {
            final uf2 uf8 = b;
            uf6 = d;
            uf7 = uf8;
        }
        final uf2 c = fh.c;
        final uf2 e = fh.e;
        uf2 uf11;
        uf2 uf12;
        if (n13 > 0) {
            uf2 uf9;
            if (q) {
                uf9 = c;
            }
            else {
                uf9 = e;
            }
            final int n17 = (int)uf9.b + n13;
            final int n18 = fh.a.n;
            int n19 = n17;
            if (n17 >= n18) {
                n19 = n18 - 1;
            }
            final uf2 uf10 = new uf2(uf9.a, (float)n19);
            if (q) {
                uf11 = e;
                uf12 = uf10;
            }
            else {
                uf12 = c;
                uf11 = uf10;
            }
        }
        else {
            final uf2 uf13 = c;
            uf11 = e;
            uf12 = uf13;
        }
        return new fh(fh.a, uf7, uf12, uf6, uf11);
    }
    
    public static ju0 b(final int[] array, final int[] array2, final int n) {
        if (array.length == 0) {
            throw FormatException.a();
        }
        final int n2 = 1 << n + 1;
        if (array2.length > n2 / 2 + 3 || n2 < 0 || n2 > 512) {
            throw ChecksumException.a();
        }
        final eq5 a = w52.a;
        a.getClass();
        if (array.length == 0) {
            throw new IllegalArgumentException();
        }
        final int length = array.length;
        int[] array3;
        if (length > 1 && array[0] == 0) {
            int n3;
            for (n3 = 1; n3 < length && array[n3] == 0; ++n3) {}
            if (n3 == length) {
                array3 = new int[] { 0 };
            }
            else {
                final int n4 = length - n3;
                array3 = new int[n4];
                System.arraycopy((Object)array, n3, (Object)array3, 0, n4);
            }
        }
        else {
            array3 = array;
        }
        final int[] array4 = new int[n2];
        boolean b = false;
        int n5 = n2;
        dy1 dy1;
        while (true) {
            dy1 = (dy1)a.n;
            if (n5 <= 0) {
                break;
            }
            final int n6 = dy1.a[n5];
            int n7;
            if (n6 == 0) {
                n7 = array3[array3.length - 1];
            }
            else if (n6 == 1) {
                final int length2 = array3.length;
                int a2 = 0;
                int n8 = 0;
                while (true) {
                    n7 = a2;
                    if (n8 >= length2) {
                        break;
                    }
                    a2 = dy1.a(a2, array3[n8]);
                    ++n8;
                }
            }
            else {
                int a3 = array3[0];
                final int length3 = array3.length;
                int n9 = 1;
                while (true) {
                    n7 = a3;
                    if (n9 >= length3) {
                        break;
                    }
                    a3 = dy1.a(dy1.c(n6, a3), array3[n9]);
                    ++n9;
                }
            }
            array4[n2 - n5] = n7;
            if (n7 != 0) {
                b = true;
            }
            --n5;
        }
        int n10 = 0;
        Label_1494: {
            if (!b) {
                n10 = 0;
            }
            else {
                qf1 qf1 = dy1.d;
                for (int length4 = array2.length, i = 0; i < length4; ++i) {
                    qf1 = qf1.C(new qf1(dy1, new int[] { (929 - dy1.a[array.length - 1 - array2[i]]) % 929, 1 }));
                }
                final qf1 qf2 = new qf1(dy1, array4);
                if (n2 < 0) {
                    throw new IllegalArgumentException();
                }
                final int[] array5 = new int[n2 + 1];
                array5[0] = 1;
                qf1 qf3 = new qf1(dy1, array5);
                qf1 qf4;
                if (qf3.u() < qf2.u()) {
                    qf4 = qf2;
                }
                else {
                    qf4 = qf3;
                    qf3 = qf2;
                }
                final qf1 c = dy1.c;
                qf1 d = dy1.d;
                qf1 qf5 = c;
                qf1 qf6 = qf4;
                while (true) {
                    qf1 f = qf6;
                    if (qf3.u() >= n2 / 2) {
                        if (qf3.A()) {
                            throw ChecksumException.a();
                        }
                        final int b2 = dy1.b(qf3.s(qf3.u()));
                        qf1 qf7 = c;
                        while (f.u() >= qf3.u() && !f.A()) {
                            final int n11 = f.u() - qf3.u();
                            final int c2 = dy1.c(f.s(f.u()), b2);
                            if (n11 < 0) {
                                throw new IllegalArgumentException();
                            }
                            qf1 qf8;
                            if (c2 == 0) {
                                qf8 = c;
                            }
                            else {
                                final int[] array6 = new int[n11 + 1];
                                array6[0] = c2;
                                qf8 = new qf1(dy1, array6);
                            }
                            final qf1 m = qf7.m(qf8);
                            if (n11 < 0) {
                                throw new IllegalArgumentException();
                            }
                            final dy1 dy2 = (dy1)qf3.v;
                            qf1 c3;
                            if (c2 == 0) {
                                c3 = dy2.c;
                            }
                            else {
                                final int[] array7 = (int[])qf3.n;
                                final int length5 = array7.length;
                                final int[] array8 = new int[n11 + length5];
                                for (int j = 0; j < length5; ++j) {
                                    array8[j] = dy2.c(array7[j], c2);
                                }
                                c3 = new qf1(dy2, array8);
                            }
                            f = f.F(c3);
                            qf7 = m;
                        }
                        final qf1 f2 = qf7.C(d).F(qf5);
                        final int[] array9 = (int[])f2.n;
                        final int length6 = array9.length;
                        final int[] array10 = new int[length6];
                        int n12 = 0;
                        dy1 dy3;
                        while (true) {
                            dy3 = (dy1)f2.v;
                            if (n12 >= length6) {
                                break;
                            }
                            final int n13 = array9[n12];
                            dy3.getClass();
                            array10[n12] = (929 - n13) % 929;
                            ++n12;
                        }
                        final qf1 qf9 = new qf1(dy3, array10);
                        qf5 = d;
                        d = qf9;
                        qf6 = qf3;
                        qf3 = f;
                    }
                    else {
                        final int s = d.s(0);
                        if (s == 0) {
                            throw ChecksumException.a();
                        }
                        final int b3 = dy1.b(s);
                        final qf1[] array11 = { d.B(b3), qf3.B(b3) };
                        final qf1 qf10 = array11[0];
                        final qf1 qf11 = array11[1];
                        final int u = qf10.u();
                        final int[] array12 = new int[u];
                        int n14;
                        int n15;
                        int n16;
                        for (n14 = 1, n15 = 0; n14 < 929 && n15 < u; ++n14, n15 = n16) {
                            n16 = n15;
                            if (qf10.q(n14) == 0) {
                                array12[n15] = dy1.b(n14);
                                n16 = n15 + 1;
                            }
                        }
                        if (n15 != u) {
                            throw ChecksumException.a();
                        }
                        final int u2 = qf10.u();
                        int[] array13;
                        if (u2 < 1) {
                            array13 = new int[0];
                        }
                        else {
                            final int[] array14 = new int[u2];
                            for (int k = 1; k <= u2; ++k) {
                                array14[u2 - k] = dy1.c(k, qf10.s(k));
                            }
                            if (u2 == 0) {
                                throw new IllegalArgumentException();
                            }
                            int[] array15 = array14;
                            if (u2 > 1) {
                                array15 = array14;
                                if (array14[0] == 0) {
                                    int n17;
                                    for (n17 = 1; n17 < u2 && array14[n17] == 0; ++n17) {}
                                    int[] array16;
                                    if (n17 == u2) {
                                        array16 = new int[] { 0 };
                                    }
                                    else {
                                        final int n18 = u2 - n17;
                                        final int[] array17 = new int[n18];
                                        System.arraycopy((Object)array14, n17, (Object)array17, 0, n18);
                                        array16 = array17;
                                    }
                                    array15 = array16;
                                }
                            }
                            final int[] array18 = new int[u];
                            int l = 0;
                            qf1 qf12 = qf11;
                            while (l < u) {
                                final int b4 = dy1.b(array12[l]);
                                final int q = qf12.q(b4);
                                int n19;
                                if (b4 == 0) {
                                    n19 = array15[array15.length - 1];
                                }
                                else {
                                    qf1 qf13;
                                    if (b4 == 1) {
                                        final int length7 = array15.length;
                                        int n20 = 0;
                                        int a4 = 0;
                                        while (true) {
                                            qf13 = qf12;
                                            n19 = a4;
                                            if (n20 >= length7) {
                                                break;
                                            }
                                            a4 = dy1.a(a4, array15[n20]);
                                            ++n20;
                                        }
                                    }
                                    else {
                                        int a5 = array15[0];
                                        final int length8 = array15.length;
                                        int n21 = 1;
                                        while (true) {
                                            qf13 = qf12;
                                            n19 = a5;
                                            if (n21 >= length8) {
                                                break;
                                            }
                                            a5 = dy1.a(dy1.c(b4, a5), array15[n21]);
                                            ++n21;
                                        }
                                    }
                                    qf12 = qf13;
                                }
                                array18[l] = dy1.c((929 - q) % 929, dy1.b(n19));
                                ++l;
                            }
                            array13 = array18;
                        }
                        int n22 = 0;
                        while (true) {
                            n10 = u;
                            if (n22 >= u) {
                                break Label_1494;
                            }
                            final int length9 = array.length;
                            final int n23 = array12[n22];
                            if (n23 == 0) {
                                throw new IllegalArgumentException();
                            }
                            final int n24 = length9 - 1 - dy1.b[n23];
                            if (n24 < 0) {
                                throw ChecksumException.a();
                            }
                            array[n24] = (array[n24] + 929 - array13[n22]) % 929;
                            ++n22;
                        }
                    }
                }
            }
        }
        if (array.length < 4) {
            throw FormatException.a();
        }
        final int n25 = array[0];
        if (n25 <= array.length) {
            if (n25 == 0) {
                if (n2 >= array.length) {
                    throw FormatException.a();
                }
                array[0] = array.length - n2;
            }
            final char[] a6 = com.google.zxing.pdf417.decoder.a.a;
            final w65 w65 = new w65(array.length * 2);
            int d2 = com.google.zxing.pdf417.decoder.a.d(array, 1, w65);
            final Object g = new Object();
            int n26 = 0;
            Label_2764: {
            Label_2280:
                while (true) {
                    final int n27 = array[n26];
                    if (d2 >= n27) {
                        break Label_2764;
                    }
                    int n28 = d2 + 1;
                    final int n29 = array[d2];
                    int n49 = 0;
                    int n50 = 0;
                    if (n29 != 913) {
                        Label_2700: {
                            Label_2317: {
                                switch (n29) {
                                    default: {
                                        switch (n29) {
                                            default: {
                                                n28 = com.google.zxing.pdf417.decoder.a.d(array, d2, w65);
                                                break;
                                            }
                                            case 928: {
                                                if (d2 + 3 <= n27) {
                                                    final int[] array19 = new int[2];
                                                    for (int n30 = 0; n30 < 2; ++n30, ++n28) {
                                                        array19[n30] = array[n28];
                                                    }
                                                    final String a7 = com.google.zxing.pdf417.decoder.a.a(2, array19);
                                                    Label_1764: {
                                                        if (a7.isEmpty()) {
                                                            break Label_1764;
                                                        }
                                                        try {
                                                            Integer.parseInt(a7);
                                                            final StringBuilder sb = new StringBuilder();
                                                            while (n28 < array[0] && n28 < array.length) {
                                                                final int n31 = array[n28];
                                                                if (n31 == 922 || n31 == 923) {
                                                                    break;
                                                                }
                                                                sb.append(String.format("%03d", new Object[] { n31 }));
                                                                ++n28;
                                                            }
                                                            if (sb.length() == 0) {
                                                                throw FormatException.a();
                                                            }
                                                            ((v52)g).a = sb.toString();
                                                            int n32;
                                                            if (array[n28] == 923) {
                                                                n32 = n28 + 1;
                                                            }
                                                            else {
                                                                n32 = -1;
                                                            }
                                                            while (true) {
                                                            Label_1987_Outer:
                                                                while (n28 < array[0]) {
                                                                    final int n33 = array[n28];
                                                                Label_2034:
                                                                    while (true) {
                                                                        if (n33 == 922) {
                                                                            ++n28;
                                                                            ((v52)g).b = true;
                                                                            break Label_1987;
                                                                        }
                                                                        if (n33 != 923) {
                                                                            throw FormatException.a();
                                                                        }
                                                                        Label_1995: {
                                                                            switch (array[n28 + 1]) {
                                                                                default: {
                                                                                    throw FormatException.a();
                                                                                }
                                                                                case 6: {
                                                                                    break;
                                                                                }
                                                                                case 5: {
                                                                                    break Label_1995;
                                                                                }
                                                                                case 4: {
                                                                                    break Label_2034;
                                                                                }
                                                                                case 3: {
                                                                                    final w65 w66 = new w65((byte)0, 8);
                                                                                    n28 = com.google.zxing.pdf417.decoder.a.d(array, n28 + 2, w66);
                                                                                    w66.toString();
                                                                                    continue Label_1987_Outer;
                                                                                }
                                                                                case 2: {
                                                                                    final w65 w67 = new w65((byte)0, 8);
                                                                                    n28 = com.google.zxing.pdf417.decoder.a.c(array, n28 + 2, w67);
                                                                                    try {
                                                                                        Long.parseLong(w67.toString());
                                                                                        break Label_1987;
                                                                                    }
                                                                                    catch (final NumberFormatException ex) {
                                                                                        throw FormatException.a();
                                                                                    }
                                                                                }
                                                                                case 1: {
                                                                                    final w65 w68 = new w65((byte)0, 8);
                                                                                    n28 = com.google.zxing.pdf417.decoder.a.c(array, n28 + 2, w68);
                                                                                    try {
                                                                                        Integer.parseInt(w68.toString());
                                                                                        break Label_1987;
                                                                                    }
                                                                                    catch (final NumberFormatException ex2) {
                                                                                        throw FormatException.a();
                                                                                    }
                                                                                }
                                                                                case 0: {
                                                                                    final w65 w69 = new w65((byte)0, 8);
                                                                                    n28 = com.google.zxing.pdf417.decoder.a.d(array, n28 + 2, w69);
                                                                                    w69.toString();
                                                                                    break Label_1987;
                                                                                }
                                                                            }
                                                                            final w65 w70 = new w65((byte)0, 8);
                                                                            n28 = com.google.zxing.pdf417.decoder.a.c(array, n28 + 2, w70);
                                                                            try {
                                                                                Integer.parseInt(w70.toString());
                                                                                continue Label_1987_Outer;
                                                                            }
                                                                            catch (final NumberFormatException ex3) {
                                                                                throw FormatException.a();
                                                                            }
                                                                        }
                                                                        final w65 w71 = new w65((byte)0, 8);
                                                                        n28 = com.google.zxing.pdf417.decoder.a.c(array, n28 + 2, w71);
                                                                        try {
                                                                            Long.parseLong(w71.toString());
                                                                            continue;
                                                                        }
                                                                        catch (final NumberFormatException ex4) {
                                                                            throw FormatException.a();
                                                                        }
                                                                        break;
                                                                    }
                                                                    final w65 w72 = new w65((byte)0, 8);
                                                                    n28 = com.google.zxing.pdf417.decoder.a.d(array, n28 + 2, w72);
                                                                    w72.toString();
                                                                }
                                                                if (n32 != -1) {
                                                                    int n35;
                                                                    final int n34 = n35 = n28 - n32;
                                                                    if (((v52)g).b) {
                                                                        n35 = n34 - 1;
                                                                    }
                                                                    if (n35 > 0) {
                                                                        Arrays.copyOfRange(array, n32, n35 + n32);
                                                                    }
                                                                }
                                                                break Label_2317;
                                                            }
                                                        }
                                                        catch (final NumberFormatException ex5) {
                                                            throw FormatException.a();
                                                        }
                                                    }
                                                    break Label_2280;
                                                }
                                                break Label_2280;
                                            }
                                            case 927: {
                                                d2 += 2;
                                                w65.h(array[n28]);
                                                n28 = d2;
                                                break;
                                            }
                                            case 926: {
                                                n28 = d2 + 3;
                                                break;
                                            }
                                            case 925: {
                                                n28 = d2 + 2;
                                                break;
                                            }
                                            case 924: {
                                                break Label_2317;
                                            }
                                            case 922:
                                            case 923: {
                                                throw FormatException.a();
                                            }
                                        }
                                        break;
                                    }
                                    case 901: {
                                        int n36 = 0;
                                        while (n28 < array[0] && n36 == 0) {
                                            int n37;
                                            while (true) {
                                                n37 = array[0];
                                                if (n28 >= n37 || array[n28] != 927) {
                                                    break;
                                                }
                                                w65.h(array[n28 + 1]);
                                                n28 += 2;
                                            }
                                            if (n28 >= n37 || array[n28] >= 900) {
                                                n36 = 1;
                                            }
                                            else {
                                                long n38 = 0L;
                                                int n39 = 0;
                                                int n40 = n28;
                                                final int n41 = n36;
                                                int n42;
                                                while (true) {
                                                    n42 = n40 + 1;
                                                    n38 = n38 * 900L + array[n40];
                                                    if (++n39 >= 5 || n42 >= array[0] || array[n42] >= 900) {
                                                        break;
                                                    }
                                                    n40 = n42;
                                                }
                                                if (n39 == 5) {
                                                    if (n29 == 924 || (n42 < array[0] && array[n42] < 900)) {
                                                        for (int n43 = 0; n43 < 6; ++n43) {
                                                            ((StringBuilder)w65.n).append((char)((byte)(n38 >> (5 - n43) * 8) & 0xFF));
                                                        }
                                                        final int n44 = n41;
                                                        n28 = n42;
                                                        n36 = n44;
                                                        continue;
                                                    }
                                                }
                                                final int n45 = n42 - n39;
                                                n36 = n41;
                                                n28 = n45;
                                                while (n28 < array[0] && n36 == 0) {
                                                    final int n46 = n28 + 1;
                                                    final int n47 = array[n28];
                                                    if (n47 < 900) {
                                                        ((StringBuilder)w65.n).append((char)((byte)n47 & 0xFF));
                                                        n28 = n46;
                                                    }
                                                    else if (n47 == 927) {
                                                        n28 += 2;
                                                        w65.h(array[n46]);
                                                    }
                                                    else {
                                                        n36 = 1;
                                                    }
                                                }
                                            }
                                        }
                                        final int n48 = 0;
                                        n49 = n10;
                                        n50 = n48;
                                        break Label_2700;
                                    }
                                    case 902: {
                                        n28 = com.google.zxing.pdf417.decoder.a.c(array, n28, w65);
                                        break;
                                    }
                                    case 900: {
                                        n49 = n10;
                                        n50 = 0;
                                        n28 = com.google.zxing.pdf417.decoder.a.d(array, n28, w65);
                                        break Label_2700;
                                    }
                                }
                            }
                            n49 = n10;
                            n50 = 0;
                        }
                    }
                    else {
                        final int n51 = 0;
                        final int n52 = d2 + 2;
                        w65.g((char)array[n28]);
                        n49 = n10;
                        n50 = n51;
                        n28 = n52;
                    }
                    n26 = n50;
                    n10 = n49;
                    d2 = n28;
                }
                throw FormatException.a();
            }
            if (((StringBuilder)w65.n).length() == 0) {
                final StringBuilder sb2 = (StringBuilder)w65.v;
                if (sb2 == null || sb2.length() == 0) {
                    if (((v52)g).a == null) {
                        throw FormatException.a();
                    }
                }
            }
            final ju0 ju0 = new ju0(w65.toString(), String.valueOf(n), (byte[])null);
            ju0.g = g;
            ju0.e = n10;
            ju0.f = array2.length;
            return ju0;
        }
        throw FormatException.a();
    }
    
    public static tf c(final qg qg, int i, int j, final boolean b, int n, int n2, int n3, int n4) {
        int n5 = i;
        if (b) {
            i = -1;
        }
        else {
            i = 1;
        }
        boolean b2 = b;
        int n6 = n;
        int n7 = 0;
        int n8 = i;
    Label_0115:
        while (true) {
            i = n6;
            if (n7 >= 2) {
                break;
            }
            while (true) {
                if (b2) {
                    if (n6 < n5) {
                        break;
                    }
                }
                else if (n6 >= j) {
                    break;
                }
                if (b2 != qg.b(n6, n2)) {
                    break;
                }
                if (Math.abs(n - n6) > 2) {
                    i = n;
                    break Label_0115;
                }
                n6 += n8;
            }
            n8 = -n8;
            b2 ^= true;
            ++n7;
        }
        final int[] array = new int[8];
        int n9;
        if (b) {
            n9 = 1;
        }
        else {
            n9 = -1;
        }
        boolean b3 = b;
        int n10 = i;
        n = 0;
        while (true) {
            if (b) {
                if (n10 >= j) {
                    break;
                }
            }
            else if (n10 < n5) {
                break;
            }
            if (n >= 8) {
                break;
            }
            if (qg.b(n10, n2) == b3) {
                ++array[n];
                n10 += n9;
            }
            else {
                ++n;
                b3 ^= true;
            }
        }
        int[] array2 = array;
        if (n != 8) {
            if (b) {
                n5 = j;
            }
            if (n10 == n5 && n == 7) {
                array2 = array;
            }
            else {
                array2 = null;
            }
        }
        if (array2 == null) {
            return null;
        }
        final int d = ex5.d(array2);
        if (b) {
            n2 = i + d;
            n = i;
        }
        else {
            for (j = 0; j < array2.length / 2; ++j) {
                n = array2[j];
                array2[j] = array2[array2.length - 1 - j];
                array2[array2.length - 1 - j] = n;
            }
            n = i - d;
            n2 = i;
        }
        if (n3 - 2 > d || d > n4 + 2) {
            return null;
        }
        final float[][] a = s52.a;
        final float n11 = (float)ex5.d(array2);
        final int[] array3 = new int[8];
        i = 0;
        n4 = 0;
        j = 0;
        while (i < 17) {
            final float n12 = n11 / 34.0f;
            final float n13 = i * n11 / 17.0f;
            final int n14 = array2[j] + n4;
            n3 = j;
            if (n14 <= n13 + n12) {
                n3 = j + 1;
                n4 = n14;
            }
            ++array3[n3];
            ++i;
            j = n3;
        }
        long n15 = 0L;
        for (i = 0; i < 8; ++i) {
            for (j = 0; j < array3[i]; ++j) {
                if (i % 2 == 0) {
                    n3 = 1;
                }
                else {
                    n3 = 0;
                }
                n15 = (n15 << 1 | (long)n3);
            }
        }
        i = (int)n15;
        final int[] b4 = fr3.b;
        j = Arrays.binarySearch(b4, i & 0x3FFFF);
        final int[] c = fr3.c;
        if (j < 0) {
            j = -1;
        }
        else {
            j = (c[j] - 1) % 929;
        }
        if (j == -1) {
            i = -1;
        }
        if (i == -1) {
            j = ex5.d(array2);
            final float[] array4 = new float[8];
            if (j > 1) {
                for (i = 0; i < 8; ++i) {
                    array4[i] = array2[i] / (float)j;
                }
            }
            float n16 = Float.MAX_VALUE;
            j = -1;
            n3 = 0;
            while (true) {
                final float[][] a2 = s52.a;
                i = j;
                if (n3 >= a2.length) {
                    break;
                }
                final float[] array5 = a2[n3];
                float n17 = 0.0f;
                i = 0;
                float n18;
                while (true) {
                    n18 = n17;
                    if (i >= 8) {
                        break;
                    }
                    final float n19 = array5[i] - array4[i];
                    n17 += n19 * n19;
                    if (n17 >= n16) {
                        n18 = n17;
                        break;
                    }
                    ++i;
                }
                float n20 = n16;
                if (n18 < n16) {
                    j = b4[n3];
                    n20 = n18;
                }
                ++n3;
                n16 = n20;
            }
        }
        j = Arrays.binarySearch(b4, i & 0x3FFFF);
        if (j < 0) {
            j = -1;
        }
        else {
            j = (c[j] - 1) % 929;
        }
        if (j == -1) {
            return null;
        }
        final int[] array6 = new int[8];
        n3 = 7;
        n4 = 0;
        while (true) {
            final int n21 = i & 0x1;
            if (n21 != n4) {
                if (--n3 < 0) {
                    break;
                }
                n4 = n21;
            }
            ++array6[n3];
            i >>= 1;
        }
        return new tf(n, n2, (array6[0] - array6[2] + array6[4] - array6[6] + 9) % 9, j, 1);
    }
    
    public static rw0 d(final qg qg, final fh fh, final uf2 uf2, final boolean b, final int n, final int n2) {
        final rw0 rw0 = new rw0(fh, b);
        for (int i = 0; i < 2; ++i) {
            int n3;
            if (i == 0) {
                n3 = 1;
            }
            else {
                n3 = -1;
            }
            int n4 = (int)uf2.a;
            for (int n5 = (int)uf2.b; n5 <= fh.i && n5 >= fh.h; n5 += n3) {
                final tf c = c(qg, 0, qg.c, b, n4, n5, n, n2);
                if (c != null) {
                    ((tf[])((en4)rw0).v)[((en4)rw0).K(n5)] = c;
                    if (b) {
                        n4 = c.b;
                    }
                    else {
                        n4 = c.c;
                    }
                }
            }
        }
        return rw0;
    }
}
