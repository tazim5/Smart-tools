import androidx.camera.core.impl.SurfaceConfig$ConfigType;
import java.util.Locale;
import android.os.Build;
import android.graphics.Point;
import android.view.Display;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.util.Size;

public final class lz0
{
    public static final Size e;
    public static final Size f;
    public static final Size g;
    public static final Object h;
    public static volatile lz0 i;
    public final DisplayManager a;
    public volatile Size b;
    public final uu5 c;
    public final c05 d;
    
    static {
        e = new Size(1920, 1080);
        f = new Size(320, 240);
        g = new Size(640, 480);
        h = new Object();
    }
    
    public lz0(final Context context) {
        this.b = null;
        this.c = new uu5(10);
        this.d = new c05((byte)0, 6);
        this.a = (DisplayManager)context.getSystemService("display");
    }
    
    public static lz0 b(final Context context) {
        if (lz0.i == null) {
            final Object h;
            monitorenter(h = lz0.h);
            Label_0040: {
                try {
                    if (lz0.i == null) {
                        lz0.i = new lz0(context);
                    }
                    break Label_0040;
                }
                finally {
                    monitorexit(h);
                    monitorexit(h);
                }
            }
        }
        return lz0.i;
    }
    
    public static Display d(final Display[] array, final boolean b) {
        final int length = array.length;
        Display display = null;
        int n = -1;
        int n2;
        for (int i = 0; i < length; ++i, n = n2) {
            final Display display2 = array[i];
            if (b && display2.getState() == 1) {
                n2 = n;
            }
            else {
                final Point point = new Point();
                display2.getRealSize(point);
                final int n3 = point.x * point.y;
                if (n3 > (n2 = n)) {
                    display = display2;
                    n2 = n3;
                }
            }
        }
        return display;
    }
    
    public final Size a() {
        final Point point = new Point();
        this.c(false).getRealSize(point);
        final Size size = new Size(point.x, point.y);
        final Size a = yn2.a;
        final int width = size.getWidth();
        Size g = size;
        if (size.getHeight() * width < yn2.a(lz0.f)) {
            Size size2;
            if (this.d.n != null) {
                size2 = (Size)zn2.a.get((Object)Build.MODEL.toUpperCase(Locale.US));
            }
            else {
                size2 = null;
            }
            if ((g = size2) == null) {
                g = lz0.g;
            }
        }
        Size size3 = g;
        if (g.getHeight() > g.getWidth()) {
            size3 = new Size(g.getHeight(), g.getWidth());
        }
        final int width2 = size3.getWidth();
        final int height = size3.getHeight();
        final Size e = lz0.e;
        final int width3 = e.getWidth();
        Size size4 = size3;
        if (height * width2 > e.getHeight() * width3) {
            size4 = e;
        }
        Size size5;
        if (this.c.n == null) {
            size5 = size4;
        }
        else {
            final Size a2 = o71.a(SurfaceConfig$ConfigType.c);
            if (a2 == null) {
                size5 = size4;
            }
            else {
                final int width4 = a2.getWidth();
                final int height2 = a2.getHeight();
                final int width5 = size4.getWidth();
                size5 = size4;
                if (height2 * width4 > size4.getHeight() * width5) {
                    size5 = a2;
                }
            }
        }
        return size5;
    }
    
    public final Display c(final boolean b) {
        final Display[] displays = this.a.getDisplays();
        if (displays.length == 1) {
            return displays[0];
        }
        final Display d = d(displays, b);
        Display d2;
        if ((d2 = d) == null) {
            d2 = d;
            if (b) {
                d2 = d(displays, false);
            }
        }
        if (d2 != null) {
            return d2;
        }
        throw new IllegalArgumentException("No display can be found from the input display manager!");
    }
    
    public final Size e() {
        if (this.b != null) {
            return this.b;
        }
        return this.b = this.a();
    }
}
