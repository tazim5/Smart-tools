import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class j66
{
    public static final AtomicLong b;
    public final Map a;
    
    static {
        b = new AtomicLong();
    }
    
    public j66(final Map a) {
        this.a = a;
    }
}
