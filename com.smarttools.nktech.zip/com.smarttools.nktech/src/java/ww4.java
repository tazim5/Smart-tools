import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase$CursorFactory;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;

public final class ww4 extends SQLiteOpenHelper
{
    public ww4(final Context context) {
        super(context, "OfflineUpload.db", (SQLiteDatabase$CursorFactory)null, 1);
    }
    
    public final void onCreate(final SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE offline_signal_contents (timestamp INTEGER PRIMARY_KEY, serialized_proto_data BLOB)");
        sqLiteDatabase.execSQL("CREATE TABLE offline_signal_statistics (statistic_name TEXT PRIMARY_KEY, value INTEGER)");
        hp3.e(sqLiteDatabase, "failed_requests");
        hp3.e(sqLiteDatabase, "total_requests");
        hp3.e(sqLiteDatabase, "completed_requests");
        final ContentValues contentValues = new ContentValues();
        contentValues.put("statistic_name", "last_successful_request_time");
        contentValues.put("value", Long.valueOf(0L));
        sqLiteDatabase.insert("offline_signal_statistics", (String)null, contentValues);
    }
    
    public final void onDowngrade(final SQLiteDatabase sqLiteDatabase, final int n, final int n2) {
        this.onUpgrade(sqLiteDatabase, n, n2);
    }
    
    public final void onUpgrade(final SQLiteDatabase sqLiteDatabase, final int n, final int n2) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS offline_signal_contents");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS offline_signal_statistics");
    }
}
