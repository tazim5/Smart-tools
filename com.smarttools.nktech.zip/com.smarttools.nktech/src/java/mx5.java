import java.nio.Buffer;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;

public abstract class mx5
{
    public static bw1 a(final MappedByteBuffer mappedByteBuffer) {
        final ByteBuffer duplicate = ((ByteBuffer)mappedByteBuffer).duplicate();
        duplicate.order(ByteOrder.BIG_ENDIAN);
        duplicate.position(((Buffer)duplicate).position() + 4);
        final int n = duplicate.getShort() & 0xFFFF;
        if (n <= 100) {
            duplicate.position(((Buffer)duplicate).position() + 6);
            final int n2 = 0;
            while (true) {
                for (int i = 0; i < n; ++i) {
                    final int int1 = duplicate.getInt();
                    duplicate.position(((Buffer)duplicate).position() + 4);
                    final long n3 = (long)duplicate.getInt() & 0xFFFFFFFFL;
                    duplicate.position(((Buffer)duplicate).position() + 4);
                    if (1835365473 == int1) {
                        if (n3 != -1L) {
                            duplicate.position(((Buffer)duplicate).position() + (int)(n3 - ((Buffer)duplicate).position()));
                            duplicate.position(((Buffer)duplicate).position() + 12);
                            final long n4 = duplicate.getInt();
                            for (int n5 = n2; n5 < (n4 & 0xFFFFFFFFL); ++n5) {
                                final int int2 = duplicate.getInt();
                                final long n6 = duplicate.getInt();
                                duplicate.getInt();
                                if (1164798569 == int2 || 1701669481 == int2) {
                                    duplicate.position((int)((n6 & 0xFFFFFFFFL) + n3));
                                    final it1 it1 = new it1();
                                    duplicate.order(ByteOrder.LITTLE_ENDIAN);
                                    final int c = ((Buffer)duplicate).position() + duplicate.getInt(((Buffer)duplicate).position());
                                    it1.w = duplicate;
                                    it1.c = c;
                                    final int n7 = c - duplicate.getInt(c);
                                    it1.n = n7;
                                    it1.v = ((ByteBuffer)it1.w).getShort(n7);
                                    return (bw1)it1;
                                }
                            }
                        }
                        throw new IOException("Cannot read metadata.");
                    }
                }
                final long n3 = -1L;
                continue;
            }
        }
        throw new IOException("Cannot read metadata.");
    }
}
