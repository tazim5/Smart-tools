import android.app.UiModeManager;

public abstract class eu3
{
    public static final hb3 a;
    public static final hb3 b;
    public static final hb3 c;
    public static final hb3 d;
    public static final hb3 e;
    public static final hb3 f;
    public static final hb3 g;
    public static UiModeManager h;
    
    static {
        a = new hb3(1, 2, 0);
        b = new hb3(3, 4, 1);
        c = new hb3(4, 5, 2);
        d = new hb3(6, 7, 3);
        e = new hb3(7, 8, 4);
        f = new hb3(8, 9, 5);
        g = new hb3(11, 12, 6);
    }
}
