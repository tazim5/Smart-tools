import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ButtonKt;
import com.smarttools.nktech.features.tools.text.e;
import androidx.compose.material3.TopAppBarScrollBehavior;
import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.MutableFloatState;
import androidx.compose.runtime.State;
import android.content.Context;
import javax.crypto.spec.SecretKeySpec;
import androidx.compose.runtime.snapshots.SnapshotStateList;
import androidx.compose.runtime.MutableState;

public final class j5 implements nd1
{
    public final int c;
    public final Object n;
    public final Object v;
    public final MutableState w;
    public final Object x;
    public final Object y;
    public final Object z;
    
    public j5(final ai2 z, final SnapshotStateList x, final dq0 n, final SecretKeySpec v, final Context y, final MutableState w) {
        this.c = 5;
        this.z = z;
        this.x = x;
        this.n = n;
        this.v = v;
        this.y = y;
        this.w = w;
    }
    
    public j5(final Context y, final qo2 z, final MutableState w, final id1 n, final MutableState x, final State v) {
        this.c = 0;
        this.y = y;
        this.z = z;
        this.w = w;
        this.n = n;
        this.x = x;
        this.v = v;
    }
    
    public j5(final SnapshotStateList y, final MutableState w, final MutableState x, final MutableState z, final MutableFloatState n, final MutableState v) {
        this.c = 3;
        this.y = y;
        this.w = w;
        this.x = x;
        this.z = z;
        this.n = n;
        this.v = v;
    }
    
    public j5(final qo2 y, final dq0 z, final MutableState w, final MutableState x, final MutableState n, final MutableState v) {
        this.c = 4;
        this.y = y;
        this.z = z;
        this.w = w;
        this.x = x;
        this.n = n;
        this.v = v;
    }
    
    public j5(final so2 z, final MutableIntState x, final Context y, final dq0 n, final MutableState w, final SnapshotStateList v) {
        this.c = 6;
        this.z = z;
        this.x = x;
        this.y = y;
        this.n = n;
        this.w = w;
        this.v = v;
    }
    
    public final Object invoke(Object o, Object rememberedValue) {
        switch (this.c) {
            default: {
                final Composer composer = (Composer)o;
                if ((((Number)rememberedValue).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                }
                else {
                    AppBarKt.TopAppBar-GHTll3U((nd1)jk0.a, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(921946872, true, (Object)new wu1((Object)this.z, 19), composer, 54), (od1)ComposableLambdaKt.rememberComposableLambda(2044501039, true, (Object)new ye1((MutableIntState)this.x, (Context)this.y, (dq0)this.n, this.w, (SnapshotStateList)this.v), composer, 54), 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer, 3462, 178);
                }
                return t43.a;
            }
            case 5: {
                final Composer composer2 = (Composer)o;
                if ((((Number)rememberedValue).intValue() & 0xB) == 0x2 && composer2.getSkipping()) {
                    composer2.skipToGroupEnd();
                }
                else {
                    ButtonKt.Button((id1)new e((ai2)this.z, (SnapshotStateList)this.x, (dq0)this.n, (SecretKeySpec)this.v, (Context)this.y, this.w), (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)fb0.o, composer2, 805306368, 510);
                }
                return t43.a;
            }
            case 4: {
                final Composer composer3 = (Composer)o;
                if ((((Number)rememberedValue).intValue() & 0xB) == 0x2 && composer3.getSkipping()) {
                    composer3.skipToGroupEnd();
                }
                else {
                    AppBarKt.TopAppBar-GHTll3U((nd1)x40.a, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(-247934915, true, (Object)new q((Object)this.y, 22), composer3, 54), (od1)ComposableLambdaKt.rememberComposableLambda(-58857818, true, (Object)new ye1((dq0)this.z, this.w, (MutableState)this.x, (MutableState)this.n, (MutableState)this.v), composer3, 54), 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer3, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer3, 3462, 178);
                }
                return t43.a;
            }
            case 3: {
                final Composer composer4 = (Composer)o;
                if ((((Number)rememberedValue).intValue() & 0xB) == 0x2 && composer4.getSkipping()) {
                    composer4.skipToGroupEnd();
                }
                else {
                    composer4.startReplaceGroup(430114788);
                    rememberedValue = composer4.rememberedValue();
                    if ((o = rememberedValue) == Composer.Companion.getEmpty()) {
                        o = new ms((SnapshotStateList)this.y, this.w, (MutableState)this.x, (MutableState)this.z, (MutableFloatState)this.n, (MutableState)this.v);
                        composer4.updateRememberedValue(o);
                    }
                    final id1 id1 = (id1)o;
                    composer4.endReplaceGroup();
                    ButtonKt.TextButton(id1, (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)i20.e, composer4, 805306374, 510);
                }
                return t43.a;
            }
            case 2: {
                final Composer composer5 = (Composer)o;
                if ((((Number)rememberedValue).intValue() & 0xB) == 0x2 && composer5.getSkipping()) {
                    composer5.skipToGroupEnd();
                }
                else {
                    AppBarKt.TopAppBar-GHTll3U((nd1)xy.a, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(-58665371, true, (Object)new q((Object)this.y, 8), composer5, 54), (od1)ComposableLambdaKt.rememberComposableLambda(2035006300, true, (Object)new ab((id1)this.n, (State)this.v, this.w, (MutableState)this.x, (MutableState)this.z, 1), composer5, 54), 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer5, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer5, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer5, 3462, 178);
                }
                return t43.a;
            }
            case 1: {
                final Composer composer6 = (Composer)o;
                if ((((Number)rememberedValue).intValue() & 0xB) == 0x2 && composer6.getSkipping()) {
                    composer6.skipToGroupEnd();
                }
                else {
                    AppBarKt.TopAppBar-GHTll3U((nd1)rw.a, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(1653727335, true, (Object)new q((Object)this.y, 2), composer6, 54), (od1)ComposableLambdaKt.rememberComposableLambda(1594483998, true, (Object)new ab((id1)this.n, (State)this.v, this.w, (MutableState)this.x, (MutableState)this.z, 0), composer6, 54), 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer6, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer6, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer6, 3462, 178);
                }
                return t43.a;
            }
            case 0: {
                final Composer composer7 = (Composer)o;
                if ((((Number)rememberedValue).intValue() & 0xB) == 0x2 && composer7.getSkipping()) {
                    composer7.skipToGroupEnd();
                }
                else {
                    AppBarKt.TopAppBar-GHTll3U((nd1)tv.q, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(-850836513, true, (Object)new g5((Object)this.y, (Object)this.z, (Object)this.w, 0), composer7, 54), (od1)ComposableLambdaKt.rememberComposableLambda(1122944790, true, (Object)new i5((Object)this.n, (Object)this.x, (Object)this.v, 0), composer7, 54), 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer7, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer7, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer7, 3462, 178);
                }
                return t43.a;
            }
        }
    }
}
