import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Map;
import java.security.GeneralSecurityException;
import java.util.HashMap;

public final class tk5
{
    public static final tk5 b;
    public final HashMap a;
    
    static {
        b = new tk5();
    }
    
    public tk5() {
        this.a = new HashMap();
    }
    
    public final mh5 a() {
        monitorenter(this);
        try {
            if (this.a.containsKey((Object)"AES128_GCM")) {
                final mh5 mh5 = (mh5)this.a.get((Object)"AES128_GCM");
                monitorexit(this);
                return mh5;
            }
            throw new GeneralSecurityException("Name AES128_GCM does not exist");
        }
        finally {
            monitorexit(this);
            throw new GeneralSecurityException("Name AES128_GCM does not exist");
        }
    }
    
    public final void b(final String s, final mh5 obj) {
        monitorenter(this);
        Label_0128: {
            try {
                if (!this.a.containsKey((Object)s)) {
                    break Label_0128;
                }
                if (this.a.get((Object)s).equals(obj)) {
                    monitorexit(this);
                    return;
                }
                final String value = String.valueOf(this.a.get((Object)s));
                final String value2 = String.valueOf((Object)obj);
                final StringBuilder sb = new StringBuilder("Parameters object with name ");
                sb.append(s);
                sb.append(" already exists (");
                sb.append(value);
                sb.append("), cannot insert ");
                sb.append(value2);
                throw new GeneralSecurityException(sb.toString());
            }
            finally {
                monitorexit(this);
                this.a.put((Object)s, (Object)obj);
                monitorexit(this);
            }
        }
    }
    
    public final void c(final Map map) {
        monitorenter(this);
        Label_0064: {
            try {
                for (final Map$Entry map$Entry : map.entrySet()) {
                    this.b((String)map$Entry.getKey(), (mh5)map$Entry.getValue());
                }
                break Label_0064;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
}
