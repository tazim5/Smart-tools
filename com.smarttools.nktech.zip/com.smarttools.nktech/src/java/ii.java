public final class ii extends dt5
{
    public final String a;
    
    public ii(final String a) {
        this.a = a;
    }
    
    public final boolean equals(final Object o) {
        return this == o || (o instanceof ii && kl1.b((Object)this.a, (Object)((ii)o).a));
    }
    
    public final int hashCode() {
        return this.a.hashCode();
    }
    
    public final String toString() {
        return ap.h(new StringBuilder("Error(message="), this.a, ")");
    }
}
