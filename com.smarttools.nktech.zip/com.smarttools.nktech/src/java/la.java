import java.util.AbstractList;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Iterator;
import java.util.Collection;

public final class la extends q0
{
    public static final Object[] w;
    public int c;
    public Object[] n;
    public int v;
    
    static {
        w = new Object[0];
    }
    
    public la() {
        this.n = la.w;
    }
    
    public la(final int n) {
        Object[] w;
        if (n == 0) {
            w = la.w;
        }
        else {
            if (n <= 0) {
                throw new IllegalArgumentException(e8.c(n, "Illegal Capacity: "));
            }
            w = new Object[n];
        }
        this.n = w;
    }
    
    public final void add(int n, final Object o) {
        final j0 companion = n0.Companion;
        final int size = this.size();
        companion.getClass();
        j0.b(n, size);
        if (n == this.size()) {
            this.addLast(o);
            return;
        }
        if (n == 0) {
            this.addFirst(o);
            return;
        }
        this.k();
        this.d(this.size() + 1);
        final int j = this.j(this.c + n);
        if (n < this.size() + 1 >> 1) {
            if (j == 0) {
                n = this.n.length - 1;
            }
            else {
                n = j - 1;
            }
            final int c = this.c;
            int c2;
            if (c == 0) {
                c2 = this.n.length - 1;
            }
            else {
                c2 = c - 1;
            }
            if (n >= c) {
                final Object[] n2 = this.n;
                n2[c2] = n2[c];
                wa.f(n2, n2, c, c + 1, n + 1);
            }
            else {
                final Object[] n3 = this.n;
                wa.f(n3, n3, c - 1, c, n3.length);
                final Object[] n4 = this.n;
                n4[n4.length - 1] = n4[0];
                wa.f(n4, n4, 0, 1, n + 1);
            }
            this.n[n] = o;
            this.c = c2;
        }
        else {
            n = this.c;
            n = this.j(this.size() + n);
            if (j < n) {
                final Object[] n5 = this.n;
                wa.f(n5, n5, j + 1, j, n);
            }
            else {
                final Object[] n6 = this.n;
                wa.f(n6, n6, 1, 0, n);
                final Object[] n7 = this.n;
                n7[0] = n7[n7.length - 1];
                wa.f(n7, n7, j + 1, j, n7.length - 1);
            }
            this.n[j] = o;
        }
        this.v = this.size() + 1;
    }
    
    public final boolean add(final Object o) {
        this.addLast(o);
        return true;
    }
    
    public final boolean addAll(int c, final Collection collection) {
        final j0 companion = n0.Companion;
        final int size = this.size();
        companion.getClass();
        j0.b(c, size);
        if (collection.isEmpty()) {
            return false;
        }
        if (c == this.size()) {
            return this.addAll(collection);
        }
        this.k();
        this.d(collection.size() + this.size());
        final int j = this.j(this.size() + this.c);
        final int i = this.j(this.c + c);
        final int size2 = collection.size();
        if (c < this.size() + 1 >> 1) {
            final int c2 = this.c;
            c = c2 - size2;
            if (i >= c2) {
                if (c >= 0) {
                    final Object[] n = this.n;
                    wa.f(n, n, c, c2, i);
                }
                else {
                    final Object[] n2 = this.n;
                    c += n2.length;
                    final int n3 = n2.length - c;
                    if (n3 >= i - c2) {
                        wa.f(n2, n2, c, c2, i);
                    }
                    else {
                        wa.f(n2, n2, c, c2, c2 + n3);
                        final Object[] n4 = this.n;
                        wa.f(n4, n4, 0, this.c + n3, i);
                    }
                }
            }
            else {
                final Object[] n5 = this.n;
                wa.f(n5, n5, c, c2, n5.length);
                if (size2 >= i) {
                    final Object[] n6 = this.n;
                    wa.f(n6, n6, n6.length - size2, 0, i);
                }
                else {
                    final Object[] n7 = this.n;
                    wa.f(n7, n7, n7.length - size2, 0, size2);
                    final Object[] n8 = this.n;
                    wa.f(n8, n8, 0, size2, i);
                }
            }
            this.c = c;
            this.b(this.h(i - size2), collection);
        }
        else {
            c = i + size2;
            if (i < j) {
                final int n9 = size2 + j;
                final Object[] n10 = this.n;
                if (n9 <= n10.length) {
                    wa.f(n10, n10, c, i, j);
                }
                else if (c >= n10.length) {
                    wa.f(n10, n10, c - n10.length, i, j);
                }
                else {
                    final int n11 = j - (n9 - n10.length);
                    wa.f(n10, n10, 0, n11, j);
                    final Object[] n12 = this.n;
                    wa.f(n12, n12, c, i, n11);
                }
            }
            else {
                final Object[] n13 = this.n;
                wa.f(n13, n13, size2, 0, j);
                final Object[] n14 = this.n;
                if (c >= n14.length) {
                    wa.f(n14, n14, c - n14.length, i, n14.length);
                }
                else {
                    wa.f(n14, n14, 0, n14.length - size2, n14.length);
                    final Object[] n15 = this.n;
                    wa.f(n15, n15, c, i, n15.length - size2);
                }
            }
            this.b(i, collection);
        }
        return true;
    }
    
    public final boolean addAll(final Collection collection) {
        if (collection.isEmpty()) {
            return false;
        }
        this.k();
        this.d(collection.size() + this.size());
        this.b(this.j(this.size() + this.c), collection);
        return true;
    }
    
    public final void addFirst(final Object o) {
        this.k();
        this.d(this.size() + 1);
        int c;
        if ((c = this.c) == 0) {
            c = this.n.length;
        }
        --c;
        this.c = c;
        this.n[c] = o;
        this.v = this.size() + 1;
    }
    
    public final void addLast(final Object o) {
        this.k();
        this.d(this.size() + 1);
        this.n[this.j(this.size() + this.c)] = o;
        this.v = this.size() + 1;
    }
    
    public final void b(int size, final Collection collection) {
        Iterator iterator;
        for (iterator = collection.iterator(); size < this.n.length && iterator.hasNext(); ++size) {
            this.n[size] = iterator.next();
        }
        int c;
        for (c = this.c, size = 0; size < c && iterator.hasNext(); ++size) {
            this.n[size] = iterator.next();
        }
        size = this.size();
        this.v = collection.size() + size;
    }
    
    public final void clear() {
        if (!((Collection)this).isEmpty()) {
            this.k();
            this.i(this.c, this.j(this.size() + this.c));
        }
        this.c = 0;
        this.v = 0;
    }
    
    public final boolean contains(final Object o) {
        return this.indexOf(o) != -1;
    }
    
    public final void d(int c) {
        if (c < 0) {
            throw new IllegalStateException("Deque is too big.");
        }
        final Object[] n = this.n;
        if (c <= n.length) {
            return;
        }
        if (n == la.w) {
            int n2;
            if ((n2 = c) < 10) {
                n2 = 10;
            }
            this.n = new Object[n2];
            return;
        }
        final j0 companion = n0.Companion;
        final int length = n.length;
        companion.getClass();
        final Object[] n3 = new Object[j0.d(length, c)];
        final Object[] n4 = this.n;
        wa.f(n4, n3, 0, this.c, n4.length);
        final Object[] n5 = this.n;
        final int length2 = n5.length;
        c = this.c;
        wa.f(n5, n3, length2 - c, 0, c);
        this.c = 0;
        this.n = n3;
    }
    
    public final Object e() {
        Object o;
        if (this.isEmpty()) {
            o = null;
        }
        else {
            o = this.n[this.c];
        }
        return o;
    }
    
    public final int f(int n) {
        if (n == this.n.length - 1) {
            n = 0;
        }
        else {
            ++n;
        }
        return n;
    }
    
    public final Object first() {
        if (!this.isEmpty()) {
            return this.n[this.c];
        }
        throw new NoSuchElementException("ArrayDeque is empty.");
    }
    
    public final Object g() {
        Object o;
        if (this.isEmpty()) {
            o = null;
        }
        else {
            o = this.n[this.j(ur.e((List)this) + this.c)];
        }
        return o;
    }
    
    public final Object get(final int n) {
        final j0 companion = n0.Companion;
        final int size = this.size();
        companion.getClass();
        j0.a(n, size);
        return this.n[this.j(this.c + n)];
    }
    
    public final int getSize() {
        return this.v;
    }
    
    public final int h(final int n) {
        int n2 = n;
        if (n < 0) {
            n2 = n + this.n.length;
        }
        return n2;
    }
    
    public final void i(final int n, final int n2) {
        if (n < n2) {
            Arrays.fill(this.n, n, n2, (Object)null);
        }
        else {
            final Object[] n3 = this.n;
            Arrays.fill(n3, n, n3.length, (Object)null);
            Arrays.fill(this.n, 0, n2, (Object)null);
        }
    }
    
    public final int indexOf(final Object o) {
        final int j = this.j(this.size() + this.c);
        int i = this.c;
        if (i < j) {
            while (i < j) {
                if (kl1.b(o, this.n[i])) {
                    final int n = this.c;
                    return i - n;
                }
                ++i;
            }
            return -1;
        }
        if (i >= j) {
            while (i < this.n.length) {
                if (kl1.b(o, this.n[i])) {
                    final int n = this.c;
                    return i - n;
                }
                ++i;
            }
            for (int k = 0; k < j; ++k) {
                if (kl1.b(o, this.n[k])) {
                    i = k + this.n.length;
                    final int n = this.c;
                    return i - n;
                }
            }
            return -1;
        }
        return -1;
    }
    
    public final boolean isEmpty() {
        return this.size() == 0;
    }
    
    public final int j(final int n) {
        final Object[] n2 = this.n;
        int n3 = n;
        if (n >= n2.length) {
            n3 = n - n2.length;
        }
        return n3;
    }
    
    public final void k() {
        ++((AbstractList)this).modCount;
    }
    
    public final Object last() {
        if (!this.isEmpty()) {
            return this.n[this.j(ur.e((List)this) + this.c)];
        }
        throw new NoSuchElementException("ArrayDeque is empty.");
    }
    
    public final int lastIndexOf(final Object o) {
        int j = this.j(this.size() + this.c);
        final int c = this.c;
        int n;
        if (c < j) {
            --j;
            if (c > j) {
                return -1;
            }
            while (!kl1.b(o, this.n[j])) {
                if (j == c) {
                    return -1;
                }
                --j;
            }
            n = this.c;
        }
        else {
            if (c <= j) {
                return -1;
            }
            --j;
            while (-1 < j) {
                if (kl1.b(o, this.n[j])) {
                    j += this.n.length;
                    n = this.c;
                    return j - n;
                }
                --j;
            }
            j = this.n.length - 1;
            final int c2 = this.c;
            if (c2 > j) {
                return -1;
            }
            while (!kl1.b(o, this.n[j])) {
                if (j == c2) {
                    return -1;
                }
                --j;
            }
            n = this.c;
        }
        return j - n;
    }
    
    public final boolean remove(final Object o) {
        final int index = this.indexOf(o);
        if (index == -1) {
            return false;
        }
        this.remove(index);
        return true;
    }
    
    public final boolean removeAll(final Collection collection) {
        final boolean empty = this.isEmpty();
        final int n = 0;
        final boolean b = false;
        final int n2 = 0;
        int n3 = b ? 1 : 0;
        if (!empty) {
            if (this.n.length == 0) {
                n3 = (b ? 1 : 0);
            }
            else {
                final int j = this.j(this.size() + this.c);
                int i = this.c;
                int n5;
                int n6;
                if (i < j) {
                    int n4 = i;
                    n5 = n2;
                    while (i < j) {
                        final Object o = this.n[i];
                        if (!collection.contains(o)) {
                            this.n[n4] = o;
                            ++n4;
                        }
                        else {
                            n5 = 1;
                        }
                        ++i;
                    }
                    Arrays.fill(this.n, n4, j, (Object)null);
                    n6 = n4;
                }
                else {
                    final int length = this.n.length;
                    n5 = 0;
                    int n7 = i;
                    while (i < length) {
                        final Object[] n8 = this.n;
                        final Object o2 = n8[i];
                        n8[i] = null;
                        if (!collection.contains(o2)) {
                            this.n[n7] = o2;
                            ++n7;
                        }
                        else {
                            n5 = 1;
                        }
                        ++i;
                    }
                    n6 = this.j(n7);
                    for (int k = n; k < j; ++k) {
                        final Object[] n9 = this.n;
                        final Object o3 = n9[k];
                        n9[k] = null;
                        if (!collection.contains(o3)) {
                            this.n[n6] = o3;
                            n6 = this.f(n6);
                        }
                        else {
                            n5 = 1;
                        }
                    }
                }
                n3 = n5;
                if (n5 != 0) {
                    this.k();
                    this.v = this.h(n6 - this.c);
                    n3 = n5;
                }
            }
        }
        return n3 != 0;
    }
    
    public final Object removeAt(int n) {
        final j0 companion = n0.Companion;
        final int size = this.size();
        companion.getClass();
        j0.a(n, size);
        if (n == ur.e((List)this)) {
            return this.removeLast();
        }
        if (n == 0) {
            return this.removeFirst();
        }
        this.k();
        final int j = this.j(this.c + n);
        final Object o = this.n[j];
        if (n < this.size() >> 1) {
            n = this.c;
            if (j >= n) {
                final Object[] n2 = this.n;
                wa.f(n2, n2, n + 1, n, j);
            }
            else {
                final Object[] n3 = this.n;
                wa.f(n3, n3, 1, 0, j);
                final Object[] n4 = this.n;
                n4[0] = n4[n4.length - 1];
                n = this.c;
                wa.f(n4, n4, n + 1, n, n4.length - 1);
            }
            final Object[] n5 = this.n;
            n = this.c;
            n5[n] = null;
            this.c = this.f(n);
        }
        else {
            n = this.c;
            n = this.j(ur.e((List)this) + n);
            if (j <= n) {
                final Object[] n6 = this.n;
                wa.f(n6, n6, j, j + 1, n + 1);
            }
            else {
                final Object[] n7 = this.n;
                wa.f(n7, n7, j, j + 1, n7.length);
                final Object[] n8 = this.n;
                n8[n8.length - 1] = n8[0];
                wa.f(n8, n8, 0, 1, n + 1);
            }
            this.n[n] = null;
        }
        this.v = this.size() - 1;
        return o;
    }
    
    public final Object removeFirst() {
        if (!this.isEmpty()) {
            this.k();
            final Object[] n = this.n;
            final int c = this.c;
            final Object o = n[c];
            n[c] = null;
            this.c = this.f(c);
            this.v = this.size() - 1;
            return o;
        }
        throw new NoSuchElementException("ArrayDeque is empty.");
    }
    
    public final Object removeLast() {
        if (!this.isEmpty()) {
            this.k();
            final int j = this.j(ur.e((List)this) + this.c);
            final Object[] n = this.n;
            final Object o = n[j];
            n[j] = null;
            this.v = this.size() - 1;
            return o;
        }
        throw new NoSuchElementException("ArrayDeque is empty.");
    }
    
    public final void removeRange(int i, int n) {
        final j0 companion = n0.Companion;
        final int size = this.size();
        companion.getClass();
        j0.c(i, n, size);
        final int n2 = n - i;
        if (n2 == 0) {
            return;
        }
        if (n2 == this.size()) {
            this.clear();
            return;
        }
        if (n2 == 1) {
            this.remove(i);
            return;
        }
        this.k();
        if (i < this.size() - n) {
            final int j = this.j(i - 1 + this.c);
            int n3 = this.j(n - 1 + this.c);
            n = j;
            while (i > 0) {
                final int n4 = n + 1;
                final int min = Math.min(i, Math.min(n4, n3 + 1));
                final Object[] n5 = this.n;
                final int n6 = n3 - min;
                n -= min;
                wa.f(n5, n5, n6 + 1, n + 1, n4);
                n = this.h(n);
                n3 = this.h(n6);
                i -= min;
            }
            i = this.j(this.c + n2);
            this.i(this.c, i);
            this.c = i;
        }
        else {
            final int k = this.j(this.c + n);
            i = this.j(this.c + i);
            int size2 = this.size();
            int min2 = n;
            n = k;
            while (true) {
                size2 -= min2;
                if (size2 <= 0) {
                    break;
                }
                final Object[] n7 = this.n;
                min2 = Math.min(size2, Math.min(n7.length - n, n7.length - i));
                final Object[] n8 = this.n;
                final int n9 = n + min2;
                wa.f(n8, n8, i, n, n9);
                n = this.j(n9);
                i = this.j(i + min2);
            }
            i = this.c;
            i = this.j(this.size() + i);
            this.i(this.h(i - n2), i);
        }
        this.v = this.size() - n2;
    }
    
    public final boolean retainAll(final Collection collection) {
        final boolean empty = this.isEmpty();
        final int n = 0;
        final boolean b = false;
        int n2 = 0;
        boolean b2 = b;
        if (!empty) {
            if (this.n.length == 0) {
                b2 = b;
            }
            else {
                final int j = this.j(this.size() + this.c);
                int i = this.c;
                int n4;
                if (i < j) {
                    int n3 = i;
                    while (i < j) {
                        final Object o = this.n[i];
                        if (collection.contains(o)) {
                            this.n[n3] = o;
                            ++n3;
                        }
                        else {
                            n2 = 1;
                        }
                        ++i;
                    }
                    Arrays.fill(this.n, n3, j, (Object)null);
                    n4 = n3;
                }
                else {
                    final int length = this.n.length;
                    n2 = 0;
                    int n5 = i;
                    while (i < length) {
                        final Object[] n6 = this.n;
                        final Object o2 = n6[i];
                        n6[i] = null;
                        if (collection.contains(o2)) {
                            this.n[n5] = o2;
                            ++n5;
                        }
                        else {
                            n2 = 1;
                        }
                        ++i;
                    }
                    n4 = this.j(n5);
                    for (int k = n; k < j; ++k) {
                        final Object[] n7 = this.n;
                        final Object o3 = n7[k];
                        n7[k] = null;
                        if (collection.contains(o3)) {
                            this.n[n4] = o3;
                            n4 = this.f(n4);
                        }
                        else {
                            n2 = 1;
                        }
                    }
                }
                b2 = (n2 != 0);
                if (n2 != 0) {
                    this.k();
                    this.v = this.h(n4 - this.c);
                    b2 = (n2 != 0);
                }
            }
        }
        return b2;
    }
    
    public final Object set(int j, final Object o) {
        final j0 companion = n0.Companion;
        final int size = this.size();
        companion.getClass();
        j0.a(j, size);
        j = this.j(this.c + j);
        final Object[] n = this.n;
        final Object o2 = n[j];
        n[j] = o;
        return o2;
    }
    
    public final Object[] toArray() {
        return this.toArray(new Object[this.size()]);
    }
    
    public final Object[] toArray(Object[] array) {
        if (array.length < this.size()) {
            array = (Object[])Array.newInstance((Class)array.getClass().getComponentType(), this.size());
        }
        final int j = this.j(this.size() + this.c);
        final int c = this.c;
        if (c < j) {
            wa.j(this.n, array, 0, c, j, 2);
        }
        else if (!this.isEmpty()) {
            final Object[] n = this.n;
            wa.f(n, array, 0, this.c, n.length);
            final Object[] n2 = this.n;
            wa.f(n2, array, n2.length - this.c, 0, j);
        }
        final int size = this.size();
        if (size < array.length) {
            array[size] = null;
        }
        return array;
    }
}
