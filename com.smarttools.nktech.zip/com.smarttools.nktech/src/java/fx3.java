public abstract class fx3
{
    public static final ro3 a;
    
    static {
        a = new ro3(1);
    }
    
    public static String a(final String s) {
        for (int length = s.length(), i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (char1 >= 'A' && char1 <= 'Z') {
                final char[] charArray = s.toCharArray();
                while (i < length) {
                    final char c = charArray[i];
                    if (c >= 'A' && c <= 'Z') {
                        charArray[i] = (char)(c ^ ' ');
                    }
                    ++i;
                }
                return String.valueOf(charArray);
            }
        }
        return s;
    }
    
    public static String b(final String s) {
        for (int length = s.length(), i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (char1 >= 'a' && char1 <= 'z') {
                final char[] charArray = s.toCharArray();
                while (i < length) {
                    final char c = charArray[i];
                    if (c >= 'a' && c <= 'z') {
                        charArray[i] = (char)(c ^ ' ');
                    }
                    ++i;
                }
                return String.valueOf(charArray);
            }
        }
        return s;
    }
    
    public static boolean c(final CharSequence charSequence, final String s) {
        final int length = s.length();
        if (s == charSequence) {
            return true;
        }
        if (length == charSequence.length()) {
            for (int i = 0; i < length; ++i) {
                final char char1 = s.charAt(i);
                final char char2 = charSequence.charAt(i);
                if (char1 != char2) {
                    final char c = (char)((char1 | ' ') - 97);
                    if (c >= '\u001a' || c != (char)((char2 | ' ') - 97)) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
}
