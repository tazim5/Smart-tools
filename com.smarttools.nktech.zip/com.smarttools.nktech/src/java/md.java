import java.util.Map;
import java.util.HashMap;

public final class md
{
    public final String a;
    public final Integer b;
    public final l31 c;
    public final long d;
    public final long e;
    public final HashMap f;
    
    public md(final String a, final Integer b, final l31 c, final long d, final long e, final HashMap f) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    public final String a(String s) {
        if ((s = (String)this.f.get((Object)s)) == null) {
            s = "";
        }
        return s;
    }
    
    public final int b(String s) {
        s = (String)this.f.get((Object)s);
        int intValue;
        if (s == null) {
            intValue = 0;
        }
        else {
            intValue = Integer.valueOf(s);
        }
        return intValue;
    }
    
    public final gl5 c() {
        final gl5 gl5 = new gl5(2, false);
        final String a = this.a;
        if (a == null) {
            throw new NullPointerException("Null transportName");
        }
        gl5.n = a;
        gl5.z = this.b;
        final l31 c = this.c;
        if (c != null) {
            gl5.v = c;
            gl5.w = this.d;
            gl5.x = this.e;
            gl5.y = new HashMap((Map)this.f);
            return gl5;
        }
        throw new NullPointerException("Null encodedPayload");
    }
    
    @Override
    public final boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof md) {
            final md md = (md)o;
            if (this.a.equals((Object)md.a)) {
                final Integer b2 = md.b;
                final Integer b3 = this.b;
                if (b3 == null) {
                    if (b2 != null) {
                        return false;
                    }
                }
                else if (!b3.equals((Object)b2)) {
                    return false;
                }
                if (this.c.equals(md.c) && this.d == md.d && this.e == md.e && ((Map)this.f).equals((Object)md.f)) {
                    return b;
                }
            }
            b = false;
            return b;
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        final int hashCode = this.a.hashCode();
        final Integer b = this.b;
        int hashCode2;
        if (b == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = b.hashCode();
        }
        final int hashCode3 = this.c.hashCode();
        final long d = this.d;
        final int n = (int)(d ^ d >>> 32);
        final long e = this.e;
        return (((((hashCode ^ 0xF4243) * 1000003 ^ hashCode2) * 1000003 ^ hashCode3) * 1000003 ^ n) * 1000003 ^ (int)(e ^ e >>> 32)) * 1000003 ^ ((Map)this.f).hashCode();
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("EventInternal{transportName=");
        sb.append(this.a);
        sb.append(", code=");
        sb.append((Object)this.b);
        sb.append(", encodedPayload=");
        sb.append((Object)this.c);
        sb.append(", eventMillis=");
        sb.append(this.d);
        sb.append(", uptimeMillis=");
        sb.append(this.e);
        sb.append(", autoMetadata=");
        sb.append((Object)this.f);
        sb.append("}");
        return sb.toString();
    }
}
