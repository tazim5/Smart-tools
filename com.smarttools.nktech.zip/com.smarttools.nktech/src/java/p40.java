import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material.icons.filled.ArrowBackKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;

public final class p40 implements nd1
{
    public static final p40 c;
    
    static {
        c = (p40)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(ArrowBackKt.getArrowBack(Icons.INSTANCE.getDefault()), "Back", (Modifier)null, MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurface-0d7_KjU(), composer, 48, 4);
        }
        return t43.a;
    }
}
