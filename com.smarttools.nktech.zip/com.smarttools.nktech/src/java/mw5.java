public final class mw5
{
    public final lt5 a = (lt5)zn4.n;
}
