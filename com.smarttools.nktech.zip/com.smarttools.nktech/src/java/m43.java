import androidx.compose.runtime.IntState;
import androidx.compose.runtime.FloatState;
import androidx.compose.runtime.State;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$HorizontalOrVertical;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.CardElevation;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.CardKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material.icons.filled.SpeedKt;
import java.util.Arrays;
import androidx.compose.material.icons.filled.TimerKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import com.smarttools.nktech.features.tools.text.k0;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.ProgressIndicatorKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.runtime.MutableIntState;
import androidx.compose.runtime.MutableFloatState;
import androidx.compose.runtime.MutableLongState;
import androidx.compose.runtime.MutableState;

public final class m43 implements od1
{
    public final MutableState P;
    public final dq0 Q;
    public final MutableState R;
    public final MutableState S;
    public final MutableLongState T;
    public final MutableState U;
    public final MutableState c;
    public final MutableState n;
    public final MutableFloatState v;
    public final MutableFloatState w;
    public final MutableIntState x;
    public final MutableIntState y;
    public final MutableIntState z;
    
    public m43(final MutableState c, final MutableState n, final MutableFloatState v, final MutableFloatState w, final MutableIntState x, final MutableIntState y, final MutableIntState z, final MutableState p13, final dq0 q, final MutableState r, final MutableState s, final MutableLongState t, final MutableState u) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p13;
        this.Q = q;
        this.R = r;
        this.S = s;
        this.T = t;
        this.U = u;
    }
    
    public final Object invoke(Object o, Object rememberedValue, final Object o2) {
        final PaddingValues paddingValues = (PaddingValues)o;
        final Composer composer = (Composer)rememberedValue;
        int intValue;
        final int n = intValue = ((Number)o2).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), paddingValues);
            final float n3 = 16;
            final Modifier verticalScroll$default = ScrollKt.verticalScroll$default(PaddingKt.padding-3ABfNKs(padding, Dp.constructor-impl(n3)), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$HorizontalOrVertical spacedBy-0680j_4 = instance.spacedBy-0680j_4(Dp.constructor-impl(n3));
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy((Arrangement$Vertical)spacedBy-0680j_4, companion2.getStart(), composer, 6);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, verticalScroll$default);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final MutableState c = this.c;
            if (((State)c).getValue()) {
                composer.startReplaceGroup(-130955136);
                final Modifier height-3ABfNKs = SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)200));
                final MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getCenter(), false);
                final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, height-3ABfNKs);
                final id1 constructor2 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor2);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl2 = Updater.constructor-impl(composer);
                final nd1 b2 = ap.b(companion3, constructor-impl2, maybeCachedBoxMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
                if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                    l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
                }
                Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
                final BoxScopeInstance instance3 = BoxScopeInstance.INSTANCE;
                final MeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(instance.getTop(), companion2.getCenterHorizontally(), composer, 48);
                final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
                final id1 constructor3 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor3);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl3 = Updater.constructor-impl(composer);
                final nd1 b3 = ap.b(companion3, constructor-impl3, columnMeasurePolicy2, constructor-impl3, currentCompositionLocalMap3);
                if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                    l3.i(currentCompositeKeyHash3, constructor-impl3, currentCompositeKeyHash3, b3);
                }
                Updater.set-impl(constructor-impl3, (Object)materializeModifier3, companion3.getSetModifier());
                ProgressIndicatorKt.CircularProgressIndicator-LxG7B9w((Modifier)null, 0L, 0.0f, 0L, 0, composer, 0, 31);
                ap.l(n3, companion, composer, 6);
                TextKt.Text--4IGK_g("Loading text...", (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 6, 0, 131070);
                e8.i(composer);
            }
            else {
                final MutableState n4 = this.n;
                final boolean booleanValue = (boolean)((State)n4).getValue();
                final MutableState s = this.S;
                final MutableFloatState v = this.v;
                final MutableFloatState w = this.w;
                final MutableIntState x = this.x;
                final MutableIntState y = this.y;
                final MutableIntState z = this.z;
                final MutableState p3 = this.P;
                final dq0 q = this.Q;
                final MutableState r = this.R;
                final MutableLongState t = this.T;
                final MutableState u = this.U;
                if (booleanValue) {
                    composer.startReplaceGroup(-130501482);
                    k0.c(((FloatState)v).getFloatValue(), ((FloatState)w).getFloatValue(), ((IntState)x).getIntValue(), ((IntState)y).getIntValue(), ((IntState)z).getIntValue(), ((String)((State)p3).getValue()).length(), new g43(q, c, r, p3, s, t, z, n4, u, 1), composer, 0);
                    composer.endReplaceGroup();
                }
                else {
                    composer.startReplaceGroup(-129919612);
                    final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
                    final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.getSpaceEvenly(), companion2.getTop(), composer, 6);
                    final int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap4 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier4 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
                    final id1 constructor4 = companion3.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor4);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl4 = Updater.constructor-impl(composer);
                    final nd1 b4 = ap.b(companion3, constructor-impl4, rowMeasurePolicy, constructor-impl4, currentCompositionLocalMap4);
                    if (constructor-impl4.getInserting() || !kl1.b(constructor-impl4.rememberedValue(), (Object)currentCompositeKeyHash4)) {
                        l3.i(currentCompositeKeyHash4, constructor-impl4, currentCompositeKeyHash4, b4);
                    }
                    Updater.set-impl(constructor-impl4, (Object)materializeModifier4, companion3.getSetModifier());
                    final RowScopeInstance instance4 = RowScopeInstance.INSTANCE;
                    final Icons instance5 = Icons.INSTANCE;
                    final ImageVector timer = TimerKt.getTimer(instance5.getDefault());
                    final int intValue2 = ((IntState)z).getIntValue();
                    k0.d(timer, "Time", String.format("%d:%02d", Arrays.copyOf(new Object[] { intValue2 / 60, intValue2 % 60 }, 2)), composer, 48);
                    k0.d(SpeedKt.getSpeed(instance5.getDefault()), "Progress", f83.f(du1.d(((String)((State)p3).getValue()).length() / (float)((String)((State)u).getValue()).length() * 100), "%"), composer, 48);
                    composer.endNode();
                    final Modifier fillMaxWidth$default2 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
                    final CardDefaults instance6 = CardDefaults.INSTANCE;
                    final MaterialTheme instance7 = MaterialTheme.INSTANCE;
                    final int $stable = MaterialTheme.$stable;
                    final long copy-wmQWz5c$default = Color.copy-wmQWz5c$default(instance7.getColorScheme(composer, $stable).getSurfaceVariant-0d7_KjU(), 0.3f, 0.0f, 0.0f, 0.0f, 14, (Object)null);
                    final int n5 = CardDefaults.$stable << 12;
                    CardKt.Card(fillMaxWidth$default2, (Shape)null, instance6.cardColors-ro_MJ88(copy-wmQWz5c$default, 0L, 0L, 0L, composer, n5, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(2137298164, true, (Object)new j43(u, p3), composer, 54), composer, 196614, 26);
                    CardKt.Card(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), (Shape)null, instance6.cardColors-ro_MJ88(Color.copy-wmQWz5c$default(instance7.getColorScheme(composer, $stable).getPrimaryContainer-0d7_KjU(), 0.2f, 0.0f, 0.0f, 0.0f, 14, (Object)null), 0L, 0L, 0L, composer, n5, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(-46222371, true, (Object)new l43(p3, s, t, u, n4, x, y, w, z, v), composer, 54), composer, 196614, 26);
                    if ((boolean)((State)s).getValue() || ((String)((State)p3).getValue()).length() > 0) {
                        final Modifier fillMaxWidth$default3 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
                        final MeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl((float)12)), companion2.getTop(), composer, 6);
                        final int currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                        final CompositionLocalMap currentCompositionLocalMap5 = composer.getCurrentCompositionLocalMap();
                        final Modifier materializeModifier5 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default3);
                        final id1 constructor5 = companion3.getConstructor();
                        if (composer.getApplier() == null) {
                            ComposablesKt.invalidApplier();
                        }
                        composer.startReusableNode();
                        if (composer.getInserting()) {
                            composer.createNode(constructor5);
                        }
                        else {
                            composer.useNode();
                        }
                        final Composer constructor-impl5 = Updater.constructor-impl(composer);
                        final nd1 b5 = ap.b(companion3, constructor-impl5, rowMeasurePolicy2, constructor-impl5, currentCompositionLocalMap5);
                        if (constructor-impl5.getInserting() || !kl1.b(constructor-impl5.rememberedValue(), (Object)currentCompositeKeyHash5)) {
                            l3.i(currentCompositeKeyHash5, constructor-impl5, currentCompositeKeyHash5, b5);
                        }
                        Updater.set-impl(constructor-impl5, (Object)materializeModifier5, companion3.getSetModifier());
                        composer.startReplaceGroup(-1154231863);
                        rememberedValue = composer.rememberedValue();
                        if ((o = rememberedValue) == Composer.Companion.getEmpty()) {
                            o = new b61(s, n4, u, p3, x, y, w, z, v);
                            composer.updateRememberedValue(o);
                        }
                        final id1 id1 = (id1)o;
                        composer.endReplaceGroup();
                        ButtonKt.OutlinedButton(id1, RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null), false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)km0.d, composer, 805306374, 508);
                        ButtonKt.OutlinedButton((id1)new g43(q, c, r, p3, s, t, z, n4, u, 2), RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null), false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)km0.e, composer, 805306368, 508);
                        composer.endNode();
                    }
                    composer.endReplaceGroup();
                }
            }
            b02.a(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), composer, 6);
            composer.endNode();
        }
        return t43.a;
    }
}
