import android.os.BaseBundle;
import java.util.Map;
import java.util.Iterator;
import android.os.Parcelable;
import java.util.HashMap;
import java.util.Collections;
import java.util.List;
import android.app.Activity;
import android.os.Bundle;
import android.os.Parcel;
import java.util.Random;

public final class n04 extends ho3 implements qc4
{
    public final eq5 c;
    
    public n04(final eq5 c) {
        super("com.google.android.gms.ads.measurement.IAppMeasurementProxy");
        this.c = c;
    }
    
    public final long f1() {
        final ex4 ex4 = (ex4)this.c.n;
        ex4.getClass();
        final z64 z64 = new z64();
        ex4.b((zr4)new zj4(ex4, z64, 2));
        final Long n = (Long)z64.g1((Class)Long.class, z64.F(500L));
        long longValue;
        if (n == null) {
            final long nextLong = new Random(System.nanoTime() ^ ex4.b.currentTimeMillis()).nextLong();
            final int e = ex4.e + 1;
            ex4.e = e;
            longValue = nextLong + e;
        }
        else {
            longValue = n;
        }
        return longValue;
    }
    
    public final boolean zzbK(int intValue, final Parcel parcel, final Parcel parcel2, final int n) {
        final Object o = null;
        final Activity activity = null;
        final eq5 c = this.c;
        switch (intValue) {
            default: {
                return false;
            }
            case 19: {
                final Bundle bundle = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                final ex4 ex4 = (ex4)c.n;
                ex4.getClass();
                ex4.b((zr4)new ee4(ex4, bundle, 1));
                parcel2.writeNoException();
                break;
            }
            case 18: {
                final String g = ((ex4)c.n).g;
                parcel2.writeNoException();
                parcel2.writeString(g);
                break;
            }
            case 17: {
                final ex4 ex5 = (ex4)c.n;
                ex5.getClass();
                final z64 z64 = new z64();
                ex5.b((zr4)new zj4(ex5, z64, 4));
                final String s = (String)z64.g1((Class)String.class, z64.F(500L));
                parcel2.writeNoException();
                parcel2.writeString(s);
                break;
            }
            case 16: {
                final ex4 ex6 = (ex4)c.n;
                ex6.getClass();
                final z64 z65 = new z64();
                ex6.b((zr4)new zj4(ex6, z65, 3));
                final String s2 = (String)z64.g1((Class)String.class, z65.F(500L));
                parcel2.writeNoException();
                parcel2.writeString(s2);
                break;
            }
            case 15: {
                final th1 d = n32.D(parcel.readStrongBinder());
                final String string = parcel.readString();
                final String string2 = parcel.readString();
                io3.b(parcel);
                Activity activity2 = activity;
                if (d != null) {
                    activity2 = (Activity)n32.F(d);
                }
                final ex4 ex7 = (ex4)c.n;
                ex7.getClass();
                ex7.b((zr4)new bf4(ex7, activity2, string, string2));
                parcel2.writeNoException();
                break;
            }
            case 14: {
                final String string3 = parcel.readString();
                io3.b(parcel);
                final ex4 ex8 = (ex4)c.n;
                ex8.getClass();
                ex8.b((zr4)new ui4(ex8, string3, 1));
                parcel2.writeNoException();
                break;
            }
            case 13: {
                final String string4 = parcel.readString();
                io3.b(parcel);
                final ex4 ex9 = (ex4)c.n;
                ex9.getClass();
                ex9.b((zr4)new ui4(ex9, string4, 0));
                parcel2.writeNoException();
                break;
            }
            case 12: {
                final long f1 = this.f1();
                parcel2.writeNoException();
                parcel2.writeLong(f1);
                break;
            }
            case 11: {
                final String zzi = this.zzi();
                parcel2.writeNoException();
                parcel2.writeString(zzi);
                break;
            }
            case 10: {
                final String zzf = this.zzf();
                parcel2.writeNoException();
                parcel2.writeString(zzf);
                break;
            }
            case 9: {
                final String string5 = parcel.readString();
                final String string6 = parcel.readString();
                io3.b(parcel);
                final ex4 ex10 = (ex4)c.n;
                ex10.getClass();
                final z64 z66 = new z64();
                ex10.b((zr4)new bf4(ex10, string5, (Object)string6, (Object)z66, 0));
                List emptyList;
                if ((emptyList = (List)z64.g1((Class)List.class, z66.F(5000L))) == null) {
                    emptyList = Collections.emptyList();
                }
                parcel2.writeNoException();
                parcel2.writeList(emptyList);
                break;
            }
            case 8: {
                final String string7 = parcel.readString();
                final String string8 = parcel.readString();
                final Bundle bundle2 = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                final ex4 ex11 = (ex4)c.n;
                ex11.getClass();
                ex11.b((zr4)new le4(ex11, string7, string8, bundle2, 0));
                parcel2.writeNoException();
                break;
            }
            case 7: {
                final Bundle bundle3 = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                final ex4 ex12 = (ex4)c.n;
                ex12.getClass();
                ex12.b((zr4)new ee4(ex12, bundle3, 0));
                parcel2.writeNoException();
                break;
            }
            case 6: {
                final String string9 = parcel.readString();
                io3.b(parcel);
                final ex4 ex13 = (ex4)c.n;
                ex13.getClass();
                final z64 z67 = new z64();
                ex13.b((zr4)new om4(ex13, (Object)string9, z67, 1));
                final Integer n2 = (Integer)z64.g1((Class)Integer.class, z67.F(10000L));
                if (n2 == null) {
                    intValue = 25;
                }
                else {
                    intValue = n2;
                }
                parcel2.writeNoException();
                parcel2.writeInt(intValue);
                break;
            }
            case 5: {
                final String string10 = parcel.readString();
                final String string11 = parcel.readString();
                final ClassLoader a = io3.a;
                final boolean b = parcel.readInt() != 0;
                io3.b(parcel);
                final ex4 ex14 = (ex4)c.n;
                ex14.getClass();
                final z64 z68 = new z64();
                ex14.b((zr4)new ql4(ex14, string10, string11, b, z68));
                final Bundle f2 = z68.F(5000L);
                Map emptyMap;
                if (f2 != null && ((BaseBundle)f2).size() != 0) {
                    final HashMap hashMap = new HashMap(((BaseBundle)f2).size());
                    final Iterator iterator = ((BaseBundle)f2).keySet().iterator();
                    while (true) {
                        emptyMap = (Map)hashMap;
                        if (!iterator.hasNext()) {
                            break;
                        }
                        final String s3 = (String)iterator.next();
                        final Object value = ((BaseBundle)f2).get(s3);
                        if (!(value instanceof Double) && !(value instanceof Long) && !(value instanceof String)) {
                            continue;
                        }
                        hashMap.put((Object)s3, value);
                    }
                }
                else {
                    emptyMap = Collections.emptyMap();
                }
                parcel2.writeNoException();
                parcel2.writeMap(emptyMap);
                break;
            }
            case 4: {
                final String string12 = parcel.readString();
                final String string13 = parcel.readString();
                final th1 d2 = n32.D(parcel.readStrongBinder());
                io3.b(parcel);
                Object f3 = o;
                if (d2 != null) {
                    f3 = n32.F(d2);
                }
                final ex4 ex15 = (ex4)c.n;
                ex15.getClass();
                ex15.b((zr4)new bf4(ex15, string12, (Object)string13, f3, 3));
                parcel2.writeNoException();
                break;
            }
            case 3: {
                final String string14 = parcel.readString();
                final String string15 = parcel.readString();
                final Bundle bundle4 = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                final ex4 ex16 = (ex4)c.n;
                ex16.getClass();
                ex16.b((zr4)new le4(ex16, string14, string15, bundle4, 1));
                parcel2.writeNoException();
                break;
            }
            case 2: {
                final Bundle bundle5 = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                final ex4 ex17 = (ex4)c.n;
                ex17.getClass();
                final z64 z69 = new z64();
                ex17.b((zr4)new om4(ex17, (Object)bundle5, z69, 0));
                final Bundle f4 = z69.F(5000L);
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)f4);
                break;
            }
            case 1: {
                final Bundle bundle6 = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                final ex4 ex18 = (ex4)c.n;
                ex18.getClass();
                ex18.b((zr4)new om4(ex18, (Object)bundle6, new z64(), 0));
                parcel2.writeNoException();
                break;
            }
        }
        return true;
    }
    
    public final String zzf() {
        final ex4 ex4 = (ex4)this.c.n;
        ex4.getClass();
        final z64 z64 = new z64();
        ex4.b((zr4)new zj4(ex4, z64, 1));
        return (String)z64.g1((Class)String.class, z64.F(50L));
    }
    
    public final String zzi() {
        final ex4 ex4 = (ex4)this.c.n;
        ex4.getClass();
        final z64 z64 = new z64();
        ex4.b((zr4)new zj4(ex4, z64, 0));
        return (String)z64.g1((Class)String.class, z64.F(500L));
    }
}
