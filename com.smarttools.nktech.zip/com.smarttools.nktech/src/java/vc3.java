import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import android.os.BadParcelableException;
import android.os.Parcelable;
import android.os.Parcelable$Creator;
import android.os.Parcel;

public abstract class vc3
{
    static {
        vc3.class.getClassLoader();
    }
    
    public static Parcelable a(final Parcel parcel, final Parcelable$Creator parcelable$Creator) {
        if (parcel.readInt() == 0) {
            return null;
        }
        return (Parcelable)parcelable$Creator.createFromParcel(parcel);
    }
    
    public static void b(final Parcel parcel) {
        final int dataAvail = parcel.dataAvail();
        if (dataAvail <= 0) {
            return;
        }
        throw new BadParcelableException(e8.c(dataAvail, "Parcel data not fully consumed, unread size: "));
    }
    
    public static void c(final Parcel parcel, final AbstractSafeParcelable abstractSafeParcelable) {
        if (abstractSafeParcelable == null) {
            parcel.writeInt(0);
            return;
        }
        parcel.writeInt(1);
        ((Parcelable)abstractSafeParcelable).writeToParcel(parcel, 0);
    }
    
    public static void d(final Parcel parcel, final IInterface interface1) {
        if (interface1 == null) {
            parcel.writeStrongBinder((IBinder)null);
            return;
        }
        parcel.writeStrongBinder(interface1.asBinder());
    }
}
