import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.internal.ads.l2;
import android.os.Bundle;
import android.widget.FrameLayout;

public final class ez4 extends cz4
{
    public final uc4 a;
    public final gl5 b;
    public final c05 c;
    public final il4 d;
    public final en4 e;
    public final gk4 f;
    public final FrameLayout g;
    public final al4 h;
    public final hz4 i;
    public final wx4 j;
    
    public ez4(final uc4 a, final gl5 b, final c05 c, final il4 d, final en4 e, final gk4 f, final FrameLayout g, final al4 h, final hz4 i, final wx4 j) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
    }
    
    public final u75 c(final o65 v, final Bundle w, final l2 l2, final k65 k65) {
        final gl5 b = this.b;
        b.v = v;
        b.w = w;
        b.y = new m14((Object)k65, (Object)l2, (Object)this.i, 8, false);
        if (zzba.zzc().a(cs3.Y2)) {
            b.z = this.j;
        }
        final nd4 c = ((nd4)this.a).c;
        final pi4 pi4 = new pi4(b);
        final il3 il3 = new il3(17, (Object)this.f, (Object)this.h);
        final eq5 eq5 = new eq5(this.g, 26);
        final il4 d = this.d;
        ep5.d(il4.class, d);
        final c05 c2 = this.c;
        ep5.d(c05.class, c2);
        final ur4 ur4 = new ur4(4);
        final en4 e = this.e;
        ep5.d(en4.class, e);
        final rh4 rh4 = (rh4)new vd4(c, eq5, e, d, pi4, ur4, c2, il3, (o55)null, (e55)null).k1.zzb();
        return rh4.a((yq1)rh4.b());
    }
}
