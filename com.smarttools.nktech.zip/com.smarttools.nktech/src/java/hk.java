import androidx.concurrent.futures.b;
import android.hardware.camera2.CaptureResult;
import android.hardware.camera2.CaptureFailure;
import java.util.Collections;
import androidx.camera.camera2.internal.l;
import android.hardware.camera2.TotalCaptureResult;
import android.view.Surface;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.CameraCaptureSession;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import android.hardware.camera2.CameraCaptureSession$CaptureCallback;

public final class hk extends CameraCaptureSession$CaptureCallback
{
    public final int a;
    public final Object b;
    
    public hk(final gl b) {
        this.a = 1;
        if (b != null) {
            this.b = b;
            return;
        }
        throw new NullPointerException("cameraCaptureCallback is null");
    }
    
    public hk(final List list) {
        this.a = 0;
        this.b = new ArrayList();
        for (final CameraCaptureSession$CaptureCallback cameraCaptureSession$CaptureCallback : list) {
            if (!(cameraCaptureSession$CaptureCallback instanceof ik)) {
                ((ArrayList)this.b).add((Object)cameraCaptureSession$CaptureCallback);
            }
        }
    }
    
    public void onCaptureBufferLost(final CameraCaptureSession cameraCaptureSession, final CaptureRequest captureRequest, final Surface surface, final long n) {
        switch (this.a) {
            default: {
                super.onCaptureBufferLost(cameraCaptureSession, captureRequest, surface, n);
                return;
            }
            case 0: {
                final Iterator iterator = ((ArrayList)this.b).iterator();
                while (iterator.hasNext()) {
                    p8.a((CameraCaptureSession$CaptureCallback)iterator.next(), cameraCaptureSession, captureRequest, surface, n);
                }
            }
        }
    }
    
    public void onCaptureCompleted(final CameraCaptureSession cameraCaptureSession, final CaptureRequest captureRequest, final TotalCaptureResult totalCaptureResult) {
        switch (this.a) {
            default: {
                super.onCaptureCompleted(cameraCaptureSession, captureRequest, totalCaptureResult);
                return;
            }
            case 2: {
                final Object a;
                monitorenter(a = ((l)this.b).a);
                Label_0081: {
                    try {
                        final yk2 g = ((l)this.b).g;
                        if (g == null) {
                            monitorexit(a);
                            return;
                        }
                        break Label_0081;
                    }
                    finally {
                        monitorexit(a);
                        final yk2 g;
                        final pn f = g.f;
                        ax5.a("CaptureSession");
                        final l l = (l)this.b;
                        l.q.getClass();
                        l.f(Collections.singletonList((Object)qr2.a(f)));
                        monitorexit(a);
                    }
                }
            }
            case 1: {
                super.onCaptureCompleted(cameraCaptureSession, captureRequest, totalCaptureResult);
                final Object tag = captureRequest.getTag();
                nv2 b;
                if (tag != null) {
                    jy5.a("The tagBundle object from the CaptureResult is not a TagBundle object.", tag instanceof nv2);
                    b = (nv2)tag;
                }
                else {
                    b = nv2.b;
                }
                ((gl)this.b).b((il)new en4(8, (Object)b, (Object)totalCaptureResult));
                return;
            }
            case 0: {
                final Iterator iterator = ((ArrayList)this.b).iterator();
                while (iterator.hasNext()) {
                    ((CameraCaptureSession$CaptureCallback)iterator.next()).onCaptureCompleted(cameraCaptureSession, captureRequest, totalCaptureResult);
                }
            }
        }
    }
    
    public void onCaptureFailed(final CameraCaptureSession cameraCaptureSession, final CaptureRequest captureRequest, final CaptureFailure captureFailure) {
        switch (this.a) {
            default: {
                super.onCaptureFailed(cameraCaptureSession, captureRequest, captureFailure);
                return;
            }
            case 1: {
                super.onCaptureFailed(cameraCaptureSession, captureRequest, captureFailure);
                ((gl)this.b).c((hl)new Object());
                return;
            }
            case 0: {
                final Iterator iterator = ((ArrayList)this.b).iterator();
                while (iterator.hasNext()) {
                    ((CameraCaptureSession$CaptureCallback)iterator.next()).onCaptureFailed(cameraCaptureSession, captureRequest, captureFailure);
                }
            }
        }
    }
    
    public void onCaptureProgressed(final CameraCaptureSession cameraCaptureSession, final CaptureRequest captureRequest, final CaptureResult captureResult) {
        switch (this.a) {
            default: {
                super.onCaptureProgressed(cameraCaptureSession, captureRequest, captureResult);
                return;
            }
            case 0: {
                final Iterator iterator = ((ArrayList)this.b).iterator();
                while (iterator.hasNext()) {
                    ((CameraCaptureSession$CaptureCallback)iterator.next()).onCaptureProgressed(cameraCaptureSession, captureRequest, captureResult);
                }
            }
        }
    }
    
    public void onCaptureSequenceAborted(final CameraCaptureSession cameraCaptureSession, final int n) {
        switch (this.a) {
            default: {
                super.onCaptureSequenceAborted(cameraCaptureSession, n);
                return;
            }
            case 3: {
                final q83 q83 = (q83)this.b;
                final b b = (b)q83.x;
                if (b != null) {
                    b.d = true;
                    final jj b2 = b.b;
                    if (b2 != null && ((a1)b2.n).cancel(true)) {
                        b.a = null;
                        b.b = null;
                        b.c = null;
                    }
                    q83.x = null;
                }
                return;
            }
            case 0: {
                final Iterator iterator = ((ArrayList)this.b).iterator();
                while (iterator.hasNext()) {
                    ((CameraCaptureSession$CaptureCallback)iterator.next()).onCaptureSequenceAborted(cameraCaptureSession, n);
                }
            }
        }
    }
    
    public void onCaptureSequenceCompleted(final CameraCaptureSession cameraCaptureSession, final int n, final long n2) {
        switch (this.a) {
            default: {
                super.onCaptureSequenceCompleted(cameraCaptureSession, n, n2);
                return;
            }
            case 0: {
                final Iterator iterator = ((ArrayList)this.b).iterator();
                while (iterator.hasNext()) {
                    ((CameraCaptureSession$CaptureCallback)iterator.next()).onCaptureSequenceCompleted(cameraCaptureSession, n, n2);
                }
            }
        }
    }
    
    public void onCaptureStarted(final CameraCaptureSession cameraCaptureSession, final CaptureRequest captureRequest, final long n, final long n2) {
        switch (this.a) {
            default: {
                super.onCaptureStarted(cameraCaptureSession, captureRequest, n, n2);
                return;
            }
            case 3: {
                final q83 q83 = (q83)this.b;
                final b b = (b)q83.x;
                if (b != null) {
                    b.a((Object)null);
                    q83.x = null;
                }
                return;
            }
            case 0: {
                final Iterator iterator = ((ArrayList)this.b).iterator();
                while (iterator.hasNext()) {
                    ((CameraCaptureSession$CaptureCallback)iterator.next()).onCaptureStarted(cameraCaptureSession, captureRequest, n, n2);
                }
            }
        }
    }
}
