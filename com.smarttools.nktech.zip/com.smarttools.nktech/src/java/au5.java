import kotlinx.coroutines.channels.a;
import kotlinx.coroutines.channels.BufferOverflow;

public abstract class au5
{
    public static a a(int n, final int n2, BufferOverflow bufferOverflow) {
        if ((n2 & 0x1) != 0x0) {
            n = 0;
        }
        final BufferOverflow c = BufferOverflow.c;
        if ((n2 & 0x2) != 0x0) {
            bufferOverflow = c;
        }
        Object o;
        if (n != -2) {
            if (n != -1) {
                if (n != 0) {
                    if (n != Integer.MAX_VALUE) {
                        if (bufferOverflow == c) {
                            o = new a(n, (jd1)null);
                        }
                        else {
                            o = new so0(n, bufferOverflow, (jd1)null);
                        }
                    }
                    else {
                        o = new a(Integer.MAX_VALUE, (jd1)null);
                    }
                }
                else if (bufferOverflow == c) {
                    o = new a(0, (jd1)null);
                }
                else {
                    o = new so0(1, bufferOverflow, (jd1)null);
                }
            }
            else {
                if (bufferOverflow != c) {
                    throw new IllegalArgumentException("CONFLATED capacity cannot be used with non-default onBufferOverflow");
                }
                o = new so0(1, BufferOverflow.n, (jd1)null);
            }
        }
        else if (bufferOverflow == c) {
            cp.f.getClass();
            o = new a(bp.b, (jd1)null);
        }
        else {
            o = new so0(1, bufferOverflow, (jd1)null);
        }
        return (a)o;
    }
}
