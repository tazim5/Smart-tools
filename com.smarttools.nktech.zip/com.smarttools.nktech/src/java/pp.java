import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map$Entry;
import kotlin.text.c;
import kotlin.collections.b;
import kotlin.Pair;
import java.util.ArrayList;
import androidx.compose.runtime.internal.ComposableLambda;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Map;

public final class pp implements in1, op
{
    public static final Map n;
    public static final HashMap v;
    public static final LinkedHashMap w;
    public final Class c;
    
    static {
        final Iterable iterable = (Iterable)ur.f((Object[])new Class[] { id1.class, jd1.class, nd1.class, od1.class, pd1.class, qd1.class, rd1.class, sd1.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, kd1.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, ComposableLambda.class, md1.class });
        final ArrayList list = new ArrayList(vr.l(iterable, 10));
        final Iterator iterator = iterable.iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            final Object next = iterator.next();
            if (n2 < 0) {
                ur.k();
                throw null;
            }
            list.add((Object)new Pair((Object)next, (Object)n2));
            ++n2;
        }
        n = b.f((Iterable)list);
        final HashMap hashMap = new HashMap();
        hashMap.put((Object)"boolean", (Object)"kotlin.Boolean");
        hashMap.put((Object)"char", (Object)"kotlin.Char");
        hashMap.put((Object)"byte", (Object)"kotlin.Byte");
        hashMap.put((Object)"short", (Object)"kotlin.Short");
        hashMap.put((Object)"int", (Object)"kotlin.Int");
        hashMap.put((Object)"float", (Object)"kotlin.Float");
        hashMap.put((Object)"long", (Object)"kotlin.Long");
        hashMap.put((Object)"double", (Object)"kotlin.Double");
        final HashMap hashMap2 = new HashMap();
        hashMap2.put((Object)"java.lang.Boolean", (Object)"kotlin.Boolean");
        hashMap2.put((Object)"java.lang.Character", (Object)"kotlin.Char");
        hashMap2.put((Object)"java.lang.Byte", (Object)"kotlin.Byte");
        hashMap2.put((Object)"java.lang.Short", (Object)"kotlin.Short");
        hashMap2.put((Object)"java.lang.Integer", (Object)"kotlin.Int");
        hashMap2.put((Object)"java.lang.Float", (Object)"kotlin.Float");
        hashMap2.put((Object)"java.lang.Long", (Object)"kotlin.Long");
        hashMap2.put((Object)"java.lang.Double", (Object)"kotlin.Double");
        final HashMap v2 = new HashMap();
        v2.put((Object)"java.lang.Object", (Object)"kotlin.Any");
        v2.put((Object)"java.lang.String", (Object)"kotlin.String");
        v2.put((Object)"java.lang.CharSequence", (Object)"kotlin.CharSequence");
        v2.put((Object)"java.lang.Throwable", (Object)"kotlin.Throwable");
        v2.put((Object)"java.lang.Cloneable", (Object)"kotlin.Cloneable");
        v2.put((Object)"java.lang.Number", (Object)"kotlin.Number");
        v2.put((Object)"java.lang.Comparable", (Object)"kotlin.Comparable");
        v2.put((Object)"java.lang.Enum", (Object)"kotlin.Enum");
        v2.put((Object)"java.lang.annotation.Annotation", (Object)"kotlin.Annotation");
        v2.put((Object)"java.lang.Iterable", (Object)"kotlin.collections.Iterable");
        v2.put((Object)"java.util.Iterator", (Object)"kotlin.collections.Iterator");
        v2.put((Object)"java.util.Collection", (Object)"kotlin.collections.Collection");
        v2.put((Object)"java.util.List", (Object)"kotlin.collections.List");
        v2.put((Object)"java.util.Set", (Object)"kotlin.collections.Set");
        v2.put((Object)"java.util.ListIterator", (Object)"kotlin.collections.ListIterator");
        v2.put((Object)"java.util.Map", (Object)"kotlin.collections.Map");
        v2.put((Object)"java.util.Map$Entry", (Object)"kotlin.collections.Map.Entry");
        v2.put((Object)"kotlin.jvm.internal.StringCompanionObject", (Object)"kotlin.String.Companion");
        v2.put((Object)"kotlin.jvm.internal.EnumCompanionObject", (Object)"kotlin.Enum.Companion");
        v2.putAll((Map)hashMap);
        v2.putAll((Map)hashMap2);
        for (final String s : (Iterable)hashMap.values()) {
            final StringBuilder sb = new StringBuilder("kotlin.jvm.internal.");
            sb.append(c.G(s, '.', s));
            sb.append("CompanionObject");
            final Pair pair = new Pair((Object)sb.toString(), (Object)s.concat(".Companion"));
            v2.put(pair.d(), pair.e());
        }
        for (final Map$Entry map$Entry : pp.n.entrySet()) {
            final Class clazz = (Class)map$Entry.getKey();
            final int intValue = ((Number)map$Entry.getValue()).intValue();
            final String name = clazz.getName();
            final StringBuilder sb2 = new StringBuilder("kotlin.Function");
            sb2.append(intValue);
            v2.put((Object)name, (Object)sb2.toString());
        }
        v = v2;
        final LinkedHashMap w2 = new LinkedHashMap(b.b(v2.size()));
        for (final Map$Entry map$Entry2 : (Iterable)v2.entrySet()) {
            final Object key = map$Entry2.getKey();
            final String s2 = (String)map$Entry2.getValue();
            ((Map)w2).put(key, (Object)c.G(s2, '.', s2));
        }
        w = w2;
    }
    
    public pp(final Class c) {
        this.c = c;
    }
    
    public final Class a() {
        return this.c;
    }
    
    public final String b() {
        final Class c = this.c;
        final boolean anonymousClass = c.isAnonymousClass();
        final CharSequence charSequence = null;
        final String s = null;
        String s2;
        if (anonymousClass) {
            s2 = (String)charSequence;
        }
        else if (c.isLocalClass()) {
            s2 = c.getSimpleName();
            final Method enclosingMethod = c.getEnclosingMethod();
            if (enclosingMethod != null) {
                final StringBuilder sb = new StringBuilder();
                sb.append(enclosingMethod.getName());
                sb.append('$');
                s2 = kotlin.text.c.F(s2, sb.toString());
            }
            else {
                final Constructor enclosingConstructor = c.getEnclosingConstructor();
                if (enclosingConstructor != null) {
                    final StringBuilder sb2 = new StringBuilder();
                    sb2.append(enclosingConstructor.getName());
                    sb2.append('$');
                    s2 = kotlin.text.c.F(s2, sb2.toString());
                }
                else {
                    final int m = kotlin.text.c.m((CharSequence)s2, '$', 0, false, 6);
                    if (m != -1) {
                        s2 = s2.substring(m + 1, s2.length());
                    }
                }
            }
        }
        else {
            final boolean array = c.isArray();
            final LinkedHashMap w = pp.w;
            if (array) {
                final Class componentType = c.getComponentType();
                String concat = s;
                if (componentType.isPrimitive()) {
                    final String s3 = (String)w.get((Object)componentType.getName());
                    concat = s;
                    if (s3 != null) {
                        concat = s3.concat("Array");
                    }
                }
                if ((s2 = concat) == null) {
                    s2 = "Array";
                }
            }
            else if ((s2 = (String)w.get((Object)c.getName())) == null) {
                s2 = c.getSimpleName();
            }
        }
        return s2;
    }
    
    @Override
    public final boolean equals(final Object o) {
        return o instanceof pp && gw5.a((in1)this).equals(gw5.a((in1)o));
    }
    
    @Override
    public final int hashCode() {
        return gw5.a((in1)this).hashCode();
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(this.c.toString());
        sb.append(" (Kotlin reflection is not available)");
        return sb.toString();
    }
}
