public final class o92
{
    public final String a;
    public final Long b;
    
    public o92(final String a, final long n) {
        this.a = a;
        this.b = n;
    }
    
    @Override
    public final boolean equals(final Object o) {
        boolean equals = true;
        if (this == o) {
            return true;
        }
        if (!(o instanceof o92)) {
            return false;
        }
        final o92 o2 = (o92)o;
        if (!this.a.equals((Object)o2.a)) {
            return false;
        }
        final Long b = o2.b;
        final Long b2 = this.b;
        if (b2 != null) {
            equals = b2.equals((Object)b);
        }
        else if (b != null) {
            equals = false;
        }
        return equals;
    }
    
    @Override
    public final int hashCode() {
        final int hashCode = this.a.hashCode();
        final Long b = this.b;
        int hashCode2;
        if (b != null) {
            hashCode2 = b.hashCode();
        }
        else {
            hashCode2 = 0;
        }
        return hashCode * 31 + hashCode2;
    }
}
