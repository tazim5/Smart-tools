import java.nio.Buffer;
import java.nio.ByteOrder;
import java.util.Iterator;
import java.io.IOException;
import java.io.OutputStream;
import android.util.Base64OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.Locale;
import java.text.Normalizer;
import java.text.Normalizer$Form;
import java.util.HashSet;
import java.util.Comparator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import java.nio.ByteBuffer;

public final class u46 implements fh3
{
    public static final byte[] e;
    public static final byte[] f;
    public final int a;
    public int b = b;
    public int c = c;
    public Object d = d;
    
    static {
        e = new byte[] { 79, 103, 103, 83, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, -43, -59, -9, 1, 19, 79, 112, 117, 115, 72, 101, 97, 100, 1, 2, 56, 1, -128, -69, 0, 0, 0, 0, 0 };
        f = new byte[] { 79, 103, 103, 83, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 11, -103, 87, 83, 1, 16, 79, 112, 117, 115, 84, 97, 103, 115, 0, 0, 0, 0, 0, 0, 0, 0 };
    }
    
    public u46(final int b, final int c) {
        this.a = 1;
        this.d = new byte[c][b];
        this.b = b;
        this.c = c;
    }
    
    public u46(int b, final int n, final int c) {
        this.a = 4;
        this.b = b;
        if (n > 64 || (b = n) < 0) {
            b = 64;
        }
        if (c <= 0) {
            this.c = 1;
        }
        else {
            this.c = c;
        }
        this.d = new ip3(b);
    }
    
    public u46(final ch3 ch3, final ak3 ak3) {
        this.a = 3;
        final f85 c = ch3.c;
        ((f85)(this.d = c)).e(12);
        int r;
        final int n = r = c.r();
        Label_0116: {
            if ("audio/raw".equals((Object)ak3.k)) {
                final int s = ec5.s(ak3.z, ak3.x);
                if (n != 0) {
                    r = n;
                    if (n % s == 0) {
                        break Label_0116;
                    }
                }
                final StringBuilder sb = new StringBuilder("Audio sample size mismatch. stsd sample size: ");
                sb.append(s);
                sb.append(", stsz sample size: ");
                sb.append(n);
                mo5.g(sb.toString());
                r = s;
            }
        }
        int b;
        if ((b = r) == 0) {
            b = -1;
        }
        this.b = b;
        this.c = c.r();
    }
    
    public static final void f(final ByteBuffer byteBuffer, long n, final int n2, final int n3, final boolean b) {
        byteBuffer.put((byte)79);
        byteBuffer.put((byte)103);
        byteBuffer.put((byte)103);
        byteBuffer.put((byte)83);
        byteBuffer.put((byte)0);
        byte b2;
        if (!b) {
            b2 = 0;
        }
        else {
            b2 = 2;
        }
        byteBuffer.put(b2);
        byteBuffer.putLong(n);
        byteBuffer.putInt(0);
        byteBuffer.putInt(n2);
        byteBuffer.putInt(0);
        n = n3;
        if (n >> 8 == 0L) {
            byteBuffer.put((byte)n);
            return;
        }
        throw new IllegalArgumentException(ny3.a("out of range: %s", new Object[] { n }));
    }
    
    public byte a(final int n, final int n2) {
        return ((byte[][])this.d)[n2][n];
    }
    
    public void b(final int n, final int n2, final int n3) {
        ((byte[][])this.d)[n2][n] = (byte)n3;
    }
    
    public void c(final int n, final int n2, final boolean b) {
        ((byte[][])this.d)[n2][n] = (byte)(b ? 1 : 0);
    }
    
    public String d(ArrayList list, ArrayList list2) {
        Collections.sort((List)list2, (Comparator)new m74(29));
        final HashSet set = new HashSet();
        int n = 0;
        String s = null;
    Label_0456:
        while (true) {
            final int size = list2.size();
            s = "";
            if (n >= size) {
                break;
            }
            final String[] split = Normalizer.normalize((CharSequence)list.get(((cp3)list2.get(n)).e), Normalizer$Form.NFKC).toLowerCase(Locale.US).split("\n");
            if (split.length != 0) {
                for (int i = 0; i < split.length; ++i) {
                    String s3;
                    final String s2 = s3 = split[i];
                    if (s2.contains((CharSequence)"'")) {
                        final StringBuilder sb = new StringBuilder(s2);
                        int n2 = 1;
                        boolean b = false;
                        while (true) {
                            final int n3 = n2 + 2;
                            if (n3 > sb.length()) {
                                break;
                            }
                            if (sb.charAt(n2) == '\'') {
                                Label_0248: {
                                    if (sb.charAt(n2 - 1) != ' ') {
                                        final int n4 = n2 + 1;
                                        if ((sb.charAt(n4) == 's' || sb.charAt(n4) == 'S') && (n3 == sb.length() || sb.charAt(n3) == ' ')) {
                                            sb.insert(n2, ' ');
                                            n2 = n3;
                                            break Label_0248;
                                        }
                                    }
                                    sb.setCharAt(n2, ' ');
                                }
                                b = true;
                            }
                            ++n2;
                        }
                        String string;
                        if (b) {
                            string = sb.toString();
                        }
                        else {
                            string = null;
                        }
                        s3 = s2;
                        if (string != null) {
                            s3 = string;
                        }
                    }
                    final String[] b2 = j26.b(s3, true);
                    final int length = b2.length;
                    final int c = this.c;
                    if (length >= c) {
                        int n5 = 0;
                        int b3 = 0;
                    Block_15:
                        while (true) {
                            final int length2 = b2.length;
                            b3 = this.b;
                            if (n5 >= length2) {
                                break;
                            }
                            String concat = "";
                            for (int j = 0; j < c; ++j) {
                                final int n6 = n5 + j;
                                if (n6 >= b2.length) {
                                    break Block_15;
                                }
                                String concat2 = concat;
                                if (j > 0) {
                                    concat2 = concat.concat(" ");
                                }
                                concat = concat2.concat(String.valueOf((Object)b2[n6]));
                            }
                            set.add((Object)concat);
                            if (set.size() >= b3) {
                                break Label_0456;
                            }
                            ++n5;
                        }
                        if (set.size() >= b3) {
                            break Label_0456;
                        }
                    }
                }
            }
            ++n;
        }
        list = (ArrayList)new ByteArrayOutputStream(4096);
        list2 = (ArrayList)new Base64OutputStream((OutputStream)list, 10);
        for (final String s4 : set) {
            try {
                ((OutputStream)list2).write(((ip3)this.d).q(s4));
                continue;
            }
            catch (final IOException ex) {
                d94.zzh("Error while writing hash to byteStream", (Throwable)ex);
            }
            break;
        }
        try {
            ((Base64OutputStream)list2).close();
        }
        catch (final IOException ex2) {
            d94.zzh("HashManager: Unable to convert to Base64.", (Throwable)ex2);
        }
        final String s5;
        Label_0573: {
            try {
                ((ByteArrayOutputStream)list).close();
                ((ByteArrayOutputStream)list).toString();
                return s5;
            }
            catch (final IOException ex3) {
                break Label_0573;
            }
            throw s5;
        }
        d94.zzh("HashManager: Unable to convert to Base64.", (Throwable)s5);
        s5 = s;
        return s5;
    }
    
    public void e(final nu5 nu5, final List list) {
        final ByteBuffer e = nu5.e;
        e.getClass();
        if (((Buffer)e).limit() - ((Buffer)nu5.e).position() == 0) {
            return;
        }
        final int b = this.b;
        byte[] array2;
        final byte[] array = array2 = null;
        Label_0084: {
            if (b == 2) {
                if (list.size() != 1) {
                    array2 = array;
                    if (list.size() != 3) {
                        break Label_0084;
                    }
                }
                array2 = (byte[])list.get(0);
            }
        }
        final ByteBuffer e2 = nu5.e;
        final int position = ((Buffer)e2).position();
        final int limit = ((Buffer)e2).limit();
        final int n = limit - position;
        final int b2 = this.b;
        final int n2 = (n + 255) / 255;
        final int n3 = n2 + 27 + n;
        int n6;
        int n7;
        if (b2 == 2) {
            int n4;
            if (array2 != null) {
                n4 = array2.length + 28;
            }
            else {
                n4 = 47;
            }
            final int n5 = n3 + (n4 + 44);
            n6 = n4;
            n7 = n5;
        }
        else {
            final int n8 = 0;
            n7 = n3;
            n6 = n8;
        }
        if (((Buffer)this.d).capacity() < n7) {
            this.d = ByteBuffer.allocate(n7).order(ByteOrder.LITTLE_ENDIAN);
        }
        else {
            ((ByteBuffer)this.d).clear();
        }
        final ByteBuffer d = (ByteBuffer)this.d;
        if (this.b == 2) {
            if (array2 != null) {
                f(d, 0L, 0, 1, true);
                int length = array2.length;
                final long n9 = length;
                if (n9 >> 8 != 0L) {
                    throw new IllegalArgumentException(ny3.a("out of range: %s", new Object[] { n9 }));
                }
                d.put((byte)n9);
                d.put(array2);
                final byte[] array3 = d.array();
                final int arrayOffset = d.arrayOffset();
                length += 28;
                d.putInt(22, ec5.m(arrayOffset, array3, length, 0));
                d.position(length);
            }
            else {
                d.put(u46.e);
            }
            d.put(u46.f);
        }
        final byte value = e2.get(0);
        byte value2;
        if (((Buffer)e2).limit() > 1) {
            value2 = e2.get(1);
        }
        else {
            value2 = 0;
        }
        final int c = this.c + (int)(i06.b(value, value2) * 48000L / 1000000L);
        this.c = c;
        f(d, c, this.b, n2, false);
        final int n10 = 0;
        int n11 = n;
        int n12 = n10;
        int i;
        while (true) {
            i = position;
            if (n12 >= n2) {
                break;
            }
            if (n11 >= 255) {
                d.put((byte)(-1));
                n11 -= 255;
            }
            else {
                d.put((byte)n11);
                n11 = 0;
            }
            ++n12;
        }
        while (i < limit) {
            d.put(e2.get(i));
            ++i;
        }
        e2.position(((Buffer)e2).limit());
        d.flip();
        if (this.b == 2) {
            d.putInt(n6 + 66, ec5.m(d.arrayOffset() + n6 + 44, d.array(), ((Buffer)d).limit() - ((Buffer)d).position(), 0));
        }
        else {
            d.putInt(22, ec5.m(d.arrayOffset(), d.array(), ((Buffer)d).limit() - ((Buffer)d).position(), 0));
        }
        ++this.b;
        this.d = d;
        nu5.d();
        nu5.e(((Buffer)this.d).remaining());
        nu5.e.put((ByteBuffer)this.d);
        nu5.f();
    }
    
    @Override
    public String toString() {
        switch (this.a) {
            default: {
                return super.toString();
            }
            case 1: {
                final int b = this.b;
                final int c = this.c;
                final StringBuilder sb = new StringBuilder(b * 2 * c + 2);
                for (int i = 0; i < c; ++i) {
                    for (final byte b2 : ((byte[][])this.d)[i]) {
                        if (b2 != 0) {
                            if (b2 != 1) {
                                sb.append("  ");
                            }
                            else {
                                sb.append(" 1");
                            }
                        }
                        else {
                            sb.append(" 0");
                        }
                    }
                    sb.append('\n');
                }
                return sb.toString();
            }
        }
    }
    
    public int zza() {
        return this.b;
    }
    
    public int zzb() {
        return this.c;
    }
    
    public int zzc() {
        final int b = this.b;
        if (b == -1) {
            return ((f85)this.d).r();
        }
        return b;
    }
}
