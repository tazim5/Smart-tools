import android.os.Parcelable$Creator;
import android.os.BadParcelableException;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.IInterface;
import android.os.Binder;

public abstract class cr3 extends Binder implements IInterface
{
    public final int c;
    
    public cr3(final String s) {
        this.c = 0;
        this.attachInterface((IInterface)this, s);
    }
    
    public abstract boolean D(final int p0, final Parcel p1);
    
    public final IBinder asBinder() {
        final int c = this.c;
        return (IBinder)this;
    }
    
    public final boolean onTransact(int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        boolean d = true;
        final boolean b = true;
        switch (this.c) {
            default: {
                if (n > 16777215) {
                    if (super.onTransact(n, parcel, parcel2, n2)) {
                        return b;
                    }
                }
                else {
                    parcel.enforceInterface(this.getInterfaceDescriptor());
                }
                final z64 z64 = (z64)this;
                boolean b2;
                if (n == 1) {
                    final Parcelable$Creator creator = Bundle.CREATOR;
                    n = qz3.a;
                    Object o;
                    if (parcel.readInt() == 0) {
                        o = null;
                    }
                    else {
                        o = creator.createFromParcel(parcel);
                    }
                    final Bundle bundle = (Bundle)o;
                    n = parcel.dataAvail();
                    if (n > 0) {
                        final StringBuilder sb = new StringBuilder(56);
                        sb.append("Parcel data not fully consumed, unread size: ");
                        sb.append(n);
                        throw new BadParcelableException(sb.toString());
                    }
                    z64.f1(bundle);
                    parcel2.writeNoException();
                    b2 = b;
                }
                else {
                    b2 = false;
                }
                return b2;
            }
            case 0: {
                if (n > 16777215) {
                    if (super.onTransact(n, parcel, parcel2, n2)) {
                        return d;
                    }
                }
                else {
                    parcel.enforceInterface(this.getInterfaceDescriptor());
                }
                d = this.D(n, parcel);
                return d;
            }
        }
    }
}
