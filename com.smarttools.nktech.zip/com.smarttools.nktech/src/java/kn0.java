import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.RowScope;

public final class kn0 implements od1
{
    public static final kn0 c;
    
    static {
        c = (kn0)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final RowScope rowScope = (RowScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            TextKt.Text--4IGK_g("Calculate & Start", (Modifier)null, 0L, TextUnitKt.getSp(18), (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 199686, 0, 131030);
        }
        return t43.a;
    }
}
