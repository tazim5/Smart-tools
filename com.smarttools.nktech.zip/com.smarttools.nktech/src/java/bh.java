import com.smarttools.nktech.navigation.NavRoutes;
import androidx.compose.material.icons.outlined.FavoriteBorderKt;
import androidx.compose.material.icons.Icons$Outlined;
import androidx.compose.material.icons.filled.FavoriteKt;
import androidx.compose.material.icons.Icons$Filled;

public final class bh extends eh
{
    public static final bh f;
    
    static {
        f = (bh)new eh(((NavRoutes)v02.a).getRoute(), "Favorites", FavoriteKt.getFavorite(Icons$Filled.INSTANCE), FavoriteBorderKt.getFavoriteBorder(Icons$Outlined.INSTANCE));
    }
    
    public final boolean equals(final Object o) {
        return this == o || o instanceof bh;
    }
    
    public final int hashCode() {
        return -1278331066;
    }
    
    public final String toString() {
        return "Favorites";
    }
}
