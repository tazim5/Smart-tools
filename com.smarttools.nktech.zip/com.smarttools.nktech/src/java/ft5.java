import androidx.concurrent.futures.b;

public abstract class ft5
{
    public static jj a(final hj hj) {
        final Object o = new Object();
        ((b)o).c = (gf2)new Object();
        final jj b = new jj((b)o);
        ((b)o).b = b;
        ((b)o).a = hj.getClass();
        try {
            final Object o2 = hj.o((b)o);
            if (o2 != null) {
                ((b)o).a = o2;
            }
        }
        catch (final Exception ex) {
            ((a1)b.n).k((Throwable)ex);
        }
        return b;
    }
}
