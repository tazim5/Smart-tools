import com.google.android.gms.internal.ads.o;
import android.content.Context;
import android.view.View;
import java.util.HashMap;

public final class vn3 extends ao3
{
    public final HashMap h;
    public final View i;
    public final Context j;
    
    public vn3(final dn3 dn3, final vl3 vl3, final int n, final HashMap h, final View i, final Context j) {
        super(dn3, "7qOZVP58PfP3kLkbSBo98onihlohkIEpZC40FvE5nnCJ8ryn0NERK9JAnlww55zq", "SMfJnKfhfLLyTw7dzHC+3CXVRNFLWK4N2mQHKB3gm/o=", vl3, n, 85);
        this.h = h;
        this.i = i;
        this.j = j;
    }
    
    public final void a() {
        final Integer value = 1;
        final HashMap h = this.h;
        final boolean containsKey = h.containsKey((Object)value);
        long longValue = Long.MIN_VALUE;
        long longValue2;
        if (containsKey) {
            longValue2 = (long)h.get((Object)value);
        }
        else {
            longValue2 = Long.MIN_VALUE;
        }
        final Integer value2 = 2;
        final HashMap h2 = this.h;
        if (h2.containsKey((Object)value2)) {
            longValue = (long)h2.get((Object)value2);
        }
        Context context;
        if ((context = this.j) == null) {
            context = super.a.a;
        }
        final long[] array = (long[])super.e.invoke((Object)null, new Object[] { { longValue2, longValue }, context, this.i });
        final long n = array[0];
        this.h.put((Object)1, (Object)array[1]);
        final long n2 = array[2];
        this.h.put((Object)2, (Object)array[3]);
        final vl3 d = super.d;
        synchronized (d) {
            final vl3 d2 = super.d;
            d2.d();
            o.Y((o)d2.n, n);
            final vl3 d3 = super.d;
            d3.d();
            o.Z((o)d3.n, n2);
        }
    }
}
