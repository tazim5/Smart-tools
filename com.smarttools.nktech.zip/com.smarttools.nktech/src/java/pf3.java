public final class pf3 implements nf3
{
    public final int a;
    public final int b;
    public final int c;
    public final int d;
    public final int e;
    
    public pf3(final int a, final int b, final int c, final int d, final int e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public final int zza() {
        return 1752331379;
    }
}
