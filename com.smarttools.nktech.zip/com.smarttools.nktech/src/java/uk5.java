import java.util.HashMap;
import java.security.GeneralSecurityException;
import java.util.concurrent.atomic.AtomicReference;

public final class uk5
{
    public static final uk5 b;
    public final AtomicReference a;
    
    static {
        b = new uk5();
    }
    
    public uk5() {
        this.a = new AtomicReference((Object)new fl5(new mw4(19)));
    }
    
    public final Class a() {
        final HashMap b = ((fl5)this.a.get()).b;
        if (b.containsKey((Object)zg5.class)) {
            return ((qh5)b.get((Object)zg5.class)).zza();
        }
        throw new GeneralSecurityException(gs1.j("No input primitive class for ", zg5.class.toString(), " available"));
    }
    
    public final Object b(final wl5 wl5, final Class clazz) {
        final fl5 fl5 = (fl5)this.a.get();
        fl5.getClass();
        final el5 el5 = new el5((Class)wl5.getClass(), clazz);
        final HashMap a = fl5.a;
        if (a.containsKey((Object)el5)) {
            return ((cl5)a.get((Object)el5)).c.a(wl5);
        }
        throw new GeneralSecurityException(gs1.j("No PrimitiveConstructor for ", el5.toString(), " available"));
    }
    
    public final void c(final cl5 cl5) {
        synchronized (this) {
            final mw4 mw4 = new mw4((fl5)this.a.get());
            mw4.k(cl5);
            this.a.set((Object)new fl5(mw4));
        }
    }
    
    public final void d(final qh5 obj) {
        synchronized (this) {
            final mw4 mw4 = new mw4((fl5)this.a.get());
            final Class zzb = obj.zzb();
            final HashMap hashMap = (HashMap)mw4.v;
            if (hashMap.containsKey((Object)zzb)) {
                final qh5 obj2 = (qh5)hashMap.get((Object)zzb);
                if (!obj2.equals(obj) || !obj.equals(obj2)) {
                    throw new GeneralSecurityException("Attempt to register non-equal PrimitiveWrapper object or input class object for already existing object of type".concat(zzb.toString()));
                }
            }
            else {
                hashMap.put((Object)zzb, (Object)obj);
            }
            this.a.set((Object)new fl5(mw4));
        }
    }
}
