public abstract class py2
{
    public static final ThreadLocal a;
    
    static {
        a = new ThreadLocal();
    }
    
    public static e41 a() {
        final ThreadLocal a = py2.a;
        Object o;
        if ((o = a.get()) == null) {
            o = new wg(Thread.currentThread());
            a.set(o);
        }
        return (e41)o;
    }
}
