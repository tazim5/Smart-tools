import java.util.Map;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzba;
import org.json.JSONObject;
import android.media.MediaCodecInfo;
import java.util.Iterator;
import java.util.HashSet;
import java.util.AbstractMap$SimpleEntry;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.internal.ads.t6;
import android.media.MediaCodecList;
import com.google.android.gms.common.api.Api;
import javax.crypto.Mac;
import java.security.Provider;
import android.content.Context;
import java.io.Serializable;
import android.media.MediaCodecInfo$CodecCapabilities;

public final class ua2 implements wa2, rq0, he3, p94, pp0, ig5, c04, kd5, oo5, f11, w25, v56
{
    public static final ua2 n;
    public final int c;
    
    public boolean a(final String s, final String s2, final MediaCodecInfo$CodecCapabilities mediaCodecInfo$CodecCapabilities) {
        return "secure-playback".equals((Object)s) && "video/avc".equals((Object)s2);
    }
    
    public void b(final int n, final Serializable s) {
    }
    
    public long c(final long n) {
        return n;
    }
    
    public e11 d(final Context context, final String s, final d11 d11) {
        final e11 e11 = new e11();
        e11.a = d11.c(context, s);
        int c = 1;
        final int b = d11.b(context, s, true);
        e11.b = b;
        Label_0083: {
            int a;
            if ((a = e11.a) == 0) {
                a = 0;
                if (b == 0) {
                    c = 0;
                    break Label_0083;
                }
            }
            if (a >= b) {
                c = -1;
            }
        }
        e11.c = c;
        return e11;
    }
    
    public boolean f(final String s, final MediaCodecInfo$CodecCapabilities mediaCodecInfo$CodecCapabilities) {
        return false;
    }
    
    public int zza() {
        return MediaCodecList.getCodecCount();
    }
    
    public Object zza() {
        return -1;
    }
    
    public void zza(final Object o) {
        switch (this.c) {
            default: {
                final y26 y26 = (y26)o;
                return;
            }
            case 15: {
                final y26 y27 = (y26)o;
                return;
            }
            case 14: {
                final y26 y28 = (y26)o;
                return;
            }
            case 13: {
                final y26 y29 = (y26)o;
                return;
            }
            case 12: {
                final y26 y30 = (y26)o;
                return;
            }
            case 11: {
                final j36 j36 = (j36)o;
                final int e0 = t6.E0;
                j36.i(j36.e(), 14, (w25)new ic2(16));
                return;
            }
            case 4: {
                final yz3 yz3 = (yz3)o;
                zze.zza("Ending javascript session.");
                final zz3 zz3 = (zz3)yz3;
                final HashSet n = zz3.n;
                for (final AbstractMap$SimpleEntry abstractMap$SimpleEntry : n) {
                    zze.zza("Unregistering eventhandler: ".concat(String.valueOf((Object)abstractMap$SimpleEntry.getValue().toString())));
                    zz3.c.g((String)abstractMap$SimpleEntry.getKey(), (hx3)abstractMap$SimpleEntry.getValue());
                }
                n.clear();
            }
        }
    }
    
    public void zza(final Throwable t) {
    }
    
    public MediaCodecInfo zzb(final int n) {
        return MediaCodecList.getCodecInfoAt(n);
    }
    
    public JSONObject zzb(final Object o) {
        final ew4 ew4 = (ew4)o;
        final JSONObject jsonObject = new JSONObject();
        final JSONObject jsonObject2 = new JSONObject();
        final JSONObject jsonObject3 = new JSONObject();
        if (zzba.zzc().a(cs3.k8)) {
            jsonObject2.put("ad_request_url", (Object)ew4.c.f);
            jsonObject2.put("ad_request_post_body", (Object)ew4.c.c);
        }
        jsonObject2.put("base_url", (Object)ew4.c.b);
        jsonObject2.put("signals", (Object)ew4.b);
        final lw4 a = ew4.a;
        jsonObject3.put("body", (Object)a.c);
        jsonObject3.put("headers", (Object)zzay.zzb().j((Map)a.b));
        jsonObject3.put("response_code", a.a);
        jsonObject3.put("latency", a.d);
        jsonObject.put("request", (Object)jsonObject2);
        jsonObject.put("response", (Object)jsonObject3);
        jsonObject.put("flags", (Object)ew4.c.h);
        return jsonObject;
    }
    
    public boolean zze() {
        return false;
    }
}
