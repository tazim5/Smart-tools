public final class jh5
{
    public final int a;
    public final boolean b;
    public final int c;
    public final int d;
    public final int e;
    public final int f;
    public final int[] g;
    public final int h;
    public final int i;
    public final int j;
    public final float k;
    public final int l;
    public final int m;
    public final int n;
    
    public jh5(final int a, final boolean b, final int c, final int d, final int e, final int f, final int[] g, final int h, final int i, final int j, final float k, final int l, final int m, final int n) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
        this.l = l;
        this.m = m;
        this.n = n;
    }
}
