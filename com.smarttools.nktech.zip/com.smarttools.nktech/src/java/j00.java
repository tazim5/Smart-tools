import androidx.compose.ui.text.font.FontWeight$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.Alignment$Vertical;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.graphics.Color;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.BackgroundKt;
import com.smarttools.nktech.features.tools.games.c;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.Alignment;
import androidx.compose.runtime.Composer;

public final class j00 implements nd1
{
    public static final j00 c;
    
    static {
        c = (j00)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Alignment$Companion companion = Alignment.Companion;
            final Alignment$Vertical centerVertically = companion.getCenterVertically();
            final Modifier$Companion companion2 = Modifier.Companion;
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, composer, 48);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, (Modifier)companion2);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, rowMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final RowScopeInstance instance = RowScopeInstance.INSTANCE;
            final Modifier background-bw27NRU$default = BackgroundKt.background-bw27NRU$default(ClipKt.clip(SizeKt.size-3ABfNKs((Modifier)companion2, Dp.constructor-impl((float)32)), (Shape)RoundedCornerShapeKt.getCircleShape()), com.smarttools.nktech.features.tools.games.c.f, (Shape)null, 2, (Object)null);
            final MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(companion.getCenter(), false);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, background-bw27NRU$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, maybeCachedBoxMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final BoxScopeInstance instance2 = BoxScopeInstance.INSTANCE;
            final long white-0d7_KjU = Color.Companion.getWhite-0d7_KjU();
            final FontWeight$Companion companion4 = FontWeight.Companion;
            TextKt.Text--4IGK_g("Nb", (Modifier)null, white-0d7_KjU, TextUnitKt.getSp(12), (FontStyle)null, companion4.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 200070, 0, 131026);
            composer.endNode();
            SpacerKt.Spacer(SizeKt.width-3ABfNKs((Modifier)companion2, Dp.constructor-impl((float)10)), composer, 6);
            TextKt.Text--4IGK_g("No Ball", (Modifier)null, 0L, TextUnitKt.getSp(20), (FontStyle)null, companion4.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 199686, 0, 131030);
            composer.endNode();
        }
        return t43.a;
    }
}
