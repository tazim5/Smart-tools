public final class wn5 extends kp5
{
}
