import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdListener;

public final class xt4 extends AdListener
{
    public final String c;
    public final AdView n;
    public final String v;
    public final cu4 w;
    
    public xt4(final cu4 w, final String c, final AdView n, final String v) {
        this.w = w;
        this.c = c;
        this.n = n;
        this.v = v;
    }
    
    public final void onAdFailedToLoad(final LoadAdError loadAdError) {
        this.w.j1(cu4.i1((Object)loadAdError), this.v);
    }
    
    public final void onAdLoaded() {
        this.w.f1(this.c, (Object)this.n, this.v);
    }
}
