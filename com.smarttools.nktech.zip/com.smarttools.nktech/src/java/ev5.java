public abstract class ev5
{
    public static final int a = 0;
    
    static {
        final kw5 c = kw5.c;
    }
}
