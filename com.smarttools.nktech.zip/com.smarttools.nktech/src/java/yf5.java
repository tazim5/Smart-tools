import android.content.res.Resources$NotFoundException;
import com.google.android.gms.common.R$string;
import android.content.Context;

public abstract class yf5
{
    public static String a(Context context) {
        try {
            context = (Context)context.getResources().getResourcePackageName(R$string.common_google_play_services_unknown_issue);
        }
        catch (final Resources$NotFoundException ex) {
            context = (Context)context.getPackageName();
        }
        return (String)context;
    }
}
