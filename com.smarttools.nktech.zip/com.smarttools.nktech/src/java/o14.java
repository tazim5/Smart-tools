import android.os.BaseBundle;
import com.google.android.gms.ads.mediation.zza;
import com.google.android.gms.ads.internal.client.zzdq;
import com.google.android.gms.internal.ads.zzbsd;
import android.os.IBinder;
import com.google.android.gms.ads.formats.NativeCustomTemplateAd;
import android.os.Parcelable;
import android.os.IInterface;
import android.os.Parcel;
import com.google.android.gms.ads.mediation.OnImmersiveModeUpdatedListener;
import com.google.android.gms.ads.mediation.MediationAppOpenAdConfiguration;
import com.google.ads.mediation.admob.AdMobAdapter;
import java.util.Iterator;
import com.google.android.gms.ads.mediation.InitializationCompleteCallback;
import com.google.android.gms.ads.mediation.MediationConfiguration;
import com.google.android.gms.ads.AdFormat;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.internal.ads.zzbmk;
import com.google.android.gms.ads.mediation.MediationNativeAdConfiguration;
import com.google.android.gms.ads.mediation.NativeMediationAdRequest;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import java.util.ArrayList;
import com.google.android.gms.internal.ads.zzbfw;
import com.google.android.gms.ads.mediation.OnContextChangedListener;
import com.google.android.gms.ads.mediation.MediationBannerAdConfiguration;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.zzb;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.internal.client.zzq;
import android.location.Location;
import android.os.Bundle;
import java.util.List;
import com.google.android.gms.ads.mediation.MediationInterstitialAdConfiguration;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import java.util.Date;
import java.util.Collection;
import java.util.HashSet;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import android.os.RemoteException;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzl;
import com.google.android.gms.ads.mediation.MediationAdapter;
import com.google.android.gms.ads.mediation.Adapter;
import com.google.android.gms.ads.mediation.UnifiedNativeAdMapper;
import com.google.android.gms.ads.mediation.MediationInterstitialAd;
import android.view.View;
import com.google.android.gms.ads.mediation.MediationExtrasReceiver;
import com.google.android.gms.ads.mediation.MediationAppOpenAd;
import com.google.android.gms.ads.mediation.MediationInterscrollerAd;
import com.google.android.gms.ads.mediation.MediationRewardedAd;

public final class o14 extends ho3 implements v04
{
    public MediationRewardedAd P;
    public MediationInterscrollerAd Q;
    public MediationAppOpenAd R;
    public final String S;
    public final MediationExtrasReceiver c;
    public m14 n;
    public v54 v;
    public th1 w;
    public View x;
    public MediationInterstitialAd y;
    public UnifiedNativeAdMapper z;
    
    public o14() {
        super("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
    }
    
    public o14(final Adapter c) {
        this();
        this.S = "";
        this.c = (MediationExtrasReceiver)c;
    }
    
    public o14(final MediationAdapter c) {
        this();
        this.S = "";
        this.c = (MediationExtrasReceiver)c;
    }
    
    public static final boolean i1(final zzl zzl) {
        if (!zzl.zzf) {
            zzay.zzb();
            if (!z84.m()) {
                return false;
            }
        }
        return true;
    }
    
    public static final String j1(zzl zzl, String s) {
        zzl = (zzl)zzl.zzu;
        try {
            s = (String)(zzl = (zzl)new JSONObject(s).getString("max_ad_content_rating"));
            return (String)zzl;
        }
        catch (final JSONException ex) {
            return (String)zzl;
        }
    }
    
    public final void A0(final th1 th1, final zzl zzl, final String s, final y04 y04) {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof Adapter) {
            d94.zze("Requesting rewarded ad from adapter.");
            try {
                ((Adapter)c).loadRewardedAd(new MediationRewardedAdConfiguration((Context)n32.F(th1), "", this.h1(s, zzl, null), this.g1(zzl), i1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, j1(zzl, s), ""), (MediationAdLoadCallback)new n14(this, y04, 3));
                return;
            }
            catch (final Exception ex) {
                d94.zzh("", (Throwable)ex);
                throw new RemoteException();
            }
        }
        final String canonicalName = Adapter.class.getCanonicalName();
        final String canonicalName2 = ((Adapter)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName2);
        d94.zzj(sb.toString());
        throw new RemoteException();
    }
    
    public final void G0(final th1 th1, final zzl zzl, final String s, String canonicalName, final y04 y04) {
        Object c = this.c;
        final boolean b = c instanceof MediationInterstitialAdapter;
        if (!b && !(c instanceof Adapter)) {
            final String canonicalName2 = MediationInterstitialAdapter.class.getCanonicalName();
            final String canonicalName3 = Adapter.class.getCanonicalName();
            canonicalName = ((MediationInterstitialAdapter)c).getClass().getCanonicalName();
            final StringBuilder sb = new StringBuilder();
            sb.append(canonicalName2);
            sb.append(" or ");
            sb.append(canonicalName3);
            sb.append(" #009 Class mismatch: ");
            sb.append(canonicalName);
            d94.zzj(sb.toString());
            throw new RemoteException();
        }
        d94.zze("Requesting interstitial ad from adapter.");
        if (b) {
            MediationInterstitialAdapter mediationInterstitialAdapter = null;
            Bundle bundle = null;
            final th1 th2;
            Label_0160: {
                try {
                    mediationInterstitialAdapter = (MediationInterstitialAdapter)c;
                    final List zze = zzl.zze;
                    bundle = null;
                    if (zze != null) {
                        c = new HashSet((Collection)zze);
                        break Label_0160;
                    }
                }
                finally {
                    throw f83.c("", (Throwable)th2);
                }
                c = null;
            }
            final long zzb = zzl.zzb;
            Date date;
            if (zzb == -1L) {
                date = null;
            }
            else {
                date = new Date(zzb);
            }
            final int zzd = zzl.zzd;
            final Location zzk = zzl.zzk;
            final boolean i1 = i1(zzl);
            final int zzg = zzl.zzg;
            final boolean zzr = zzl.zzr;
            j1(zzl, s);
            final l14 l14 = new l14(date, zzd, (HashSet)c, zzk, i1, zzg, zzr);
            final Bundle zzm = zzl.zzm;
            Bundle bundle2 = bundle;
            if (zzm != null) {
                bundle2 = zzm.getBundle(mediationInterstitialAdapter.getClass().getName());
            }
            mediationInterstitialAdapter.requestInterstitialAd((Context)n32.F(th2), (MediationInterstitialListener)new m14(y04), this.h1(s, zzl, canonicalName), (MediationAdRequest)l14, bundle2);
            return;
        }
        if (c instanceof Adapter) {
            try {
                ((Adapter)c).loadInterstitialAd(new MediationInterstitialAdConfiguration((Context)n32.F(th1), "", this.h1(s, zzl, canonicalName), this.g1(zzl), i1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, j1(zzl, s), this.S), (MediationAdLoadCallback)new n14(this, y04, 1));
            }
            finally {
                final Throwable t;
                throw f83.c("", t);
            }
        }
    }
    
    public final void L(final th1 th1, final v54 v54, final List list) {
        d94.zzj("Could not initialize rewarded video adapter.");
        throw new RemoteException();
    }
    
    public final void M0(final zzl zzl, final String s) {
        this.f1(zzl, s);
    }
    
    public final void U(final th1 th1, zzq zzq, final zzl zzl, String s, final String s2, final y04 y04) {
        Object c = this.c;
        final boolean b = c instanceof MediationBannerAdapter;
        if (!b && !(c instanceof Adapter)) {
            final String canonicalName = MediationBannerAdapter.class.getCanonicalName();
            final String canonicalName2 = Adapter.class.getCanonicalName();
            s = ((MediationBannerAdapter)c).getClass().getCanonicalName();
            final StringBuilder sb = new StringBuilder();
            sb.append(canonicalName);
            sb.append(" or ");
            sb.append(canonicalName2);
            sb.append(" #009 Class mismatch: ");
            sb.append(s);
            d94.zzj(sb.toString());
            throw new RemoteException();
        }
        d94.zze("Requesting banner ad from adapter.");
        if (zzq.zzn) {
            zzq = (zzq)zzb.zzd(zzq.zze, zzq.zzb);
        }
        else {
            zzq = (zzq)zzb.zzc(zzq.zze, zzq.zzb, zzq.zza);
        }
        if (b) {
            MediationBannerAdapter mediationBannerAdapter = null;
            final th1 th2;
            Label_0200: {
                try {
                    mediationBannerAdapter = (MediationBannerAdapter)c;
                    final List zze = zzl.zze;
                    if (zze != null) {
                        c = new HashSet((Collection)zze);
                        break Label_0200;
                    }
                }
                finally {
                    throw f83.c("", (Throwable)th2);
                }
                c = null;
            }
            final long zzb = zzl.zzb;
            Date date;
            if (zzb == -1L) {
                date = null;
            }
            else {
                date = new Date(zzb);
            }
            final int zzd = zzl.zzd;
            final Location zzk = zzl.zzk;
            final boolean i1 = i1(zzl);
            final int zzg = zzl.zzg;
            final boolean zzr = zzl.zzr;
            j1(zzl, s);
            final l14 l14 = new l14(date, zzd, (HashSet)c, zzk, i1, zzg, zzr);
            final Bundle zzm = zzl.zzm;
            Bundle bundle;
            if (zzm != null) {
                bundle = zzm.getBundle(mediationBannerAdapter.getClass().getName());
            }
            else {
                bundle = null;
            }
            mediationBannerAdapter.requestBannerAd((Context)n32.F(th2), (MediationBannerListener)new m14(y04), this.h1(s, zzl, s2), (AdSize)zzq, (MediationAdRequest)l14, bundle);
            return;
        }
        if (c instanceof Adapter) {
            try {
                final Adapter adapter = (Adapter)c;
                final n14 n14 = new n14(this, y04, 0);
                final Context context = (Context)n32.F(th1);
                final Bundle h1 = this.h1(s, zzl, s2);
                final Bundle g1 = this.g1(zzl);
                final boolean i2 = i1(zzl);
                final Location zzk2 = zzl.zzk;
                final int zzg2 = zzl.zzg;
                final int zzt = zzl.zzt;
                s = j1(zzl, s);
                final String s3 = this.S;
                try {
                    adapter.loadBannerAd(new MediationBannerAdConfiguration(context, "", h1, g1, i2, zzk2, zzg2, zzt, s, (AdSize)zzq, s3), (MediationAdLoadCallback)n14);
                    return;
                }
                finally {}
            }
            finally {}
            final Throwable t;
            throw f83.c("", t);
        }
    }
    
    public final void U0(final th1 th1) {
        final Context context = (Context)n32.F(th1);
        final MediationExtrasReceiver c = this.c;
        if (c instanceof OnContextChangedListener) {
            ((OnContextChangedListener)c).onContextChanged(context);
        }
    }
    
    public final void X(final th1 th1) {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter)) {
            final String canonicalName = Adapter.class.getCanonicalName();
            final String canonicalName2 = c.getClass().getCanonicalName();
            final StringBuilder sb = new StringBuilder();
            sb.append(canonicalName);
            sb.append(" #009 Class mismatch: ");
            sb.append(canonicalName2);
            d94.zzj(sb.toString());
            throw new RemoteException();
        }
        d94.zze("Show app open ad from adapter.");
        final MediationAppOpenAd r = this.R;
        if (r != null) {
            r.showAd((Context)n32.F(th1));
            return;
        }
        d94.zzg("Can not show null mediation app open ad.");
        throw new RemoteException();
    }
    
    public final void a0(final th1 th1, final zzl zzl, String canonicalName, final String s, final y04 y04, final zzbfw zzbfw, final ArrayList list) {
        Object c = this.c;
        final boolean b = c instanceof MediationNativeAdapter;
        if (!b && !(c instanceof Adapter)) {
            final String canonicalName2 = MediationNativeAdapter.class.getCanonicalName();
            final String canonicalName3 = Adapter.class.getCanonicalName();
            canonicalName = ((MediationNativeAdapter)c).getClass().getCanonicalName();
            final StringBuilder sb = new StringBuilder();
            sb.append(canonicalName2);
            sb.append(" or ");
            sb.append(canonicalName3);
            sb.append(" #009 Class mismatch: ");
            sb.append(canonicalName);
            d94.zzj(sb.toString());
            throw new RemoteException();
        }
        d94.zze("Requesting native ad from adapter.");
        if (b) {
            MediationNativeAdapter mediationNativeAdapter = null;
            Bundle bundle = null;
            final th1 th2;
            Label_0167: {
                try {
                    mediationNativeAdapter = (MediationNativeAdapter)c;
                    final List zze = zzl.zze;
                    bundle = null;
                    if (zze != null) {
                        c = new HashSet((Collection)zze);
                        break Label_0167;
                    }
                }
                finally {
                    throw f83.c("", (Throwable)th2);
                }
                c = null;
            }
            final long zzb = zzl.zzb;
            Date date;
            if (zzb == -1L) {
                date = null;
            }
            else {
                date = new Date(zzb);
            }
            final int zzd = zzl.zzd;
            final Location zzk = zzl.zzk;
            final boolean i1 = i1(zzl);
            final int zzg = zzl.zzg;
            final boolean zzr = zzl.zzr;
            j1(zzl, canonicalName);
            final r14 r14 = new r14(date, zzd, (HashSet)c, zzk, i1, zzg, zzbfw, list, zzr);
            final Bundle zzm = zzl.zzm;
            Bundle bundle2 = bundle;
            if (zzm != null) {
                bundle2 = zzm.getBundle(mediationNativeAdapter.getClass().getName());
            }
            this.n = new m14(y04);
            mediationNativeAdapter.requestNativeAd((Context)n32.F(th2), (MediationNativeListener)this.n, this.h1(canonicalName, zzl, s), (NativeMediationAdRequest)r14, bundle2);
            return;
        }
        if (c instanceof Adapter) {
            try {
                ((Adapter)c).loadNativeAd(new MediationNativeAdConfiguration((Context)n32.F(th1), "", this.h1(canonicalName, zzl, s), this.g1(zzl), i1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, j1(zzl, canonicalName), this.S, zzbfw), (MediationAdLoadCallback)new n14(this, y04, 2));
            }
            finally {
                final Throwable t;
                throw f83.c("", t);
            }
        }
    }
    
    public final void c1(final th1 th1, final py3 py3, final ArrayList list) {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof Adapter) {
            final pe1 pe1 = new pe1(py3, 23);
            final ArrayList list2 = new ArrayList();
            for (final zzbmk zzbmk : list) {
                final String c2 = zzbmk.c;
                int n = 0;
                Label_0259: {
                    switch (c2.hashCode()) {
                        case 1911491517: {
                            if (c2.equals((Object)"rewarded_interstitial")) {
                                n = 3;
                                break Label_0259;
                            }
                            break;
                        }
                        case 1778294298: {
                            if (c2.equals((Object)"app_open_ad")) {
                                n = 6;
                                break Label_0259;
                            }
                            break;
                        }
                        case 1167692200: {
                            if (c2.equals((Object)"app_open")) {
                                n = 5;
                                break Label_0259;
                            }
                            break;
                        }
                        case 604727084: {
                            if (c2.equals((Object)"interstitial")) {
                                n = 1;
                                break Label_0259;
                            }
                            break;
                        }
                        case -239580146: {
                            if (c2.equals((Object)"rewarded")) {
                                n = 2;
                                break Label_0259;
                            }
                            break;
                        }
                        case -1052618729: {
                            if (c2.equals((Object)"native")) {
                                n = 4;
                                break Label_0259;
                            }
                            break;
                        }
                        case -1396342996: {
                            if (c2.equals((Object)"banner")) {
                                n = 0;
                                break Label_0259;
                            }
                            break;
                        }
                    }
                    n = -1;
                }
                AdFormat adFormat = null;
                switch (n) {
                    case 6: {
                        if (zzba.zzc().a(cs3.aa)) {
                            adFormat = AdFormat.APP_OPEN_AD;
                            break;
                        }
                        break;
                    }
                    case 5: {
                        adFormat = AdFormat.APP_OPEN_AD;
                        break;
                    }
                    case 4: {
                        adFormat = AdFormat.NATIVE;
                        break;
                    }
                    case 3: {
                        adFormat = AdFormat.REWARDED_INTERSTITIAL;
                        break;
                    }
                    case 2: {
                        adFormat = AdFormat.REWARDED;
                        break;
                    }
                    case 1: {
                        adFormat = AdFormat.INTERSTITIAL;
                        break;
                    }
                    case 0: {
                        adFormat = AdFormat.BANNER;
                        break;
                    }
                }
                if (adFormat != null) {
                    list2.add((Object)new MediationConfiguration(adFormat, zzbmk.n));
                }
            }
            ((Adapter)c).initialize((Context)n32.F(th1), (InitializationCompleteCallback)pe1, (List)list2);
            return;
        }
        throw new RemoteException();
    }
    
    public final void e0(final th1 th1) {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter) && !(c instanceof MediationInterstitialAdapter)) {
            final String canonicalName = MediationInterstitialAdapter.class.getCanonicalName();
            final String canonicalName2 = Adapter.class.getCanonicalName();
            final String canonicalName3 = c.getClass().getCanonicalName();
            final StringBuilder sb = new StringBuilder();
            sb.append(canonicalName);
            sb.append(" or ");
            sb.append(canonicalName2);
            sb.append(" #009 Class mismatch: ");
            sb.append(canonicalName3);
            d94.zzj(sb.toString());
            throw new RemoteException();
        }
        if (c instanceof MediationInterstitialAdapter) {
            this.p();
            return;
        }
        d94.zze("Show interstitial ad from adapter.");
        final MediationInterstitialAd y = this.y;
        if (y != null) {
            y.showAd((Context)n32.F(th1));
            return;
        }
        d94.zzg("Can not show null mediation interstitial ad.");
        throw new RemoteException();
    }
    
    public final void f0(final th1 th1, final zzq zzq, final zzl zzl, final String s, final String s2, final y04 y04) {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof Adapter) {
            d94.zze("Requesting interscroller ad from adapter.");
            try {
                final Adapter adapter = (Adapter)c;
                adapter.loadInterscrollerAd(new MediationBannerAdConfiguration((Context)n32.F(th1), "", this.h1(s, zzl, s2), this.g1(zzl), i1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, j1(zzl, s), zzb.zze(zzq.zze, zzq.zzb), ""), (MediationAdLoadCallback)new m14((Object)this, (Object)y04, (Object)adapter, 0));
                return;
            }
            catch (final Exception ex) {
                d94.zzh("", (Throwable)ex);
                throw new RemoteException();
            }
        }
        final String canonicalName = Adapter.class.getCanonicalName();
        final String canonicalName2 = ((Adapter)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName2);
        d94.zzj(sb.toString());
        throw new RemoteException();
    }
    
    public final void f1(final zzl zzl, final String s) {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof Adapter) {
            this.A0(this.w, zzl, s, (y04)new q14((Adapter)c, this.v));
            return;
        }
        final String canonicalName = Adapter.class.getCanonicalName();
        final String canonicalName2 = ((Adapter)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName2);
        d94.zzj(sb.toString());
        throw new RemoteException();
    }
    
    public final void g0(final th1 th1, final zzl zzl, String canonicalName, final y04 y04) {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof Adapter) {
            d94.zze("Requesting rewarded interstitial ad from adapter.");
            try {
                ((Adapter)c).loadRewardedInterstitialAd(new MediationRewardedAdConfiguration((Context)n32.F(th1), "", this.h1(canonicalName, zzl, null), this.g1(zzl), i1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, j1(zzl, canonicalName), ""), (MediationAdLoadCallback)new n14(this, y04, 3));
                return;
            }
            catch (final Exception ex) {
                d94.zzh("", (Throwable)ex);
                throw new RemoteException();
            }
        }
        final String canonicalName2 = Adapter.class.getCanonicalName();
        canonicalName = ((Adapter)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName2);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName);
        d94.zzj(sb.toString());
        throw new RemoteException();
    }
    
    public final Bundle g1(final zzl zzl) {
        final Bundle zzm = zzl.zzm;
        if (zzm != null) {
            final Bundle bundle = zzm.getBundle(this.c.getClass().getName());
            if (bundle != null) {
                return bundle;
            }
        }
        return new Bundle();
    }
    
    public final Bundle h1(final String s, final zzl zzl, final String s2) {
        d94.zze("Server parameters: ".concat(String.valueOf((Object)s)));
        Bundle bundle;
        try {
            bundle = new Bundle();
            if (s != null) {
                final JSONObject jsonObject = new JSONObject(s);
                bundle = new Bundle();
                final Iterator keys = jsonObject.keys();
                while (keys.hasNext()) {
                    final String s3 = (String)keys.next();
                    ((BaseBundle)bundle).putString(s3, jsonObject.getString(s3));
                }
            }
        }
        finally {
            final Throwable t;
            throw f83.c("", t);
        }
        if (this.c instanceof AdMobAdapter) {
            ((BaseBundle)bundle).putString("adJson", s2);
            if (zzl != null) {
                ((BaseBundle)bundle).putInt("tagForChildDirectedTreatment", zzl.zzg);
            }
        }
        bundle.remove("max_ad_content_rating");
        return bundle;
    }
    
    public final void j() {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter)) {
            final String canonicalName = Adapter.class.getCanonicalName();
            final String canonicalName2 = c.getClass().getCanonicalName();
            final StringBuilder sb = new StringBuilder();
            sb.append(canonicalName);
            sb.append(" #009 Class mismatch: ");
            sb.append(canonicalName2);
            d94.zzj(sb.toString());
            throw new RemoteException();
        }
        final MediationRewardedAd p = this.P;
        if (p != null) {
            p.showAd((Context)n32.F(this.w));
            return;
        }
        d94.zzg("Can not show null mediated rewarded ad.");
        throw new RemoteException();
    }
    
    public final boolean l() {
        return false;
    }
    
    public final void m0(final th1 w, final zzl zzl, final v54 v, String canonicalName) {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter)) {
            canonicalName = c.getClass().getCanonicalName();
            if (canonicalName != "com.google.ads.mediation.admob.AdMobAdapter") {
                if (canonicalName == null || !canonicalName.equals("com.google.ads.mediation.admob.AdMobAdapter")) {
                    final String canonicalName2 = Adapter.class.getCanonicalName();
                    final String canonicalName3 = c.getClass().getCanonicalName();
                    final StringBuilder sb = new StringBuilder();
                    sb.append(canonicalName2);
                    sb.append(" #009 Class mismatch: ");
                    sb.append(canonicalName3);
                    d94.zzj(sb.toString());
                    throw new RemoteException();
                }
            }
        }
        this.w = w;
        (this.v = v).d0(new n32(c));
    }
    
    public final void p() {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof MediationInterstitialAdapter) {
            d94.zze("Showing interstitial from adapter.");
            try {
                ((MediationInterstitialAdapter)c).showInterstitial();
                return;
            }
            finally {
                final Throwable t;
                throw f83.c("", t);
            }
        }
        final String canonicalName = MediationInterstitialAdapter.class.getCanonicalName();
        final String canonicalName2 = ((MediationInterstitialAdapter)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName2);
        d94.zzj(sb.toString());
        throw new RemoteException();
    }
    
    public final void w(final th1 th1) {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter)) {
            final String canonicalName = Adapter.class.getCanonicalName();
            final String canonicalName2 = c.getClass().getCanonicalName();
            final StringBuilder sb = new StringBuilder();
            sb.append(canonicalName);
            sb.append(" #009 Class mismatch: ");
            sb.append(canonicalName2);
            d94.zzj(sb.toString());
            throw new RemoteException();
        }
        d94.zze("Show rewarded ad from adapter.");
        final MediationRewardedAd p = this.P;
        if (p != null) {
            p.showAd((Context)n32.F(th1));
            return;
        }
        d94.zzg("Can not show null mediation rewarded ad.");
        throw new RemoteException();
    }
    
    public final void y0(final th1 th1, final zzl zzl, final String s, final y04 y04) {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof Adapter) {
            d94.zze("Requesting app open ad from adapter.");
            try {
                ((Adapter)c).loadAppOpenAd(new MediationAppOpenAdConfiguration((Context)n32.F(th1), "", this.h1(s, zzl, null), this.g1(zzl), i1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, j1(zzl, s), ""), (MediationAdLoadCallback)new n14(this, y04, 4));
                return;
            }
            catch (final Exception ex) {
                d94.zzh("", (Throwable)ex);
                throw new RemoteException();
            }
        }
        final String canonicalName = Adapter.class.getCanonicalName();
        final String canonicalName2 = ((Adapter)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName2);
        d94.zzj(sb.toString());
        throw new RemoteException();
    }
    
    public final void z0(final boolean b) {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof OnImmersiveModeUpdatedListener) {
            try {
                ((OnImmersiveModeUpdatedListener)c).onImmersiveModeUpdated(b);
                return;
            }
            finally {
                final Throwable t;
                d94.zzh("", t);
                return;
            }
        }
        final String canonicalName = OnImmersiveModeUpdatedListener.class.getCanonicalName();
        final String canonicalName2 = ((OnImmersiveModeUpdatedListener)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName2);
        d94.zze(sb.toString());
    }
    
    public final void zzE() {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof MediationAdapter)) {
            return;
        }
        try {
            ((MediationAdapter)c).onPause();
        }
        finally {
            final Throwable t;
            throw f83.c("", t);
        }
    }
    
    public final void zzF() {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof MediationAdapter)) {
            return;
        }
        try {
            ((MediationAdapter)c).onResume();
        }
        finally {
            final Throwable t;
            throw f83.c("", t);
        }
    }
    
    public final boolean zzN() {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter)) {
            final String canonicalName = c.getClass().getCanonicalName();
            if (canonicalName != "com.google.ads.mediation.admob.AdMobAdapter") {
                if (canonicalName == null || !canonicalName.equals("com.google.ads.mediation.admob.AdMobAdapter")) {
                    final String canonicalName2 = Adapter.class.getCanonicalName();
                    final String canonicalName3 = c.getClass().getCanonicalName();
                    final StringBuilder sb = new StringBuilder();
                    sb.append(canonicalName2);
                    sb.append(" #009 Class mismatch: ");
                    sb.append(canonicalName3);
                    d94.zzj(sb.toString());
                    throw new RemoteException();
                }
            }
        }
        return this.v != null;
    }
    
    public final e14 zzO() {
        return null;
    }
    
    public final f14 zzP() {
        return null;
    }
    
    public final boolean zzbK(int zzN, final Parcel parcel, final Parcel parcel2, final int n) {
        Object o = null;
        final y04 y04 = null;
        final py3 py3 = null;
        final y04 y5 = null;
        final IInterface interface1 = null;
        final y04 y6 = null;
        final v54 v54 = null;
        final y04 y7 = null;
        final y04 y8 = null;
        final y04 y9 = null;
        final y04 y10 = null;
        final y04 y11 = null;
        switch (zzN) {
            default: {
                return false;
            }
            case 39: {
                final th1 d = n32.D(parcel.readStrongBinder());
                io3.b(parcel);
                this.X(d);
                parcel2.writeNoException();
                break;
            }
            case 38: {
                final th1 d2 = n32.D(parcel.readStrongBinder());
                final zzl zzl = (zzl)io3.a(parcel, com.google.android.gms.ads.internal.client.zzl.CREATOR);
                final String string = parcel.readString();
                final IBinder strongBinder = parcel.readStrongBinder();
                Object o2;
                if (strongBinder == null) {
                    o2 = y11;
                }
                else {
                    final IInterface queryLocalInterface = strongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface instanceof y04) {
                        o2 = queryLocalInterface;
                    }
                    else {
                        o2 = new w04(strongBinder);
                    }
                }
                io3.b(parcel);
                this.y0(d2, zzl, string, (y04)o2);
                parcel2.writeNoException();
                break;
            }
            case 37: {
                final th1 d3 = n32.D(parcel.readStrongBinder());
                io3.b(parcel);
                this.e0(d3);
                parcel2.writeNoException();
                break;
            }
            case 36: {
                final c14 zzj = this.zzj();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzj);
                break;
            }
            case 35: {
                final th1 d4 = n32.D(parcel.readStrongBinder());
                final zzq zzq = (zzq)io3.a(parcel, com.google.android.gms.ads.internal.client.zzq.CREATOR);
                final zzl zzl2 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string2 = parcel.readString();
                final String string3 = parcel.readString();
                final IBinder strongBinder2 = parcel.readStrongBinder();
                if (strongBinder2 != null) {
                    final IInterface queryLocalInterface2 = strongBinder2.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface2 instanceof y04) {
                        o = queryLocalInterface2;
                    }
                    else {
                        o = new w04(strongBinder2);
                    }
                }
                io3.b(parcel);
                this.f0(d4, zzq, zzl2, string2, string3, (y04)o);
                parcel2.writeNoException();
                break;
            }
            case 34: {
                final zzbsd zzm = this.zzm();
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)zzm);
                break;
            }
            case 33: {
                final zzbsd zzl3 = this.zzl();
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)zzl3);
                break;
            }
            case 32: {
                final th1 d5 = n32.D(parcel.readStrongBinder());
                final zzl zzl4 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string4 = parcel.readString();
                final IBinder strongBinder3 = parcel.readStrongBinder();
                Object o3;
                if (strongBinder3 == null) {
                    o3 = y04;
                }
                else {
                    final IInterface queryLocalInterface3 = strongBinder3.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface3 instanceof y04) {
                        o3 = queryLocalInterface3;
                    }
                    else {
                        o3 = new w04(strongBinder3);
                    }
                }
                io3.b(parcel);
                this.g0(d5, zzl4, string4, (y04)o3);
                parcel2.writeNoException();
                break;
            }
            case 31: {
                final th1 d6 = n32.D(parcel.readStrongBinder());
                final IBinder strongBinder4 = parcel.readStrongBinder();
                Object o4;
                if (strongBinder4 == null) {
                    o4 = py3;
                }
                else {
                    final IInterface queryLocalInterface4 = strongBinder4.queryLocalInterface("com.google.android.gms.ads.internal.initialization.IAdapterInitializationCallback");
                    if (queryLocalInterface4 instanceof py3) {
                        o4 = queryLocalInterface4;
                    }
                    else {
                        o4 = new go3(strongBinder4, "com.google.android.gms.ads.internal.initialization.IAdapterInitializationCallback");
                    }
                }
                final ArrayList typedArrayList = parcel.createTypedArrayList(zzbmk.CREATOR);
                io3.b(parcel);
                this.c1(d6, (py3)o4, typedArrayList);
                parcel2.writeNoException();
                break;
            }
            case 30: {
                final th1 d7 = n32.D(parcel.readStrongBinder());
                io3.b(parcel);
                this.w(d7);
                parcel2.writeNoException();
                break;
            }
            case 28: {
                final th1 d8 = n32.D(parcel.readStrongBinder());
                final zzl zzl5 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string5 = parcel.readString();
                final IBinder strongBinder5 = parcel.readStrongBinder();
                Object o5;
                if (strongBinder5 == null) {
                    o5 = y5;
                }
                else {
                    final IInterface queryLocalInterface5 = strongBinder5.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface5 instanceof y04) {
                        o5 = queryLocalInterface5;
                    }
                    else {
                        o5 = new w04(strongBinder5);
                    }
                }
                io3.b(parcel);
                this.A0(d8, zzl5, string5, (y04)o5);
                parcel2.writeNoException();
                break;
            }
            case 27: {
                final i14 zzk = this.zzk();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzk);
                break;
            }
            case 26: {
                final zzdq zzh = this.zzh();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzh);
                break;
            }
            case 25: {
                final boolean f = io3.f(parcel);
                io3.b(parcel);
                this.z0(f);
                parcel2.writeNoException();
                break;
            }
            case 24: {
                final m14 n2 = this.n;
                Object a = interface1;
                if (n2 != null) {
                    final NativeCustomTemplateAd nativeCustomTemplateAd = (NativeCustomTemplateAd)n2.w;
                    a = interface1;
                    if (nativeCustomTemplateAd instanceof hv3) {
                        a = ((hv3)nativeCustomTemplateAd).a;
                    }
                }
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)a);
                break;
            }
            case 23: {
                final th1 d9 = n32.D(parcel.readStrongBinder());
                final IBinder strongBinder6 = parcel.readStrongBinder();
                Object o6;
                if (strongBinder6 != null) {
                    final IInterface queryLocalInterface6 = strongBinder6.queryLocalInterface("com.google.android.gms.ads.internal.reward.mediation.client.IMediationRewardedVideoAdListener");
                    if (queryLocalInterface6 instanceof v54) {
                        o6 = queryLocalInterface6;
                    }
                    else {
                        o6 = new go3(strongBinder6, "com.google.android.gms.ads.internal.reward.mediation.client.IMediationRewardedVideoAdListener");
                    }
                }
                else {
                    o6 = null;
                }
                final ArrayList stringArrayList = parcel.createStringArrayList();
                io3.b(parcel);
                this.L(d9, (v54)o6, (List)stringArrayList);
                throw null;
            }
            case 22: {
                parcel2.writeNoException();
                final ClassLoader a2 = io3.a;
                parcel2.writeInt(0);
                break;
            }
            case 21: {
                final th1 d10 = n32.D(parcel.readStrongBinder());
                io3.b(parcel);
                this.U0(d10);
                parcel2.writeNoException();
                break;
            }
            case 20: {
                final zzl zzl6 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string6 = parcel.readString();
                parcel.readString();
                io3.b(parcel);
                this.f1(zzl6, string6);
                parcel2.writeNoException();
                break;
            }
            case 19: {
                final Bundle bundle = new Bundle();
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)bundle);
                break;
            }
            case 18: {
                final Bundle bundle2 = new Bundle();
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)bundle2);
                break;
            }
            case 17: {
                final Bundle bundle3 = new Bundle();
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)bundle3);
                break;
            }
            case 16: {
                parcel2.writeNoException();
                final ClassLoader a3 = io3.a;
                parcel2.writeStrongBinder((IBinder)null);
                break;
            }
            case 15: {
                parcel2.writeNoException();
                final ClassLoader a4 = io3.a;
                parcel2.writeStrongBinder((IBinder)null);
                break;
            }
            case 14: {
                final th1 d11 = n32.D(parcel.readStrongBinder());
                final zzl zzl7 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string7 = parcel.readString();
                final String string8 = parcel.readString();
                final IBinder strongBinder7 = parcel.readStrongBinder();
                Object o7;
                if (strongBinder7 == null) {
                    o7 = y6;
                }
                else {
                    final IInterface queryLocalInterface7 = strongBinder7.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface7 instanceof y04) {
                        o7 = queryLocalInterface7;
                    }
                    else {
                        o7 = new w04(strongBinder7);
                    }
                }
                final zzbfw zzbfw = (zzbfw)io3.a(parcel, com.google.android.gms.internal.ads.zzbfw.CREATOR);
                final ArrayList stringArrayList2 = parcel.createStringArrayList();
                io3.b(parcel);
                this.a0(d11, zzl7, string7, string8, (y04)o7, zzbfw, stringArrayList2);
                parcel2.writeNoException();
                break;
            }
            case 13: {
                zzN = (this.zzN() ? 1 : 0);
                parcel2.writeNoException();
                final ClassLoader a5 = io3.a;
                parcel2.writeInt(zzN);
                break;
            }
            case 12: {
                this.j();
                parcel2.writeNoException();
                break;
            }
            case 11: {
                final zzl zzl8 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string9 = parcel.readString();
                io3.b(parcel);
                this.f1(zzl8, string9);
                parcel2.writeNoException();
                break;
            }
            case 10: {
                final th1 d12 = n32.D(parcel.readStrongBinder());
                final zzl zzl9 = (zzl)io3.a(parcel, zzl.CREATOR);
                parcel.readString();
                final IBinder strongBinder8 = parcel.readStrongBinder();
                Object o8;
                if (strongBinder8 == null) {
                    o8 = v54;
                }
                else {
                    final IInterface queryLocalInterface8 = strongBinder8.queryLocalInterface("com.google.android.gms.ads.internal.reward.mediation.client.IMediationRewardedVideoAdListener");
                    if (queryLocalInterface8 instanceof v54) {
                        o8 = queryLocalInterface8;
                    }
                    else {
                        o8 = new go3(strongBinder8, "com.google.android.gms.ads.internal.reward.mediation.client.IMediationRewardedVideoAdListener");
                    }
                }
                final String string10 = parcel.readString();
                io3.b(parcel);
                this.m0(d12, zzl9, (v54)o8, string10);
                parcel2.writeNoException();
                break;
            }
            case 9: {
                this.zzF();
                parcel2.writeNoException();
                break;
            }
            case 8: {
                this.zzE();
                parcel2.writeNoException();
                break;
            }
            case 7: {
                final th1 d13 = n32.D(parcel.readStrongBinder());
                final zzl zzl10 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string11 = parcel.readString();
                final String string12 = parcel.readString();
                final IBinder strongBinder9 = parcel.readStrongBinder();
                Object o9;
                if (strongBinder9 == null) {
                    o9 = y7;
                }
                else {
                    final IInterface queryLocalInterface9 = strongBinder9.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface9 instanceof y04) {
                        o9 = queryLocalInterface9;
                    }
                    else {
                        o9 = new w04(strongBinder9);
                    }
                }
                io3.b(parcel);
                this.G0(d13, zzl10, string11, string12, (y04)o9);
                parcel2.writeNoException();
                break;
            }
            case 6: {
                final th1 d14 = n32.D(parcel.readStrongBinder());
                final zzq zzq2 = (zzq)io3.a(parcel, zzq.CREATOR);
                final zzl zzl11 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string13 = parcel.readString();
                final String string14 = parcel.readString();
                final IBinder strongBinder10 = parcel.readStrongBinder();
                Object o10;
                if (strongBinder10 == null) {
                    o10 = y8;
                }
                else {
                    final IInterface queryLocalInterface10 = strongBinder10.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface10 instanceof y04) {
                        o10 = queryLocalInterface10;
                    }
                    else {
                        o10 = new w04(strongBinder10);
                    }
                }
                io3.b(parcel);
                this.U(d14, zzq2, zzl11, string13, string14, (y04)o10);
                parcel2.writeNoException();
                break;
            }
            case 5: {
                this.zzo();
                parcel2.writeNoException();
                break;
            }
            case 4: {
                this.p();
                parcel2.writeNoException();
                break;
            }
            case 3: {
                final th1 d15 = n32.D(parcel.readStrongBinder());
                final zzl zzl12 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string15 = parcel.readString();
                final IBinder strongBinder11 = parcel.readStrongBinder();
                Object o11;
                if (strongBinder11 == null) {
                    o11 = y9;
                }
                else {
                    final IInterface queryLocalInterface11 = strongBinder11.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface11 instanceof y04) {
                        o11 = queryLocalInterface11;
                    }
                    else {
                        o11 = new w04(strongBinder11);
                    }
                }
                io3.b(parcel);
                this.G0(d15, zzl12, string15, null, (y04)o11);
                parcel2.writeNoException();
                break;
            }
            case 2: {
                final th1 zzn = this.zzn();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzn);
                break;
            }
            case 1: {
                final th1 d16 = n32.D(parcel.readStrongBinder());
                final zzq zzq3 = (zzq)io3.a(parcel, zzq.CREATOR);
                final zzl zzl13 = (zzl)io3.a(parcel, zzl.CREATOR);
                final String string16 = parcel.readString();
                final IBinder strongBinder12 = parcel.readStrongBinder();
                Object o12;
                if (strongBinder12 == null) {
                    o12 = y10;
                }
                else {
                    final IInterface queryLocalInterface12 = strongBinder12.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapterListener");
                    if (queryLocalInterface12 instanceof y04) {
                        o12 = queryLocalInterface12;
                    }
                    else {
                        o12 = new w04(strongBinder12);
                    }
                }
                io3.b(parcel);
                this.U(d16, zzq3, zzl13, string16, null, (y04)o12);
                parcel2.writeNoException();
                break;
            }
        }
        return true;
    }
    
    public final zzdq zzh() {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof zza) {
            try {
                return ((zza)c).getVideoController();
            }
            finally {
                final Throwable t;
                d94.zzh("", t);
            }
        }
        return null;
    }
    
    public final c14 zzj() {
        final MediationInterscrollerAd q = this.Q;
        if (q != null) {
            return (c14)new p14(q);
        }
        return null;
    }
    
    public final i14 zzk() {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof MediationNativeAdapter) {
            final m14 n = this.n;
            if (n != null) {
                final UnifiedNativeAdMapper unifiedNativeAdMapper = (UnifiedNativeAdMapper)n.v;
                if (unifiedNativeAdMapper != null) {
                    return (i14)new s14(unifiedNativeAdMapper);
                }
            }
        }
        else if (c instanceof Adapter) {
            final UnifiedNativeAdMapper z = this.z;
            if (z != null) {
                return (i14)new s14(z);
            }
        }
        return null;
    }
    
    public final zzbsd zzl() {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter)) {
            return null;
        }
        return zzbsd.c(((Adapter)c).getVersionInfo());
    }
    
    public final zzbsd zzm() {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof Adapter)) {
            return null;
        }
        return zzbsd.c(((Adapter)c).getSDKVersionInfo());
    }
    
    public final th1 zzn() {
        final MediationExtrasReceiver c = this.c;
        if (c instanceof MediationBannerAdapter) {
            try {
                return new n32(((MediationBannerAdapter)c).getBannerView());
            }
            finally {
                final Throwable t;
                throw f83.c("", t);
            }
        }
        if (c instanceof Adapter) {
            return new n32(this.x);
        }
        final String canonicalName = MediationBannerAdapter.class.getCanonicalName();
        final String canonicalName2 = Adapter.class.getCanonicalName();
        final String canonicalName3 = ((MediationBannerAdapter)c).getClass().getCanonicalName();
        final StringBuilder sb = new StringBuilder();
        sb.append(canonicalName);
        sb.append(" or ");
        sb.append(canonicalName2);
        sb.append(" #009 Class mismatch: ");
        sb.append(canonicalName3);
        d94.zzj(sb.toString());
        throw new RemoteException();
    }
    
    public final void zzo() {
        final MediationExtrasReceiver c = this.c;
        if (!(c instanceof MediationAdapter)) {
            return;
        }
        try {
            ((MediationAdapter)c).onDestroy();
        }
        finally {
            final Throwable t;
            throw f83.c("", t);
        }
    }
}
