import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.material3.IconKt;
import androidx.compose.material.icons.filled.CheckKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import java.util.TimeZone;

public final class ej implements od1
{
    public final TimeZone c;
    public final boolean n;
    
    public ej(final TimeZone c, final boolean n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs(SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)12));
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)Arrangement.INSTANCE.getSpaceBetween(), Alignment.Companion.getCenterVertically(), composer, 54);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion = ComposeUiNode.Companion;
            final id1 constructor = companion.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion, constructor-impl, rowMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion.getSetModifier());
            final RowScopeInstance instance = RowScopeInstance.INSTANCE;
            final String displayName = this.c.getDisplayName();
            final MaterialTheme instance2 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            TextKt.Text--4IGK_g(displayName, (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance2.getTypography(composer, $stable).getBodyMedium(), composer, 0, 0, 65534);
            composer.startReplaceGroup(-845836813);
            if (this.n) {
                IconKt.Icon-ww6aTOc(CheckKt.getCheck(Icons.INSTANCE.getDefault()), "Selected", (Modifier)null, instance2.getColorScheme(composer, $stable).getPrimary-0d7_KjU(), composer, 48, 4);
            }
            composer.endReplaceGroup();
            composer.endNode();
        }
        return t43.a;
    }
}
