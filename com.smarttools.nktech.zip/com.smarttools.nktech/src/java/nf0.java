import androidx.compose.material3.DividerKt;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;

public final class nf0 implements od1
{
    public static final nf0 c;
    
    static {
        c = (nf0)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            DividerKt.HorizontalDivider-9IZ8Weo(PaddingKt.padding-VpY3zN4$default((Modifier)Modifier.Companion, 0.0f, Dp.constructor-impl((float)8), 1, (Object)null), 0.0f, 0L, composer, 6, 6);
        }
        return t43.a;
    }
}
