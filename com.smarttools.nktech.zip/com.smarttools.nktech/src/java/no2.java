import androidx.compose.ui.Modifier;
import com.smarttools.nktech.features.settings.presentation.l;
import com.smarttools.nktech.c;
import com.smarttools.nktech.core.data.datastore.ThemeMode;
import com.smarttools.nktech.core.data.datastore.LayoutStyle;
import androidx.compose.runtime.Composer;
import androidx.navigation.a;
import androidx.compose.animation.AnimatedContentScope;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.State;
import android.content.Context;
import com.smarttools.nktech.core.data.datastore.r;

public final class no2 implements pd1
{
    public final dq0 P;
    public final r Q;
    public final Context R;
    public final ft1 S;
    public final n02 T;
    public final u13 c;
    public final State n;
    public final State v;
    public final State w;
    public final State x;
    public final State y;
    public final MutableState z;
    
    public no2(final u13 c, final State n, final State v, final State w, final State x, final State y, final MutableState z, final dq0 p12, final r q, final Context r, final ft1 s, final n02 t) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p12;
        this.Q = q;
        this.R = r;
        this.S = s;
        this.T = t;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3, final Object o4) {
        final AnimatedContentScope animatedContentScope = (AnimatedContentScope)o;
        final a a = (a)o2;
        final Composer composer = (Composer)o3;
        ((Number)o4).intValue();
        final LayoutStyle layoutStyle = (LayoutStyle)this.n.getValue();
        final ThemeMode themeMode = (ThemeMode)this.v.getValue();
        final boolean booleanValue = (boolean)this.w.getValue();
        final boolean booleanValue2 = (boolean)this.x.getValue();
        u13 c;
        if (!(boolean)this.y.getValue() && !(boolean)((State)this.z).getValue()) {
            c = null;
        }
        else {
            c = this.c;
        }
        final r q = this.Q;
        final dq0 p4 = this.P;
        final com.smarttools.nktech.a a2 = new com.smarttools.nktech.a(p4, q, 1);
        final com.smarttools.nktech.a a3 = new com.smarttools.nktech.a(p4, q, 2);
        final com.smarttools.nktech.a a4 = new com.smarttools.nktech.a(p4, q, 3);
        final c c2 = new c(this.R, p4, this.S, q);
        final n02 t = this.T;
        l.d(layoutStyle, themeMode, booleanValue, false, booleanValue2, (jd1)a2, (jd1)a3, (jd1)a4, (jd1)null, (jd1)c2, (id1)new io2(t, 3), (id1)new io2(t, 4), (id1)new io2(t, 5), (id1)new io2(t, 6), new io2(t, 7), c, (Modifier)null, composer, 0, 0);
        return t43.a;
    }
}
