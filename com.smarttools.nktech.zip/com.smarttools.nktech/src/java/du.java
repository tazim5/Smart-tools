public final class du
{
    public Object a;
    public b83 b;
}
