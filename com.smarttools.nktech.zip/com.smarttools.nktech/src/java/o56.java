import android.media.metrics.LogSessionId;

public abstract class o56
{
    public static void a(final k56 k56, final r36 r36) {
        final q36 a = r36.a;
        a.getClass();
        final LogSessionId a2 = a.a;
        if (!o36.g(a2, (Object)ev2.c())) {
            k56.b.setString("log-session-id", o36.e(a2));
        }
    }
}
