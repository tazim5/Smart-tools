public final class p16
{
    public final q66 a;
    public final long b;
    public final long c;
    public final long d;
    public final long e;
    public final boolean f;
    public final boolean g;
    public final boolean h;
    
    public p16(final q66 a, final long b, final long c, final long d, final long e, final boolean f, final boolean g, final boolean h) {
        final boolean b2 = false;
        aq3.i(!h || f);
        boolean b3 = false;
        Label_0048: {
            if (g) {
                b3 = b2;
                if (!f) {
                    break Label_0048;
                }
            }
            b3 = true;
        }
        aq3.i(b3);
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o != null) {
            if (p16.class == o.getClass()) {
                final p16 p = (p16)o;
                if (this.b == p.b && this.c == p.c && this.d == p.d && this.e == p.e && this.f == p.f && this.g == p.g && this.h == p.h && ec5.d((Object)this.a, (Object)p.a)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        return (((((((this.a.hashCode() + 527) * 31 + (int)this.b) * 31 + (int)this.c) * 31 + (int)this.d) * 31 + (int)this.e) * 961 + (this.f ? 1 : 0)) * 31 + (this.g ? 1 : 0)) * 31 + (this.h ? 1 : 0);
    }
}
