import com.google.android.gms.ads.internal.client.zzbk;
import com.google.android.gms.ads.internal.client.zzdq;
import com.google.android.gms.ads.internal.client.zzdn;
import java.util.Collections;
import android.os.Bundle;
import com.google.android.gms.ads.internal.client.zzcf;
import com.google.android.gms.ads.internal.client.zzfl;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzdg;
import com.google.android.gms.ads.internal.client.zzdu;
import com.google.android.gms.ads.internal.client.zzci;
import com.google.android.gms.ads.internal.client.zzw;
import com.google.android.gms.ads.internal.client.zzcb;
import com.google.android.gms.ads.internal.client.zzby;
import com.google.android.gms.ads.internal.client.zzbh;
import com.google.android.gms.ads.internal.client.zzbe;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zze;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.ads.internal.client.zzl;
import com.google.android.gms.internal.ads.zzcbt;
import com.google.android.gms.ads.internal.client.zzq;
import android.content.Context;
import com.google.android.gms.ads.internal.client.zzbt;

public final class p05 extends zzbt implements hk4
{
    public final gs4 P;
    public eg4 Q;
    public final Context c;
    public final b55 n;
    public final String v;
    public final s05 w;
    public zzq x;
    public final n65 y;
    public final zzcbt z;
    
    public p05(final Context c, final zzq x, final String v, final b55 n, final s05 w, final zzcbt z, final gs4 p7) {
        this.c = c;
        this.n = n;
        this.x = x;
        this.v = v;
        this.w = w;
        this.y = n.k;
        this.z = z;
        this.P = p7;
        ((xo1)n.h).s0((Object)this, n.b);
    }
    
    public final boolean f1(final zzl zzl) {
        monitorenter(this);
        Label_0024: {
            try {
                if (this.g1()) {
                    Preconditions.checkMainThread("loadAd must be called on the main UI thread.");
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                s05 w = null;
            Block_7:
                while (true) {
                    d94.zzg("Failed to load the ad because app ID is missing.");
                    w = this.w;
                    iftrue(Label_0069:)(w == null);
                    break Block_7;
                    Label_0074: {
                        yr3.b(this.c, zzl.zzf);
                    }
                    final boolean b = this.n.b(zzl, this.v, (nq3)null, (b15)new am4((Object)this, 8));
                    monitorexit(this);
                    return b;
                    zzt.zzp();
                    iftrue(Label_0074:)(!com.google.android.gms.ads.internal.util.zzt.zzG(this.c) || zzl.zzs != null);
                    continue;
                }
                w.x(zr3.g(4, (String)null, (zze)null));
                Label_0069: {
                    monitorexit(this);
                }
                return false;
            }
        }
    }
    
    public final boolean g1() {
        final boolean b = (boolean)bt3.f.k() && (boolean)zzba.zzc().a(cs3.A9);
        return this.z.v < (int)zzba.zzc().a(cs3.B9) || !b;
    }
    
    public final void zzA() {
        monitorenter(this);
        Label_0029: {
            try {
                Preconditions.checkMainThread("recordManualImpression must be called on the main UI thread.");
                final eg4 q = this.Q;
                if (q != null) {
                    q.g();
                    monitorexit(this);
                    return;
                }
                break Label_0029;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzB() {
        monitorenter(this);
        Label_0076: {
            try {
                if ((boolean)bt3.h.k() && (boolean)zzba.zzc().a(cs3.w9) && this.z.v >= (int)zzba.zzc().a(cs3.C9)) {
                    break Label_0076;
                }
                break Label_0076;
            }
            finally {
                monitorexit(this);
                Label_0120: {
                    monitorexit(this);
                }
                return;
                Preconditions.checkMainThread("resume must be called on the main UI thread.");
                break Label_0076;
                while (true) {
                    final eg4 q;
                    final lj4 c = ((dh4)q).c;
                    c.getClass();
                    ((xo1)c).t0((gl4)new uu5((Object)null, 26));
                    monitorexit(this);
                    return;
                    q = this.Q;
                    iftrue(Label_0120:)(q == null);
                    continue;
                }
            }
        }
    }
    
    public final void zzC(final zzbe c) {
        if (this.g1()) {
            Preconditions.checkMainThread("setAdListener must be called on the main UI thread.");
        }
        final u05 e = this.n.e;
        synchronized (e) {
            e.c = c;
        }
    }
    
    public final void zzD(final zzbh zzbh) {
        if (this.g1()) {
            Preconditions.checkMainThread("setAdListener must be called on the main UI thread.");
        }
        this.w.c.set((Object)zzbh);
    }
    
    public final void zzE(final zzby zzby) {
        Preconditions.checkMainThread("setAdMetadataListener must be called on the main UI thread.");
    }
    
    public final void zzF(final zzq zzq) {
        monitorenter(this);
        Label_0050: {
            try {
                Preconditions.checkMainThread("setAdSize must be called on the main UI thread.");
                this.y.b = zzq;
                this.x = zzq;
                final eg4 q = this.Q;
                if (q != null) {
                    q.h(this.n.f, zzq);
                    monitorexit(this);
                    return;
                }
                break Label_0050;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzG(final zzcb zzcb) {
        if (this.g1()) {
            Preconditions.checkMainThread("setAppEventListener must be called on the main UI thread.");
        }
        this.w.h(zzcb);
    }
    
    public final void zzH(final rp3 rp3) {
    }
    
    public final void zzI(final zzw zzw) {
    }
    
    public final void zzJ(final zzci zzci) {
    }
    
    public final void zzK(final zzdu zzdu) {
    }
    
    public final void zzL(final boolean b) {
    }
    
    public final void zzM(final w34 w34) {
    }
    
    public final void zzN(final boolean e) {
        monitorenter(this);
        Label_0024: {
            try {
                if (this.g1()) {
                    Preconditions.checkMainThread("setManualImpressionsEnabled must be called from the main thread.");
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                this.y.e = e;
                monitorexit(this);
            }
        }
    }
    
    public final void zzO(final ns3 g) {
        synchronized (this) {
            Preconditions.checkMainThread("setOnCustomRenderedAdLoadedListener must be called on the main UI thread.");
            this.n.g = g;
        }
    }
    
    public final void zzP(final zzdg zzdg) {
        if (this.g1()) {
            Preconditions.checkMainThread("setPaidEventListener must be called on the main UI thread.");
        }
        try {
            if (!zzdg.zzf()) {
                this.P.b();
            }
        }
        catch (final RemoteException ex) {
            d94.zzf("Error in making CSI ping for reporting paid event callback", (Throwable)ex);
        }
        this.w.v.set((Object)zzdg);
    }
    
    public final void zzQ(final a44 a44, final String s) {
    }
    
    public final void zzR(final String s) {
    }
    
    public final void zzS(final p54 p) {
    }
    
    public final void zzT(final String s) {
    }
    
    public final void zzU(final zzfl d) {
        monitorenter(this);
        Label_0024: {
            try {
                if (this.g1()) {
                    Preconditions.checkMainThread("setVideoOptions must be called on the main UI thread.");
                }
                break Label_0024;
            }
            finally {
                monitorexit(this);
                this.y.d = d;
                monitorexit(this);
            }
        }
    }
    
    public final void zzW(final th1 th1) {
    }
    
    public final void zzX() {
    }
    
    public final boolean zzY() {
        synchronized (this) {
            return this.n.a();
        }
    }
    
    public final boolean zzZ() {
        return false;
    }
    
    public final boolean zzaa(final zzl zzl) {
        p05 p = this;
        final zzq x;
        synchronized (this) {
            x = this.x;
            p = this;
            monitorenter(this);
            final p05 p2 = this;
            final n65 n65 = p2.y;
            final n65 n67;
            final n65 n66 = n67 = n65;
            final zzq zzq = x;
            n67.b = zzq;
            final n65 n68 = n66;
            final p05 p3 = this;
            final zzq zzq2 = p3.x;
            final boolean b = zzq2.zzn;
            n68.p = b;
            final p05 p4 = p;
            monitorexit(p4);
            final p05 p5 = this;
            final zzl zzl2 = zzl;
            final boolean f1 = p5.f1(zzl2);
            return f1;
        }
        try {
            final p05 p2 = this;
            final n65 n65 = p2.y;
            final n65 n67;
            final n65 n66 = n67 = n65;
            final zzq zzq = x;
            n67.b = zzq;
            final n65 n68 = n66;
            final p05 p3 = this;
            final zzq zzq2 = p3.x;
            final boolean b = zzq2.zzn;
            n68.p = b;
            final p05 p4 = p;
            monitorexit(p4);
            final p05 p5 = this;
            final zzl zzl2 = zzl;
            final boolean f2;
            final boolean f1 = f2 = p5.f1(zzl2);
            return f2;
        }
        finally {}
    }
    
    public final void zzab(final zzcf s) {
        synchronized (this) {
            Preconditions.checkMainThread("setCorrelationIdProvider must be called on the main UI thread");
            this.y.s = s;
        }
    }
    
    public final Bundle zzd() {
        Preconditions.checkMainThread("getAdMetadata must be called on the main UI thread.");
        return new Bundle();
    }
    
    public final zzq zzg() {
        monitorenter(this);
        Label_0042: {
            try {
                Preconditions.checkMainThread("getAdSize must be called on the main UI thread.");
                final eg4 q = this.Q;
                if (q != null) {
                    final zzq c = or3.c(this.c, Collections.singletonList((Object)q.e()));
                    monitorexit(this);
                    return c;
                }
                break Label_0042;
            }
            finally {
                monitorexit(this);
                final zzq b = this.y.b;
                monitorexit(this);
                return b;
            }
        }
    }
    
    public final zzbh zzi() {
        return this.w.g();
    }
    
    public final zzcb zzj() {
        final s05 w = this.w;
        synchronized (w) {
            return (zzcb)w.n.get();
        }
    }
    
    public final zzdn zzk() {
        synchronized (this) {
            if (zzba.zzc().a(cs3.V5)) {
                final eg4 q = this.Q;
                if (q != null) {
                    return (zzdn)((dh4)q).f;
                }
            }
            return null;
        }
    }
    
    public final zzdq zzl() {
        monitorenter(this);
        Label_0032: {
            try {
                Preconditions.checkMainThread("getVideoController must be called from the main thread.");
                final eg4 q = this.Q;
                if (q != null) {
                    final zzdq d = q.d();
                    monitorexit(this);
                    return d;
                }
                break Label_0032;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
                return null;
            }
        }
    }
    
    public final th1 zzn() {
        if (this.g1()) {
            Preconditions.checkMainThread("getAdFrame must be called on the main UI thread.");
        }
        return new n32(this.n.f);
    }
    
    public final String zzr() {
        synchronized (this) {
            return this.v;
        }
    }
    
    public final String zzs() {
        synchronized (this) {
            final eg4 q = this.Q;
            if (q != null) {
                final vi4 f = ((dh4)q).f;
                if (f != null) {
                    return f.c;
                }
            }
            return null;
        }
    }
    
    public final String zzt() {
        synchronized (this) {
            final eg4 q = this.Q;
            if (q != null) {
                final vi4 f = ((dh4)q).f;
                if (f != null) {
                    return f.c;
                }
            }
            return null;
        }
    }
    
    public final void zzx() {
        monitorenter(this);
        Label_0076: {
            try {
                if ((boolean)bt3.e.k() && (boolean)zzba.zzc().a(cs3.x9) && this.z.v >= (int)zzba.zzc().a(cs3.C9)) {
                    break Label_0076;
                }
                break Label_0076;
            }
            finally {
                monitorexit(this);
                Preconditions.checkMainThread("destroy must be called on the main UI thread.");
                break Label_0076;
                while (true) {
                    final eg4 q;
                    final lj4 c = ((dh4)q).c;
                    c.getClass();
                    ((xo1)c).t0((gl4)new tr3((Context)null, false));
                    monitorexit(this);
                    return;
                    Label_0120: {
                        monitorexit(this);
                    }
                    return;
                    q = this.Q;
                    iftrue(Label_0120:)(q == null);
                    continue;
                }
            }
        }
    }
    
    public final void zzy(final zzl zzl, final zzbk zzbk) {
    }
    
    public final void zzz() {
        monitorenter(this);
        Label_0076: {
            try {
                if ((boolean)bt3.g.k() && (boolean)zzba.zzc().a(cs3.y9) && this.z.v >= (int)zzba.zzc().a(cs3.C9)) {
                    break Label_0076;
                }
                break Label_0076;
            }
            finally {
                monitorexit(this);
                Label_0120: {
                    monitorexit(this);
                }
                return;
                Preconditions.checkMainThread("pause must be called on the main UI thread.");
                break Label_0076;
                while (true) {
                    final eg4 q;
                    final lj4 c = ((dh4)q).c;
                    c.getClass();
                    ((xo1)c).t0((gl4)new tt0((Context)null, false));
                    monitorexit(this);
                    return;
                    q = this.Q;
                    iftrue(Label_0120:)(q == null);
                    continue;
                }
            }
        }
    }
}
