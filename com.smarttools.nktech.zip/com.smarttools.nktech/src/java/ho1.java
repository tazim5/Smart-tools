public interface ho1
{
}
