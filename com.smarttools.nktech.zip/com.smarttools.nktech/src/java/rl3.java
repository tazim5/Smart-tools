import com.google.android.gms.internal.ads.zzayz;
import com.google.android.gms.internal.ads.zzazn;
import com.google.android.gms.internal.ads.zzbbc;

public final class rl3 implements np5
{
    public static final rl3 A;
    public static final rl3 B;
    public static final rl3 C;
    public static final rl3 D;
    public static final rl3 E;
    public static final rl3 b;
    public static final rl3 c;
    public static final rl3 d;
    public static final rl3 e;
    public static final rl3 f;
    public static final rl3 g;
    public static final rl3 h;
    public static final rl3 i;
    public static final rl3 j;
    public static final rl3 k;
    public static final rl3 l;
    public static final rl3 m;
    public static final rl3 n;
    public static final rl3 o;
    public static final rl3 p;
    public static final rl3 q;
    public static final rl3 r;
    public static final rl3 s;
    public static final rl3 t;
    public static final rl3 u;
    public static final rl3 v;
    public static final rl3 w;
    public static final rl3 x;
    public static final rl3 y;
    public static final rl3 z;
    public final int a;
    
    public final boolean zza(final int n) {
        switch (this.a) {
            default: {
                boolean b = true;
                if (n != 0) {
                    b = b;
                    if (n != 1) {
                        b = false;
                    }
                }
                return b;
            }
            case 28: {
                boolean b3;
                final boolean b2 = b3 = true;
                if (n != 0) {
                    b3 = b2;
                    if (n != 1) {
                        b3 = b2;
                        if (n != 2) {
                            b3 = b2;
                            if (n != 3) {
                                b3 = false;
                            }
                        }
                    }
                }
                return b3;
            }
            case 27: {
                boolean b4 = false;
                switch (n) {
                    default: {
                        b4 = false;
                        break;
                    }
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                    case 15: {
                        b4 = true;
                        break;
                    }
                }
                return b4;
            }
            case 26: {
                boolean b6;
                final boolean b5 = b6 = true;
                if (n != 0) {
                    b6 = b5;
                    if (n != 1) {
                        b6 = b5;
                        if (n != 2) {
                            b6 = b5;
                            if (n != 3) {
                                b6 = b5;
                                if (n != 4) {
                                    b6 = false;
                                }
                            }
                        }
                    }
                }
                return b6;
            }
            case 25: {
                boolean b8;
                final boolean b7 = b8 = true;
                if (n != 0) {
                    b8 = b7;
                    if (n != 1) {
                        b8 = b7;
                        if (n != 2) {
                            b8 = b7;
                            if (n != 3) {
                                b8 = b7;
                                if (n != 4) {
                                    b8 = false;
                                }
                            }
                        }
                    }
                }
                return b8;
            }
            case 24: {
                boolean b9 = false;
                switch (n) {
                    default: {
                        b9 = false;
                        break;
                    }
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8: {
                        b9 = true;
                        break;
                    }
                }
                return b9;
            }
            case 23: {
                boolean b10 = false;
                switch (n) {
                    default: {
                        b10 = false;
                        break;
                    }
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                    case 11:
                    case 12: {
                        b10 = true;
                        break;
                    }
                }
                return b10;
            }
            case 22: {
                boolean b12;
                final boolean b11 = b12 = true;
                if (n != 0) {
                    b12 = b11;
                    if (n != 1) {
                        b12 = b11;
                        if (n != 2) {
                            b12 = b11;
                            if (n != 3) {
                                b12 = false;
                            }
                        }
                    }
                }
                return b12;
            }
            case 21: {
                boolean b14;
                final boolean b13 = b14 = true;
                if (n != 0) {
                    b14 = b13;
                    if (n != 1) {
                        b14 = b13;
                        if (n != 2) {
                            b14 = b13;
                            if (n != 3) {
                                b14 = false;
                            }
                        }
                    }
                }
                return b14;
            }
            case 20: {
                boolean b15 = true;
                if (n != 0) {
                    b15 = b15;
                    if (n != 1) {
                        b15 = false;
                    }
                }
                return b15;
            }
            case 19: {
                boolean b17;
                final boolean b16 = b17 = true;
                if (n != 0) {
                    b17 = b16;
                    if (n != 1) {
                        b17 = b16;
                        if (n != 2) {
                            b17 = b16;
                            if (n != 1999) {
                                b17 = b16;
                                switch (n) {
                                    default: {
                                        b17 = false;
                                        break;
                                    }
                                    case 1000:
                                    case 1001:
                                    case 1002:
                                    case 1003:
                                    case 1004:
                                    case 1005:
                                    case 1006:
                                    case 1007:
                                    case 1008:
                                    case 1009:
                                    case 1010: {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                return b17;
            }
            case 18: {
                boolean b18 = true;
                if (n != 0) {
                    b18 = b18;
                    if (n != 1) {
                        b18 = false;
                    }
                }
                return b18;
            }
            case 17: {
                boolean b19 = true;
                if (n != 1) {
                    b19 = b19;
                    if (n != 2) {
                        b19 = false;
                    }
                }
                return b19;
            }
            case 16: {
                boolean b21;
                final boolean b20 = b21 = true;
                if (n != 0) {
                    b21 = b20;
                    if (n != 1) {
                        b21 = b20;
                        if (n != 2) {
                            b21 = b20;
                            if (n != 3) {
                                b21 = false;
                            }
                        }
                    }
                }
                return b21;
            }
            case 15: {
                return zzbbc.b(n) != null;
            }
            case 14: {
                boolean b23;
                final boolean b22 = b23 = true;
                if (n != 0) {
                    b23 = b22;
                    if (n != 1) {
                        b23 = b22;
                        if (n != 2) {
                            b23 = false;
                        }
                    }
                }
                return b23;
            }
            case 13: {
                boolean b25;
                final boolean b24 = b25 = true;
                if (n != 0) {
                    b25 = b24;
                    if (n != 1) {
                        b25 = b24;
                        if (n != 2) {
                            b25 = b24;
                            if (n != 4) {
                                b25 = false;
                            }
                        }
                    }
                }
                return b25;
            }
            case 12: {
                return ib.b(n) != 0;
            }
            case 11: {
                boolean b27;
                final boolean b26 = b27 = true;
                if (n != 0) {
                    b27 = b26;
                    if (n != 1) {
                        b27 = b26;
                        if (n != 2) {
                            b27 = false;
                        }
                    }
                }
                return b27;
            }
            case 10: {
                return zzazn.b(n) != null;
            }
            case 9: {
                boolean b28 = true;
                if (n != 0) {
                    b28 = b28;
                    if (n != 1) {
                        b28 = false;
                    }
                }
                return b28;
            }
            case 8: {
                zzayz zzayz = null;
                switch (n) {
                    default: {
                        zzayz = null;
                        break;
                    }
                    case 11: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.T;
                        break;
                    }
                    case 10: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.S;
                        break;
                    }
                    case 9: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.R;
                        break;
                    }
                    case 8: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.Q;
                        break;
                    }
                    case 7: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.P;
                        break;
                    }
                    case 6: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.z;
                        break;
                    }
                    case 5: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.y;
                        break;
                    }
                    case 4: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.x;
                        break;
                    }
                    case 3: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.w;
                        break;
                    }
                    case 2: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.v;
                        break;
                    }
                    case 1: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.n;
                        break;
                    }
                    case 0: {
                        zzayz = com.google.android.gms.internal.ads.zzayz.c;
                        break;
                    }
                }
                return zzayz != null;
            }
            case 7: {
                boolean b30;
                final boolean b29 = b30 = true;
                if (n != 0) {
                    b30 = b29;
                    if (n != 1) {
                        b30 = b29;
                        if (n != 2) {
                            b30 = b29;
                            if (n != 3) {
                                b30 = false;
                            }
                        }
                    }
                }
                return b30;
            }
            case 6: {
                boolean b32;
                final boolean b31 = b32 = true;
                if (n != 0) {
                    b32 = b31;
                    if (n != 1) {
                        b32 = b31;
                        if (n != 2) {
                            b32 = b31;
                            if (n != 1000) {
                                b32 = false;
                            }
                        }
                    }
                }
                return b32;
            }
            case 5: {
                boolean b34;
                final boolean b33 = b34 = true;
                if (n != 0) {
                    b34 = b33;
                    if (n != 1) {
                        b34 = b33;
                        if (n != 2) {
                            b34 = b33;
                            if (n != 3) {
                                b34 = b33;
                                if (n != 4) {
                                    b34 = b33;
                                    if (n != 5) {
                                        b34 = false;
                                    }
                                }
                            }
                        }
                    }
                }
                return b34;
            }
            case 4: {
                return c16.a(n) != 0;
            }
            case 3: {
                boolean b36;
                final boolean b35 = b36 = true;
                if (n != 0) {
                    b36 = b35;
                    if (n != 1) {
                        b36 = b35;
                        if (n != 2) {
                            b36 = b35;
                            if (n != 3) {
                                b36 = b35;
                                if (n != 4) {
                                    b36 = false;
                                }
                            }
                        }
                    }
                }
                return b36;
            }
            case 2: {
                boolean b37 = false;
                switch (n) {
                    default: {
                        b37 = false;
                        break;
                    }
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9: {
                        b37 = true;
                        break;
                    }
                }
                return b37;
            }
            case 1: {
                boolean b38 = false;
                switch (n) {
                    default: {
                        b38 = false;
                        break;
                    }
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6: {
                        b38 = true;
                        break;
                    }
                }
                return b38;
            }
            case 0: {
                boolean b40;
                final boolean b39 = b40 = true;
                if (n != 0) {
                    b40 = b39;
                    if (n != 1) {
                        b40 = b39;
                        if (n != 2) {
                            b40 = false;
                        }
                    }
                }
                return b40;
            }
        }
    }
}
