import java.util.Comparator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;

public final class x86
{
    public final ArrayList a;
    public final w86[] b;
    public int c;
    public int d;
    public int e;
    public int f;
    
    public x86() {
        this.b = new w86[5];
        this.a = new ArrayList();
        this.c = -1;
    }
    
    public final float a() {
        final int c = this.c;
        final ArrayList a = this.a;
        int i = 0;
        if (c != 0) {
            Collections.sort((List)a, (Comparator)m74.S);
            this.c = 0;
        }
        final float n = (float)this.e;
        int n2 = 0;
        while (i < a.size()) {
            final w86 w86 = (w86)a.get(i);
            n2 += w86.b;
            if (n2 >= 0.5f * n) {
                return w86.c;
            }
            ++i;
        }
        if (a.isEmpty()) {
            return Float.NaN;
        }
        return ((w86)a.get(a.size() - 1)).c;
    }
    
    public final void b(final float c, int b) {
        final int c2 = this.c;
        final ArrayList a = this.a;
        if (c2 != 1) {
            Collections.sort((List)a, (Comparator)m74.R);
            this.c = 1;
        }
        int f = this.f;
        final w86[] b2 = this.b;
        Object o;
        if (f > 0) {
            --f;
            this.f = f;
            o = b2[f];
        }
        else {
            o = new Object();
        }
        ((w86)o).a = this.d++;
        ((w86)o).b = b;
        ((w86)o).c = c;
        a.add(o);
        this.e += b;
        while (true) {
            b = this.e;
            if (b <= 2000) {
                break;
            }
            final int n = b - 2000;
            final w86 w86 = (w86)a.get(0);
            b = w86.b;
            if (b <= n) {
                this.e -= b;
                a.remove(0);
                b = this.f;
                if (b >= 5) {
                    continue;
                }
                this.f = b + 1;
                b2[b] = w86;
            }
            else {
                w86.b = b - n;
                this.e -= n;
            }
        }
    }
}
