import java.util.Arrays;

public final class sv4
{
    public final int a;
    public final int b;
    public final float c;
    public final float d;
    public final float e;
    public final int f;
    public final int g;
    public final int h;
    public final short[] i;
    public short[] j;
    public int k;
    public short[] l;
    public int m;
    public short[] n;
    public int o;
    public int p;
    public int q;
    public int r;
    public int s;
    public int t;
    public int u;
    public int v;
    
    public sv4(final float c, int h, final float d, final int b, final int n) {
        this.a = h;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = h / (float)n;
        this.f = h / 400;
        h /= 65;
        this.g = h;
        h += h;
        this.h = h;
        this.i = new short[h];
        h *= b;
        this.j = new short[h];
        this.l = new short[h];
        this.n = new short[h];
    }
    
    public static void d(final int n, final int n2, final short[] array, final int n3, final short[] array2, final int n4, final short[] array3, final int n5) {
        for (int i = 0; i < n2; ++i) {
            int n6 = n4 * n2 + i;
            int n7 = n5 * n2 + i;
            int n8 = n3 * n2 + i;
            for (short n9 = 0; n9 < n; ++n9) {
                array[n8] = (short)((array3[n7] * n9 + (n - n9) * array2[n6]) / n);
                n8 += n2;
                n6 += n2;
                n7 += n2;
            }
        }
    }
    
    public final int a(final short[] array, final int n, int i, final int n2) {
        int n3 = 1;
        int n4 = 255;
        int n5 = 0;
        int n6 = 0;
        while (i <= n2) {
            int j = 0;
            int n7 = 0;
            while (j < i) {
                final int n8 = this.b * n;
                n7 += Math.abs(array[n8 + j] - array[n8 + i + j]);
                ++j;
            }
            final int n9 = n7 * n5;
            final int n10 = n3 * i;
            if (n9 < n10) {
                n3 = n7;
            }
            if (n9 < n10) {
                n5 = i;
            }
            final int n11 = n7 * n4;
            final int n12 = n6 * i;
            if (n11 > n12) {
                n6 = n7;
            }
            if (n11 > n12) {
                n4 = i;
            }
            ++i;
        }
        this.u = n3 / n5;
        this.v = n6 / n4;
        return n5;
    }
    
    public final void b(final short[] array, final int n, final int n2) {
        final short[] f = this.f(this.l, this.m, n2);
        this.l = f;
        final int m = this.m;
        final int b = this.b;
        System.arraycopy((Object)array, n * b, (Object)f, m * b, n2 * b);
        this.m += n2;
    }
    
    public final void c(final short[] array, final int n, final int n2) {
        for (short n3 = 0; n3 < this.h / n2; ++n3) {
            short n4 = 0;
            int n5 = 0;
            int n6;
            while (true) {
                final int b = this.b;
                n6 = b * n2;
                if (n4 >= n6) {
                    break;
                }
                n5 += array[n6 * n3 + b * n + n4];
                ++n4;
            }
            this.i[n3] = (short)(n5 / n6);
        }
    }
    
    public final void e() {
        final float c = this.c;
        final float d = this.d;
        final float n = c / d;
        final double n2 = n;
        final int m = this.m;
        final int a = this.a;
        final int b = this.b;
        if (n2 <= 1.00001 && n2 >= 0.99999) {
            this.b(this.j, 0, this.k);
            this.k = 0;
        }
        else {
            final int k = this.k;
            final int h = this.h;
            if (k >= h) {
                int n3 = 0;
                int n4;
                while (true) {
                    final int r = this.r;
                    if (r > 0) {
                        final int min = Math.min(h, r);
                        this.b(this.j, n3, min);
                        this.r -= min;
                        n4 = n3 + min;
                    }
                    else {
                        final short[] j = this.j;
                        int n5;
                        if (a > 4000) {
                            n5 = a / 4000;
                        }
                        else {
                            n5 = 1;
                        }
                        int g = this.g;
                        final int f = this.f;
                        int s;
                        if (b == 1 && n5 == 1) {
                            s = this.a(j, n3, f, g);
                        }
                        else {
                            this.c(j, n3, n5);
                            final int n6 = g / n5;
                            final int n7 = f / n5;
                            final short[] i = this.i;
                            final int a2 = this.a(i, 0, n7, n6);
                            if (n5 != 1) {
                                final int n8 = a2 * n5;
                                final int n9 = n5 * 4;
                                final int n10 = n8 - n9;
                                int n11;
                                if (n10 >= (n11 = f)) {
                                    n11 = n10;
                                }
                                final int n12 = n8 + n9;
                                if (n12 <= g) {
                                    g = n12;
                                }
                                if (b == 1) {
                                    s = this.a(j, n3, n11, g);
                                }
                                else {
                                    this.c(j, n3, 1);
                                    s = this.a(i, 0, n11, g);
                                }
                            }
                            else {
                                s = a2;
                            }
                        }
                        final int u = this.u;
                        final int v = this.v;
                        int s2 = 0;
                        Label_0447: {
                            if (u != 0) {
                                s2 = this.s;
                                if (s2 != 0) {
                                    if (v <= u * 3) {
                                        if (u + u > this.t * 3) {
                                            break Label_0447;
                                        }
                                    }
                                }
                            }
                            s2 = s;
                        }
                        final int n13 = n3 + s2;
                        this.t = u;
                        this.s = s;
                        final float n14 = (float)s2;
                        if (n2 > 1.0) {
                            final short[] l = this.j;
                            final float n15 = -1.0f + n;
                            int n16;
                            if (n >= 2.0f) {
                                n16 = (int)(n14 / n15);
                            }
                            else {
                                this.r = (int)((2.0f - n) * n14 / n15);
                                n16 = s2;
                            }
                            final short[] f2 = this.f(this.l, this.m, n16);
                            this.l = f2;
                            d(n16, this.b, f2, this.m, l, n3, l, n13);
                            this.m += n16;
                            n4 = s2 + n16 + n3;
                        }
                        else {
                            final short[] j2 = this.j;
                            final float n17 = 1.0f - n;
                            int n18;
                            if (n < 0.5f) {
                                n18 = (int)(n14 * n / n17);
                            }
                            else {
                                this.r = (int)((n + n - 1.0f) * n14 / n17);
                                n18 = s2;
                            }
                            final short[] l2 = this.l;
                            final int m2 = this.m;
                            final int n19 = s2 + n18;
                            System.arraycopy((Object)j2, n3 * b, (Object)(this.l = this.f(l2, m2, n19)), this.m * b, s2 * b);
                            d(n18, this.b, this.l, this.m + s2, j2, n13, j2, n3);
                            this.m += n19;
                            n4 = n3 + n18;
                        }
                    }
                    if (n4 + h > k) {
                        break;
                    }
                    n3 = n4;
                }
                final int k2 = this.k - n4;
                final short[] j3 = this.j;
                System.arraycopy((Object)j3, n4 * b, (Object)j3, 0, k2 * b);
                this.k = k2;
            }
        }
        final float n20 = this.e * d;
        if (n20 != 1.0f) {
            if (this.m != m) {
                int n21;
                int n22;
                for (n21 = (int)(a / n20), n22 = a; n21 > 16384 || n22 > 16384; n21 /= 2, n22 /= 2) {}
                final int n23 = this.m - m;
                final short[] f3 = this.f(this.n, this.o, n23);
                this.n = f3;
                System.arraycopy((Object)this.l, m * b, (Object)f3, this.o * b, n23 * b);
                this.m = m;
                this.o += n23;
                int n24 = 0;
                int o;
                int n25;
                while (true) {
                    o = this.o;
                    n25 = o - 1;
                    if (n24 >= n25) {
                        break;
                    }
                    int p;
                    int q;
                    while (true) {
                        p = this.p + 1;
                        q = this.q;
                        if (p * n21 <= q * n22) {
                            break;
                        }
                        this.l = this.f(this.l, this.m, 1);
                        for (int n26 = 0; n26 < b; ++n26) {
                            final short[] l3 = this.l;
                            final int m3 = this.m;
                            final short[] n27 = this.n;
                            final int n28 = n24 * b + n26;
                            final short n29 = n27[n28];
                            final short n30 = n27[n28 + b];
                            final int q2 = this.q;
                            final int p2 = this.p;
                            final int n31 = (p2 + 1) * n21;
                            final int n32 = n31 - q2 * n22;
                            final int n33 = n31 - p2 * n21;
                            l3[m3 * b + n26] = (short)(((n33 - n32) * n30 + n29 * n32) / n33);
                        }
                        ++this.q;
                        ++this.m;
                    }
                    if ((this.p = p) == n22) {
                        this.p = 0;
                        aq3.k(q == n21);
                        this.q = 0;
                    }
                    ++n24;
                }
                if (n25 != 0) {
                    final short[] n34 = this.n;
                    System.arraycopy((Object)n34, n25 * b, (Object)n34, 0, (o - n25) * b);
                    this.o -= n25;
                }
            }
        }
    }
    
    public final short[] f(final short[] array, final int n, final int n2) {
        final int length = array.length;
        final int b = this.b;
        final int n3 = length / b;
        if (n + n2 <= n3) {
            return array;
        }
        return Arrays.copyOf(array, (n3 * 3 / 2 + n2) * b);
    }
}
