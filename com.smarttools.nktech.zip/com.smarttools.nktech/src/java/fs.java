import androidx.compose.ui.text.font.FontWeight$Companion;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Horizontal;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.material3.IconButtonColors;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.BorderKt;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.foundation.BackgroundKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import android.content.Context;
import androidx.compose.ui.platform.ClipboardManager;
import androidx.compose.runtime.MutableState;

public final class fs implements od1
{
    public final long c;
    public final MutableState n;
    public final ClipboardManager v;
    public final Context w;
    
    public fs(final long c, final MutableState n, final ClipboardManager v, final Context w) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)16));
            final Alignment$Companion companion2 = Alignment.Companion;
            final Alignment$Horizontal centerHorizontally = companion2.getCenterHorizontally();
            final Arrangement instance = Arrangement.INSTANCE;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(instance.getTop(), centerHorizontally, composer, 48);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final MaterialTheme instance3 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            final TextStyle titleMedium = instance3.getTypography(composer, $stable).getTitleMedium();
            final FontWeight$Companion companion4 = FontWeight.Companion;
            TextKt.Text--4IGK_g("Blended Result", (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, titleMedium, composer, 196614, 0, 65502);
            final float n = 12;
            ap.l(n, companion, composer, 6);
            BoxKt.Box(BorderKt.border-xT4_qwU(BackgroundKt.background-bw27NRU$default(ap.d(SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)100)), n), this.c, (Shape)null, 2, (Object)null), Dp.constructor-impl((float)3), Color.copy-wmQWz5c$default(instance3.getColorScheme(composer, $stable).getOutline-0d7_KjU(), 0.3f, 0.0f, 0.0f, 0.0f, 14, (Object)null), (Shape)RoundedCornerShapeKt.RoundedCornerShape-0680j_4(Dp.constructor-impl(n))), composer, 0);
            SpacerKt.Spacer(SizeKt.height-3ABfNKs((Modifier)companion, Dp.constructor-impl(n)), composer, 6);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(instance.getStart(), companion2.getCenterVertically(), composer, 48);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance4 = RowScopeInstance.INSTANCE;
            final MutableState n2 = this.n;
            TextKt.Text--4IGK_g(hs.b(n2), (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getTitleMedium(), composer, 196608, 0, 65502);
            final float n3 = 8;
            SpacerKt.Spacer(SizeKt.width-3ABfNKs((Modifier)companion, Dp.constructor-impl(n3)), composer, 6);
            final ClipboardManager v = this.v;
            final Context w = this.w;
            IconButtonKt.IconButton((id1)new j6(v, w, n2, 1), (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)jz.l, composer, 196608, 30);
            composer.endNode();
            final MeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy(instance.getStart(), companion2.getCenterVertically(), composer, 48);
            final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
            final id1 constructor3 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor3);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl3 = Updater.constructor-impl(composer);
            final nd1 b3 = ap.b(companion3, constructor-impl3, rowMeasurePolicy2, constructor-impl3, currentCompositionLocalMap3);
            if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                l3.i(currentCompositeKeyHash3, constructor-impl3, currentCompositeKeyHash3, b3);
            }
            Updater.set-impl(constructor-impl3, (Object)materializeModifier3, companion3.getSetModifier());
            TextKt.Text--4IGK_g(hs.c(n2), (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getBodyMedium(), composer, 0, 0, 65534);
            SpacerKt.Spacer(SizeKt.width-3ABfNKs((Modifier)companion, Dp.constructor-impl(n3)), composer, 6);
            IconButtonKt.IconButton((id1)new j6(v, w, n2, 2), (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)jz.m, composer, 196608, 30);
            composer.endNode();
            composer.endNode();
        }
        return t43.a;
    }
}
