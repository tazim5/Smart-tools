import androidx.compose.runtime.State;
import java.util.List;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ButtonKt;
import com.smarttools.nktech.features.tools.text.d;
import androidx.compose.material3.TopAppBarScrollBehavior;
import androidx.compose.foundation.layout.WindowInsets;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.AppBarKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.TopAppBarDefaults;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableIntState;
import javax.crypto.spec.SecretKeySpec;
import androidx.compose.runtime.snapshots.SnapshotStateList;
import androidx.compose.runtime.MutableState;
import android.content.Context;

public final class h01 implements nd1
{
    public final Object P;
    public final Object Q;
    public final Object R;
    public final int c;
    public final Context n;
    public final Object v;
    public final MutableState w;
    public final MutableState x;
    public final MutableState y;
    public final Object z;
    
    public h01(final Context n, final SnapshotStateList v, final MutableState w, final MutableState x, final MutableState y, final MutableState z, final dq0 p9, final SecretKeySpec q, final MutableState r) {
        this.c = 1;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p9;
        this.Q = q;
        this.R = r;
    }
    
    public h01(final MutableState w, final qo2 z, final SnapshotStateList v, final SnapshotStateList p9, final SnapshotStateList q, final SnapshotStateList r, final Context n, final MutableState x, final MutableState y) {
        this.c = 0;
        this.w = w;
        this.z = z;
        this.v = v;
        this.P = p9;
        this.Q = q;
        this.R = r;
        this.n = n;
        this.x = x;
        this.y = y;
    }
    
    public h01(final qo2 z, final MutableState w, final MutableIntState v, final dq0 p9, final Context n, final MutableState x, final MutableState y, final MutableState q, final MutableState r) {
        this.c = 2;
        this.z = z;
        this.w = w;
        this.v = v;
        this.P = p9;
        this.n = n;
        this.x = x;
        this.y = y;
        this.Q = q;
        this.R = r;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        switch (this.c) {
            default: {
                final Composer composer = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                }
                else {
                    AppBarKt.TopAppBar-GHTll3U((nd1)ai0.a, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(1395321840, true, (Object)new wu1((Object)this.z, 16), composer, 54), (od1)ComposableLambdaKt.rememberComposableLambda(-1333222745, true, (Object)new g01(this.w, (MutableIntState)this.v, (dq0)this.P, this.n, this.x, this.y, (MutableState)this.Q, (MutableState)this.R), composer, 54), 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer, 3462, 178);
                }
                return t43.a;
            }
            case 1: {
                final Composer composer2 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer2.getSkipping()) {
                    composer2.skipToGroupEnd();
                }
                else {
                    ButtonKt.Button((id1)new d(this.n, (SnapshotStateList)this.v, this.w, this.x, this.y, (MutableState)this.z, (dq0)this.P, (SecretKeySpec)this.Q, (MutableState)this.R), (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)fb0.i, composer2, 805306368, 510);
                }
                return t43.a;
            }
            case 0: {
                final Composer composer3 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer3.getSkipping()) {
                    composer3.skipToGroupEnd();
                }
                else if (!(boolean)((State)this.w).getValue()) {
                    AppBarKt.TopAppBar-GHTll3U((nd1)i20.i, (Modifier)null, (nd1)ComposableLambdaKt.rememberComposableLambda(-1767429464, true, (Object)new q((Object)this.z, 16), composer3, 54), (od1)ComposableLambdaKt.rememberComposableLambda(-452965679, true, (Object)new g01((Object)this.v, (List)this.P, (Object)this.Q, (Object)this.R, (Object)this.n, (State)this.x, (State)this.y, (State)this.w, 0), composer3, 54), 0.0f, (WindowInsets)null, TopAppBarDefaults.INSTANCE.topAppBarColors-zjMxDiM(MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSurface-0d7_KjU(), 0L, 0L, 0L, 0L, composer3, TopAppBarDefaults.$stable << 15, 30), (TopAppBarScrollBehavior)null, composer3, 3462, 178);
                }
                return t43.a;
            }
        }
    }
}
