import java.util.concurrent.atomic.AtomicBoolean;
import com.google.android.gms.ads.internal.overlay.zzo;

public final class oh4 implements zzo
{
    public final mj4 c;
    public final AtomicBoolean n;
    public final AtomicBoolean v;
    
    public oh4(final mj4 c) {
        this.n = new AtomicBoolean(false);
        this.v = new AtomicBoolean(false);
        this.c = c;
    }
    
    public final void zzbM() {
    }
    
    public final void zzbp() {
    }
    
    public final void zzbv() {
        final AtomicBoolean v = this.v;
        if (!v.get()) {
            v.set(true);
            ((xo1)this.c).t0((gl4)uf5.z);
        }
    }
    
    public final void zzbw() {
        ((xo1)this.c).t0((gl4)k26.P);
    }
    
    public final void zzby() {
    }
    
    public final void zzbz(final int n) {
        this.n.set(true);
        final AtomicBoolean v = this.v;
        if (!v.get()) {
            v.set(true);
            ((xo1)this.c).t0((gl4)uf5.z);
        }
    }
}
