import kotlin.coroutines.a;

public final class s43 implements sp0, tp0
{
    public static final s43 c;
    
    static {
        c = (s43)new Object();
    }
    
    public final Object fold(final Object o, final nd1 nd1) {
        return nd1.invoke(o, (Object)this);
    }
    
    public final sp0 get(final tp0 tp0) {
        return tu5.a((sp0)this, tp0);
    }
    
    public final tp0 getKey() {
        return (tp0)this;
    }
    
    public final up0 minusKey(final tp0 tp0) {
        return tu5.b((sp0)this, tp0);
    }
    
    public final up0 plus(final up0 up0) {
        return a.a((up0)this, up0);
    }
}
