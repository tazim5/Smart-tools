import kotlin.coroutines.Continuation;
import kotlinx.coroutines.flow.p;
import java.util.concurrent.atomic.AtomicReference;

public final class ir2 extends e1
{
    public final AtomicReference a;
    
    public ir2() {
        this.a = new AtomicReference((Object)null);
    }
    
    public final boolean a(final d1 d1) {
        final p p = (p)d1;
        final AtomicReference a = this.a;
        boolean b;
        if (a.get() != null) {
            b = false;
        }
        else {
            a.set((Object)it3.a);
            b = true;
        }
        return b;
    }
    
    public final Continuation[] b(final d1 d1) {
        final p p = (p)d1;
        this.a.set((Object)null);
        return ot0.a;
    }
}
