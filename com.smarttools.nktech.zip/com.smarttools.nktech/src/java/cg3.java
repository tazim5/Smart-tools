import java.util.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.Serializable;

public final class cg3 extends gb1
{
    public long v;
    public long[] w;
    public long[] x;
    
    public static Serializable q(int i, final f85 f85) {
        if (i == 0) {
            return (Serializable)Double.valueOf(Double.longBitsToDouble(f85.v()));
        }
        boolean b = true;
        final int n = 0;
        if (i == 1) {
            if (f85.o() != 1) {
                b = false;
            }
            return (Serializable)Boolean.valueOf(b);
        }
        if (i == 2) {
            return (Serializable)r(f85);
        }
        if (i == 3) {
            final HashMap hashMap = new HashMap();
            while (true) {
                final String r = r(f85);
                i = f85.o();
                if (i == 9) {
                    break;
                }
                final Serializable q = q(i, f85);
                if (q == null) {
                    continue;
                }
                hashMap.put((Object)r, (Object)q);
            }
            return (Serializable)hashMap;
        }
        if (i == 8) {
            return (Serializable)s(f85);
        }
        if (i == 10) {
            final int r2 = f85.r();
            final ArrayList list = new ArrayList(r2);
            Serializable q2;
            for (i = n; i < r2; ++i) {
                q2 = q(f85.o(), f85);
                if (q2 != null) {
                    list.add((Object)q2);
                }
            }
            return (Serializable)list;
        }
        if (i != 11) {
            return null;
        }
        final Date date = new Date((long)Double.longBitsToDouble(f85.v()));
        f85.f(2);
        return (Serializable)date;
    }
    
    public static String r(final f85 f85) {
        final int s = f85.s();
        final int b = f85.b;
        f85.f(s);
        return new String(f85.a, b, s);
    }
    
    public static HashMap s(final f85 f85) {
        final int r = f85.r();
        final HashMap hashMap = new HashMap(r);
        for (int i = 0; i < r; ++i) {
            final String r2 = r(f85);
            final Serializable q = q(f85.o(), f85);
            if (q != null) {
                hashMap.put((Object)r2, (Object)q);
            }
        }
        return hashMap;
    }
}
