public abstract class kc5
{
}
