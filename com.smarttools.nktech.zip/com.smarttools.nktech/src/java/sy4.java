import com.google.android.gms.internal.ads.zzcbt;
import com.google.android.gms.internal.ads.k1;
import android.content.Context;

public final class sy4 implements ls5
{
    public final int a;
    public final ks5 b;
    public final ms5 c;
    public final ed4 d;
    
    public sy4(final ks5 b, final ed4 d, final ms5 c) {
        this.a = 0;
        this.b = b;
        this.d = d;
        this.c = c;
    }
    
    public sy4(final ks5 b, final ms5 c, final ed4 d) {
        this.a = 1;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    public final Object zzb() {
        switch (this.a) {
            default: {
                return new ky4((Context)this.b.zzb(), (gn4)this.c.a, this.d.a());
            }
            case 0: {
                final Context context = (Context)this.b.zzb();
                final zzcbt a = this.d.a();
                final vm4 vm4 = (vm4)this.c.a;
                final i94 a2 = k1.a;
                ep5.c((Object)a2);
                return new ky4(context, a, vm4, (pg5)a2);
            }
        }
    }
}
