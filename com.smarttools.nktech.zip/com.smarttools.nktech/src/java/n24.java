import com.google.android.gms.ads.mediation.Adapter;
import android.os.BaseBundle;
import com.google.android.gms.ads.mediation.zza;
import android.os.Parcelable$Creator;
import com.google.android.gms.internal.ads.zzbsd;
import com.google.android.gms.ads.internal.client.zzdq;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.Parcel;
import com.google.android.gms.ads.mediation.MediationInterstitialAdConfiguration;
import com.google.android.gms.ads.mediation.rtb.SignalCallbacks;
import java.util.List;
import com.google.android.gms.ads.mediation.rtb.RtbSignalData;
import java.util.ArrayList;
import com.google.android.gms.ads.mediation.MediationConfiguration;
import com.google.android.gms.ads.AdFormat;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.mediation.MediationNativeAdConfiguration;
import com.google.android.gms.internal.ads.zzbfw;
import com.google.android.gms.ads.mediation.MediationAppOpenAdConfiguration;
import android.os.IInterface;
import com.google.android.gms.ads.mediation.MediationRewardedAdConfiguration;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;
import com.google.android.gms.ads.mediation.MediationBannerAdConfiguration;
import com.google.android.gms.ads.zzb;
import android.content.Context;
import com.google.android.gms.ads.internal.client.zzq;
import com.google.android.gms.ads.internal.client.zzay;
import com.google.android.gms.ads.internal.client.zzl;
import java.util.Iterator;
import android.os.RemoteException;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.Bundle;
import com.google.android.gms.ads.mediation.MediationAppOpenAd;
import com.google.android.gms.ads.mediation.MediationRewardedAd;
import com.google.android.gms.ads.mediation.MediationInterstitialAd;
import com.google.android.gms.ads.mediation.rtb.RtbAdapter;

public final class n24 extends ho3 implements g24
{
    public static final int y = 0;
    public final RtbAdapter c;
    public MediationInterstitialAd n;
    public MediationRewardedAd v;
    public MediationAppOpenAd w;
    public String x;
    
    public n24(final RtbAdapter c) {
        super("com.google.android.gms.ads.internal.mediation.client.rtb.IRtbAdapter");
        this.x = "";
        this.c = c;
    }
    
    public static final Bundle g1(String s) {
        d94.zzj("Server parameters: ".concat(String.valueOf((Object)s)));
        Label_0084: {
            Bundle bundle;
            try {
                bundle = new Bundle();
                if (s != null) {
                    final JSONObject jsonObject = new JSONObject(s);
                    bundle = new Bundle();
                    final Iterator keys = jsonObject.keys();
                    while (keys.hasNext()) {
                        s = (String)keys.next();
                        ((BaseBundle)bundle).putString(s, jsonObject.getString(s));
                    }
                }
            }
            catch (final JSONException ex) {
                break Label_0084;
            }
            return bundle;
        }
        final JSONException ex;
        d94.zzh("", (Throwable)ex);
        throw new RemoteException();
    }
    
    public static final boolean h1(final zzl zzl) {
        if (!zzl.zzf) {
            zzay.zzb();
            if (!z84.m()) {
                return false;
            }
        }
        return true;
    }
    
    public static final String i1(zzl zzl, String s) {
        zzl = (zzl)zzl.zzu;
        try {
            s = (String)(zzl = (zzl)new JSONObject(s).getString("max_ad_content_rating"));
            return (String)zzl;
        }
        catch (final JSONException ex) {
            return (String)zzl;
        }
    }
    
    public final void E(final String s, final String s2, final zzl zzl, final th1 th1, final y14 y14, final y04 y15, final zzq zzq) {
        try {
            this.c.loadRtbInterscrollerAd(new MediationBannerAdConfiguration((Context)n32.F(th1), s, g1(s2), this.f1(zzl), h1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, i1(zzl, s2), zzb.zzc(zzq.zze, zzq.zzb, zzq.zza), this.x), (MediationAdLoadCallback)new k24(y14, y15, 1));
        }
        finally {
            final Throwable t;
            throw f83.c("Adapter failed to render interscroller ad.", t);
        }
    }
    
    public final void E0(final String s, final String s2, final zzl zzl, final th1 th1, final e24 e24, final y04 y04) {
        try {
            this.c.loadRtbRewardedAd(new MediationRewardedAdConfiguration((Context)n32.F(th1), s, g1(s2), this.f1(zzl), h1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, i1(zzl, s2), this.x), (MediationAdLoadCallback)new m14(this, (IInterface)e24, y04, 4));
        }
        finally {
            final Throwable t;
            throw f83.c("Adapter failed to render rewarded ad.", t);
        }
    }
    
    public final void H(final String s, final String s2, final zzl zzl, final th1 th1, final w14 w14, final y04 y04) {
        try {
            this.c.loadRtbAppOpenAd(new MediationAppOpenAdConfiguration((Context)n32.F(th1), s, g1(s2), this.f1(zzl), h1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, i1(zzl, s2), this.x), (MediationAdLoadCallback)new m14(this, (IInterface)w14, y04, 3));
        }
        finally {
            final Throwable t;
            throw f83.c("Adapter failed to render app open ad.", t);
        }
    }
    
    public final void O(final String s, final String s2, final zzl zzl, final th1 th1, final c24 c24, final y04 y04, final zzbfw zzbfw) {
        try {
            this.c.loadRtbNativeAd(new MediationNativeAdConfiguration((Context)n32.F(th1), s, g1(s2), this.f1(zzl), h1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, i1(zzl, s2), this.x, zzbfw), (MediationAdLoadCallback)new il3(4, (Object)c24, (Object)y04));
        }
        finally {
            final Throwable t;
            throw f83.c("Adapter failed to render native ad.", t);
        }
    }
    
    public final void O0(final th1 th1, String s, final Bundle bundle, final Bundle bundle2, final zzq zzq, i24 c) {
        eq5 eq5 = null;
        Label_0346: {
            Label_0342: {
                Label_0335: {
                    Label_0328: {
                        Label_0321: {
                            Label_0314: {
                                Label_0307: {
                                    try {
                                        eq5 = new eq5((Object)c, 24);
                                        c = (i24)this.c;
                                        int n = 0;
                                        Label_0217: {
                                            switch (s.hashCode()) {
                                                case 1911491517: {
                                                    if (s.equals((Object)"rewarded_interstitial")) {
                                                        n = 3;
                                                        break Label_0217;
                                                    }
                                                    break;
                                                }
                                                case 1778294298: {
                                                    if (s.equals((Object)"app_open_ad")) {
                                                        n = 6;
                                                        break Label_0217;
                                                    }
                                                    break;
                                                }
                                                case 1167692200: {
                                                    if (s.equals((Object)"app_open")) {
                                                        n = 5;
                                                        break Label_0217;
                                                    }
                                                    break;
                                                }
                                                case 604727084: {
                                                    if (s.equals((Object)"interstitial")) {
                                                        n = 1;
                                                        break Label_0217;
                                                    }
                                                    break;
                                                }
                                                case -239580146: {
                                                    if (s.equals((Object)"rewarded")) {
                                                        n = 2;
                                                        break Label_0217;
                                                    }
                                                    break;
                                                }
                                                case -1052618729: {
                                                    if (s.equals((Object)"native")) {
                                                        n = 4;
                                                        break Label_0217;
                                                    }
                                                    break;
                                                }
                                                case -1396342996: {
                                                    if (s.equals((Object)"banner")) {
                                                        n = 0;
                                                        break Label_0217;
                                                    }
                                                    break;
                                                }
                                            }
                                            n = -1;
                                        }
                                        switch (n) {
                                            case 6: {
                                                s = (String)cs3.aa;
                                                if (zzba.zzc().a((ur3)s)) {
                                                    s = (String)AdFormat.APP_OPEN_AD;
                                                    break Label_0346;
                                                }
                                                break;
                                            }
                                            case 5: {
                                                break Label_0307;
                                            }
                                            case 4: {
                                                break Label_0314;
                                            }
                                            case 3: {
                                                break Label_0321;
                                            }
                                            case 2: {
                                                break Label_0328;
                                            }
                                            case 1: {
                                                break Label_0335;
                                            }
                                            case 0: {
                                                break Label_0342;
                                            }
                                        }
                                    }
                                    finally {
                                        throw f83.c("Error generating signals for RTB", (Throwable)th1);
                                    }
                                    throw new IllegalArgumentException("Internal Error");
                                }
                                s = (String)AdFormat.APP_OPEN_AD;
                                break Label_0346;
                            }
                            s = (String)AdFormat.NATIVE;
                            break Label_0346;
                        }
                        s = (String)AdFormat.REWARDED_INTERSTITIAL;
                        break Label_0346;
                    }
                    s = (String)AdFormat.REWARDED;
                    break Label_0346;
                }
                s = (String)AdFormat.INTERSTITIAL;
                break Label_0346;
            }
            s = (String)AdFormat.BANNER;
        }
        final MediationConfiguration mediationConfiguration = new MediationConfiguration((AdFormat)s, bundle2);
        final ArrayList list = new ArrayList();
        list.add((Object)mediationConfiguration);
        ((RtbAdapter)c).collectSignals(new RtbSignalData((Context)n32.F(th1), (List)list, bundle, zzb.zzc(zzq.zze, zzq.zzb, zzq.zza)), (SignalCallbacks)eq5);
    }
    
    public final void R0(final String s, final String s2, final zzl zzl, final n32 n32, final wy4 wy4, final y04 y04) {
        this.O(s, s2, zzl, (th1)n32, (c24)wy4, y04, null);
    }
    
    public final void a1(final String x) {
        this.x = x;
    }
    
    public final Bundle f1(final zzl zzl) {
        final Bundle zzm = zzl.zzm;
        if (zzm != null) {
            final Bundle bundle = zzm.getBundle(this.c.getClass().getName());
            if (bundle != null) {
                return bundle;
            }
        }
        return new Bundle();
    }
    
    public final boolean h0(final th1 th1) {
        final MediationRewardedAd v = this.v;
        if (v != null) {
            try {
                v.showAd((Context)n32.F(th1));
            }
            finally {
                final Throwable t;
                d94.zzh("", t);
            }
            return true;
        }
        return false;
    }
    
    public final void i0(final String s, final String s2, final zzl zzl, final th1 th1, final a24 a24, final y04 y04) {
        try {
            this.c.loadRtbInterstitialAd(new MediationInterstitialAdConfiguration((Context)n32.F(th1), s, g1(s2), this.f1(zzl), h1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, i1(zzl, s2), this.x), (MediationAdLoadCallback)new m14(this, (IInterface)a24, y04, 2));
        }
        finally {
            final Throwable t;
            throw f83.c("Adapter failed to render interstitial ad.", t);
        }
    }
    
    public final boolean k(final th1 th1) {
        final MediationInterstitialAd n = this.n;
        if (n != null) {
            try {
                n.showAd((Context)n32.F(th1));
            }
            finally {
                final Throwable t;
                d94.zzh("", t);
            }
            return true;
        }
        return false;
    }
    
    public final boolean o(final th1 th1) {
        final MediationAppOpenAd w = this.w;
        if (w != null) {
            try {
                w.showAd((Context)n32.F(th1));
            }
            finally {
                final Throwable t;
                d94.zzh("", t);
            }
            return true;
        }
        return false;
    }
    
    public final void t0(final String s, final String s2, final zzl zzl, final th1 th1, final e24 e24, final y04 y04) {
        try {
            this.c.loadRtbRewardedInterstitialAd(new MediationRewardedAdConfiguration((Context)n32.F(th1), s, g1(s2), this.f1(zzl), h1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, i1(zzl, s2), this.x), (MediationAdLoadCallback)new m14(this, (IInterface)e24, y04, 4));
        }
        finally {
            final Throwable t;
            throw f83.c("Adapter failed to render rewarded interstitial ad.", t);
        }
    }
    
    public final void z(final String s, final String s2, final zzl zzl, final th1 th1, final y14 y14, final y04 y15, final zzq zzq) {
        try {
            this.c.loadRtbBannerAd(new MediationBannerAdConfiguration((Context)n32.F(th1), s, g1(s2), this.f1(zzl), h1(zzl), zzl.zzk, zzl.zzg, zzl.zzt, i1(zzl, s2), zzb.zzc(zzq.zze, zzq.zzb, zzq.zza), this.x), (MediationAdLoadCallback)new k24(y14, y15, 0));
        }
        finally {
            final Throwable t;
            throw f83.c("Adapter failed to render banner ad.", t);
        }
    }
    
    public final boolean zzbK(int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        final y14 y14 = null;
        final e24 e24 = null;
        final c24 c24 = null;
        final e24 e25 = null;
        Object o = null;
        final c24 c25 = null;
        if (n != 1) {
            if (n != 2) {
                if (n != 3) {
                    if (n != 5) {
                        if (n != 10) {
                            if (n != 11) {
                                switch (n) {
                                    default: {
                                        return false;
                                    }
                                    case 24: {
                                        final th1 d = n32.D(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        n = (this.o(d) ? 1 : 0);
                                        parcel2.writeNoException();
                                        parcel2.writeInt(n);
                                        break;
                                    }
                                    case 23: {
                                        final String string = parcel.readString();
                                        final String string2 = parcel.readString();
                                        final zzl zzl = (zzl)io3.a(parcel, com.google.android.gms.ads.internal.client.zzl.CREATOR);
                                        final th1 d2 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder = parcel.readStrongBinder();
                                        Object o2;
                                        if (strongBinder == null) {
                                            o2 = null;
                                        }
                                        else {
                                            final IInterface queryLocalInterface = strongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IAppOpenCallback");
                                            if (queryLocalInterface instanceof w14) {
                                                o2 = queryLocalInterface;
                                            }
                                            else {
                                                o2 = new go3(strongBinder, "com.google.android.gms.ads.internal.mediation.client.rtb.IAppOpenCallback");
                                            }
                                        }
                                        final y04 f1 = x04.f1(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        this.H(string, string2, zzl, d2, (w14)o2, f1);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 22: {
                                        final String string3 = parcel.readString();
                                        final String string4 = parcel.readString();
                                        final zzl zzl2 = (zzl)io3.a(parcel, zzl.CREATOR);
                                        final th1 d3 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder2 = parcel.readStrongBinder();
                                        Object o3;
                                        if (strongBinder2 == null) {
                                            o3 = c25;
                                        }
                                        else {
                                            final IInterface queryLocalInterface2 = strongBinder2.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.INativeCallback");
                                            if (queryLocalInterface2 instanceof c24) {
                                                o3 = queryLocalInterface2;
                                            }
                                            else {
                                                o3 = new b24(strongBinder2);
                                            }
                                        }
                                        final y04 f2 = x04.f1(parcel.readStrongBinder());
                                        final zzbfw zzbfw = (zzbfw)io3.a(parcel, com.google.android.gms.internal.ads.zzbfw.CREATOR);
                                        io3.b(parcel);
                                        this.O(string3, string4, zzl2, d3, (c24)o3, f2, zzbfw);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 21: {
                                        final String string5 = parcel.readString();
                                        final String string6 = parcel.readString();
                                        final zzl zzl3 = (zzl)io3.a(parcel, zzl.CREATOR);
                                        final th1 d4 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder3 = parcel.readStrongBinder();
                                        Object o4;
                                        if (strongBinder3 == null) {
                                            o4 = y14;
                                        }
                                        else {
                                            final IInterface queryLocalInterface3 = strongBinder3.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IBannerCallback");
                                            if (queryLocalInterface3 instanceof y14) {
                                                o4 = queryLocalInterface3;
                                            }
                                            else {
                                                o4 = new x14(strongBinder3);
                                            }
                                        }
                                        final y04 f3 = x04.f1(parcel.readStrongBinder());
                                        final zzq zzq = (zzq)io3.a(parcel, com.google.android.gms.ads.internal.client.zzq.CREATOR);
                                        io3.b(parcel);
                                        this.E(string5, string6, zzl3, d4, (y14)o4, f3, zzq);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 20: {
                                        final String string7 = parcel.readString();
                                        final String string8 = parcel.readString();
                                        final zzl zzl4 = (zzl)io3.a(parcel, zzl.CREATOR);
                                        final th1 d5 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder4 = parcel.readStrongBinder();
                                        Object o5;
                                        if (strongBinder4 == null) {
                                            o5 = e24;
                                        }
                                        else {
                                            final IInterface queryLocalInterface4 = strongBinder4.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IRewardedCallback");
                                            if (queryLocalInterface4 instanceof e24) {
                                                o5 = queryLocalInterface4;
                                            }
                                            else {
                                                o5 = new d24(strongBinder4);
                                            }
                                        }
                                        final y04 f4 = x04.f1(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        this.t0(string7, string8, zzl4, d5, (e24)o5, f4);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 19: {
                                        final String string9 = parcel.readString();
                                        io3.b(parcel);
                                        this.x = string9;
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 18: {
                                        final String string10 = parcel.readString();
                                        final String string11 = parcel.readString();
                                        final zzl zzl5 = (zzl)io3.a(parcel, zzl.CREATOR);
                                        final th1 d6 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder5 = parcel.readStrongBinder();
                                        Object o6;
                                        if (strongBinder5 == null) {
                                            o6 = c24;
                                        }
                                        else {
                                            final IInterface queryLocalInterface5 = strongBinder5.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.INativeCallback");
                                            if (queryLocalInterface5 instanceof c24) {
                                                o6 = queryLocalInterface5;
                                            }
                                            else {
                                                o6 = new b24(strongBinder5);
                                            }
                                        }
                                        final y04 f5 = x04.f1(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        this.O(string10, string11, zzl5, d6, (c24)o6, f5, null);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 17: {
                                        final th1 d7 = n32.D(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        n = (this.h0(d7) ? 1 : 0);
                                        parcel2.writeNoException();
                                        parcel2.writeInt(n);
                                        break;
                                    }
                                    case 16: {
                                        final String string12 = parcel.readString();
                                        final String string13 = parcel.readString();
                                        final zzl zzl6 = (zzl)io3.a(parcel, zzl.CREATOR);
                                        final th1 d8 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder6 = parcel.readStrongBinder();
                                        Object o7;
                                        if (strongBinder6 == null) {
                                            o7 = e25;
                                        }
                                        else {
                                            final IInterface queryLocalInterface6 = strongBinder6.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IRewardedCallback");
                                            if (queryLocalInterface6 instanceof e24) {
                                                o7 = queryLocalInterface6;
                                            }
                                            else {
                                                o7 = new d24(strongBinder6);
                                            }
                                        }
                                        final y04 f6 = x04.f1(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        this.E0(string12, string13, zzl6, d8, (e24)o7, f6);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 15: {
                                        final th1 d9 = n32.D(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        n = (this.k(d9) ? 1 : 0);
                                        parcel2.writeNoException();
                                        parcel2.writeInt(n);
                                        break;
                                    }
                                    case 14: {
                                        final String string14 = parcel.readString();
                                        final String string15 = parcel.readString();
                                        final zzl zzl7 = (zzl)io3.a(parcel, zzl.CREATOR);
                                        final th1 d10 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder7 = parcel.readStrongBinder();
                                        Object o8;
                                        if (strongBinder7 == null) {
                                            o8 = null;
                                        }
                                        else {
                                            final IInterface queryLocalInterface7 = strongBinder7.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IInterstitialCallback");
                                            if (queryLocalInterface7 instanceof a24) {
                                                o8 = queryLocalInterface7;
                                            }
                                            else {
                                                o8 = new go3(strongBinder7, "com.google.android.gms.ads.internal.mediation.client.rtb.IInterstitialCallback");
                                            }
                                        }
                                        final y04 f7 = x04.f1(parcel.readStrongBinder());
                                        io3.b(parcel);
                                        this.i0(string14, string15, zzl7, d10, (a24)o8, f7);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                    case 13: {
                                        final String string16 = parcel.readString();
                                        final String string17 = parcel.readString();
                                        final zzl zzl8 = (zzl)io3.a(parcel, zzl.CREATOR);
                                        final th1 d11 = n32.D(parcel.readStrongBinder());
                                        final IBinder strongBinder8 = parcel.readStrongBinder();
                                        if (strongBinder8 != null) {
                                            final IInterface queryLocalInterface8 = strongBinder8.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IBannerCallback");
                                            if (queryLocalInterface8 instanceof y14) {
                                                o = queryLocalInterface8;
                                            }
                                            else {
                                                o = new x14(strongBinder8);
                                            }
                                        }
                                        final y04 f8 = x04.f1(parcel.readStrongBinder());
                                        final zzq zzq2 = (zzq)io3.a(parcel, zzq.CREATOR);
                                        io3.b(parcel);
                                        this.z(string16, string17, zzl8, d11, (y14)o, f8, zzq2);
                                        parcel2.writeNoException();
                                        break;
                                    }
                                }
                            }
                            else {
                                parcel.createStringArray();
                                final Bundle[] array = (Bundle[])parcel.createTypedArray(Bundle.CREATOR);
                                io3.b(parcel);
                                parcel2.writeNoException();
                            }
                        }
                        else {
                            n32.D(parcel.readStrongBinder());
                            io3.b(parcel);
                            parcel2.writeNoException();
                        }
                    }
                    else {
                        final zzdq zze = this.zze();
                        parcel2.writeNoException();
                        io3.e(parcel2, (IInterface)zze);
                    }
                }
                else {
                    final zzbsd zzg = this.zzg();
                    parcel2.writeNoException();
                    io3.d(parcel2, (Parcelable)zzg);
                }
            }
            else {
                final zzbsd zzf = this.zzf();
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)zzf);
            }
        }
        else {
            final th1 d12 = n32.D(parcel.readStrongBinder());
            final String string18 = parcel.readString();
            final Parcelable$Creator creator = Bundle.CREATOR;
            final Bundle bundle = (Bundle)io3.a(parcel, creator);
            final Bundle bundle2 = (Bundle)io3.a(parcel, creator);
            final zzq zzq3 = (zzq)io3.a(parcel, zzq.CREATOR);
            final IBinder strongBinder9 = parcel.readStrongBinder();
            Object o9;
            if (strongBinder9 == null) {
                o9 = null;
            }
            else {
                final IInterface queryLocalInterface9 = strongBinder9.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.ISignalsCallback");
                if (queryLocalInterface9 instanceof i24) {
                    o9 = queryLocalInterface9;
                }
                else {
                    o9 = new go3(strongBinder9, "com.google.android.gms.ads.internal.mediation.client.rtb.ISignalsCallback");
                }
            }
            io3.b(parcel);
            this.O0(d12, string18, bundle, bundle2, zzq3, (i24)o9);
            parcel2.writeNoException();
        }
        return true;
    }
    
    public final zzdq zze() {
        final RtbAdapter c = this.c;
        if (c instanceof zza) {
            try {
                return ((zza)c).getVideoController();
            }
            finally {
                final Throwable t;
                d94.zzh("", t);
            }
        }
        return null;
    }
    
    public final zzbsd zzf() {
        return zzbsd.c(((Adapter)this.c).getVersionInfo());
    }
    
    public final zzbsd zzg() {
        return zzbsd.c(((Adapter)this.c).getSDKVersionInfo());
    }
}
