import com.google.android.gms.internal.ads.a0;

public interface dl4
{
    void A(final a0 p0);
    
    void H(final a0 p0);
    
    void k(final boolean p0);
    
    void t(final a0 p0);
    
    void y(final boolean p0);
    
    void zzh();
}
