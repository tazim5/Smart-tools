public final class mh2
{
    public final String a;
    public final String b;
    
    public mh2(final String a, final String b) {
        this.a = a;
        this.b = b;
    }
}
