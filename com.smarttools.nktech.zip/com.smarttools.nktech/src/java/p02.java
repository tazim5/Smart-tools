public final class p02
{
    public final boolean a;
    public final boolean b;
    public final int c;
    public final boolean d;
    public final boolean e;
    public final int f;
    public final int g;
    public String h;
    
    public p02(final boolean a, final boolean b, final int c, final boolean d, final boolean e, final int f, final int g) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    @Override
    public final boolean equals(final Object o) {
        boolean b = true;
        if (this == o) {
            return true;
        }
        if (o != null && o instanceof p02) {
            final p02 p = (p02)o;
            if (this.a != p.a || this.b != p.b || this.c != p.c || !kl1.b((Object)this.h, (Object)p.h) || !kl1.b((Object)null, (Object)null) || !kl1.b((Object)null, (Object)null) || this.d != p.d || this.e != p.e || this.f != p.f || this.g != p.g) {
                b = false;
            }
            return b;
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        final int a = this.a ? 1 : 0;
        final int b = this.b ? 1 : 0;
        final int c = this.c;
        final String h = this.h;
        int hashCode;
        if (h != null) {
            hashCode = h.hashCode();
        }
        else {
            hashCode = 0;
        }
        return ((((((((a * 31 + b) * 31 + c) * 31 + hashCode) * 29791 + (this.d ? 1 : 0)) * 31 + (this.e ? 1 : 0)) * 31 + this.f) * 31 + this.g) * 31 - 1) * 31 - 1;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(p02.class.getSimpleName());
        sb.append("(");
        if (this.a) {
            sb.append("launchSingleTop ");
        }
        if (this.b) {
            sb.append("restoreState ");
        }
        final String h = this.h;
        if ((h != null || this.c != -1) && h != null) {
            sb.append("popUpTo(");
            sb.append(h);
            if (this.d) {
                sb.append(" inclusive");
            }
            if (this.e) {
                sb.append(" saveState");
            }
            sb.append(")");
        }
        final int g = this.g;
        final int f = this.f;
        if (f != -1 || g != -1) {
            sb.append("anim(enterAnim=0x");
            sb.append(Integer.toHexString(f));
            sb.append(" exitAnim=0x");
            sb.append(Integer.toHexString(g));
            sb.append(" popEnterAnim=0x");
            sb.append(Integer.toHexString(-1));
            sb.append(" popExitAnim=0x");
            sb.append(Integer.toHexString(-1));
            sb.append(")");
        }
        return sb.toString();
    }
}
