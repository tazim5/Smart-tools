import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

public final class aq1 extends xp0 implements qv0
{
    public static final AtomicIntegerFieldUpdater z;
    public final qv0 c;
    public final xp0 n;
    private volatile int runningWorkers$volatile;
    public final int v;
    public final String w;
    public final xr1 x;
    public final Object y;
    
    static {
        z = AtomicIntegerFieldUpdater.newUpdater((Class)aq1.class, "runningWorkers$volatile");
    }
    
    public aq1(final xp0 n, final int v, final String w) {
        qv0 qv0;
        if (n instanceof qv0) {
            qv0 = (qv0)n;
        }
        else {
            qv0 = null;
        }
        qv0 a = qv0;
        if (qv0 == null) {
            a = ou0.a;
        }
        this.c = a;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = new xr1();
        this.y = new Object();
    }
    
    @Override
    public final nz0 C(final long n, final rz2 rz2, final up0 up0) {
        return this.c.C(n, rz2, up0);
    }
    
    @Override
    public final void F(final long n, final in in) {
        this.c.F(n, in);
    }
    
    public final Runnable V() {
        Runnable runnable;
        while (true) {
            runnable = (Runnable)this.x.d();
            if (runnable == null) {
                final Object y = this.y;
                synchronized (y) {
                    final AtomicIntegerFieldUpdater z = aq1.z;
                    z.decrementAndGet((Object)this);
                    if (this.x.c() == 0) {
                        return null;
                    }
                    z.incrementAndGet((Object)this);
                    continue;
                }
                break;
            }
            break;
        }
        return runnable;
    }
    
    public final boolean W() {
        final Object y = this.y;
        synchronized (y) {
            final AtomicIntegerFieldUpdater z = aq1.z;
            if (z.get((Object)this) >= this.v) {
                return false;
            }
            z.incrementAndGet((Object)this);
            return true;
        }
    }
    
    @Override
    public final void dispatch(final up0 up0, final Runnable runnable) {
        this.x.a(runnable);
        if (aq1.z.get((Object)this) < this.v && this.W()) {
            final Runnable v = this.V();
            if (v != null) {
                this.n.dispatch((up0)this, (Runnable)new jg5(3, (Object)this, false, (Object)v));
            }
        }
    }
    
    @Override
    public final void dispatchYield(final up0 up0, final Runnable runnable) {
        this.x.a(runnable);
        if (aq1.z.get((Object)this) < this.v && this.W()) {
            final Runnable v = this.V();
            if (v != null) {
                this.n.dispatchYield((up0)this, (Runnable)new jg5(3, (Object)this, false, (Object)v));
            }
        }
    }
    
    @Override
    public final xp0 limitedParallelism(final int n, final String s) {
        sw5.a(n);
        if (n >= this.v) {
            Object o;
            if (s != null) {
                o = new uz1((xp0)this, s);
            }
            else {
                o = this;
            }
            return (xp0)o;
        }
        return super.limitedParallelism(n, s);
    }
    
    @Override
    public final String toString() {
        String s;
        if ((s = this.w) == null) {
            final StringBuilder sb = new StringBuilder();
            sb.append((Object)this.n);
            sb.append(".limitedParallelism(");
            s = mb.g(sb, this.v, ')');
        }
        return s;
    }
}
