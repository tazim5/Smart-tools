import com.google.android.gms.internal.ads.n3;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public final class ef5 extends j24
{
    public final AtomicReferenceFieldUpdater b;
    public final AtomicReferenceFieldUpdater c;
    public final AtomicReferenceFieldUpdater d;
    public final AtomicReferenceFieldUpdater e;
    public final AtomicReferenceFieldUpdater f;
    
    public ef5(final AtomicReferenceFieldUpdater b, final AtomicReferenceFieldUpdater c, final AtomicReferenceFieldUpdater d, final AtomicReferenceFieldUpdater e, final AtomicReferenceFieldUpdater f) {
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
    }
    
    @Override
    public final df5 a(final n3 n3) {
        return (df5)this.e.getAndSet((Object)n3, (Object)df5.d);
    }
    
    @Override
    public final lf5 b(final n3 n3) {
        return (lf5)this.d.getAndSet((Object)n3, (Object)lf5.c);
    }
    
    @Override
    public final void c(final lf5 lf5, final lf5 lf6) {
        this.c.lazySet((Object)lf5, (Object)lf6);
    }
    
    @Override
    public final void d(final lf5 lf5, final Thread thread) {
        this.b.lazySet((Object)lf5, (Object)thread);
    }
    
    @Override
    public final boolean e(final n3 n3, final df5 df5, final df5 df6) {
        return l24.a(this.e, n3, (Object)df5, (Object)df6);
    }
    
    @Override
    public final boolean f(final n3 n3, final Object o, final Object o2) {
        return l24.a(this.f, n3, o, o2);
    }
    
    @Override
    public final boolean g(final n3 n3, final lf5 lf5, final lf5 lf6) {
        return l24.a(this.d, n3, (Object)lf5, (Object)lf6);
    }
}
