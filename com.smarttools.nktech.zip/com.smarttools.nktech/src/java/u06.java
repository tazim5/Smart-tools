import com.google.android.gms.internal.ads.zzcf;

public abstract class u06
{
    public static boolean a(final le3 le3) {
        final f85 f85 = new f85(8);
        final int a = tj3.a(le3, f85).a;
        if (a != 1380533830 && a != 1380333108) {
            return false;
        }
        le3.g(f85.a, 0, 4, false);
        f85.e(0);
        final int j = f85.j();
        if (j != 1463899717) {
            final StringBuilder sb = new StringBuilder("Unsupported form type: ");
            sb.append(j);
            mo5.d("WavHeaderReader", sb.toString());
            return false;
        }
        return true;
    }
    
    public static tj3 b(final int n, final le3 le3, final f85 f85) {
        tj3 tj3 = tj3.a(le3, f85);
        while (true) {
            final int a = tj3.a;
            if (a == n) {
                return tj3;
            }
            f83.m(a, "Ignoring unknown WAV chunk: ");
            final long n2 = tj3.b + 8L;
            if (n2 > 2147483647L) {
                final StringBuilder sb = new StringBuilder("Chunk is too large (~2GB+) to skip; id: ");
                sb.append(a);
                throw zzcf.b(sb.toString());
            }
            le3.j((int)n2);
            tj3 = tj3.a(le3, f85);
        }
    }
}
