import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.Modifier;
import com.smarttools.nktech.features.settings.presentation.l;
import androidx.compose.material.icons.filled.PaletteKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;
import com.smarttools.nktech.core.data.datastore.LayoutStyle;

public final class hm2 implements od1
{
    public final LayoutStyle c;
    public final id1 n;
    
    public hm2(final LayoutStyle c, final id1 n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object invoke(final Object o, Object o2, Object rememberedValue) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)rememberedValue).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final ImageVector palette = PaletteKt.getPalette(Icons.INSTANCE.getDefault());
            final LayoutStyle n = LayoutStyle.n;
            final LayoutStyle c = this.c;
            String s;
            if (c == n) {
                s = "Change accent colors for each category";
            }
            else {
                s = "Available in Modern Layout only";
            }
            composer.startReplaceGroup(-774245684);
            final boolean changed = composer.changed((Object)c);
            final id1 n2 = this.n;
            final boolean changed2 = composer.changed((Object)n2);
            rememberedValue = composer.rememberedValue();
            if ((changed | changed2) || (o2 = rememberedValue) == Composer.Companion.getEmpty()) {
                o2 = new d5(c, n2);
                composer.updateRememberedValue(o2);
            }
            final id1 id1 = (id1)o2;
            composer.endReplaceGroup();
            l.b(palette, "Customize Category Colors", s, id1, c == n, (Modifier)null, composer, 48, 32);
        }
        return t43.a;
    }
}
