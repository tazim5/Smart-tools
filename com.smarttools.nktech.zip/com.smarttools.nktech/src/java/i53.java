public final class i53 extends xp0
{
    public static final i53 c;
    
    static {
        c = (i53)new xp0();
    }
    
    public final void dispatch(final up0 up0, final Runnable runnable) {
        ((wi2)zu0.n).c.c(runnable, true, false);
    }
    
    public final void dispatchYield(final up0 up0, final Runnable runnable) {
        ((wi2)zu0.n).c.c(runnable, true, true);
    }
    
    public final xp0 limitedParallelism(final int n, final String s) {
        sw5.a(n);
        if (n >= kw2.d) {
            Object o;
            if (s != null) {
                o = new uz1((xp0)this, s);
            }
            else {
                o = this;
            }
            return (xp0)o;
        }
        return super.limitedParallelism(n, s);
    }
    
    public final String toString() {
        return "Dispatchers.IO";
    }
}
