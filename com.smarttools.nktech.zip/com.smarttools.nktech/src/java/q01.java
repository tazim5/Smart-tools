import android.widget.AdapterView;
import android.widget.Adapter;
import android.graphics.drawable.Drawable$Callback;
import java.lang.reflect.InvocationTargetException;
import android.graphics.Canvas;
import java.lang.reflect.Field;
import android.widget.AbsListView;
import android.os.Build$VERSION;
import android.view.MotionEvent;
import android.view.ViewGroup$LayoutParams;
import android.view.View;
import android.widget.ListAdapter;
import android.graphics.drawable.Drawable;
import android.view.View$MeasureSpec;
import android.view.ViewGroup;
import android.util.AttributeSet;
import android.content.Context;
import android.graphics.Rect;
import android.widget.ListView;

public abstract class q01 extends ListView
{
    public boolean P;
    public final boolean Q;
    public boolean R;
    public xq1 S;
    public g7 T;
    public final Rect c;
    public int n;
    public int v;
    public int w;
    public int x;
    public int y;
    public o01 z;
    
    public q01(final Context context, final boolean q) {
        super(context, (AttributeSet)null, 2130903171);
        this.c = new Rect();
        this.n = 0;
        this.v = 0;
        this.w = 0;
        this.x = 0;
        this.Q = q;
        ((AbsListView)this).setCacheColorHint(0);
    }
    
    public final int a(final int n, final int n2) {
        final int listPaddingTop = ((AbsListView)this).getListPaddingTop();
        final int listPaddingBottom = ((AbsListView)this).getListPaddingBottom();
        int dividerHeight = this.getDividerHeight();
        final Drawable divider = this.getDivider();
        final ListAdapter adapter = this.getAdapter();
        if (adapter == null) {
            return listPaddingTop + listPaddingBottom;
        }
        int n3 = listPaddingTop + listPaddingBottom;
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        final int count = ((Adapter)adapter).getCount();
        int i = 0;
        int n4 = 0;
        View view = null;
        while (i < count) {
            final int itemViewType = ((Adapter)adapter).getItemViewType(i);
            int n5;
            if (itemViewType != (n5 = n4)) {
                view = null;
                n5 = itemViewType;
            }
            final View view2 = ((Adapter)adapter).getView(i, view, (ViewGroup)this);
            ViewGroup$LayoutParams layoutParams;
            if ((layoutParams = view2.getLayoutParams()) == null) {
                layoutParams = ((ViewGroup)this).generateDefaultLayoutParams();
                view2.setLayoutParams(layoutParams);
            }
            final int height = layoutParams.height;
            int n6;
            if (height > 0) {
                n6 = View$MeasureSpec.makeMeasureSpec(height, 1073741824);
            }
            else {
                n6 = View$MeasureSpec.makeMeasureSpec(0, 0);
            }
            view2.measure(n, n6);
            view2.forceLayout();
            int n7 = n3;
            if (i > 0) {
                n7 = n3 + dividerHeight;
            }
            n3 = n7 + view2.getMeasuredHeight();
            if (n3 >= n2) {
                return n2;
            }
            ++i;
            n4 = n5;
            view = view2;
        }
        return n3;
    }
    
    public final boolean b(final MotionEvent motionEvent, int y) {
        final int actionMasked = motionEvent.getActionMasked();
        final int n = 0;
        boolean b = false;
        Label_0695: {
            int pointerIndex;
            while (true) {
                Label_0054: {
                    if (actionMasked == 1) {
                        b = false;
                        break Label_0054;
                    }
                    if (actionMasked == 2) {
                        b = true;
                        break Label_0054;
                    }
                    if (actionMasked != 3) {
                        b = true;
                        y = n;
                        break Label_0695;
                    }
                    b = false;
                    y = n;
                    break Label_0695;
                }
                pointerIndex = motionEvent.findPointerIndex(y);
                if (pointerIndex < 0) {
                    continue;
                }
                break;
            }
            y = (int)motionEvent.getX(pointerIndex);
            final int n2 = (int)motionEvent.getY(pointerIndex);
            final int pointToPosition = ((AbsListView)this).pointToPosition(y, n2);
            if (pointToPosition == -1) {
                y = 1;
            }
            else {
                final View child = ((ViewGroup)this).getChildAt(pointToPosition - ((AdapterView)this).getFirstVisiblePosition());
                final float n3 = (float)y;
                final float n4 = (float)n2;
                this.R = true;
                l01.a((View)this, n3, n4);
                if (!((View)this).isPressed()) {
                    ((View)this).setPressed(true);
                }
                ((AbsListView)this).layoutChildren();
                y = this.y;
                if (y != -1) {
                    final View child2 = ((ViewGroup)this).getChildAt(y - ((AdapterView)this).getFirstVisiblePosition());
                    if (child2 != null && child2 != child && child2.isPressed()) {
                        child2.setPressed(false);
                    }
                }
                this.y = pointToPosition;
                l01.a(child, n3 - child.getLeft(), n4 - child.getTop());
                if (!child.isPressed()) {
                    child.setPressed(true);
                }
                final Drawable selector = ((AbsListView)this).getSelector();
                if (selector != null && pointToPosition != -1) {
                    y = 1;
                }
                else {
                    y = 0;
                }
                if (y != 0) {
                    selector.setVisible(false, false);
                }
                final int left = child.getLeft();
                final int top = child.getTop();
                final int right = child.getRight();
                final int bottom = child.getBottom();
                final Rect c = this.c;
                c.set(left, top, right, bottom);
                c.left -= this.n;
                c.top -= this.v;
                c.right += this.w;
                c.bottom += this.x;
                final int a = bi.a;
                final int sdk_INT = Build$VERSION.SDK_INT;
                boolean b2 = false;
                Label_0466: {
                    if (sdk_INT < 33 && (sdk_INT < 32 || !bi.a("Tiramisu", Build$VERSION.CODENAME))) {
                        final Field a2 = p01.a;
                        if (a2 != null) {
                            try {
                                b2 = a2.getBoolean((Object)this);
                                break Label_0466;
                            }
                            catch (final IllegalAccessException ex) {
                                ((Throwable)ex).printStackTrace();
                            }
                        }
                        b2 = false;
                    }
                    else {
                        b2 = n01.a((AbsListView)this);
                    }
                }
                if (child.isEnabled() != b2) {
                    final boolean b3 = b2 ^ true;
                    final int sdk_INT2 = Build$VERSION.SDK_INT;
                    if (sdk_INT2 < 33 && (sdk_INT2 < 32 || !bi.a("Tiramisu", Build$VERSION.CODENAME))) {
                        final Field a3 = p01.a;
                        if (a3 != null) {
                            try {
                                a3.set((Object)this, (Object)b3);
                            }
                            catch (final IllegalAccessException ex2) {
                                ((Throwable)ex2).printStackTrace();
                            }
                        }
                    }
                    else {
                        n01.b((AbsListView)this, b3);
                    }
                    if (pointToPosition != -1) {
                        ((View)this).refreshDrawableState();
                    }
                }
                if (y != 0) {
                    final float exactCenterX = c.exactCenterX();
                    final float exactCenterY = c.exactCenterY();
                    selector.setVisible(((View)this).getVisibility() == 0, false);
                    tz0.e(selector, exactCenterX, exactCenterY);
                }
                final Drawable selector2 = ((AbsListView)this).getSelector();
                if (selector2 != null && pointToPosition != -1) {
                    tz0.e(selector2, n3, n4);
                }
                final o01 z = this.z;
                if (z != null) {
                    z.n = false;
                }
                ((View)this).refreshDrawableState();
                if (actionMasked == 1) {
                    ((AdapterView)this).performItemClick(child, pointToPosition, ((AdapterView)this).getItemIdAtPosition(pointToPosition));
                }
                b = true;
                y = 0;
            }
        }
        if (!b || y != 0) {
            ((View)this).setPressed(this.R = false);
            this.drawableStateChanged();
            final View child3 = ((ViewGroup)this).getChildAt(this.y - ((AdapterView)this).getFirstVisiblePosition());
            if (child3 != null) {
                child3.setPressed(false);
            }
        }
        if (b) {
            if (this.S == null) {
                this.S = new xq1(this);
            }
            final xq1 s = this.S;
            final boolean x = s.X;
            s.X = true;
            s.onTouch((View)this, motionEvent);
        }
        else {
            final xq1 s2 = this.S;
            if (s2 != null) {
                if (s2.X) {
                    s2.d();
                }
                s2.X = false;
            }
        }
        return b;
    }
    
    public final void dispatchDraw(final Canvas canvas) {
        final Rect c = this.c;
        if (!c.isEmpty()) {
            final Drawable selector = ((AbsListView)this).getSelector();
            if (selector != null) {
                selector.setBounds(c);
                selector.draw(canvas);
            }
        }
        super.dispatchDraw(canvas);
    }
    
    public final void drawableStateChanged() {
        if (this.T != null) {
            return;
        }
        super.drawableStateChanged();
        final o01 z = this.z;
        if (z != null) {
            z.n = true;
        }
        final Drawable selector = ((AbsListView)this).getSelector();
        if (selector != null && this.R && ((View)this).isPressed()) {
            selector.setState(((View)this).getDrawableState());
        }
    }
    
    public final boolean hasFocus() {
        return this.Q || super.hasFocus();
    }
    
    public final boolean hasWindowFocus() {
        return this.Q || super.hasWindowFocus();
    }
    
    public final boolean isFocused() {
        return this.Q || super.isFocused();
    }
    
    public final boolean isInTouchMode() {
        return (this.Q && this.P) || super.isInTouchMode();
    }
    
    public final void onDetachedFromWindow() {
        this.T = null;
        super.onDetachedFromWindow();
    }
    
    public boolean onHoverEvent(final MotionEvent motionEvent) {
        final int sdk_INT = Build$VERSION.SDK_INT;
        if (sdk_INT < 26) {
            return super.onHoverEvent(motionEvent);
        }
        final int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.T == null) {
            ((View)this).post((Runnable)(this.T = new g7((Object)this, 7)));
        }
        final boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked != 9 && actionMasked != 7) {
            ((AdapterView)this).setSelection(-1);
        }
        else {
            final int pointToPosition = ((AbsListView)this).pointToPosition((int)motionEvent.getX(), (int)motionEvent.getY());
            if (pointToPosition != -1 && pointToPosition != ((AdapterView)this).getSelectedItemPosition()) {
                final View child = ((ViewGroup)this).getChildAt(pointToPosition - ((AdapterView)this).getFirstVisiblePosition());
                Label_0272: {
                    if (child.isEnabled()) {
                        ((View)this).requestFocus();
                        if (sdk_INT >= 30 && m01.d) {
                            Label_0251: {
                                try {
                                    m01.a.invoke((Object)this, new Object[] { pointToPosition, child, Boolean.FALSE, -1, -1 });
                                    m01.b.invoke((Object)this, new Object[] { pointToPosition });
                                    m01.c.invoke((Object)this, new Object[] { pointToPosition });
                                    break Label_0272;
                                }
                                catch (final InvocationTargetException ex) {}
                                catch (final IllegalAccessException ex2) {
                                    break Label_0251;
                                }
                                final InvocationTargetException ex;
                                ((Throwable)ex).printStackTrace();
                                break Label_0272;
                            }
                            final IllegalAccessException ex2;
                            ((Throwable)ex2).printStackTrace();
                        }
                        else {
                            ((AbsListView)this).setSelectionFromTop(pointToPosition, child.getTop() - ((View)this).getTop());
                        }
                    }
                }
                final Drawable selector = ((AbsListView)this).getSelector();
                if (selector != null && this.R && ((View)this).isPressed()) {
                    selector.setState(((View)this).getDrawableState());
                }
            }
        }
        return onHoverEvent;
    }
    
    public final boolean onTouchEvent(final MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.y = ((AbsListView)this).pointToPosition((int)motionEvent.getX(), (int)motionEvent.getY());
        }
        final g7 t = this.T;
        if (t != null) {
            final q01 q01 = (q01)t.n;
            q01.T = null;
            ((View)q01).removeCallbacks((Runnable)t);
        }
        return super.onTouchEvent(motionEvent);
    }
    
    public void setListSelectionHidden(final boolean p) {
        this.P = p;
    }
    
    public void setSelector(final Drawable c) {
        Object o = null;
        if (c != null) {
            o = new Drawable();
            final Drawable c2 = ((o01)o).c;
            if (c2 != null) {
                c2.setCallback((Drawable$Callback)null);
            }
            (((o01)o).c = c).setCallback((Drawable$Callback)o);
            ((o01)o).n = true;
        }
        super.setSelector((Drawable)(this.z = (o01)o));
        final Rect rect = new Rect();
        if (c != null) {
            c.getPadding(rect);
        }
        this.n = rect.left;
        this.v = rect.top;
        this.w = rect.right;
        this.x = rect.bottom;
    }
}
