import java.util.Iterator;
import java.util.AbstractSet;

public final class na extends AbstractSet
{
    public final sa c;
    
    public na(final sa c) {
        this.c = c;
    }
    
    public final Iterator iterator() {
        return (Iterator)new qa(this.c);
    }
    
    public final int size() {
        return ((un2)this.c).v;
    }
}
