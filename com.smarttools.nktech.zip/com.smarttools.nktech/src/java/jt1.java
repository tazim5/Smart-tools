import java.util.Iterator;
import java.util.Collection;
import java.util.Map$Entry;
import kotlin.collections.builders.MapBuilder;

public final class jt1 extends s0
{
    public final MapBuilder c;
    
    public jt1(final MapBuilder c) {
        this.c = c;
    }
    
    @Override
    public final boolean add(final Object o) {
        final Map$Entry map$Entry = (Map$Entry)o;
        throw new UnsupportedOperationException();
    }
    
    public final boolean addAll(final Collection collection) {
        throw new UnsupportedOperationException();
    }
    
    public final void clear() {
        this.c.clear();
    }
    
    public final boolean contains(final Object o) {
        return o instanceof Map$Entry && this.c.k((Map$Entry)o);
    }
    
    public final boolean containsAll(final Collection collection) {
        return this.c.j(collection);
    }
    
    @Override
    public final int getSize() {
        return this.c.size();
    }
    
    public final boolean isEmpty() {
        return this.c.isEmpty();
    }
    
    public final Iterator iterator() {
        final MapBuilder c = this.c;
        c.getClass();
        return (Iterator)new gt1(c, 0);
    }
    
    public final boolean remove(final Object o) {
        return o instanceof Map$Entry && this.c.r((Map$Entry)o);
    }
    
    public final boolean removeAll(final Collection collection) {
        this.c.i();
        return super.removeAll(collection);
    }
    
    public final boolean retainAll(final Collection collection) {
        this.c.i();
        return super.retainAll(collection);
    }
}
