import android.app.Notification$Builder;
import android.app.Notification$Action$Builder;

public abstract class e32
{
    public static Notification$Action$Builder a(final Notification$Action$Builder notification$Action$Builder, final boolean authenticationRequired) {
        return notification$Action$Builder.setAuthenticationRequired(authenticationRequired);
    }
    
    public static Notification$Builder b(final Notification$Builder notification$Builder, final int foregroundServiceBehavior) {
        return notification$Builder.setForegroundServiceBehavior(foregroundServiceBehavior);
    }
}
