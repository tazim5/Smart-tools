import com.smarttools.nktech.features.settings.presentation.l;
import com.smarttools.nktech.features.intro.TourStep;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;

public final class cm2 implements od1
{
    public final u13 c;
    
    public cm2(final u13 c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            composer.startReplaceGroup(-774339664);
            final u13 c = this.c;
            Object o4;
            if (c != null) {
                o4 = q42.b(Modifier.Companion, TourStep.x, c, composer);
            }
            else {
                o4 = Modifier.Companion;
            }
            composer.endReplaceGroup();
            l.e("Layout Style", (Modifier)o4, composer, 6, 0);
        }
        return t43.a;
    }
}
