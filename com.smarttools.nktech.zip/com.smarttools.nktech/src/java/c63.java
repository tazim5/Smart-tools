import android.hardware.camera2.CaptureRequest$Key;

public interface c63 extends yd2
{
    public static final id N = new id("camerax.core.useCaseEventCallback", v53.class, null);
}
