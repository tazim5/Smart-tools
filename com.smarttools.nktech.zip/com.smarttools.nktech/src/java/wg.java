public final class wg extends d41
{
    public final Thread P;
    
    public wg(final Thread p) {
        this.P = p;
    }
    
    public final Thread X() {
        return this.P;
    }
}
