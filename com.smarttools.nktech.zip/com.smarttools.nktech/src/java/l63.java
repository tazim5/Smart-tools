import android.view.VelocityTracker;

public abstract class l63
{
    public static float a(final VelocityTracker velocityTracker, final int n) {
        return velocityTracker.getAxisVelocity(n);
    }
    
    public static float b(final VelocityTracker velocityTracker, final int n, final int n2) {
        return velocityTracker.getAxisVelocity(n, n2);
    }
    
    public static boolean c(final VelocityTracker velocityTracker, final int n) {
        return velocityTracker.isAxisSupported(n);
    }
}
