public final class sq4
{
    public final qq4 a;
    
    public sq4() {
        this.a = (qq4)new Object();
    }
}
