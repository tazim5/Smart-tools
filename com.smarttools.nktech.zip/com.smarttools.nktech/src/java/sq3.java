public final class sq3 extends kp5
{
}
