import android.widget.AdapterView;
import android.widget.AbsListView;
import android.widget.Adapter;
import java.lang.reflect.Field;
import android.util.Log;
import android.view.View$OnTouchListener;
import android.os.Build$VERSION;
import android.view.View$MeasureSpec;
import android.view.ViewGroup;
import android.widget.AbsListView$OnScrollListener;
import android.widget.AdapterView$OnItemSelectedListener;
import android.widget.AdapterView$OnItemClickListener;
import android.widget.ListView;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.content.res.TypedArray;
import android.widget.PopupWindow;
import android.util.AttributeSet;
import android.widget.ListAdapter;
import android.content.Context;
import android.graphics.Rect;
import android.os.Handler;
import android.view.View;
import java.lang.reflect.Method;

public abstract class wq1 implements jn2
{
    public static final Method e0;
    public static final Method f0;
    public boolean P;
    public boolean Q;
    public int R;
    public kt0 S;
    public View T;
    public hv1 U;
    public final tq1 V;
    public final vq1 W;
    public final uq1 X;
    public final tq1 Y;
    public final Handler Z;
    public final Rect a0;
    public Rect b0;
    public final Context c;
    public boolean c0;
    public final i9 d0;
    public ListAdapter n;
    public ov1 v;
    public int w;
    public int x;
    public int y;
    public boolean z;
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: bipush          28
        //     5: if_icmpgt       47
        //     8: ldc             Landroid/widget/PopupWindow;.class
        //    10: ldc             "setClipToScreenEnabled"
        //    12: iconst_1       
        //    13: anewarray       Ljava/lang/Class;
        //    16: dup            
        //    17: iconst_0       
        //    18: getstatic       java/lang/Boolean.TYPE:Ljava/lang/Class;
        //    21: aastore        
        //    22: invokevirtual   java/lang/Class.getDeclaredMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //    25: putstatic       wq1.e0:Ljava/lang/reflect/Method;
        //    28: ldc             Landroid/widget/PopupWindow;.class
        //    30: ldc             "setEpicenterBounds"
        //    32: iconst_1       
        //    33: anewarray       Ljava/lang/Class;
        //    36: dup            
        //    37: iconst_0       
        //    38: ldc             Landroid/graphics/Rect;.class
        //    40: aastore        
        //    41: invokevirtual   java/lang/Class.getDeclaredMethod:(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
        //    44: putstatic       wq1.f0:Ljava/lang/reflect/Method;
        //    47: return         
        //    48: astore_0       
        //    49: goto            28
        //    52: astore_0       
        //    53: goto            47
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  8      28     48     52     Ljava/lang/NoSuchMethodException;
        //  28     47     52     56     Ljava/lang/NoSuchMethodException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Expression is linked from several locations: Label_0028:
        //     at q5.p.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:150)
        //     at q5.p.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:470)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:30)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public wq1(final Context c, int resourceId) {
        this.w = -2;
        this.R = 0;
        this.V = new tq1(this, 1);
        this.W = new vq1((Object)this, 0);
        this.X = new uq1(this);
        this.Y = new tq1(this, 0);
        this.a0 = new Rect();
        this.c = c;
        this.Z = new Handler(c.getMainLooper());
        final TypedArray obtainStyledAttributes = c.obtainStyledAttributes((AttributeSet)null, kd2.k, resourceId, 0);
        this.x = obtainStyledAttributes.getDimensionPixelOffset(0, 0);
        final int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.y = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.z = true;
        }
        obtainStyledAttributes.recycle();
        final PopupWindow d0 = new PopupWindow(c, (AttributeSet)null, resourceId, 0);
        final TypedArray obtainStyledAttributes2 = c.obtainStyledAttributes((AttributeSet)null, kd2.o, resourceId, 0);
        if (obtainStyledAttributes2.hasValue(2)) {
            k92.c(d0, obtainStyledAttributes2.getBoolean(2, false));
        }
        Drawable backgroundDrawable = null;
        Label_0230: {
            if (obtainStyledAttributes2.hasValue(0)) {
                resourceId = obtainStyledAttributes2.getResourceId(0, 0);
                if (resourceId != 0) {
                    backgroundDrawable = ps5.b(c, resourceId);
                    break Label_0230;
                }
            }
            backgroundDrawable = obtainStyledAttributes2.getDrawable(0);
        }
        d0.setBackgroundDrawable(backgroundDrawable);
        obtainStyledAttributes2.recycle();
        (this.d0 = (i9)d0).setInputMethodMode(1);
    }
    
    public final void b(final ListAdapter n) {
        final kt0 s = this.S;
        if (s == null) {
            this.S = new kt0((Object)this, 1);
        }
        else {
            final ListAdapter n2 = this.n;
            if (n2 != null) {
                ((Adapter)n2).unregisterDataSetObserver((DataSetObserver)s);
            }
        }
        if ((this.n = n) != null) {
            ((Adapter)n).registerDataSetObserver((DataSetObserver)this.S);
        }
        final ov1 v = this.v;
        if (v != null) {
            ((AbsListView)v).setAdapter(this.n);
        }
    }
    
    @Override
    public final boolean c() {
        return this.d0.isShowing();
    }
    
    @Override
    public final void dismiss() {
        final i9 d0 = this.d0;
        d0.dismiss();
        d0.setContentView((View)null);
        this.v = null;
        this.Z.removeCallbacks((Runnable)this.V);
    }
    
    @Override
    public final ListView i() {
        return this.v;
    }
    
    @Override
    public final void show() {
        final int n = 0;
        final ov1 v = this.v;
        Object o = this.d0;
        final Context c = this.c;
        if (v == null) {
            final boolean c2 = this.c0;
            final pv1 hoverListener = (pv1)this;
            final ov1 v2 = new ov1(c, c2 ^ true);
            v2.setHoverListener(hoverListener);
            ((AbsListView)(this.v = v2)).setAdapter(this.n);
            ((AdapterView)this.v).setOnItemClickListener((AdapterView$OnItemClickListener)this.U);
            ((View)this.v).setFocusable(true);
            ((View)this.v).setFocusableInTouchMode(true);
            ((AdapterView)this.v).setOnItemSelectedListener((AdapterView$OnItemSelectedListener)new qq1((Object)this, 0));
            ((AbsListView)this.v).setOnScrollListener((AbsListView$OnScrollListener)this.X);
            ((PopupWindow)o).setContentView((View)this.v);
        }
        else {
            final ViewGroup viewGroup = (ViewGroup)((PopupWindow)o).getContentView();
        }
        final Drawable background = ((PopupWindow)o).getBackground();
        final Rect a0 = this.a0;
        int n2;
        if (background != null) {
            background.getPadding(a0);
            final int top = a0.top;
            n2 = a0.bottom + top;
            if (!this.z) {
                this.y = -top;
                n2 = n2;
            }
        }
        else {
            a0.setEmpty();
            n2 = 0;
        }
        final int a2 = rq1.a((PopupWindow)o, this.T, this.y, ((PopupWindow)o).getInputMethodMode() == 2);
        final int w = this.w;
        int n3;
        if (w != -2) {
            if (w != -1) {
                n3 = View$MeasureSpec.makeMeasureSpec(w, 1073741824);
            }
            else {
                n3 = View$MeasureSpec.makeMeasureSpec(c.getResources().getDisplayMetrics().widthPixels - (a0.left + a0.right), 1073741824);
            }
        }
        else {
            n3 = View$MeasureSpec.makeMeasureSpec(c.getResources().getDisplayMetrics().widthPixels - (a0.left + a0.right), Integer.MIN_VALUE);
        }
        final int a3 = this.v.a(n3, a2);
        int n4 = n;
        if (a3 > 0) {
            n4 = ((View)this.v).getPaddingBottom() + ((View)this.v).getPaddingTop() + n2;
        }
        int height = a3 + n4;
        this.d0.getInputMethodMode();
        k92.d((PopupWindow)o, 1002);
        Label_0602: {
            while (true) {
                Method e0;
                if (((PopupWindow)o).isShowing()) {
                    final View t = this.T;
                    final Field a4 = q73.a;
                    if (!t.isAttachedToWindow()) {
                        return;
                    }
                    final int w2 = this.w;
                    int width;
                    if (w2 == -1) {
                        width = -1;
                    }
                    else if ((width = w2) == -2) {
                        width = this.T.getWidth();
                    }
                    ((PopupWindow)o).setOutsideTouchable(true);
                    final View t2 = this.T;
                    final int x = this.x;
                    final int y = this.y;
                    if (width < 0) {
                        width = -1;
                    }
                    if (height < 0) {
                        height = -1;
                    }
                    ((PopupWindow)o).update(t2, x, y, width, height);
                    return;
                }
                else {
                    final int w3 = this.w;
                    int width2;
                    if (w3 == -1) {
                        width2 = -1;
                    }
                    else if ((width2 = w3) == -2) {
                        width2 = this.T.getWidth();
                    }
                    ((PopupWindow)o).setWidth(width2);
                    ((PopupWindow)o).setHeight(height);
                    if (Build$VERSION.SDK_INT > 28) {
                        break Label_0602;
                    }
                    e0 = wq1.e0;
                    if (e0 == null) {
                        break Label_0608;
                    }
                }
                try {
                    e0.invoke(o, new Object[] { Boolean.TRUE });
                    ((PopupWindow)o).setOutsideTouchable(true);
                    ((PopupWindow)o).setTouchInterceptor((View$OnTouchListener)this.W);
                    if (this.Q) {
                        k92.c((PopupWindow)o, this.P);
                    }
                    if (Build$VERSION.SDK_INT <= 28) {
                        final Method f0 = wq1.f0;
                        if (f0 != null) {
                            try {
                                f0.invoke(o, new Object[] { this.b0 });
                            }
                            catch (final Exception ex) {
                                Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", (Throwable)ex);
                            }
                        }
                    }
                    else {
                        sq1.a((PopupWindow)o, this.b0);
                    }
                    ((PopupWindow)o).showAsDropDown(this.T, this.x, this.y, this.R);
                    ((AdapterView)this.v).setSelection(-1);
                    if (!this.c0 || this.v.isInTouchMode()) {
                        o = this.v;
                        if (o != null) {
                            ((q01)o).setListSelectionHidden(true);
                            ((View)o).requestLayout();
                        }
                    }
                    if (!this.c0) {
                        this.Z.post((Runnable)this.Y);
                    }
                    return;
                    sq1.b((PopupWindow)o, true);
                    continue;
                }
                catch (final Exception ex2) {
                    continue;
                }
                break;
            }
        }
    }
}
