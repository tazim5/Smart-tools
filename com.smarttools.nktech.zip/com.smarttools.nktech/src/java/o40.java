import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.internal.ComposableLambda;

public abstract class o40
{
    public static final ComposableLambda a;
    public static final ComposableLambda b;
    public static final ComposableLambda c;
    public static final ComposableLambda d;
    
    static {
        a = ComposableLambdaKt.composableLambdaInstance(546476324, false, (Object)s30.h0);
        b = ComposableLambdaKt.composableLambdaInstance(-1288644477, false, (Object)m40.c);
        c = ComposableLambdaKt.composableLambdaInstance(-931162670, false, (Object)n40.c);
        d = ComposableLambdaKt.composableLambdaInstance(-948620168, false, (Object)t10.Z);
    }
}
