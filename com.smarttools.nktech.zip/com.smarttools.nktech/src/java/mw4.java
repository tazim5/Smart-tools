import java.util.ArrayDeque;
import com.google.android.gms.internal.ads.l2;
import com.google.android.gms.internal.ads.zzfio;
import android.os.Parcel;
import android.os.IInterface;
import com.google.android.gms.ads.internal.util.zzbt;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.zzt;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.content.SharedPreferences;
import com.google.android.gms.internal.ads.e;
import com.google.android.gms.internal.ads.zzbwa;
import java.util.List;
import java.security.GeneralSecurityException;
import com.google.android.gms.internal.ads.zzfev;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.internal.ads.zzcbt;
import java.util.concurrent.Executor;
import java.util.concurrent.Callable;
import java.io.IOException;
import android.util.Pair;
import android.util.SparseBooleanArray;
import android.util.SparseArray;
import java.util.Map;
import android.media.MediaCodec$CryptoInfo$Pattern;
import android.media.MediaCodec$CryptoInfo;
import android.content.Context;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public final class mw4 implements s75, zm4, ig5, nc4, t75, n55, gl4, i42, u66, a56, f35, w25
{
    public static mw4 w;
    public final int c;
    public Object n = new HashMap((Map)fl5.a);
    public Object v = new HashMap((Map)fl5.b);
    
    public mw4(final int c) {
        switch (this.c = c) {
            default: {
                final qk4 n = new qk4();
                this.n = n;
                this.v = new ur4((Object)n, 9);
                return;
            }
            case 22: {
                this.n = new HashMap();
                return;
            }
            case 19: {
                this.n = new HashMap();
                this.v = new HashMap();
            }
        }
    }
    
    public mw4(final int n, final int n2) {
        this.c = 20;
        Object emptyList;
        if (n == 0) {
            emptyList = Collections.emptyList();
        }
        else {
            emptyList = new ArrayList(n);
        }
        this.n = emptyList;
        Object emptyList2;
        if (n2 == 0) {
            emptyList2 = Collections.emptyList();
        }
        else {
            emptyList2 = new ArrayList(n2);
        }
        this.v = emptyList2;
    }
    
    public mw4(final Context context) {
        this.c = 16;
        this.v = context.getPackageName();
        this.n = context.getSharedPreferences("paid_storage_sp", 0);
    }
    
    public mw4(final m14 v) {
        this.c = 15;
        this.v = v;
    }
    
    public mw4(final qg3 n, final SparseArray sparseArray) {
        this.c = 27;
        this.n = n;
        final SparseBooleanArray a = n.a;
        final SparseArray v = new SparseArray(a.size());
        for (int i = 0; i < a.size(); ++i) {
            final int a2 = n.a(i);
            final x26 x26 = (x26)sparseArray.get(a2);
            x26.getClass();
            v.append(a2, (Object)x26);
        }
        this.v = v;
    }
    
    public mw4(final qk4 n) {
        this.c = 8;
        this.n = n;
    }
    
    public mw4(final tk2 n) {
        this.c = 25;
        this.v = new Object();
        this.n = n;
        h26.c();
    }
    
    private final void p(final Object o) {
    }
    
    public void a(final int n, final q66 q66, final j66 j66, final n66 n2) {
        final Pair u = this.u(q66);
        if (u != null) {
            ((i26)this.v).i.b((Runnable)new y16(this, u, j66, n2, 1));
        }
    }
    
    public void b(final int n, final q66 q66, final j66 j66, final n66 n2) {
        final Pair u = this.u(q66);
        if (u != null) {
            ((i26)this.v).i.b((Runnable)new y16(this, u, j66, n2, 0));
        }
    }
    
    public void c(final Object o, final qg3 qg3) {
        ((y26)o).l((v26)this.v, new mw4(qg3, ((j36)this.n).x));
    }
    
    public void d(final int n, final q66 q66, final j66 j66, final n66 n2, final IOException ex, final boolean b) {
        final Pair u = this.u(q66);
        if (u != null) {
            ((i26)this.v).i.b((Runnable)new x16((Object)this, (Object)u, j66, n2, ex, b, 0));
        }
    }
    
    public void f(final int n, final q66 q66, final j66 j66, final n66 n2) {
        final Pair u = this.u(q66);
        if (u != null) {
            ((i26)this.v).i.b((Runnable)new y16(this, u, j66, n2, 2));
        }
    }
    
    public void g(final int n, final q66 q66, final n66 n2) {
        final Pair u = this.u(q66);
        if (u != null) {
            ((i26)this.v).i.b((Runnable)new xo0((Object)this, (Object)u, (Object)n2, 18));
        }
    }
    
    public Map h() {
        monitorenter(this);
        Label_0046: {
            try {
                if (this.v == null) {
                    this.v = Collections.unmodifiableMap((Map)new HashMap((Map)this.n));
                }
                break Label_0046;
            }
            finally {
                monitorexit(this);
                final Map map = (Map)this.v;
                monitorexit(this);
                return map;
            }
        }
    }
    
    public void i(final s75 s75) {
        final mg1 mg1 = new mg1((Object)this.n, 6);
        final pg5 pg5 = (pg5)this.v;
        final yq1 b;
        b.addListener((Runnable)new jg5(0, (Object)(b = ((i94)pg5).b((Callable)mg1)), (Object)new bl4((Object)s75, 5)), (Executor)pg5);
    }
    
    public void j(final boolean b, final Context context, final dj4 dj4) {
        final tx4 tx4 = (tx4)this.v;
        final ky4 ky4 = (ky4)this.n;
        ky4.getClass();
        final Object b2 = tx4.b;
        Label_0148: {
            try {
                ((x65)b2).b(b);
                if (((zzcbt)ky4.d).v < (int)zzba.zzc().a(cs3.x0)) {
                    final x65 x65 = (x65)b2;
                    try {
                        x65.a.p();
                    }
                    finally {
                        final Throwable t;
                        throw new Exception(t);
                    }
                }
            }
            catch (final zzfev zzfev) {
                break Label_0148;
            }
            final x65 x66 = (x65)b2;
            try {
                x66.a.e0((th1)new n32((Object)context));
                return;
            }
            finally {
                final Throwable t2;
                throw new Exception(t2);
            }
        }
        d94.zzi("Cannot show interstitial.");
        final zzfev zzfev;
        throw new Exception(((Throwable)zzfev).getCause());
    }
    
    public void k(final cl5 obj) {
        final el5 el5 = new el5(obj.a, obj.b);
        final HashMap hashMap = (HashMap)this.n;
        if (hashMap.containsKey((Object)el5)) {
            final cl5 obj2 = (cl5)hashMap.get((Object)el5);
            if (!obj2.equals(obj) || !obj.equals(obj2)) {
                throw new GeneralSecurityException("Attempt to register non-equal PrimitiveConstructor object for already existing object of type: ".concat(el5.toString()));
            }
        }
        else {
            hashMap.put((Object)el5, (Object)obj);
        }
    }
    
    public void l(final ts5 ts5) {
        ((List)this.v).add((Object)ts5);
    }
    
    public yq1 m(final mw4 mw4, final am4 am4, final oi4 v) {
        monitorenter(this);
        Label_0055: {
            try {
                this.v = v;
                if (mw4.n != null) {
                    final rh4 zzb = v.zzb();
                    final u75 a = zzb.a((yq1)zzb.c((yq1)e.r((Object)mw4.n)));
                    monitorexit(this);
                    return (yq1)a;
                }
                break Label_0055;
            }
            finally {
                monitorexit(this);
                final yq1 o = ((qk4)this.n).o(mw4, am4, v);
                monitorexit(this);
                return o;
            }
        }
    }
    
    public lw4 n(final kw4 p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getfield        kw4.a:Ljava/lang/String;
        //     4: astore          10
        //     6: aload_1        
        //     7: getfield        kw4.b:I
        //    10: istore_3       
        //    11: aload_1        
        //    12: getfield        kw4.c:Ljava/util/HashMap;
        //    15: astore          9
        //    17: aload_1        
        //    18: getfield        kw4.d:[B
        //    21: astore          8
        //    23: aload_1        
        //    24: getfield        kw4.e:Ljava/lang/String;
        //    27: astore          11
        //    29: invokestatic    com/google/android/gms/ads/internal/zzt.zzB:()Lcom/google/android/gms/common/util/Clock;
        //    32: invokeinterface com/google/android/gms/common/util/Clock.elapsedRealtime:()J
        //    37: lstore          5
        //    39: new             Llw4;
        //    42: astore_1       
        //    43: aload_1        
        //    44: invokespecial   lw4.<init>:()V
        //    47: aload_0        
        //    48: getfield        mw4.v:Ljava/lang/Object;
        //    51: checkcast       Ljava/lang/String;
        //    54: astore          7
        //    56: new             Ljava/lang/StringBuilder;
        //    59: astore          12
        //    61: aload           12
        //    63: ldc_w           "SDK version: "
        //    66: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    69: aload           12
        //    71: aload           7
        //    73: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //    76: pop            
        //    77: aload           12
        //    79: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //    82: invokestatic    d94.zzi:(Ljava/lang/String;)V
        //    85: new             Ljava/lang/StringBuilder;
        //    88: astore          7
        //    90: aload           7
        //    92: ldc_w           "AdRequestServiceImpl: Sending request: "
        //    95: invokespecial   java/lang/StringBuilder.<init>:(Ljava/lang/String;)V
        //    98: aload           7
        //   100: aload           10
        //   102: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   105: pop            
        //   106: aload           7
        //   108: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   111: invokestatic    d94.zze:(Ljava/lang/String;)V
        //   114: new             Ljava/net/URL;
        //   117: astore          7
        //   119: aload           7
        //   121: aload           10
        //   123: invokespecial   java/net/URL.<init>:(Ljava/lang/String;)V
        //   126: new             Ljava/util/HashMap;
        //   129: astore          12
        //   131: aload           12
        //   133: invokespecial   java/util/HashMap.<init>:()V
        //   136: iconst_0       
        //   137: istore_2       
        //   138: aload           7
        //   140: invokevirtual   java/net/URL.openConnection:()Ljava/net/URLConnection;
        //   143: checkcast       Ljava/net/HttpURLConnection;
        //   146: astore          10
        //   148: invokestatic    com/google/android/gms/ads/internal/zzt.zzp:()Lcom/google/android/gms/ads/internal/util/zzt;
        //   151: astore          14
        //   153: aload_0        
        //   154: getfield        mw4.n:Ljava/lang/Object;
        //   157: checkcast       Landroid/content/Context;
        //   160: astore          7
        //   162: aload_0        
        //   163: getfield        mw4.v:Ljava/lang/Object;
        //   166: checkcast       Ljava/lang/String;
        //   169: astore          13
        //   171: aload           14
        //   173: aload           7
        //   175: aload           13
        //   177: iconst_0       
        //   178: aload           10
        //   180: iconst_0       
        //   181: iload_3        
        //   182: invokevirtual   com/google/android/gms/ads/internal/util/zzt.zzf:(Landroid/content/Context;Ljava/lang/String;ZLjava/net/HttpURLConnection;ZI)V
        //   185: aload           9
        //   187: invokevirtual   java/util/HashMap.entrySet:()Ljava/util/Set;
        //   190: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //   195: astore          13
        //   197: aload           13
        //   199: invokeinterface java/util/Iterator.hasNext:()Z
        //   204: ifeq            256
        //   207: aload           13
        //   209: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   214: checkcast       Ljava/util/Map$Entry;
        //   217: astore          7
        //   219: aload           10
        //   221: aload           7
        //   223: invokeinterface java/util/Map$Entry.getKey:()Ljava/lang/Object;
        //   228: checkcast       Ljava/lang/String;
        //   231: aload           7
        //   233: invokeinterface java/util/Map$Entry.getValue:()Ljava/lang/Object;
        //   238: checkcast       Ljava/lang/String;
        //   241: invokevirtual   java/net/URLConnection.addRequestProperty:(Ljava/lang/String;Ljava/lang/String;)V
        //   244: goto            197
        //   247: astore_1       
        //   248: goto            972
        //   251: astore          7
        //   253: goto            927
        //   256: aload           11
        //   258: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   261: ifne            274
        //   264: aload           10
        //   266: ldc_w           "Content-Type"
        //   269: aload           11
        //   271: invokevirtual   java/net/URLConnection.setRequestProperty:(Ljava/lang/String;Ljava/lang/String;)V
        //   274: aload           8
        //   276: arraylength    
        //   277: istore          4
        //   279: iload           4
        //   281: ifle            353
        //   284: aload           10
        //   286: iconst_1       
        //   287: invokevirtual   java/net/URLConnection.setDoOutput:(Z)V
        //   290: aload           10
        //   292: iload           4
        //   294: invokevirtual   java/net/HttpURLConnection.setFixedLengthStreamingMode:(I)V
        //   297: new             Ljava/io/BufferedOutputStream;
        //   300: astore          7
        //   302: aload           7
        //   304: aload           10
        //   306: invokevirtual   java/net/URLConnection.getOutputStream:()Ljava/io/OutputStream;
        //   309: invokespecial   java/io/BufferedOutputStream.<init>:(Ljava/io/OutputStream;)V
        //   312: aload           7
        //   314: aload           8
        //   316: invokevirtual   java/io/OutputStream.write:([B)V
        //   319: aload           7
        //   321: invokestatic    com/google/android/gms/common/util/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   324: goto            353
        //   327: astore          8
        //   329: aload           7
        //   331: astore          9
        //   333: goto            345
        //   336: astore          7
        //   338: aconst_null    
        //   339: astore          9
        //   341: aload           7
        //   343: astore          8
        //   345: aload           9
        //   347: invokestatic    com/google/android/gms/common/util/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   350: aload           8
        //   352: athrow         
        //   353: new             Lc94;
        //   356: astore          7
        //   358: aload           7
        //   360: invokespecial   c94.<init>:()V
        //   363: aload           7
        //   365: aload           10
        //   367: aload           8
        //   369: invokevirtual   c94.a:(Ljava/net/HttpURLConnection;[B)V
        //   372: aload           10
        //   374: invokevirtual   java/net/HttpURLConnection.getResponseCode:()I
        //   377: istore          4
        //   379: aload           10
        //   381: invokevirtual   java/net/URLConnection.getHeaderFields:()Ljava/util/Map;
        //   384: invokeinterface java/util/Map.entrySet:()Ljava/util/Set;
        //   389: invokeinterface java/util/Set.iterator:()Ljava/util/Iterator;
        //   394: astore          13
        //   396: aload           13
        //   398: invokeinterface java/util/Iterator.hasNext:()Z
        //   403: ifeq            498
        //   406: aload           13
        //   408: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   413: checkcast       Ljava/util/Map$Entry;
        //   416: astore          15
        //   418: aload           15
        //   420: invokeinterface java/util/Map$Entry.getKey:()Ljava/lang/Object;
        //   425: checkcast       Ljava/lang/String;
        //   428: astore          14
        //   430: aload           15
        //   432: invokeinterface java/util/Map$Entry.getValue:()Ljava/lang/Object;
        //   437: checkcast       Ljava/util/List;
        //   440: astore          16
        //   442: aload           12
        //   444: aload           14
        //   446: invokevirtual   java/util/HashMap.containsKey:(Ljava/lang/Object;)Z
        //   449: ifeq            473
        //   452: aload           12
        //   454: aload           14
        //   456: invokevirtual   java/util/HashMap.get:(Ljava/lang/Object;)Ljava/lang/Object;
        //   459: checkcast       Ljava/util/List;
        //   462: aload           16
        //   464: invokeinterface java/util/List.addAll:(Ljava/util/Collection;)Z
        //   469: pop            
        //   470: goto            396
        //   473: new             Ljava/util/ArrayList;
        //   476: astore          15
        //   478: aload           15
        //   480: aload           16
        //   482: invokespecial   java/util/ArrayList.<init>:(Ljava/util/Collection;)V
        //   485: aload           12
        //   487: aload           14
        //   489: aload           15
        //   491: invokevirtual   java/util/HashMap.put:(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
        //   494: pop            
        //   495: goto            396
        //   498: aload           7
        //   500: aload           10
        //   502: iload           4
        //   504: invokevirtual   c94.b:(Ljava/net/HttpURLConnection;I)V
        //   507: aload_1        
        //   508: iload           4
        //   510: putfield        lw4.a:I
        //   513: aload_1        
        //   514: aload           12
        //   516: putfield        lw4.b:Ljava/util/HashMap;
        //   519: aload_1        
        //   520: ldc_w           ""
        //   523: putfield        lw4.c:Ljava/lang/String;
        //   526: iload           4
        //   528: sipush          200
        //   531: if_icmplt       714
        //   534: iload           4
        //   536: sipush          300
        //   539: if_icmpge       714
        //   542: new             Ljava/io/InputStreamReader;
        //   545: astore          8
        //   547: aload           8
        //   549: aload           10
        //   551: invokevirtual   java/net/URLConnection.getInputStream:()Ljava/io/InputStream;
        //   554: invokespecial   java/io/InputStreamReader.<init>:(Ljava/io/InputStream;)V
        //   557: invokestatic    com/google/android/gms/ads/internal/zzt.zzp:()Lcom/google/android/gms/ads/internal/util/zzt;
        //   560: pop            
        //   561: aload           8
        //   563: invokestatic    com/google/android/gms/ads/internal/util/zzt.zzM:(Ljava/io/InputStreamReader;)Ljava/lang/String;
        //   566: astore          9
        //   568: aload           8
        //   570: invokestatic    com/google/android/gms/common/util/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   573: invokestatic    c94.c:()Z
        //   576: ifne            582
        //   579: goto            616
        //   582: aload           9
        //   584: ifnull          616
        //   587: aload           9
        //   589: invokevirtual   java/lang/String.getBytes:()[B
        //   592: astore          8
        //   594: new             La94;
        //   597: astore          11
        //   599: aload           11
        //   601: aload           8
        //   603: invokespecial   a94.<init>:([B)V
        //   606: aload           7
        //   608: ldc_w           "onNetworkResponseBody"
        //   611: aload           11
        //   613: invokevirtual   c94.d:(Ljava/lang/String;Lb94;)V
        //   616: aload_1        
        //   617: aload           9
        //   619: putfield        lw4.c:Ljava/lang/String;
        //   622: aload           9
        //   624: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   627: ifeq            669
        //   630: getstatic       cs3.G4:Lur3;
        //   633: astore          7
        //   635: invokestatic    com/google/android/gms/ads/internal/client/zzba.zzc:()Las3;
        //   638: aload           7
        //   640: invokevirtual   as3.a:(Lur3;)Ljava/lang/Object;
        //   643: checkcast       Ljava/lang/Boolean;
        //   646: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   649: ifeq            655
        //   652: goto            669
        //   655: new             Lcom/google/android/gms/internal/ads/zzdxn;
        //   658: astore          7
        //   660: aload           7
        //   662: iconst_3       
        //   663: invokespecial   com/google/android/gms/internal/ads/zzdxn.<init>:(I)V
        //   666: aload           7
        //   668: athrow         
        //   669: aload_1        
        //   670: invokestatic    com/google/android/gms/ads/internal/zzt.zzB:()Lcom/google/android/gms/common/util/Clock;
        //   673: invokeinterface com/google/android/gms/common/util/Clock.elapsedRealtime:()J
        //   678: lload           5
        //   680: lsub           
        //   681: putfield        lw4.d:J
        //   684: aload           10
        //   686: invokevirtual   java/net/HttpURLConnection.disconnect:()V
        //   689: goto            967
        //   692: astore_1       
        //   693: goto            979
        //   696: astore          7
        //   698: goto            706
        //   701: astore          7
        //   703: aconst_null    
        //   704: astore          8
        //   706: aload           8
        //   708: invokestatic    com/google/android/gms/common/util/IOUtils.closeQuietly:(Ljava/io/Closeable;)V
        //   711: aload           7
        //   713: athrow         
        //   714: iload           4
        //   716: sipush          300
        //   719: if_icmplt       844
        //   722: iload           4
        //   724: sipush          400
        //   727: if_icmpge       844
        //   730: aload           10
        //   732: ldc_w           "Location"
        //   735: invokevirtual   java/net/URLConnection.getHeaderField:(Ljava/lang/String;)Ljava/lang/String;
        //   738: astore          13
        //   740: aload           13
        //   742: invokestatic    android/text/TextUtils.isEmpty:(Ljava/lang/CharSequence;)Z
        //   745: ifne            821
        //   748: new             Ljava/net/URL;
        //   751: astore          7
        //   753: aload           7
        //   755: aload           13
        //   757: invokespecial   java/net/URL.<init>:(Ljava/lang/String;)V
        //   760: iinc            2, 1
        //   763: getstatic       cs3.q4:Lur3;
        //   766: astore          13
        //   768: invokestatic    com/google/android/gms/ads/internal/client/zzba.zzc:()Las3;
        //   771: aload           13
        //   773: invokevirtual   as3.a:(Lur3;)Ljava/lang/Object;
        //   776: checkcast       Ljava/lang/Integer;
        //   779: invokevirtual   java/lang/Integer.intValue:()I
        //   782: istore          4
        //   784: iload_2        
        //   785: iload           4
        //   787: if_icmpgt       798
        //   790: aload           10
        //   792: invokevirtual   java/net/HttpURLConnection.disconnect:()V
        //   795: goto            138
        //   798: ldc_w           "Too many redirects."
        //   801: invokestatic    d94.zzj:(Ljava/lang/String;)V
        //   804: new             Lcom/google/android/gms/internal/ads/zzdxn;
        //   807: astore          7
        //   809: aload           7
        //   811: iconst_1       
        //   812: ldc_w           "Too many redirects"
        //   815: invokespecial   com/google/android/gms/internal/ads/zzdxn.<init>:(ILjava/lang/String;)V
        //   818: aload           7
        //   820: athrow         
        //   821: ldc_w           "No location header to follow redirect."
        //   824: invokestatic    d94.zzj:(Ljava/lang/String;)V
        //   827: new             Lcom/google/android/gms/internal/ads/zzdxn;
        //   830: astore          7
        //   832: aload           7
        //   834: iconst_1       
        //   835: ldc_w           "No location header to follow redirect"
        //   838: invokespecial   com/google/android/gms/internal/ads/zzdxn.<init>:(ILjava/lang/String;)V
        //   841: aload           7
        //   843: athrow         
        //   844: new             Ljava/lang/StringBuilder;
        //   847: astore          7
        //   849: aload           7
        //   851: invokespecial   java/lang/StringBuilder.<init>:()V
        //   854: aload           7
        //   856: ldc_w           "Received error HTTP response code: "
        //   859: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   862: pop            
        //   863: aload           7
        //   865: iload           4
        //   867: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   870: pop            
        //   871: aload           7
        //   873: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   876: invokestatic    d94.zzj:(Ljava/lang/String;)V
        //   879: new             Lcom/google/android/gms/internal/ads/zzdxn;
        //   882: astore          7
        //   884: new             Ljava/lang/StringBuilder;
        //   887: astore          8
        //   889: aload           8
        //   891: invokespecial   java/lang/StringBuilder.<init>:()V
        //   894: aload           8
        //   896: ldc_w           "Received error HTTP response code: "
        //   899: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   902: pop            
        //   903: aload           8
        //   905: iload           4
        //   907: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   910: pop            
        //   911: aload           7
        //   913: iconst_1       
        //   914: aload           8
        //   916: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   919: invokespecial   com/google/android/gms/internal/ads/zzdxn.<init>:(ILjava/lang/String;)V
        //   922: aload           7
        //   924: athrow         
        //   925: astore          7
        //   927: getstatic       cs3.o7:Lur3;
        //   930: astore          8
        //   932: invokestatic    com/google/android/gms/ads/internal/client/zzba.zzc:()Las3;
        //   935: aload           8
        //   937: invokevirtual   as3.a:(Lur3;)Ljava/lang/Object;
        //   940: checkcast       Ljava/lang/Boolean;
        //   943: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   946: ifeq            969
        //   949: aload_1        
        //   950: invokestatic    com/google/android/gms/ads/internal/zzt.zzB:()Lcom/google/android/gms/common/util/Clock;
        //   953: invokeinterface com/google/android/gms/common/util/Clock.elapsedRealtime:()J
        //   958: lload           5
        //   960: lsub           
        //   961: putfield        lw4.d:J
        //   964: goto            684
        //   967: aload_1        
        //   968: areturn        
        //   969: aload           7
        //   971: athrow         
        //   972: aload           10
        //   974: invokevirtual   java/net/HttpURLConnection.disconnect:()V
        //   977: aload_1        
        //   978: athrow         
        //   979: ldc_w           "Error while connecting to ad server: "
        //   982: aload_1        
        //   983: invokevirtual   java/lang/Throwable.getMessage:()Ljava/lang/String;
        //   986: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   989: invokevirtual   java/lang/String.concat:(Ljava/lang/String;)Ljava/lang/String;
        //   992: astore          7
        //   994: aload           7
        //   996: invokestatic    d94.zzj:(Ljava/lang/String;)V
        //   999: new             Lcom/google/android/gms/internal/ads/zzdxn;
        //  1002: dup            
        //  1003: aload           7
        //  1005: aload_1        
        //  1006: invokespecial   com/google/android/gms/internal/ads/zzdxn.<init>:(Ljava/lang/String;Ljava/lang/Throwable;)V
        //  1009: athrow         
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  39     136    692    696    Ljava/io/IOException;
        //  138    148    692    696    Ljava/io/IOException;
        //  148    171    925    927    Lcom/google/android/gms/internal/ads/zzdxn;
        //  148    171    247    251    Any
        //  171    197    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  171    197    247    251    Any
        //  197    244    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  197    244    247    251    Any
        //  256    274    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  256    274    247    251    Any
        //  274    279    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  274    279    247    251    Any
        //  284    297    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  284    297    247    251    Any
        //  297    312    336    345    Any
        //  312    319    327    336    Any
        //  319    324    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  319    324    247    251    Any
        //  345    353    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  345    353    247    251    Any
        //  353    396    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  353    396    247    251    Any
        //  396    470    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  396    470    247    251    Any
        //  473    495    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  473    495    247    251    Any
        //  498    526    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  498    526    247    251    Any
        //  542    557    701    706    Any
        //  557    568    696    701    Any
        //  568    579    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  568    579    247    251    Any
        //  587    616    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  587    616    247    251    Any
        //  616    652    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  616    652    247    251    Any
        //  655    669    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  655    669    247    251    Any
        //  669    684    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  669    684    247    251    Any
        //  684    689    692    696    Ljava/io/IOException;
        //  706    714    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  706    714    247    251    Any
        //  730    760    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  730    760    247    251    Any
        //  763    784    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  763    784    247    251    Any
        //  790    795    692    696    Ljava/io/IOException;
        //  798    821    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  798    821    247    251    Any
        //  821    844    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  821    844    247    251    Any
        //  844    925    251    256    Lcom/google/android/gms/internal/ads/zzdxn;
        //  844    925    247    251    Any
        //  927    964    247    251    Any
        //  969    972    247    251    Any
        //  972    979    692    696    Ljava/io/IOException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index: 422, Size: 422
        //     at java.util.ArrayList.get(ArrayList.java:437)
        //     at q5.g.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at q5.g.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:284)
        //     at q5.g.b(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:2125)
        //     at u5.m.d(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:21)
        //     at u5.i.g(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:23)
        //     at u5.i.f(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:159)
        //     at u5.i.j(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:619)
        //     at u5.i.k(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:13)
        //     at u5.i.i(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:29)
        //     at s5.b.a(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:90)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithProcyon(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:367)
        //     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:162)
        //     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:3)
        //     at z6.a.run(r8-map-id-5336d296fbf3284427aba3c9406dc63d81d5d24d9edcf157bc560c004a742559:31)
        //     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1167)
        //     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:641)
        //     at java.lang.Thread.run(Thread.java:764)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void o(final ts5 ts5) {
        ((List)this.n).add((Object)ts5);
    }
    
    public void onComplete(final fw2 fw2) {
        final uc5 uc5 = (uc5)this.n;
        final gw2 gw2 = (gw2)this.v;
        final Object f = uc5.f;
        synchronized (f) {
            uc5.e.remove((Object)gw2);
        }
    }
    
    public rs5 q() {
        return new rs5((List)this.n, (List)this.v);
    }
    
    public void r(Object o, final String s) {
        final boolean b = o instanceof String;
        final String s2 = (String)this.v;
        final SharedPreferences sharedPreferences = (SharedPreferences)this.n;
        boolean b2;
        if (b) {
            b2 = sharedPreferences.edit().putString(s, (String)o).commit();
        }
        else if (o instanceof Long) {
            b2 = sharedPreferences.edit().putLong(s, (long)o).commit();
        }
        else {
            if (!(o instanceof Boolean)) {
                final String value = String.valueOf((Object)o.getClass());
                final StringBuilder sb = new StringBuilder("Unexpected object class ");
                sb.append(value);
                sb.append(" for app ");
                sb.append(s2);
                final String string = sb.toString();
                Log.e("PaidLifecycleSPHandler", string);
                throw new IllegalArgumentException(string);
            }
            b2 = sharedPreferences.edit().putBoolean(s, (boolean)o).commit();
        }
        if (b2) {
            return;
        }
        o = new StringBuilder("Failed to store ");
        ((StringBuilder)o).append(s);
        ((StringBuilder)o).append(" for app ");
        ((StringBuilder)o).append(s2);
        final String string2 = ((StringBuilder)o).toString();
        Log.e("PaidLifecycleSPHandler", string2);
        throw new IOException(string2);
    }
    
    public boolean s(final int n) {
        return ((qg3)this.n).a.get(n);
    }
    
    public void t(String string) {
        if (((SharedPreferences)this.n).edit().remove(string).commit()) {
            return;
        }
        final StringBuilder sb = new StringBuilder("Failed to remove ");
        sb.append(string);
        sb.append(" for app ");
        sb.append((String)this.v);
        string = sb.toString();
        Log.e("PaidLifecycleSPHandler", string);
        throw new IOException(string);
    }
    
    public Pair u(q66 a) {
        final f26 f26 = (f26)this.n;
        Object o = null;
        if (a != null) {
            int i = 0;
            while (true) {
                while (i < f26.c.size()) {
                    if (((q66)f26.c.get(i)).d == a.d) {
                        a = a.a((Object)Pair.create(f26.b, a.a));
                        if (a == null) {
                            return null;
                        }
                        o = a;
                        return Pair.create((Object)f26.d, o);
                    }
                    else {
                        ++i;
                    }
                }
                a = null;
                continue;
            }
        }
        return Pair.create((Object)f26.d, o);
    }
    
    public Object zza(final Object o) {
        switch (this.c) {
            default: {
                final SQLiteDatabase sqLiteDatabase = (SQLiteDatabase)o;
                final gx4 gx4 = (gx4)this.n;
                gx4.getClass();
                final ContentValues contentValues = new ContentValues();
                final bl3 bl3 = (bl3)this.v;
                contentValues.put("timestamp", Long.valueOf(bl3.a));
                contentValues.put("gws_query_id", (String)bl3.c);
                contentValues.put("url", (String)bl3.d);
                contentValues.put("event_state", Integer.valueOf(bl3.b - 1));
                sqLiteDatabase.insert("offline_buffered_pings", (String)null, contentValues);
                zzt.zzp();
                final Context c = gx4.c;
                final zzbt zzy = com.google.android.gms.ads.internal.util.zzt.zzy(c);
                if (zzy != null) {
                    try {
                        zzy.zze((th1)new n32((Object)c));
                    }
                    catch (final RemoteException ex) {
                        zze.zzb("Failed to schedule offline ping sender.", (Throwable)ex);
                    }
                }
                return null;
            }
            case 0: {
                return this.n((kw4)o);
            }
        }
    }
    
    public void zza() {
        switch (this.c) {
            default: {
                final js3 js3 = (js3)((ly4)this.n).b;
                final is3 is3 = (is3)this.v;
                final Parcel zza = ((go3)js3).zza();
                io3.e(zza, (IInterface)is3);
                ((go3)js3).zzbi(1, zza);
                return;
            }
            case 6: {
                final js3 js4 = (js3)((my4)this.n).d;
                final is3 is4 = (is3)this.v;
                final Parcel zza2 = ((go3)js4).zza();
                io3.e(zza2, (IInterface)is4);
                ((go3)js4).zzbi(1, zza2);
            }
        }
    }
    
    public void zza(final Object o) {
        switch (this.c) {
            default: {
                ((y26)o).h((x26)this.n, (n66)this.v);
                return;
            }
            case 12: {
                final a85 a85 = (a85)o;
                final u75 u75 = (u75)this.n;
                a85.g((zzfio)u75.c, u75.n, (Throwable)this.v);
            }
        }
    }
    
    public void zza(final Throwable t) {
        switch (this.c) {
            default: {
                final o85 o85 = (o85)this.v;
                o85.f(t);
                o85.zzf(false);
                ((v85)this.n).a(o85);
                return;
            }
            case 11: {
                ((xo1)((z75)((gl5)this.v).z).c).t0((gl4)new mw4(12, this.n, t));
                return;
            }
            case 10: {
                final m86 m86 = (m86)this.v;
                synchronized (m86) {
                    ((m86)this.v).y = null;
                }
            }
            case 4: {
                final vb3 vb3;
                monitorenter(vb3 = (vb3)this.v);
                Label_0228: {
                    try {
                        ((az4)((vb3)this.v).h).b((l2)this.n);
                        if (((az4)((vb3)this.v).h).d()) {
                            final vb3 vb4 = (vb3)this.v;
                            vb4.p(((az4)vb4.h).a());
                        }
                        break Label_0228;
                    }
                    finally {
                        monitorexit(vb3);
                        monitorexit(vb3);
                        return;
                    }
                }
                break;
            }
        }
    }
    
    public void zza(final boolean b, final int n, final String s, final String s2) {
        ((il3)this.n).e();
        final dc4 dc4 = (dc4)this.v;
        dc4.n();
        dc4.c.U.H();
    }
    
    public void zzb(final Object o) {
        switch (this.c) {
            default: {
                return;
            }
            case 11: {
                ((xo1)((z75)((gl5)this.v).z).c).t0((gl4)new zn4((Object)this.n, 12));
                return;
            }
            case 10: {
                final Void void1 = (Void)o;
                final m86 m86 = (m86)this.v;
                synchronized (m86) {
                    final m86 m87 = (m86)this.v;
                    m87.y = null;
                    ((ArrayDeque)m87.x).addFirst((Object)this.n);
                    final m86 m88 = (m86)this.v;
                    if (m88.n == 1) {
                        m88.f();
                    }
                }
            }
            case 4: {
                final vb3 vb3 = (vb3)this.v;
                final iz4 iz4 = (iz4)o;
                final vb3 vb4;
                monitorenter(vb4 = vb3);
                Label_0242: {
                    try {
                        ((az4)((vb3)this.v).h).c(iz4, (l2)this.n);
                        if (((az4)((vb3)this.v).h).d()) {
                            final vb3 vb5 = (vb3)this.v;
                            vb5.p(((az4)vb5.h).a());
                        }
                        break Label_0242;
                    }
                    finally {
                        monitorexit(vb4);
                        monitorexit(vb4);
                        return;
                    }
                }
                break;
            }
        }
    }
    
    public Object zzd() {
        monitorenter(this);
        while (true) {
            try {
                final oi4 oi4 = (oi4)this.v;
                monitorexit(this);
                return oi4;
                monitorexit(this);
                throw;
            }
            finally {
                continue;
            }
            break;
        }
    }
}
