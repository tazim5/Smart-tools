import androidx.compose.material3.IconKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import com.smarttools.nktech.features.tools.finance.ExpenseCategory;

public final class e61 implements nd1
{
    public final ExpenseCategory c;
    
    public e61(final ExpenseCategory c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(this.c.c(), (String)null, SizeKt.size-3ABfNKs((Modifier)Modifier.Companion, Dp.constructor-impl((float)16)), 0L, composer, 432, 8);
        }
        return t43.a;
    }
}
