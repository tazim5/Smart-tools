import java.util.concurrent.Executor;
import android.os.BaseBundle;
import java.util.Iterator;
import com.google.android.gms.ads.internal.util.zze;
import android.content.SharedPreferences$OnSharedPreferenceChangeListener;
import com.google.android.gms.ads.internal.util.zzad;
import java.util.Map;
import com.google.android.gms.ads.internal.client.zzba;
import android.os.Bundle;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicBoolean;
import android.content.Context;
import java.util.HashMap;

public final class js4
{
    public final HashMap a;
    public final Context b;
    public final pg5 c;
    public final f94 d;
    public final boolean e;
    public final ri5 f;
    public final boolean g;
    public final boolean h;
    public final AtomicBoolean i;
    public final AtomicReference j;
    
    public js4(final pg5 c, final f94 d, final m14 m14, final ri5 f, final Context b) {
        final String s = (String)xs3.a.k();
        final HashMap a = new HashMap();
        this.a = a;
        this.i = new AtomicBoolean();
        this.j = new AtomicReference((Object)new Bundle());
        this.c = c;
        this.d = d;
        this.e = (boolean)zzba.zzc().a(cs3.K1);
        this.f = f;
        this.g = (boolean)zzba.zzc().a(cs3.N1);
        this.h = (boolean)zzba.zzc().a(cs3.j6);
        this.b = b;
        m14.b(a);
    }
    
    public final void a(final Map map, final boolean b) {
        if (!map.isEmpty()) {
            if (map.isEmpty()) {
                d94.zze("Empty or null paramMap.");
            }
            else {
                final boolean andSet = this.i.getAndSet(true);
                final AtomicReference j = this.j;
                if (!andSet) {
                    final String s = (String)zzba.zzc().a(cs3.W8);
                    j.set((Object)zzad.zza(this.b, s, (SharedPreferences$OnSharedPreferenceChangeListener)new h74(s, 1, (Object)this)));
                }
                final Bundle bundle = (Bundle)j.get();
                for (final String s2 : ((BaseBundle)bundle).keySet()) {
                    map.put((Object)s2, (Object)String.valueOf(((BaseBundle)bundle).get(s2)));
                }
            }
            final String a = this.f.a(map);
            zze.zza(a);
            final boolean boolean1 = Boolean.parseBoolean((String)map.get((Object)"scar"));
            if (this.e && (!b || this.g)) {
                if (!boolean1 || this.h) {
                    ((Executor)this.c).execute((Runnable)new jg5(17, this, a));
                }
            }
            return;
        }
        d94.zze("Empty paramMap.");
    }
}
