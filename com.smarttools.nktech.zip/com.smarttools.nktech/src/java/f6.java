import com.smarttools.nktech.e;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.Composer;

public final class f6 implements nd1
{
    public final int c;
    public final String n;
    
    public final Object invoke(final Object o, final Object o2) {
        switch (this.c) {
            default: {
                final Composer composer = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
                    composer.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g(this.n, (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 0, 0, 131070);
                }
                return t43.a;
            }
            case 6: {
                final Composer composer2 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer2.getSkipping()) {
                    composer2.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g(this.n, (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer2, 0, 0, 131070);
                }
                return t43.a;
            }
            case 5: {
                final Composer composer3 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer3.getSkipping()) {
                    composer3.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g(x03.b(this.n), (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer3, 0, 0, 131070);
                }
                return t43.a;
            }
            case 4: {
                final Composer composer4 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer4.getSkipping()) {
                    composer4.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g(this.n, (Modifier)null, 0L, TextUnitKt.getSp(11), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer4, 3072, 0, 131062);
                }
                return t43.a;
            }
            case 3: {
                final Composer composer5 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer5.getSkipping()) {
                    composer5.skipToGroupEnd();
                }
                else {
                    e.a(this.n, composer5, 0);
                }
                return t43.a;
            }
            case 2: {
                final Composer composer6 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer6.getSkipping()) {
                    composer6.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g(this.n, (Modifier)null, 0L, TextUnitKt.getSp(12), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer6, 3072, 0, 131062);
                }
                return t43.a;
            }
            case 1: {
                final Composer composer7 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer7.getSkipping()) {
                    composer7.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g(this.n, (Modifier)null, 0L, TextUnitKt.getSp(12), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer7, 3072, 0, 131062);
                }
                return t43.a;
            }
            case 0: {
                final Composer composer8 = (Composer)o;
                if ((((Number)o2).intValue() & 0xB) == 0x2 && composer8.getSkipping()) {
                    composer8.skipToGroupEnd();
                }
                else {
                    TextKt.Text--4IGK_g(this.n, (Modifier)null, 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer8, 0, 0, 131070);
                }
                return t43.a;
            }
        }
    }
}
