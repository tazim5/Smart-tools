import java.util.Objects;
import android.content.res.Resources$Theme;
import android.content.res.Resources;

public final class mf2
{
    public final Resources a;
    public final Resources$Theme b;
    
    public mf2(final Resources a, final Resources$Theme b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        boolean b = true;
        if (this == o) {
            return true;
        }
        if (o != null && mf2.class == o.getClass()) {
            final mf2 mf2 = (mf2)o;
            if (!this.a.equals(mf2.a) || !Objects.equals((Object)this.b, (Object)mf2.b)) {
                b = false;
            }
            return b;
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        return Objects.hash(new Object[] { this.a, this.b });
    }
}
