import org.json.JSONObject;

public final class dw4
{
    public final e54 a;
    public final JSONObject b;
    public final String c;
    public final o85 d;
    
    public dw4(final e54 a, final JSONObject b, final String c, final o85 d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
}
