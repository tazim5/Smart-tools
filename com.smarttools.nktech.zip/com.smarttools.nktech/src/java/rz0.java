public final class rz0 implements up0
{
    public final up0 c;
    public final Throwable n;
    
    public rz0(final up0 c, final Throwable n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object fold(final Object o, final nd1 nd1) {
        return this.c.fold(o, nd1);
    }
    
    public final sp0 get(final tp0 tp0) {
        return this.c.get(tp0);
    }
    
    public final up0 minusKey(final tp0 tp0) {
        return this.c.minusKey(tp0);
    }
    
    public final up0 plus(final up0 up0) {
        return this.c.plus(up0);
    }
}
