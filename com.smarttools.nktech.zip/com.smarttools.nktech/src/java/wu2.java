import java.util.concurrent.ExecutorService;
import android.os.PowerManager$WakeLock;
import java.util.concurrent.ScheduledExecutorService;
import java.util.Iterator;
import android.text.TextUtils;
import android.os.Looper;
import android.os.Handler;
import android.content.Context;
import androidx.work.impl.background.systemalarm.SystemAlarmService;
import android.content.Intent;
import java.util.ArrayList;

public final class wu2 implements h41
{
    public static final String S;
    public final ArrayList P;
    public Intent Q;
    public SystemAlarmService R;
    public final Context c;
    public final w65 n;
    public final ac3 v;
    public final qa2 w;
    public final ob3 x;
    public final at y;
    public final Handler z;
    
    static {
        S = fs1.g("SystemAlarmDispatcher");
    }
    
    public wu2(final SystemAlarmService systemAlarmService) {
        final Context applicationContext = ((Context)systemAlarmService).getApplicationContext();
        this.c = applicationContext;
        this.y = new at(applicationContext);
        this.v = new ac3();
        final ob3 b = ob3.b((Context)systemAlarmService);
        this.x = b;
        final qa2 f = b.f;
        this.w = f;
        this.n = b.d;
        f.a((h41)this);
        this.P = new ArrayList();
        this.Q = null;
        this.z = new Handler(Looper.getMainLooper());
    }
    
    public final void a(final Intent intent, final int n) {
        final fs1 e = fs1.e();
        String.format("Adding command %s (%s)", new Object[] { intent, n });
        e.a(new Throwable[0]);
        this.c();
        final String action = intent.getAction();
        if (TextUtils.isEmpty((CharSequence)action)) {
            fs1.e().h(new Throwable[0]);
            return;
        }
        if ("ACTION_CONSTRAINTS_CHANGED".equals((Object)action)) {
            this.c();
            final ArrayList p2;
            monitorenter(p2 = this.P);
            Label_0138: {
                try {
                    final Iterator iterator = this.P.iterator();
                    Block_7: {
                        while (iterator.hasNext()) {
                            if ("ACTION_CONSTRAINTS_CHANGED".equals((Object)((Intent)iterator.next()).getAction())) {
                                break Block_7;
                            }
                        }
                        break Label_0138;
                    }
                    monitorexit(p2);
                    return;
                }
                finally {
                    monitorexit(p2);
                    monitorexit(p2);
                }
            }
        }
        intent.putExtra("KEY_START_ID", n);
        final ArrayList p3;
        monitorenter(p3 = this.P);
        Label_0201: {
            try {
                final boolean empty = this.P.isEmpty();
                this.P.add((Object)intent);
                if (empty) {
                    this.f();
                }
                break Label_0201;
            }
            finally {
                monitorexit(p3);
                monitorexit(p3);
            }
        }
    }
    
    public final void b(final String s, final boolean b) {
        final String w = at.w;
        final Intent intent = new Intent(this.c, (Class)SystemAlarmService.class);
        intent.setAction("ACTION_EXECUTION_COMPLETED");
        intent.putExtra("KEY_WORKSPEC_ID", s);
        intent.putExtra("KEY_NEEDS_RESCHEDULE", b);
        this.e((Runnable)new l9((Object)this, (Object)intent, 0, 3));
    }
    
    public final void c() {
        if (this.z.getLooper().getThread() == Thread.currentThread()) {
            return;
        }
        throw new IllegalStateException("Needs to be invoked on the main thread.");
    }
    
    public final void d() {
        fs1.e().a(new Throwable[0]);
        this.w.e((h41)this);
        final ScheduledExecutorService a = this.v.a;
        if (!((ExecutorService)a).isShutdown()) {
            ((ExecutorService)a).shutdownNow();
        }
        this.R = null;
    }
    
    public final void e(final Runnable runnable) {
        this.z.post(runnable);
    }
    
    public final void f() {
        this.c();
        final PowerManager$WakeLock a = v83.a(this.c, "ProcessCommand");
        try {
            a.acquire();
            this.x.d.u((Runnable)new vu2(this, 0));
        }
        finally {
            a.release();
        }
    }
}
