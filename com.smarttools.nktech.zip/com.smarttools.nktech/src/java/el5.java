import java.util.Arrays;

public final class el5
{
    public final Class a = a;
    public final Class b = b;
    
    @Override
    public final boolean equals(final Object o) {
        if (!(o instanceof el5)) {
            return false;
        }
        final el5 el5 = (el5)o;
        return el5.a.equals(this.a) && el5.b.equals(this.b);
    }
    
    @Override
    public final int hashCode() {
        return Arrays.hashCode(new Object[] { this.a, this.b });
    }
    
    @Override
    public final String toString() {
        return az0.f(this.a.getSimpleName(), " with primitive type: ", this.b.getSimpleName());
    }
}
