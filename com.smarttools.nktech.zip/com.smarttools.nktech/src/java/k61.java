import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.CardElevation;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.CardKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material3.CardDefaults;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;
import com.smarttools.nktech.features.tools.finance.Currency;

public final class k61 implements od1
{
    public final Currency c;
    public final double n;
    
    public k61(final Currency c, final double n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            CardKt.Card(SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), (Shape)RoundedCornerShapeKt.RoundedCornerShape-0680j_4(Dp.constructor-impl((float)16)), CardDefaults.INSTANCE.cardColors-ro_MJ88(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getPrimaryContainer-0d7_KjU(), 0L, 0L, 0L, composer, CardDefaults.$stable << 12, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(-1110309382, true, (Object)new j61(this.c, this.n), composer, 54), composer, 196614, 24);
        }
        return t43.a;
    }
}
