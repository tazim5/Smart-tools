import com.google.android.gms.ads.nonagon.signalgeneration.zzf;
import java.util.concurrent.Executor;
import com.google.android.gms.internal.ads.k1;
import kotlinx.coroutines.flow.p;

public abstract class it3
{
    public static final vi5 a;
    public static final vi5 b;
    
    static {
        a = new vi5("NONE", 3);
        b = new vi5("PENDING", 3);
    }
    
    public static final p a(final Object o) {
        Object a = o;
        if (o == null) {
            a = oq3.a;
        }
        return new p(a);
    }
    
    public static void b(final yq1 yq1, final o85 o85) {
        if (!(boolean)ws3.c.k()) {
            return;
        }
        final gg5 r = gg5.r(yq1);
        ((yq1)r).addListener((Runnable)new jg5(0, r, new zn4((Object)o85, 13)), (Executor)k1.f);
    }
    
    public static int c(final o65 o65) {
        final int n = zzf.zze(o65) - 1;
        if (n != 0 && n != 1) {
            return 23;
        }
        return 7;
    }
    
    public static void d(final yq1 yq1, final v85 n, final o85 v, final boolean c) {
        if (!(boolean)ws3.c.k()) {
            return;
        }
        final gg5 r = gg5.r(yq1);
        final Object o = new Object();
        ((y7)o).n = n;
        ((y7)o).v = v;
        ((y7)o).c = c;
        ((yq1)r).addListener((Runnable)new jg5(0, r, o), (Executor)k1.f);
    }
}
