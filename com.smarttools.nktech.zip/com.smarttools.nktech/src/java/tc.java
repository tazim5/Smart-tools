public final class tc implements h32
{
    public static final tc a;
    
    static {
        a = (tc)new Object();
        u81.b("clientMetrics");
    }
    
    public final void a(final Object o, final Object o2) {
        if (o == null) {
            throw null;
        }
        throw new ClassCastException();
    }
}
