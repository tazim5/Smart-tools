import android.os.IInterface;

public interface fb5 extends IInterface
{
    void J0();
    
    void Z(final byte[] p0);
    
    void b(final int p0);
    
    void q0(final int p0);
    
    void s0(final n32 p0, final String p1);
    
    void zzf();
}
