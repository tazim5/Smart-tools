import androidx.compose.runtime.IntState;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material.icons.filled.KeyboardArrowUpKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableIntState;

public final class so1 implements nd1
{
    public final boolean c;
    public final MutableIntState n;
    
    public so1(final boolean c, final MutableIntState n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final ImageVector keyboardArrowUp = KeyboardArrowUpKt.getKeyboardArrowUp(Icons.INSTANCE.getDefault());
            long n;
            if (!this.c && ((IntState)this.n).getIntValue() < 0) {
                composer.startReplaceGroup(1346784870);
                n = MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant-0d7_KjU();
                composer.endReplaceGroup();
            }
            else {
                composer.startReplaceGroup(1346780584);
                n = Color.copy-wmQWz5c$default(MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurfaceVariant-0d7_KjU(), 0.3f, 0.0f, 0.0f, 0.0f, 14, (Object)null);
                composer.endReplaceGroup();
            }
            IconKt.Icon-ww6aTOc(keyboardArrowUp, "Move up", (Modifier)null, n, composer, 48, 4);
        }
        return t43.a;
    }
}
