import android.content.Context;
import java.util.concurrent.Callable;

public final class ta1 implements Callable
{
    public final int a;
    public final String b;
    public final Context c;
    public final l44 d;
    public final int e;
    
    public final Object call() {
        switch (this.a) {
            default: {
                ua1 ua1;
                try {
                    va1.a(this.b, this.c, this.d, this.e);
                }
                finally {
                    ua1 = new ua1(-3);
                }
                return ua1;
            }
            case 0: {
                return va1.a(this.b, this.c, this.d, this.e);
            }
        }
    }
}
