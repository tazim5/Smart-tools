import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.internal.ComposableLambda;

public abstract class cw
{
    public static final ComposableLambda a;
    public static final ComposableLambda b;
    
    static {
        a = ComposableLambdaKt.composableLambdaInstance(-428181618, false, (Object)bw.c);
        b = ComposableLambdaKt.composableLambdaInstance(-530110433, false, (Object)yu.R);
    }
}
