import java.text.DateFormat;
import androidx.compose.ui.text.font.FontWeight$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.ui.Modifier$Companion;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import android.location.Location;

public final class or1 implements od1
{
    public final Location c;
    public final Long n;
    
    public or1(final Location c, final Long n) {
        this.c = c;
        this.n = n;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)20));
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$Vertical top = instance.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final Location c = this.c;
            ur1.c("Latitude", ur1.d(c.getLatitude(), true), composer, 6);
            final float n = 12;
            SpacerKt.Spacer(SizeKt.height-3ABfNKs((Modifier)companion, Dp.constructor-impl(n)), composer, 6);
            ur1.c("Longitude", ur1.d(c.getLongitude(), false), composer, 6);
            ap.l((float)16, companion, composer, 6);
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.getSpaceBetween(), companion2.getTop(), composer, 6);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance3 = RowScopeInstance.INSTANCE;
            final MeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(instance.getTop(), companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
            final id1 constructor3 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor3);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl3 = Updater.constructor-impl(composer);
            final nd1 b3 = ap.b(companion3, constructor-impl3, columnMeasurePolicy2, constructor-impl3, currentCompositionLocalMap3);
            if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                l3.i(currentCompositeKeyHash3, constructor-impl3, currentCompositeKeyHash3, b3);
            }
            Updater.set-impl(constructor-impl3, (Object)materializeModifier3, companion3.getSetModifier());
            final MaterialTheme instance4 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            TextKt.Text--4IGK_g("Accuracy", (Modifier)null, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 6, 0, 65530);
            String e;
            if (c.hasAccuracy()) {
                e = xg.e((int)c.getAccuracy(), "±", " meters");
            }
            else {
                e = "Unknown";
            }
            final FontWeight$Companion companion4 = FontWeight.Companion;
            TextKt.Text--4IGK_g(e, (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196608, 0, 131038);
            composer.endNode();
            final MeasurePolicy columnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(instance.getTop(), companion2.getEnd(), composer, 48);
            final int currentCompositeKeyHash4 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap4 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier4 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
            final id1 constructor4 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor4);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl4 = Updater.constructor-impl(composer);
            final nd1 b4 = ap.b(companion3, constructor-impl4, columnMeasurePolicy3, constructor-impl4, currentCompositionLocalMap4);
            if (constructor-impl4.getInserting() || !kl1.b(constructor-impl4.rememberedValue(), (Object)currentCompositeKeyHash4)) {
                l3.i(currentCompositeKeyHash4, constructor-impl4, currentCompositeKeyHash4, b4);
            }
            Updater.set-impl(constructor-impl4, (Object)materializeModifier4, companion3.getSetModifier());
            TextKt.Text--4IGK_g("Provider", (Modifier)null, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 6, 0, 65530);
            String upperCase;
            if (kl1.b((Object)c.getProvider(), (Object)"gps")) {
                upperCase = "GPS";
            }
            else if (kl1.b((Object)c.getProvider(), (Object)"network")) {
                upperCase = "Network";
            }
            else if (kl1.b((Object)c.getProvider(), (Object)"fused")) {
                upperCase = "Fused";
            }
            else {
                final String provider = c.getProvider();
                if (provider != null) {
                    upperCase = provider.toUpperCase(Locale.ROOT);
                }
                else {
                    upperCase = "Unknown";
                }
            }
            final FontWeight medium = companion4.getMedium();
            long n2;
            if (kl1.b((Object)c.getProvider(), (Object)"gps")) {
                composer.startReplaceGroup(-1724692280);
                n2 = instance4.getColorScheme(composer, $stable).getPrimary-0d7_KjU();
            }
            else {
                composer.startReplaceGroup(-1724691030);
                n2 = instance4.getColorScheme(composer, $stable).getOnSurface-0d7_KjU();
            }
            composer.endReplaceGroup();
            TextKt.Text--4IGK_g(upperCase, (Modifier)null, n2, 0L, (FontStyle)null, medium, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196608, 0, 131034);
            composer.endNode();
            composer.endNode();
            composer.startReplaceGroup(1760500949);
            final boolean hasAltitude = c.hasAltitude();
            final Long n3 = this.n;
            if (hasAltitude || n3 != null) {
                ap.l(n, companion, composer, 6);
                final Modifier fillMaxWidth$default2 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
                final MeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.getSpaceBetween(), companion2.getTop(), composer, 6);
                final int currentCompositeKeyHash5 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap5 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier5 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default2);
                final id1 constructor5 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor5);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl5 = Updater.constructor-impl(composer);
                final nd1 b5 = ap.b(companion3, constructor-impl5, rowMeasurePolicy2, constructor-impl5, currentCompositionLocalMap5);
                if (constructor-impl5.getInserting() || !kl1.b(constructor-impl5.rememberedValue(), (Object)currentCompositeKeyHash5)) {
                    l3.i(currentCompositeKeyHash5, constructor-impl5, currentCompositeKeyHash5, b5);
                }
                l3.l(companion3, constructor-impl5, materializeModifier5, composer, 1917911840);
                if (c.hasAltitude()) {
                    final MeasurePolicy columnMeasurePolicy4 = ColumnKt.columnMeasurePolicy(instance.getTop(), companion2.getStart(), composer, 0);
                    final int currentCompositeKeyHash6 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap6 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier6 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
                    final id1 constructor6 = companion3.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor6);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl6 = Updater.constructor-impl(composer);
                    final nd1 b6 = ap.b(companion3, constructor-impl6, columnMeasurePolicy4, constructor-impl6, currentCompositionLocalMap6);
                    if (constructor-impl6.getInserting() || !kl1.b(constructor-impl6.rememberedValue(), (Object)currentCompositeKeyHash6)) {
                        l3.i(currentCompositeKeyHash6, constructor-impl6, currentCompositeKeyHash6, b6);
                    }
                    Updater.set-impl(constructor-impl6, (Object)materializeModifier6, companion3.getSetModifier());
                    TextKt.Text--4IGK_g("Altitude", (Modifier)null, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 6, 0, 65530);
                    TextKt.Text--4IGK_g(f83.f((int)c.getAltitude(), " m"), (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196608, 0, 131038);
                    composer.endNode();
                }
                composer.endReplaceGroup();
                composer.startReplaceGroup(1917924368);
                if (n3 != null) {
                    final long longValue = ((Number)n3).longValue();
                    final MeasurePolicy columnMeasurePolicy5 = ColumnKt.columnMeasurePolicy(instance.getTop(), companion2.getEnd(), composer, 48);
                    final int currentCompositeKeyHash7 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                    final CompositionLocalMap currentCompositionLocalMap7 = composer.getCurrentCompositionLocalMap();
                    final Modifier materializeModifier7 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
                    final id1 constructor7 = companion3.getConstructor();
                    if (composer.getApplier() == null) {
                        ComposablesKt.invalidApplier();
                    }
                    composer.startReusableNode();
                    if (composer.getInserting()) {
                        composer.createNode(constructor7);
                    }
                    else {
                        composer.useNode();
                    }
                    final Composer constructor-impl7 = Updater.constructor-impl(composer);
                    final nd1 b7 = ap.b(companion3, constructor-impl7, columnMeasurePolicy5, constructor-impl7, currentCompositionLocalMap7);
                    if (constructor-impl7.getInserting() || !kl1.b(constructor-impl7.rememberedValue(), (Object)currentCompositeKeyHash7)) {
                        l3.i(currentCompositeKeyHash7, constructor-impl7, currentCompositeKeyHash7, b7);
                    }
                    Updater.set-impl(constructor-impl7, (Object)materializeModifier7, companion3.getSetModifier());
                    TextKt.Text--4IGK_g("Last Update", (Modifier)null, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 6, 0, 65530);
                    TextKt.Text--4IGK_g(((DateFormat)new SimpleDateFormat("HH:mm:ss", Locale.getDefault())).format(new Date(longValue)), (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196608, 0, 131038);
                    composer.endNode();
                }
                final Composer composer2 = composer;
                composer2.endReplaceGroup();
                composer2.endNode();
            }
            composer.endReplaceGroup();
            composer.startReplaceGroup(1760540461);
            if (c.hasSpeed() && c.getSpeed() > 0.0f) {
                ap.l(n, companion, composer, 6);
                TextKt.Text--4IGK_g("Speed", (Modifier)null, instance4.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance4.getTypography(composer, $stable).getBodySmall(), composer, 6, 0, 65530);
                TextKt.Text--4IGK_g(f83.f((int)(c.getSpeed() * 3.6), " km/h"), (Modifier)null, 0L, 0L, (FontStyle)null, companion4.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196608, 0, 131038);
            }
            composer.endReplaceGroup();
            composer.endNode();
        }
        return t43.a;
    }
}
