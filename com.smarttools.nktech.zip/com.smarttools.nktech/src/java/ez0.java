import java.util.List;

public final class ez0
{
    public final List a;
    public final String b;
    
    public ez0(final String b, final List a) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ez0)) {
            return false;
        }
        final ez0 ez0 = (ez0)o;
        return kl1.b((Object)this.a, (Object)ez0.a) && kl1.b((Object)this.b, (Object)ez0.b);
    }
    
    @Override
    public final int hashCode() {
        return this.b.hashCode() + this.a.hashCode() * 31;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("DiscountResult(breakdown=");
        sb.append((Object)this.a);
        sb.append(", finalText=");
        sb.append(this.b);
        sb.append(")");
        return sb.toString();
    }
}
