public final class e75 implements Cloneable
{
    public boolean c;
    public boolean n;
    
    public final e75 a() {
        try {
            return (e75)super.clone();
        }
        catch (final CloneNotSupportedException ex) {
            throw new AssertionError();
        }
    }
}
