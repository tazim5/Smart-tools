import com.google.android.gms.internal.ads.n3;
import com.google.android.gms.ads.internal.zzt;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;

public class m94 implements yq1
{
    private final ug5 zza;
    
    public m94() {
        this.zza = (ug5)new Object();
    }
    
    public final void addListener(final Runnable runnable, final Executor executor) {
        ((n3)this.zza).addListener(runnable, executor);
    }
    
    public boolean cancel(final boolean b) {
        return ((n3)this.zza).cancel(b);
    }
    
    public final Object get() throws ExecutionException, InterruptedException {
        return ((n3)this.zza).get();
    }
    
    public final Object get(final long n, final TimeUnit timeUnit) throws ExecutionException, InterruptedException, TimeoutException {
        return ((n3)this.zza).get(n, timeUnit);
    }
    
    public final boolean isCancelled() {
        return ((n3)this.zza).c instanceof cf5;
    }
    
    public final boolean isDone() {
        return ((n3)this.zza).isDone();
    }
    
    public final boolean zzc(final Object o) {
        final boolean f = ((n3)this.zza).f(o);
        if (!f) {
            zzt.zzo().f("SettableFuture", (Throwable)new IllegalStateException("Provided SettableFuture with multiple values."));
        }
        return f;
    }
    
    public final boolean zzd(final Throwable t) {
        final boolean g = ((n3)this.zza).g(t);
        if (!g) {
            zzt.zzo().f("SettableFuture", (Throwable)new IllegalStateException("Provided SettableFuture with multiple values."));
        }
        return g;
    }
}
