import java.security.spec.AlgorithmParameterSpec;
import java.security.Key;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.Cipher;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.security.GeneralSecurityException;

public final class jo5 implements zg5
{
    public final po5 a;
    public final lh5 b;
    public final int c;
    
    public jo5(final po5 a, final lh5 b, final int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public final byte[] a(byte[] b, final byte[] array) {
        final int length = b.length;
        final int c = this.c;
        if (length < c) {
            throw new GeneralSecurityException("ciphertext too short");
        }
        final int n = length - c;
        final byte[] copyOfRange = Arrays.copyOfRange(b, 0, n);
        final byte[] copyOfRange2 = Arrays.copyOfRange(b, n, length);
        if ((b = array) == null) {
            b = new byte[0];
        }
        b = un5.b(new byte[][] { b, copyOfRange, Arrays.copyOf(ByteBuffer.allocate(8).putLong(b.length * 8L).array(), 8) });
        this.b.a(copyOfRange2, b);
        final go5 go5 = (go5)this.a;
        go5.getClass();
        final int length2 = copyOfRange.length;
        final int b2 = go5.b;
        if (length2 < b2) {
            throw new GeneralSecurityException("ciphertext too short");
        }
        final byte[] array2 = new byte[b2];
        System.arraycopy((Object)copyOfRange, 0, (Object)array2, 0, b2);
        final int b3 = go5.b;
        final int n2 = length2 - b3;
        b = new byte[n2];
        final Cipher cipher = (Cipher)((ThreadLocal)go5.d).get();
        final byte[] array3 = new byte[go5.c];
        System.arraycopy((Object)array2, 0, (Object)array3, 0, b2);
        cipher.init(2, (Key)go5.a, (AlgorithmParameterSpec)new IvParameterSpec(array3));
        if (cipher.doFinal(copyOfRange, b3, n2, b, 0) == n2) {
            return b;
        }
        throw new GeneralSecurityException("stored output's length does not match input's length");
    }
}
