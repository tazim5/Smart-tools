import androidx.compose.material3.IconKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.material.icons.filled.ShareKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;

public final class yc0 implements nd1
{
    public static final yc0 c;
    
    static {
        c = (yc0)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(ShareKt.getShare(Icons.INSTANCE.getDefault()), "Share", SizeKt.size-3ABfNKs((Modifier)Modifier.Companion, Dp.constructor-impl((float)20)), 0L, composer, 432, 8);
        }
        return t43.a;
    }
}
