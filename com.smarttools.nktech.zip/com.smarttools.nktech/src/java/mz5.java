import java.io.File;
import java.io.InputStream;
import android.graphics.Typeface;
import android.content.res.Resources;
import android.content.Context;
import java.util.concurrent.ConcurrentHashMap;

public abstract class mz5
{
    public mz5() {
        new ConcurrentHashMap();
    }
    
    public abstract Typeface a(final Context p0, final ya1 p1, final Resources p2, final int p3);
    
    public abstract Typeface b(final Context p0, final bb1[] p1, final int p2);
    
    public Typeface c(Context d, final InputStream inputStream) {
        d = (Context)nz5.d(d);
        if (d == null) {
            return null;
        }
        try {
            if (!nz5.c((File)d, inputStream)) {
                return null;
            }
            return Typeface.createFromFile(((File)d).getPath());
        }
        catch (final RuntimeException ex) {
            return null;
        }
        finally {
            ((File)d).delete();
        }
    }
    
    public Typeface d(Context d, final Resources resources, final int n, final String s, final int n2) {
        d = (Context)nz5.d(d);
        if (d == null) {
            return null;
        }
        try {
            if (!nz5.b((File)d, resources, n)) {
                return null;
            }
            return Typeface.createFromFile(((File)d).getPath());
        }
        catch (final RuntimeException ex) {
            return null;
        }
        finally {
            ((File)d).delete();
        }
    }
    
    public bb1 e(final bb1[] array, int i) {
        new ua2(2);
        int n;
        if ((i & 0x1) == 0x0) {
            n = 400;
        }
        else {
            n = 700;
        }
        final boolean b = (i & 0x2) != 0x0;
        final int length = array.length;
        bb1 bb1 = null;
        int n2 = Integer.MAX_VALUE;
        bb1 bb2;
        int abs;
        int n3;
        int n4;
        int n5;
        for (i = 0; i < length; ++i, n2 = n5) {
            bb2 = array[i];
            abs = Math.abs(bb2.c - n);
            if (bb2.d == b) {
                n3 = 0;
            }
            else {
                n3 = 1;
            }
            n4 = abs * 2 + n3;
            if (bb1 == null || (n5 = n2) > n4) {
                bb1 = bb2;
                n5 = n4;
            }
        }
        return bb1;
    }
}
