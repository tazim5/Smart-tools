import androidx.compose.runtime.State;
import androidx.compose.runtime.Composer$Companion;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonKt;
import androidx.compose.material3.IconButtonColors;
import androidx.compose.material3.IconButtonKt;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.CardColors;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.BoxKt;
import android.graphics.Bitmap;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import android.util.Patterns;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableState;

public final class ol2 implements nd1
{
    public final MutableState P;
    public final MutableState c;
    public final MutableState n;
    public final MutableState v;
    public final MutableState w;
    public final MutableState x;
    public final MutableState y;
    public final ft1 z;
    
    public ol2(final MutableState c, final MutableState n, final MutableState v, final MutableState w, final MutableState x, final MutableState y, final ft1 z, final MutableState p8) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
        this.z = z;
        this.P = p8;
    }
    
    public final Object invoke(Object rememberedValue, Object o) {
        final Composer composer = (Composer)rememberedValue;
        if ((((Number)o).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier verticalScroll$default = ScrollKt.verticalScroll$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
            final Arrangement$Vertical top = Arrangement.INSTANCE.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, verticalScroll$default);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance = ColumnScopeInstance.INSTANCE;
            final MutableState c = this.c;
            final String s = (String)((State)c).getValue();
            final Modifier height-3ABfNKs = SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)120));
            final MutableState n = this.n;
            final boolean booleanValue = (boolean)((State)n).getValue();
            composer.startReplaceGroup(263718769);
            o = composer.rememberedValue();
            final Composer$Companion companion4 = Composer.Companion;
            if ((rememberedValue = o) == companion4.getEmpty()) {
                rememberedValue = new y42(c, 27);
                composer.updateRememberedValue(rememberedValue);
            }
            final jd1 jd1 = (jd1)rememberedValue;
            composer.endReplaceGroup();
            OutlinedTextFieldKt.OutlinedTextField(s, jd1, height-3ABfNKs, booleanValue ^ true, false, (TextStyle)null, (nd1)ag0.F, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, false, (VisualTransformation)null, (KeyboardOptions)null, (KeyboardActions)null, false, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, composer, 1573296, 0, 0, 8388528);
            final float n2 = 16;
            ap.l(n2, companion, composer, 6);
            final MutableState v = this.v;
            boolean b2 = false;
            Label_0491: {
                if (((String)((State)v).getValue()).length() != 0) {
                    if (!Patterns.EMAIL_ADDRESS.matcher((CharSequence)((State)v).getValue()).matches()) {
                        b2 = false;
                        break Label_0491;
                    }
                }
                b2 = true;
            }
            final String s2 = (String)((State)v).getValue();
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final boolean booleanValue2 = (boolean)((State)n).getValue();
            composer.startReplaceGroup(263738283);
            o = (rememberedValue = composer.rememberedValue());
            if (o == companion4.getEmpty()) {
                rememberedValue = new y42(v, 28);
                composer.updateRememberedValue(rememberedValue);
            }
            final jd1 jd2 = (jd1)rememberedValue;
            composer.endReplaceGroup();
            OutlinedTextFieldKt.OutlinedTextField(s2, jd2, fillMaxWidth$default, booleanValue2 ^ true, false, (TextStyle)null, (nd1)ag0.G, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)ComposableLambdaKt.rememberComposableLambda(1650468081, true, (Object)new q81(b2, 2), composer, 54), b2 ^ true, (VisualTransformation)null, (KeyboardOptions)null, (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, composer, 1573296, 12583296, 0, 8245168);
            ap.l(n2, companion, composer, 6);
            final MutableState w = this.w;
            if (((State)w).getValue() != null) {
                composer.startReplaceGroup(-413191411);
                final MeasurePolicy maybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(companion2.getTopEnd(), false);
                final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
                final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
                final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, (Modifier)companion);
                final id1 constructor2 = companion3.getConstructor();
                if (composer.getApplier() == null) {
                    ComposablesKt.invalidApplier();
                }
                composer.startReusableNode();
                if (composer.getInserting()) {
                    composer.createNode(constructor2);
                }
                else {
                    composer.useNode();
                }
                final Composer constructor-impl2 = Updater.constructor-impl(composer);
                final nd1 b3 = ap.b(companion3, constructor-impl2, maybeCachedBoxMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
                if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                    l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b3);
                }
                Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
                final BoxScopeInstance instance2 = BoxScopeInstance.INSTANCE;
                CardKt.Card(PaddingKt.padding-3ABfNKs(SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)100)), Dp.constructor-impl((float)4)), (Shape)null, (CardColors)null, CardDefaults.INSTANCE.cardElevation-aqJV_2Y(Dp.constructor-impl((float)2), 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, composer, CardDefaults.$stable << 18 | 0x6, 62), (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(-697660634, true, (Object)new nl2(w), composer, 54), composer, 196614, 22);
                composer.startReplaceGroup(-1733438175);
                o = composer.rememberedValue();
                if ((rememberedValue = o) == companion4.getEmpty()) {
                    rememberedValue = new ya(this.x, w, this.y, 7);
                    composer.updateRememberedValue(rememberedValue);
                }
                final id1 id1 = (id1)rememberedValue;
                composer.endReplaceGroup();
                IconButtonKt.IconButton(id1, (Modifier)null, false, (IconButtonColors)null, (MutableInteractionSource)null, (nd1)ag0.H, composer, 196614, 30);
                composer.endNode();
                composer.endReplaceGroup();
            }
            else {
                composer.startReplaceGroup(-411793187);
                ButtonKt.OutlinedButton((id1)new l5(this.z, 19), SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), (boolean)((State)n).getValue() ^ true, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)ag0.I, composer, 805306416, 504);
                composer.endReplaceGroup();
            }
            composer.startReplaceGroup(263828828);
            final MutableState p2 = this.P;
            if (((State)p2).getValue() != null) {
                String s3;
                if ((s3 = (String)az0.c((float)8, companion, composer, 6, p2)) == null) {
                    s3 = "";
                }
                final MaterialTheme instance3 = MaterialTheme.INSTANCE;
                final int $stable = MaterialTheme.$stable;
                TextKt.Text--4IGK_g(s3, (Modifier)null, instance3.getColorScheme(composer, $stable).getError-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getBodySmall(), composer, 0, 0, 65530);
            }
            composer.endReplaceGroup();
            composer.endNode();
        }
        return t43.a;
    }
}
