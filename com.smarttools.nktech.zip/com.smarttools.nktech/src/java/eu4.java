import com.google.android.gms.ads.internal.client.zzda;
import com.google.android.gms.internal.ads.zzdwm;
import android.hardware.SensorEvent;
import com.google.android.gms.ads.internal.util.zze;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.ads.internal.client.zzba;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.content.Context;
import android.hardware.SensorEventListener;

public final class eu4 implements SensorEventListener
{
    public final Context c;
    public SensorManager n;
    public Sensor v;
    public long w;
    public int x;
    public qt4 y;
    public boolean z;
    
    public eu4(final Context c) {
        this.c = c;
    }
    
    public final void a() {
        monitorenter(this);
        Label_0033: {
            try {
                if (!(boolean)zzba.zzc().a(cs3.V7)) {
                    monitorexit(this);
                    return;
                }
                break Label_0033;
            }
            finally {
                monitorexit(this);
                SensorManager n;
                Sensor v;
                SensorManager n2;
                Label_0159_Outer:Block_7_Outer:Label_0080_Outer:
                while (true) {
                    n = (SensorManager)this.c.getSystemService("sensor");
                    iftrue(Label_0071:)((this.n = n) != null);
                    while (true) {
                        while (true) {
                            Block_6: {
                                break Block_6;
                                while (true) {
                                Block_9:
                                    while (true) {
                                        v = this.v;
                                        iftrue(Label_0159:)(v == null);
                                        break Block_9;
                                        monitorexit(this);
                                        return;
                                        n2 = this.n;
                                        iftrue(Label_0159:)(n2 == null);
                                        continue Label_0159_Outer;
                                    }
                                    n2.registerListener((SensorEventListener)this, v, 2);
                                    this.w = zzt.zzB().currentTimeMillis() - (int)zzba.zzc().a(cs3.X7);
                                    this.z = true;
                                    zze.zza("Listening for shake gestures.");
                                    continue Block_7_Outer;
                                }
                            }
                            d94.zzj("Shake detection failed to initialize. Failed to obtain accelerometer.");
                            monitorexit(this);
                            return;
                            iftrue(Label_0159:)(this.z);
                            continue Label_0080_Outer;
                        }
                        Label_0071: {
                            this.v = n.getDefaultSensor(1);
                        }
                        continue;
                    }
                    iftrue(Label_0080:)(this.n != null);
                    continue Block_7_Outer;
                }
            }
        }
    }
    
    public final void onAccuracyChanged(final Sensor sensor, final int n) {
    }
    
    public final void onSensorChanged(final SensorEvent sensorEvent) {
        if (zzba.zzc().a(cs3.V7)) {
            final float[] values = sensorEvent.values;
            final float n = values[0];
            final float n2 = values[1];
            final float n3 = values[2];
            final float n4 = n / 9.80665f;
            final float n5 = n2 / 9.80665f;
            final float n6 = n3 / 9.80665f;
            if ((float)Math.sqrt((double)(n6 * n6 + (n5 * n5 + n4 * n4))) >= (float)zzba.zzc().a(cs3.W7)) {
                final long currentTimeMillis = zzt.zzB().currentTimeMillis();
                if (this.w + (int)zzba.zzc().a(cs3.X7) <= currentTimeMillis) {
                    if (this.w + (int)zzba.zzc().a(cs3.Y7) < currentTimeMillis) {
                        this.x = 0;
                    }
                    zze.zza("Shake detected.");
                    this.w = currentTimeMillis;
                    final int x = this.x + 1;
                    this.x = x;
                    final qt4 y = this.y;
                    if (y != null && x == (int)zzba.zzc().a(cs3.Z7)) {
                        y.d((zzda)new pt4(0), zzdwm.v);
                    }
                }
            }
        }
    }
}
