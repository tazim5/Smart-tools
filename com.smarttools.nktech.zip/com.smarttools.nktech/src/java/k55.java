import com.google.android.gms.internal.ads.zzbwa;

public final class k55
{
    public final zzbwa a = a;
    public final h75 b = b;
}
