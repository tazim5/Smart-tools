import com.google.android.gms.common.util.Clock;
import com.google.android.gms.ads.internal.client.zzba;
import java.util.concurrent.Executor;
import com.google.android.gms.internal.ads.e;
import java.util.concurrent.Callable;
import java.util.Set;
import android.content.Context;

public final class j15 implements m35
{
    public final int a;
    public final Object b;
    public final Object c;
    
    public j15(final i94 b, final Context context, final Set c) {
        this.a = 4;
        this.b = b;
        this.c = c;
    }
    
    public final int zza() {
        switch (this.a) {
            default: {
                return 48;
            }
            case 6: {
                return 41;
            }
            case 5: {
                return 31;
            }
            case 4: {
                return 27;
            }
            case 3: {
                return 23;
            }
            case 2: {
                return 10;
            }
            case 1: {
                return 6;
            }
            case 0: {
                return 4;
            }
        }
    }
    
    public final yq1 zzb() {
        switch (this.a) {
            default: {
                return ((i94)this.b).b((Callable)new mg1((Object)this, 27));
            }
            case 6: {
                final og5 r = e.r((Object)this.c);
                final nh3 p = nh3.p;
                final pg5 pg5 = (pg5)this.b;
                return (yq1)e.o((yq1)e.x((yq1)r, (ad5)p, (Executor)pg5), (Class)Throwable.class, (cg5)new dx3((Object)this, 22), (Executor)pg5);
            }
            case 5: {
                return (yq1)e.r((Object)new a35(0, (String)this.b, (String)this.c));
            }
            case 4: {
                return ((i94)this.b).b((Callable)new mg1((Object)this, 19));
            }
            case 3: {
                return ((i94)this.b).b((Callable)new mg1((Object)this, 17));
            }
            case 2: {
                Object o;
                if (zzba.zzc().a(cs3.l2)) {
                    o = og5.n;
                }
                else {
                    o = e.x(((p84)this.c).d(), (ad5)nh3.l, (Executor)this.b);
                }
                return (yq1)o;
            }
            case 1: {
                return (yq1)e.y((yq1)this.b, (cg5)qh4.m, (Executor)this.c);
            }
            case 0: {
                return (yq1)e.r((Object)new k15((o65)this.c, ((Clock)this.b).currentTimeMillis()));
            }
        }
    }
}
