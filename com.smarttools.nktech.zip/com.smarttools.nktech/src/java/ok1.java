import android.content.ClipDescription;
import android.net.Uri;

public interface ok1
{
    Uri c();
    
    void d();
    
    Uri e();
    
    Object f();
    
    ClipDescription getDescription();
}
