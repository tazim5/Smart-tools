public interface zg5
{
    byte[] a(final byte[] p0, final byte[] p1);
}
