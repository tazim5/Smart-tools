public final class vt4 implements h32
{
    public static final vt4 a;
    public static final u81 b;
    public static final u81 c;
    public static final u81 d;
    public static final u81 e;
    public static final u81 f;
    public static final u81 g;
    public static final u81 h;
    public static final u81 i;
    public static final u81 j;
    public static final u81 k;
    
    static {
        a = (vt4)new Object();
        b = new u81("durationMs", mb.l(f83.i((Class)yj3.class, new og3(1))));
        c = new u81("errorCode", mb.l(f83.i((Class)yj3.class, new og3(2))));
        d = new u81("isColdCall", mb.l(f83.i((Class)yj3.class, new og3(3))));
        e = new u81("autoManageModelOnBackground", mb.l(f83.i((Class)yj3.class, new og3(4))));
        f = new u81("autoManageModelOnLowMemory", mb.l(f83.i((Class)yj3.class, new og3(5))));
        g = new u81("isNnApiEnabled", mb.l(f83.i((Class)yj3.class, new og3(6))));
        h = new u81("eventsCount", mb.l(f83.i((Class)yj3.class, new og3(7))));
        i = new u81("otherErrors", mb.l(f83.i((Class)yj3.class, new og3(8))));
        j = new u81("remoteConfigValueForAcceleration", mb.l(f83.i((Class)yj3.class, new og3(9))));
        k = new u81("isAccelerated", mb.l(f83.i((Class)yj3.class, new og3(10))));
    }
    
    public final void a(final Object o, final Object o2) {
        final pt5 pt5 = (pt5)o;
        final i32 i32 = (i32)o2;
        i32.a(vt4.b, (Object)pt5.a);
        i32.a(vt4.c, (Object)pt5.b);
        i32.a(vt4.d, (Object)pt5.c);
        i32.a(vt4.e, (Object)null);
        i32.a(vt4.f, (Object)null);
        i32.a(vt4.g, (Object)null);
        i32.a(vt4.h, (Object)null);
        i32.a(vt4.i, (Object)null);
        i32.a(vt4.j, (Object)null);
        i32.a(vt4.k, (Object)null);
    }
}
