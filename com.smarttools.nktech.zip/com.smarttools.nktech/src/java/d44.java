import java.util.List;
import android.os.IInterface;

public interface d44 extends IInterface
{
    void P(final List p0);
    
    void a(final String p0);
}
