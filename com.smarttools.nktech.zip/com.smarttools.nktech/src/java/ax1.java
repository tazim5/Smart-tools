import androidx.compose.runtime.State;
import androidx.compose.runtime.FloatState;
import android.graphics.RectF;
import android.graphics.Rect;
import android.graphics.Bitmap;
import android.graphics.Shader;
import android.graphics.RadialGradient;
import android.graphics.Shader$TileMode;
import android.graphics.Color;
import androidx.compose.runtime.MutableFloatState;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.content.Context;
import androidx.compose.runtime.MutableState;
import android.view.View;

public final class ax1 extends View
{
    public final int c;
    public final MutableState n;
    
    public final void onDraw(final Canvas canvas) {
        final MutableState n = this.n;
        switch (this.c) {
            default: {
                super.onDraw(canvas);
                final float n2 = this.getWidth() / 2.0f;
                final float n3 = this.getHeight() * 0.35f;
                final float n4 = Math.min(this.getWidth(), this.getHeight()) * 0.45f;
                final Paint paint = new Paint(1);
                paint.setShader((Shader)new RadialGradient(n2, n3, n4, new int[] { 16777215, 16777215, Color.argb(py5.f((int)(((FloatState)n).getFloatValue() * 100), 0, 255), 255, 255, 240), 16777215 }, new float[] { 0.0f, 0.5f, 0.75f, 1.0f }, Shader$TileMode.CLAMP));
                canvas.drawCircle(n2, n3, n4, paint);
                this.invalidate();
                return;
            }
            case 0: {
                super.onDraw(canvas);
                final Bitmap bitmap = (Bitmap)((State)n).getValue();
                if (bitmap != null) {
                    if (!bitmap.isRecycled()) {
                        final float n5 = (float)this.getWidth();
                        final float n6 = (float)this.getHeight();
                        final float n7 = n5 / 2.0f;
                        canvas.drawBitmap(bitmap, new Rect(0, 0, bitmap.getWidth() / 2, bitmap.getHeight()), new RectF(0.0f, 0.0f, n7, n6), (Paint)null);
                        final Rect rect = new Rect(bitmap.getWidth() / 2, 0, bitmap.getWidth(), bitmap.getHeight());
                        canvas.save();
                        canvas.scale(-1.0f, 1.0f, n7 / 2.0f + n7, n6 / 2.0f);
                        canvas.drawBitmap(bitmap, rect, new RectF(n7, 0.0f, n5, n6), (Paint)null);
                        canvas.restore();
                        final Paint paint2 = new Paint();
                        paint2.setColor(-2130706433);
                        paint2.setStrokeWidth(2.0f);
                        canvas.drawLine(n7, 0.0f, n7, n6, paint2);
                        this.invalidate();
                    }
                }
            }
        }
    }
}
