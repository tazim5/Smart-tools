import com.google.android.gms.internal.ads.g7;

public interface p66 extends r76
{
    void c();
    
    long d(final long p0);
    
    long f(final long p0, final u26 p1);
    
    void h(final o66 p0, final long p1);
    
    long i(final h86[] p0, final boolean[] p1, final q76[] p2, final boolean[] p3, final long p4);
    
    void k(final long p0);
    
    long zzd();
    
    g7 zzi();
}
