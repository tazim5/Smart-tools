import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;

public final class d60 implements od1
{
    public static final d60 c;
    
    static {
        c = (d60)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            ap.l((float)16, Modifier.Companion, composer, 6);
        }
        return t43.a;
    }
}
