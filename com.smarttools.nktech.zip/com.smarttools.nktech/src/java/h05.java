import java.util.concurrent.ConcurrentHashMap;

public final class h05
{
    public final ConcurrentHashMap a;
    public final nr4 b;
    
    public h05(final nr4 b) {
        this.a = new ConcurrentHashMap();
        this.b = b;
    }
}
