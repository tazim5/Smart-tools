import java.util.Collections;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.ads.internal.client.zzdq;
import android.os.IBinder;
import com.google.android.gms.ads.internal.client.zzdn;
import android.os.Parcelable;
import com.google.android.gms.ads.internal.client.zzcv;
import com.google.android.gms.ads.internal.client.zzcr;
import android.os.IInterface;
import com.google.android.gms.ads.internal.client.zzdf;
import android.os.Parcel;
import com.google.android.gms.ads.internal.client.zzel;
import java.util.List;
import com.google.android.gms.ads.internal.client.zzcs;
import android.os.RemoteException;
import com.google.android.gms.ads.internal.client.zzdg;
import com.google.android.gms.ads.internal.client.zzcw;
import android.os.Bundle;
import com.google.android.gms.internal.ads.w1;

public final class fq4 extends ho3 implements kw3
{
    public final String c;
    public final w1 n;
    public final do4 v;
    public final gs4 w;
    
    public fq4(final String c, final w1 n, final do4 v, final gs4 w) {
        super("com.google.android.gms.ads.internal.formats.client.IUnifiedNativeAd");
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
    }
    
    public final boolean C0(final Bundle bundle) {
        return this.n.i(bundle);
    }
    
    public final void I(final iw3 iw3) {
        final w1 n = this.n;
        synchronized (n) {
            n.l.f(iw3);
        }
    }
    
    public final void I0() {
        final w1 n = this.n;
        synchronized (n) {
            n.l.zzv();
        }
    }
    
    public final void M(final zzcw zzcw) {
        final w1 n = this.n;
        synchronized (n) {
            n.l.o(zzcw);
        }
    }
    
    public final void T(final zzdg zzdg) {
        try {
            if (!zzdg.zzf()) {
                this.w.b();
            }
        }
        catch (final RemoteException ex) {
            d94.zzf("Error in making CSI ping for reporting paid event callback", (Throwable)ex);
        }
        final w1 n = this.n;
        synchronized (n) {
            n.D.c.set((Object)zzdg);
        }
    }
    
    public final void c0(final Bundle bundle) {
        final w1 n = this.n;
        synchronized (n) {
            n.l.j(bundle);
        }
    }
    
    public final void d() {
        final w1 n = this.n;
        synchronized (n) {
            n.l.zzh();
        }
    }
    
    public final void e1(final Bundle bundle) {
        final w1 n = this.n;
        synchronized (n) {
            n.l.i(bundle);
        }
    }
    
    public final boolean i() {
        final w1 n = this.n;
        synchronized (n) {
            return n.l.zzB();
        }
    }
    
    public final void v0(final zzcs zzcs) {
        final w1 n = this.n;
        synchronized (n) {
            n.l.l(zzcs);
        }
    }
    
    public final void zzA() {
        final w1 n = this.n;
        final w1 w1;
        monitorenter(w1 = n);
        Label_0036: {
            try {
                final ho3 u = n.u;
                if (u == null) {
                    d94.zze("Ad should be associated with an ad view before calling recordCustomClickGesture()");
                    monitorexit(w1);
                    return;
                }
                break Label_0036;
            }
            finally {
                monitorexit(w1);
                return;
                final ho3 u;
                n.j.execute((Runnable)new xn4(0, u instanceof lo4, (Object)n));
                monitorexit(w1);
            }
        }
    }
    
    public final boolean zzH() {
        final do4 v = this.v;
        synchronized (v) {
            final List f = v.f;
            monitorexit(v);
            if (!f.isEmpty()) {
                synchronized (v) {
                    final zzel g = v.g;
                    monitorexit(v);
                    if (g != null) {
                        return true;
                    }
                }
            }
            return false;
        }
    }
    
    public final boolean zzbK(int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        final do4 v = this.v;
        switch (n) {
            default: {
                return false;
            }
            case 32: {
                final zzdg zzb = zzdf.zzb(parcel.readStrongBinder());
                io3.b(parcel);
                this.T(zzb);
                parcel2.writeNoException();
                break;
            }
            case 31: {
                final zzdn zzg = this.zzg();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzg);
                break;
            }
            case 30: {
                n = (this.i() ? 1 : 0);
                parcel2.writeNoException();
                final ClassLoader a = io3.a;
                parcel2.writeInt(n);
                break;
            }
            case 29: {
                final ku3 zzj = this.zzj();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzj);
                break;
            }
            case 28: {
                this.zzA();
                parcel2.writeNoException();
                break;
            }
            case 27: {
                this.I0();
                parcel2.writeNoException();
                break;
            }
            case 26: {
                final zzcs zzb2 = zzcr.zzb(parcel.readStrongBinder());
                io3.b(parcel);
                this.v0(zzb2);
                parcel2.writeNoException();
                break;
            }
            case 25: {
                final zzcw zzb3 = zzcv.zzb(parcel.readStrongBinder());
                io3.b(parcel);
                this.M(zzb3);
                parcel2.writeNoException();
                break;
            }
            case 24: {
                n = (this.zzH() ? 1 : 0);
                parcel2.writeNoException();
                final ClassLoader a2 = io3.a;
                parcel2.writeInt(n);
                break;
            }
            case 23: {
                final List zzv = this.zzv();
                parcel2.writeNoException();
                parcel2.writeList(zzv);
                break;
            }
            case 22: {
                this.d();
                parcel2.writeNoException();
                break;
            }
            case 21: {
                final IBinder strongBinder = parcel.readStrongBinder();
                Object o;
                if (strongBinder == null) {
                    o = null;
                }
                else {
                    final IInterface queryLocalInterface = strongBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IUnconfirmedClickListener");
                    if (queryLocalInterface instanceof iw3) {
                        o = queryLocalInterface;
                    }
                    else {
                        o = new go3(strongBinder, "com.google.android.gms.ads.internal.formats.client.IUnconfirmedClickListener");
                    }
                }
                io3.b(parcel);
                this.I((iw3)o);
                parcel2.writeNoException();
                break;
            }
            case 20: {
                final Bundle h = v.h();
                parcel2.writeNoException();
                io3.d(parcel2, (Parcelable)h);
                break;
            }
            case 19: {
                synchronized (v) {
                    final th1 q = v.q;
                    monitorexit(v);
                    parcel2.writeNoException();
                    io3.e(parcel2, (IInterface)q);
                    break;
                }
            }
            case 18: {
                final th1 zzm = this.zzm();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)zzm);
                break;
            }
            case 17: {
                final Bundle bundle = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                this.c0(bundle);
                parcel2.writeNoException();
                break;
            }
            case 16: {
                final Bundle bundle2 = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                n = (this.n.i(bundle2) ? 1 : 0);
                parcel2.writeNoException();
                parcel2.writeInt(n);
                break;
            }
            case 15: {
                final Bundle bundle3 = (Bundle)io3.a(parcel, Bundle.CREATOR);
                io3.b(parcel);
                this.e1(bundle3);
                parcel2.writeNoException();
                break;
            }
            case 14: {
                final gu3 j = v.j();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)j);
                break;
            }
            case 13: {
                this.zzx();
                parcel2.writeNoException();
                break;
            }
            case 12: {
                parcel2.writeNoException();
                parcel2.writeString(this.c);
                break;
            }
            case 11: {
                final zzdq i = v.i();
                parcel2.writeNoException();
                io3.e(parcel2, (IInterface)i);
                break;
            }
            case 10: {
                synchronized (v) {
                    final String c = v.c("price");
                    monitorexit(v);
                    parcel2.writeNoException();
                    parcel2.writeString(c);
                    break;
                }
            }
            case 9: {
                synchronized (v) {
                    final String c2 = v.c("store");
                    monitorexit(v);
                    parcel2.writeNoException();
                    parcel2.writeString(c2);
                    break;
                }
            }
            case 8: {
                synchronized (v) {
                    final double r = v.r;
                    monitorexit(v);
                    parcel2.writeNoException();
                    parcel2.writeDouble(r);
                    break;
                }
            }
            case 7: {
                synchronized (v) {
                    final String c3 = v.c("advertiser");
                    monitorexit(v);
                    parcel2.writeNoException();
                    parcel2.writeString(c3);
                    break;
                }
            }
            case 6: {
                final String p4 = v.p();
                parcel2.writeNoException();
                parcel2.writeString(p4);
                break;
            }
            case 5: {
                synchronized (v) {
                    final mu3 s = v.s;
                    monitorexit(v);
                    parcel2.writeNoException();
                    io3.e(parcel2, (IInterface)s);
                    break;
                }
            }
            case 4: {
                final String o2 = v.o();
                parcel2.writeNoException();
                parcel2.writeString(o2);
                break;
            }
            case 3: {
                synchronized (v) {
                    final List e = v.e;
                    monitorexit(v);
                    parcel2.writeNoException();
                    parcel2.writeList(e);
                    break;
                }
            }
            case 2: {
                final String b = v.b();
                parcel2.writeNoException();
                parcel2.writeString(b);
                break;
            }
        }
        return true;
    }
    
    public final double zze() {
        final do4 v = this.v;
        synchronized (v) {
            return v.r;
        }
    }
    
    public final Bundle zzf() {
        return this.v.h();
    }
    
    public final zzdn zzg() {
        if (!(boolean)zzba.zzc().a(cs3.V5)) {
            return null;
        }
        return (zzdn)((dh4)this.n).f;
    }
    
    public final zzdq zzh() {
        return this.v.i();
    }
    
    public final gu3 zzi() {
        return this.v.j();
    }
    
    public final ku3 zzj() {
        final bo4 c = this.n.C;
        synchronized (c) {
            return c.a;
        }
    }
    
    public final mu3 zzk() {
        final do4 v = this.v;
        synchronized (v) {
            return v.s;
        }
    }
    
    public final th1 zzl() {
        final do4 v = this.v;
        synchronized (v) {
            return v.q;
        }
    }
    
    public final th1 zzm() {
        return (th1)new n32((Object)this.n);
    }
    
    public final String zzn() {
        final do4 v = this.v;
        synchronized (v) {
            return v.c("advertiser");
        }
    }
    
    public final String zzo() {
        return this.v.o();
    }
    
    public final String zzp() {
        return this.v.p();
    }
    
    public final String zzq() {
        return this.v.b();
    }
    
    public final String zzr() {
        return this.c;
    }
    
    public final String zzs() {
        final do4 v = this.v;
        synchronized (v) {
            return v.c("price");
        }
    }
    
    public final String zzt() {
        final do4 v = this.v;
        synchronized (v) {
            return v.c("store");
        }
    }
    
    public final List zzu() {
        final do4 v = this.v;
        synchronized (v) {
            return v.e;
        }
    }
    
    public final List zzv() {
        if (this.zzH()) {
            final do4 v = this.v;
            synchronized (v) {
                final List f = v.f;
                return;
            }
        }
        return Collections.emptyList();
    }
    
    public final void zzx() {
        this.n.p();
    }
}
