import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.ButtonKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableLongState;
import androidx.compose.runtime.MutableState;
import android.content.Context;

public final class d03 implements nd1
{
    public final long c;
    public final Context n;
    public final MutableState v;
    public final MutableState w;
    public final MutableLongState x;
    public final MutableState y;
    
    public d03(final long c, final Context n, final MutableState v, final MutableState w, final MutableLongState x, final MutableState y) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
        this.y = y;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            ButtonKt.OutlinedButton((id1)new c03(this.c, this.n, this.v, this.w, this.x, this.y), (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)bl0.b, composer, 805306368, 510);
        }
        return t43.a;
    }
}
