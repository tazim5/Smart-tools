import java.util.UUID;
import android.content.Context;

public final class om2
{
    public static final ut b;
    public final Context a;
    
    static {
        final tt b2 = ut.b((Class)om2.class);
        b2.a(nw0.a(lx1.class));
        b2.a(nw0.a(Context.class));
        b2.f = (mu)qq.g0;
        b = b2.b();
    }
    
    public om2(final Context a) {
        this.a = a;
    }
    
    public final String a() {
        synchronized (this) {
            final String string = this.a.getSharedPreferences("com.google.mlkit.internal", 0).getString("ml_sdk_instance_id", (String)null);
            if (string != null) {
                return string;
            }
            final String string2 = UUID.randomUUID().toString();
            this.a.getSharedPreferences("com.google.mlkit.internal", 0).edit().putString("ml_sdk_instance_id", string2).apply();
            return string2;
        }
    }
}
