public final class ir3 extends kp5
{
}
