import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.material.icons.Icons$Filled;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.material3.IconKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.material.icons.filled.PlayArrowKt;
import androidx.compose.material.icons.filled.PauseKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.RowScope;

public final class t4 implements od1
{
    public final boolean c;
    
    public t4(final boolean c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final RowScope rowScope = (RowScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) != 0x10 || !composer.getSkipping()) {
            final boolean c = this.c;
            final Icons$Filled default1 = Icons.INSTANCE.getDefault();
            ImageVector imageVector;
            if (c) {
                imageVector = PauseKt.getPause(default1);
            }
            else {
                imageVector = PlayArrowKt.getPlayArrow(default1);
            }
            final Modifier$Companion companion = Modifier.Companion;
            IconKt.Icon-ww6aTOc(imageVector, (String)null, SizeKt.size-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)18)), 0L, composer, 432, 8);
            gs1.o((float)6, companion, composer, 6);
            String s;
            if (c) {
                s = "Pause";
            }
            else {
                s = "Play Recording";
            }
            TextKt.Text--4IGK_g(s, (Modifier)null, 0L, TextUnitKt.getSp(13), (FontStyle)null, FontWeight.Companion.getSemiBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 199680, 0, 131030);
        }
        else {
            composer.skipToGroupEnd();
        }
        return t43.a;
    }
}
