import java.util.List;
import com.google.android.gms.internal.ads.zzagb;
import com.google.android.gms.internal.ads.zzcf;
import com.google.android.gms.internal.ads.zzca;
import com.google.android.gms.internal.ads.zzagj;
import com.google.android.gms.internal.ads.zzagf;
import java.math.RoundingMode;
import java.io.EOFException;
import com.google.android.gms.internal.ads.zzcb;

public final class wg3 implements qe3
{
    public final f85 a;
    public final q93 b;
    public final ye3 c;
    public final eq5 d;
    public g76 e;
    public jf3 f;
    public jf3 g;
    public int h;
    public zzcb i;
    public long j;
    public long k;
    public long l;
    public int m;
    public yg3 n;
    public boolean o;
    
    public wg3() {
        this.a = new f85(10);
        this.b = (q93)new Object();
        this.c = new ye3();
        this.j = -9223372036854775807L;
        this.d = new eq5(17);
        this.g = (jf3)new pe3();
    }
    
    public final ug3 a(final le3 le3) {
        final f85 a = this.a;
        le3.g(a.a, 0, 4, false);
        a.e(0);
        this.b.d(a.j());
        return new ug3(le3.v, le3.w, this.b);
    }
    
    public final boolean b(final le3 le3) {
        final yg3 n = this.n;
        if (n != null) {
            final long zzc = n.zzc();
            if (zzc != -1L) {
                if (le3.zze() > zzc - 4L) {
                    return true;
                }
            }
        }
        try {
            return !le3.g(this.a.a, 0, 4, true);
        }
        catch (final EOFException ex) {
            return true;
        }
    }
    
    public final int c(final re3 re3, final ue3 ue3) {
        final q93 b = this.b;
        aq3.h((Object)this.f);
        final int a = ec5.a;
        Label_0043: {
            if (this.h != 0) {
                break Label_0043;
            }
            try {
                this.g((le3)re3, false);
                break Label_0043;
            }
            catch (final EOFException ex) {}
            return -1;
        }
        final yg3 n2 = this.n;
        f85 a2 = this.a;
        q93 q3;
        f85 f88;
        if (n2 == null) {
            final f85 f85 = new f85(b.b);
            ((le3)re3).g(f85.g(), 0, b.b, false);
            final int a3 = b.a;
            int n3 = 21;
            if ((a3 & 0x1) != 0x0) {
                if (b.d != 1) {
                    n3 = 36;
                }
            }
            else if (b.d == 1) {
                n3 = 13;
            }
            int n4 = 0;
            Label_0228: {
                if (f85.i() >= n3 + 4) {
                    f85.e(n3);
                    final int j = f85.j();
                    if ((n4 = j) == 1483304551) {
                        break Label_0228;
                    }
                    if (j == 1231971951) {
                        n4 = 1231971951;
                        break Label_0228;
                    }
                }
                if (f85.i() >= 40) {
                    f85.e(36);
                    if (f85.j() == 1447187017) {
                        n4 = 1447187017;
                        break Label_0228;
                    }
                }
                n4 = 0;
            }
            ye3 c = this.c;
            Object n5 = null;
            if (n4 == 1483304551 || n4 == 1231971951) {
                final le3 le3 = (le3)re3;
                final long zzd = le3.zzd();
                final long zzf = ((re3)le3).zzf();
                final int f86 = b.f;
                final int c2 = b.c;
                final int i = f85.j();
                Label_0901: {
                    if ((i & 0x1) == 0x1) {
                        final int r = f85.r();
                        if (r != 0) {
                            final long w = ec5.w((long)r, f86 * 1000000L, (long)c2, RoundingMode.FLOOR);
                            if ((i & 0x6) != 0x6) {
                                n5 = new ah3(zzf, b.b, w, -1L, (long[])null);
                                break Label_0901;
                            }
                            final long w2 = f85.w();
                            final long[] array = new long[100];
                            for (int k = 0; k < 100; ++k) {
                                array[k] = f85.o();
                            }
                            if (zzd != -1L) {
                                final long n6 = zzf + w2;
                                if (zzd != n6) {
                                    final StringBuilder sb = new StringBuilder("XING data size mismatch: ");
                                    sb.append(zzd);
                                    sb.append(", ");
                                    sb.append(n6);
                                    mo5.g(sb.toString());
                                }
                            }
                            n5 = new ah3(zzf, b.b, w, w2, array);
                            break Label_0901;
                        }
                    }
                    n5 = null;
                }
                if (n5 != null && !c.a()) {
                    ((re3)le3).zzj();
                    le3.a(n3 + 141, false);
                    le3.g(a2.g(), 0, 3, false);
                    a2.e(0);
                    final int q = a2.q();
                    final int a4 = q >> 12;
                    final int b2 = q & 0xFFF;
                    if (a4 > 0 || b2 > 0) {
                        c.a = a4;
                        c.b = b2;
                    }
                }
                le3.j(b.b);
                if (n5 != null && !((ah3)n5).zzh() && n4 == 1231971951) {
                    n5 = this.a(le3);
                }
            }
            else if (n4 == 1447187017) {
                final le3 le4 = (le3)re3;
                final long zzd2 = le4.zzd();
                final long zzf2 = ((re3)le4).zzf();
                f85.f(10);
                final int l = f85.j();
                Object o = null;
                Label_0608: {
                    Label_0468: {
                        if (l > 0) {
                            final int c3 = b.c;
                            int n7;
                            if (c3 >= 32000) {
                                n7 = 1152;
                            }
                            else {
                                n7 = 576;
                            }
                            final long w3 = ec5.w((long)l, n7 * 1000000L, (long)c3, RoundingMode.FLOOR);
                            final int s = f85.s();
                            final int s2 = f85.s();
                            final int s3 = f85.s();
                            f85.f(2);
                            final long n8 = b.b;
                            final long[] array2 = new long[s];
                            final long[] array3 = new long[s];
                            int n9 = 0;
                            long n10 = zzf2;
                            while (n9 < s) {
                                array2[n9] = n9 * w3 / s;
                                array3[n9] = Math.max(n10, zzf2 + n8);
                                int n11;
                                if (s3 != 1) {
                                    if (s3 != 2) {
                                        if (s3 != 3) {
                                            if (s3 != 4) {
                                                break Label_0468;
                                            }
                                            n11 = f85.r();
                                        }
                                        else {
                                            n11 = f85.q();
                                        }
                                    }
                                    else {
                                        n11 = f85.s();
                                    }
                                }
                                else {
                                    n11 = f85.o();
                                }
                                n10 += n11 * (long)s2;
                                ++n9;
                            }
                            if (zzd2 != -1L && zzd2 != n10) {
                                final StringBuilder sb2 = new StringBuilder("VBRI data size mismatch: ");
                                sb2.append(zzd2);
                                sb2.append(", ");
                                sb2.append(n10);
                                mo5.g(sb2.toString());
                            }
                            o = new zg3(array2, array3, w3, n10);
                            break Label_0608;
                        }
                    }
                    o = null;
                }
                le4.j(b.b);
                n5 = o;
            }
            else {
                ((le3)re3).zzj();
                n5 = null;
            }
            final q93 q2 = b;
            final zzcb m = this.i;
            final le3 le5 = (le3)re3;
            long zzf3 = le5.zzf();
            f85 f87 = a2;
            Object o2 = null;
            Label_1365: {
                if (m != null) {
                    final int b3 = m.b();
                    int n12 = 0;
                    while (true) {
                        f87 = a2;
                        if (n12 >= b3) {
                            break;
                        }
                        final zzca c4 = m.c(n12);
                        if (c4 instanceof zzagf) {
                            final zzagf zzagf = (zzagf)c4;
                            while (true) {
                                for (int b4 = m.b(), n13 = 0; n13 < b4; ++n13) {
                                    final zzca c5 = m.c(n13);
                                    if (c5 instanceof zzagj) {
                                        final zzagj zzagj = (zzagj)c5;
                                        if (((zzagb)zzagj).c.equals((Object)"TLEN")) {
                                            final long u = ec5.u(Long.parseLong((String)((List)zzagj.v).get(0)));
                                            final int length = zzagf.x.length;
                                            final int n14 = length + 1;
                                            final long[] array4 = new long[n14];
                                            final long[] array5 = new long[n14];
                                            array4[0] = zzf3;
                                            array5[0] = 0L;
                                            int n15 = 1;
                                            long n16 = 0L;
                                            final ye3 ye3 = c;
                                            while (n15 <= length) {
                                                final int n17 = n15 - 1;
                                                zzf3 += zzagf.v + zzagf.x[n17];
                                                n16 += zzagf.w + zzagf.y[n17];
                                                array4[n15] = zzf3;
                                                array5[n15] = n16;
                                                ++n15;
                                            }
                                            c = ye3;
                                            o2 = new vg3(u, array4, array5);
                                            break Label_1365;
                                        }
                                    }
                                }
                                final long u = -9223372036854775807L;
                                continue;
                            }
                        }
                        ++n12;
                    }
                }
                a2 = f87;
                o2 = null;
            }
            if (this.o) {
                n5 = new ve3(-9223372036854775807L, 0L);
            }
            else {
                if (o2 != null) {
                    n5 = o2;
                }
                else if (n5 == null) {
                    n5 = null;
                }
                if (n5 != null) {
                    ((ef3)n5).zzh();
                }
                else {
                    n5 = this.a(le5);
                }
            }
            this.n = (yg3)n5;
            this.e.m((ef3)n5);
            final jf3 g = this.g;
            final qi3 qi3 = new qi3();
            q3 = q2;
            qi3.j = (String)q3.g;
            qi3.k = 4096;
            qi3.w = q3.d;
            qi3.x = q3.c;
            qi3.z = c.a;
            qi3.A = c.b;
            qi3.h = this.i;
            g.e(qi3.b());
            this.l = ((re3)le5).zzf();
            f88 = a2;
        }
        else {
            final long l2 = this.l;
            q3 = b;
            f88 = a2;
            if (l2 != 0L) {
                final le3 le6 = (le3)re3;
                final long zzf4 = le6.zzf();
                q3 = b;
                f88 = a2;
                if (zzf4 < l2) {
                    le6.j((int)(l2 - zzf4));
                    f88 = a2;
                    q3 = b;
                }
            }
        }
        int m2;
        if ((m2 = this.m) == 0) {
            final le3 le7 = (le3)re3;
            le7.zzj();
            if (this.b(le7)) {
                return -1;
            }
            f88.e(0);
            final int j2 = f88.j();
            if ((0xFFFE0C00 & j2) != ((long)this.h & 0xFFFFFFFFFFFE0C00L) || dw3.b(j2) == -1) {
                le7.j(1);
                this.h = 0;
                return 0;
            }
            q3.d(j2);
            if (this.j == -9223372036854775807L) {
                this.j = this.n.b(((re3)le7).zzf());
            }
            m2 = q3.b;
            this.m = m2;
        }
        final int c6 = this.g.c(re3, m2, true);
        if (c6 == -1) {
            return -1;
        }
        if ((this.m -= c6) <= 0) {
            this.g.b(this.k * 1000000L / q3.c + this.j, 1, q3.b, 0, (if3)null);
            this.k += q3.f;
            this.m = 0;
            return 0;
        }
        return 0;
    }
    
    public final void d(final g76 e) {
        this.e = e;
        final jf3 j = e.j(0, 1);
        this.f = j;
        this.g = j;
        this.e.a();
    }
    
    public final boolean e(final le3 le3) {
        return this.g(le3, true);
    }
    
    public final void f(final long n, final long n2) {
        this.h = 0;
        this.j = -9223372036854775807L;
        this.k = 0L;
        this.m = 0;
    }
    
    public final boolean g(final le3 le3, final boolean b) {
        le3.y = 0;
        int n;
        if (le3.w == 0L) {
            final zzcb j = this.d.j(le3, (qq)null);
            if ((this.i = j) != null) {
                this.c.b(j);
            }
            n = (int)le3.zze();
            if (!b) {
                le3.j(n);
            }
        }
        else {
            n = 0;
        }
        int h = 0;
        int n2 = 0;
        int n3 = 0;
        while (true) {
            while (!this.b(le3)) {
                final f85 a = this.a;
                a.e(0);
                final int i = a.j();
                if (h == 0 || (0xFFFE0C00 & i) == ((long)h & 0xFFFFFFFFFFFE0C00L)) {
                    final int b2 = dw3.b(i);
                    if (b2 != -1) {
                        final int n4 = n2 + 1;
                        int n5;
                        if (n4 == 1) {
                            this.b.d(i);
                            n5 = i;
                        }
                        else {
                            n5 = h;
                            if (n4 == 4) {
                                if (b) {
                                    le3.j(n + n3);
                                }
                                else {
                                    le3.y = 0;
                                }
                                this.h = h;
                                return true;
                            }
                        }
                        le3.a(b2 - 4, false);
                        h = n5;
                        n2 = n4;
                        continue;
                    }
                }
                int n6;
                if (!b) {
                    n6 = 131072;
                }
                else {
                    n6 = 32768;
                }
                final int n7 = n3 + 1;
                if (n3 == n6) {
                    if (b) {
                        return false;
                    }
                    throw zzcf.a("Searched too many bytes.", (ArrayIndexOutOfBoundsException)null);
                }
                else {
                    if (b) {
                        le3.y = 0;
                        le3.a(n + n7, false);
                    }
                    else {
                        le3.j(1);
                    }
                    h = 0;
                    n3 = n7;
                    n2 = 0;
                }
            }
            if (n2 > 0) {
                continue;
            }
            break;
        }
        throw new EOFException();
    }
}
