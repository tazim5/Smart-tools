public final class ie3
{
    public static final ie3 d;
    public final int a;
    public final long b;
    public final long c;
    
    static {
        d = new ie3(-9223372036854775807L, -1L, -3);
    }
    
    public ie3(final long b, final long c, final int a) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
}
