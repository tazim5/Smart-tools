import android.view.Display;
import android.view.WindowManager;
import android.hardware.display.DisplayManager;
import android.content.Context;
import android.view.Surface;

public final class yd3
{
    public final a96 a;
    public final vd3 b;
    public final xd3 c;
    public boolean d;
    public Surface e;
    public float f;
    public float g;
    public float h;
    public float i;
    public int j;
    public long k;
    public long l;
    public long m;
    public long n;
    public long o;
    public long p;
    public long q;
    
    public yd3(final Context context) {
        final Object a = new Object();
        ((a96)a).a = new z86();
        ((a96)a).b = new z86();
        ((a96)a).d = -9223372036854775807L;
        this.a = (a96)a;
        final xd3 xd3 = null;
        Object b = null;
        Label_0129: {
            if (context != null) {
                final Context applicationContext = context.getApplicationContext();
                final int a2 = ec5.a;
                final DisplayManager displayManager = (DisplayManager)applicationContext.getSystemService("display");
                Object o;
                if (displayManager != null) {
                    o = new wd3(displayManager);
                }
                else {
                    o = null;
                }
                b = o;
                if (o != null) {
                    break Label_0129;
                }
                final WindowManager windowManager = (WindowManager)applicationContext.getSystemService("window");
                if (windowManager != null) {
                    b = new c05((Object)windowManager, 19);
                    break Label_0129;
                }
            }
            b = null;
        }
        this.b = (vd3)b;
        xd3 x = xd3;
        if (b != null) {
            x = xd3.x;
        }
        this.c = x;
        this.k = -9223372036854775807L;
        this.l = -9223372036854775807L;
        this.f = -1.0f;
        this.i = 1.0f;
        this.j = 0;
    }
    
    public final void b() {
        if (ec5.a >= 30) {
            final Surface e = this.e;
            if (e != null && this.j != Integer.MIN_VALUE) {
                if (this.h != 0.0f) {
                    ud3.a(e, this.h = 0.0f);
                }
            }
        }
    }
    
    public final void c() {
        if (ec5.a >= 30) {
            if (this.e != null) {
                final a96 a = this.a;
                float f;
                if (a.a.c()) {
                    if (a.a.c()) {
                        final z86 a2 = a.a;
                        final long e = a2.e;
                        long n = 0L;
                        if (e != 0L) {
                            n = a2.f / e;
                        }
                        f = (float)(1.0E9 / n);
                    }
                    else {
                        f = -1.0f;
                    }
                }
                else {
                    f = this.f;
                }
                final float g = this.g;
                if (f != g) {
                    final float n2 = fcmpl(f, -1.0f);
                    if (n2 != 0 && g != -1.0f) {
                        final boolean c = a.a.c();
                        float n3 = 1.0f;
                        if (c) {
                            long f2;
                            if (a.a.c()) {
                                f2 = a.a.f;
                            }
                            else {
                                f2 = -9223372036854775807L;
                            }
                            n3 = n3;
                            if (f2 >= 5000000000L) {
                                n3 = 0.02f;
                            }
                        }
                        if (Math.abs(f - this.g) < n3) {
                            return;
                        }
                    }
                    else if (n2 == 0 && a.e < 30) {
                        return;
                    }
                    this.g = f;
                    this.d(false);
                }
            }
        }
    }
    
    public final void d(final boolean b) {
        if (ec5.a >= 30) {
            final Surface e = this.e;
            if (e != null) {
                if (this.j != Integer.MIN_VALUE) {
                    final boolean d = this.d;
                    float h;
                    final float n = h = 0.0f;
                    if (d) {
                        final float g = this.g;
                        h = n;
                        if (g != -1.0f) {
                            h = this.i * g;
                        }
                    }
                    if (b || this.h != h) {
                        ud3.a(e, this.h = h);
                    }
                }
            }
        }
    }
}
