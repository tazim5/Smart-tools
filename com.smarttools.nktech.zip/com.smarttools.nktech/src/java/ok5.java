import java.util.Arrays;
import com.google.android.gms.internal.ads.o4;

public final class ok5 extends mh5
{
    public final hl5 a;
    
    public ok5(final hl5 a) {
        this.a = a;
    }
    
    public final boolean equals(final Object o) {
        if (!(o instanceof ok5)) {
            return false;
        }
        final hl5 a = ((ok5)o).a;
        final hl5 a2 = this.a;
        if (a2.n.y().equals(a.n.y())) {
            final String a3 = a2.n.A();
            final o4 n = a.n;
            if (a3.equals((Object)n.A()) && a2.n.z().equals((Object)n.z())) {
                return true;
            }
        }
        return false;
    }
    
    public final int hashCode() {
        final hl5 a = this.a;
        return Arrays.hashCode(new Object[] { a.n, a.c });
    }
    
    public final String toString() {
        final hl5 a = this.a;
        final String a2 = a.n.A();
        final int ordinal = ((Enum)a.n.y()).ordinal();
        String s;
        if (ordinal != 1) {
            if (ordinal != 2) {
                if (ordinal != 3) {
                    if (ordinal != 4) {
                        s = "UNKNOWN";
                    }
                    else {
                        s = "CRUNCHY";
                    }
                }
                else {
                    s = "RAW";
                }
            }
            else {
                s = "LEGACY";
            }
        }
        else {
            s = "TINK";
        }
        final StringBuilder sb = new StringBuilder("(typeUrl=");
        sb.append(a2);
        sb.append(", outputPrefixType=");
        sb.append(s);
        sb.append(")");
        return sb.toString();
    }
}
