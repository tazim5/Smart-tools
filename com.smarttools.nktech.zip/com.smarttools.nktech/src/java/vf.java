import java.util.Iterator;
import java.util.Map$Entry;
import java.util.ArrayList;
import java.util.HashMap;

public final class vf
{
    public final HashMap a;
    
    public vf() {
        this.a = new HashMap();
    }
    
    public final int[] a() {
        final ArrayList list = new ArrayList();
        final Iterator iterator = this.a.entrySet().iterator();
        int intValue = -1;
        while (iterator.hasNext()) {
            final Map$Entry map$Entry = (Map$Entry)iterator.next();
            if ((int)map$Entry.getValue() > intValue) {
                intValue = (int)map$Entry.getValue();
                list.clear();
                list.add((Object)map$Entry.getKey());
            }
            else {
                if ((int)map$Entry.getValue() != intValue) {
                    continue;
                }
                list.add((Object)map$Entry.getKey());
            }
        }
        return fr3.a(list);
    }
    
    public final void b(final int n) {
        final HashMap a = this.a;
        Integer value;
        if ((value = (Integer)a.get((Object)n)) == null) {
            value = 0;
        }
        a.put((Object)n, (Object)(value + 1));
    }
}
