import android.net.Uri;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.common.internal.Preconditions;
import com.google.android.gms.ads.h5.OnH5AdsEventListener;
import android.content.Context;

public final class cy3
{
    public final Context a;
    public final OnH5AdsEventListener b;
    public yx3 c;
    
    public cy3(final Context a, final OnH5AdsEventListener b) {
        Preconditions.checkState(true, (Object)"Android version must be Lollipop or higher");
        Preconditions.checkNotNull((Object)a);
        Preconditions.checkNotNull((Object)b);
        this.a = a;
        this.b = b;
        cs3.a(a);
    }
    
    public static final boolean a(final String s) {
        if (!(boolean)zzba.zzc().a(cs3.D8)) {
            return false;
        }
        Preconditions.checkNotNull((Object)s);
        if (s.length() > (int)zzba.zzc().a(cs3.F8)) {
            d94.zze("H5 GMSG exceeds max length");
            return false;
        }
        final Uri parse = Uri.parse(s);
        return "gmsg".equals((Object)parse.getScheme()) && "mobileads.google.com".equals((Object)parse.getHost()) && "/h5ads".equals((Object)parse.getPath());
    }
}
