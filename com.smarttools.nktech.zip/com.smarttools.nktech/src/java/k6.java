import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.foundation.layout.Arrangement$Vertical;
import androidx.compose.ui.Modifier$Companion;
import java.util.Map;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ButtonKt;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.runtime.MutableState;
import android.content.Context;
import androidx.compose.ui.platform.ClipboardManager;

public final class k6 implements od1
{
    public final ClipboardManager c;
    public final Context n;
    public final MutableState v;
    
    public k6(final ClipboardManager c, final Context n, final MutableState v) {
        this.c = c;
        this.n = n;
        this.v = v;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final ColumnScope columnScope = (ColumnScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding-3ABfNKs = PaddingKt.padding-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)16));
            final Arrangement instance = Arrangement.INSTANCE;
            final Arrangement$Vertical top = instance.getTop();
            final Alignment$Companion companion2 = Alignment.Companion;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(top, companion2.getStart(), composer, 0);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, padding-3ABfNKs);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.getSpaceBetween(), companion2.getCenterVertically(), composer, 54);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance3 = RowScopeInstance.INSTANCE;
            TextKt.Text--4IGK_g("Generated Output", (Modifier)null, 0L, TextUnitKt.getSp(14), (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 199686, 0, 131030);
            final ClipboardManager c = this.c;
            final Context n = this.n;
            final MutableState v = this.v;
            ButtonKt.TextButton((id1)new j6(c, n, v, 0), (Modifier)null, false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)wv.b, composer, 805306368, 510);
            composer.endNode();
            TextKt.Text-IbK3jfQ(mt1.a((String)az0.c((float)8, companion, composer, 6, v)), (Modifier)null, MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurface-0d7_KjU(), TextUnitKt.getSp(14), (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, TextUnitKt.getSp(22), 0, false, 0, 0, (Map)null, (jd1)null, (TextStyle)null, composer, 3072, 6, 261106);
            composer.endNode();
        }
        return t43.a;
    }
}
