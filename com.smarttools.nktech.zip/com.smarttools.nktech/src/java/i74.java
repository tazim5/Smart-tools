import android.content.SharedPreferences;
import android.content.SharedPreferences$OnSharedPreferenceChangeListener;
import android.preference.PreferenceManager;
import android.content.Context;
import java.util.ArrayList;
import java.util.HashMap;

public final class i74
{
    public final HashMap a;
    public final ArrayList b;
    public final Context c;
    public final il3 d;
    
    public i74(final Context c, final il3 d) {
        this.a = new HashMap();
        this.b = new ArrayList();
        this.c = c;
        this.d = d;
    }
    
    public final void a(final String s) {
        monitorenter(this);
        Label_0055: {
            try {
                if (this.a.containsKey((Object)s)) {
                    break Label_0055;
                }
                if (s != "__default__" && (s == null || !s.equals("__default__"))) {
                    break Label_0055;
                }
                break Label_0055;
            }
            finally {
                monitorexit(this);
                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.c);
                while (true) {
                    final h74 h74 = new h74(s, 0, this);
                    this.a.put((Object)s, (Object)h74);
                    sharedPreferences.registerOnSharedPreferenceChangeListener((SharedPreferences$OnSharedPreferenceChangeListener)h74);
                    monitorexit(this);
                    return;
                    sharedPreferences = this.c.getSharedPreferences(s, 0);
                    continue;
                }
                monitorexit(this);
            }
        }
    }
}
