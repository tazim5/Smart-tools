public interface s23
{
}
