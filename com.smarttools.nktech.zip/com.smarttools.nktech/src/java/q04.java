import org.json.JSONArray;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public final class q04
{
    public static final List a(final JSONObject jsonObject, final String s) {
        final JSONArray optJSONArray = jsonObject.optJSONArray(s);
        if (optJSONArray != null) {
            final ArrayList list = new ArrayList(optJSONArray.length());
            for (int i = 0; i < optJSONArray.length(); ++i) {
                list.add((Object)optJSONArray.getString(i));
            }
            return Collections.unmodifiableList((List)list);
        }
        return null;
    }
}
