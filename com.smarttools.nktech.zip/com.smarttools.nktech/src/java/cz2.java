import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.CardElevation;
import androidx.compose.material3.CardColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.CardKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableState;
import java.util.List;

public final class cz2 implements nd1
{
    public final List c;
    public final MutableState n;
    public final jd1 v;
    
    public cz2(final jd1 v, final MutableState n, final List c) {
        this.c = c;
        this.n = n;
        this.v = v;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            CardKt.Card(SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth$default((Modifier)Modifier.Companion, 0.0f, 1, (Object)null), Dp.constructor-impl((float)500)), (Shape)null, (CardColors)null, (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(-680461254, true, (Object)new bz2(this.v, this.n, this.c), composer, 54), composer, 196614, 30);
        }
        return t43.a;
    }
}
