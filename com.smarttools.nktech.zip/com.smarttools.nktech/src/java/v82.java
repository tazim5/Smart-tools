import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public final class v82 extends t0
{
    public final int d(final int n, final int n2) {
        return ThreadLocalRandom.current().nextInt(n, n2);
    }
    
    public final long f() {
        return ThreadLocalRandom.current().nextLong(1500L, 4000L);
    }
    
    public final Random g() {
        return (Random)ThreadLocalRandom.current();
    }
}
