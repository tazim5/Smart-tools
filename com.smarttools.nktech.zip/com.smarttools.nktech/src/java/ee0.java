import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.internal.ComposableLambda;

public abstract class ee0
{
    public static final ComposableLambda a;
    public static final ComposableLambda b;
    public static final ComposableLambda c;
    public static final ComposableLambda d;
    public static final ComposableLambda e;
    public static final ComposableLambda f;
    public static final ComposableLambda g;
    public static final ComposableLambda h;
    public static final ComposableLambda i;
    public static final ComposableLambda j;
    
    static {
        a = ComposableLambdaKt.composableLambdaInstance(-6907273, false, (Object)yb0.e0);
        b = ComposableLambdaKt.composableLambdaInstance(342037206, false, (Object)xd0.c);
        c = ComposableLambdaKt.composableLambdaInstance(1107122190, false, (Object)yd0.c);
        d = ComposableLambdaKt.composableLambdaInstance(-2008252746, false, (Object)zd0.c);
        e = ComposableLambdaKt.composableLambdaInstance(-1037494099, false, (Object)ae0.c);
        f = ComposableLambdaKt.composableLambdaInstance(-522095155, false, (Object)be0.c);
        g = ComposableLambdaKt.composableLambdaInstance(185368950, false, (Object)ce0.c);
        h = ComposableLambdaKt.composableLambdaInstance(1230861995, false, (Object)yb0.f0);
        i = ComposableLambdaKt.composableLambdaInstance(-454134076, false, (Object)de0.n);
        j = ComposableLambdaKt.composableLambdaInstance(929645037, false, (Object)m70.m0);
    }
}
