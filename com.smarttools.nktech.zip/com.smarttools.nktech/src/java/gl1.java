public final class gl1
{
    public final double a;
    public final double b;
    public final double c;
    public final double d;
    public final double e;
    
    public gl1(final double a, final double b, final double c, final double d, final double e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof gl1)) {
            return false;
        }
        final gl1 gl1 = (gl1)o;
        return Double.compare(this.a, gl1.a) == 0 && Double.compare(this.b, gl1.b) == 0 && Double.compare(this.c, gl1.c) == 0 && Double.compare(this.d, gl1.d) == 0 && Double.compare(this.e, gl1.e) == 0;
    }
    
    @Override
    public final int hashCode() {
        return Double.hashCode(this.e) + vo2.b(this.d, vo2.b(this.c, vo2.b(this.b, Double.hashCode(this.a) * 31, 31), 31), 31);
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("InterestResult(principal=");
        sb.append(this.a);
        sb.append(", rate=");
        sb.append(this.b);
        sb.append(", time=");
        sb.append(this.c);
        sb.append(", interest=");
        sb.append(this.d);
        sb.append(", total=");
        sb.append(this.e);
        sb.append(")");
        return sb.toString();
    }
}
