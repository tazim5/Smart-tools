import androidx.compose.runtime.State;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.ui.graphics.Color;
import androidx.compose.material.icons.filled.FlashOffKt;
import androidx.compose.material.icons.filled.FlashOnKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.MutableState;

public final class wc2 implements nd1
{
    public final MutableState c;
    
    public wc2(final MutableState c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final MutableState c = this.c;
            ImageVector imageVector;
            if (((State)c).getValue()) {
                imageVector = FlashOnKt.getFlashOn(Icons.INSTANCE.getDefault());
            }
            else {
                imageVector = FlashOffKt.getFlashOff(Icons.INSTANCE.getDefault());
            }
            composer.startReplaceGroup(1544148944);
            long n;
            if (((State)c).getValue()) {
                n = Color.Companion.getBlack-0d7_KjU();
            }
            else {
                n = MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getOnSurface-0d7_KjU();
            }
            composer.endReplaceGroup();
            IconKt.Icon-ww6aTOc(imageVector, "Toggle Flash", (Modifier)null, n, composer, 48, 4);
        }
        return t43.a;
    }
}
