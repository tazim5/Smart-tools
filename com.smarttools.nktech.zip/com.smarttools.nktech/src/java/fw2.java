import java.util.concurrent.Executor;

public abstract class fw2
{
    public abstract o76 a(final Executor p0, final i42 p1);
    
    public abstract o76 b(final Executor p0, final k42 p1);
    
    public abstract o76 c(final Executor p0, final m42 p1);
    
    public abstract o76 d(final Executor p0, final pp0 p1);
    
    public abstract Exception e();
    
    public abstract Object f();
    
    public abstract boolean g();
    
    public abstract boolean h();
    
    public abstract o76 i(final et2 p0);
}
