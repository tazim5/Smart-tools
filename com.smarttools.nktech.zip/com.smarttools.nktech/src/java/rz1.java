import androidx.compose.runtime.State;
import androidx.compose.foundation.layout.ColumnScope;
import androidx.compose.ui.text.input.KeyboardType$Companion;
import androidx.compose.runtime.Composer$Companion;
import androidx.compose.foundation.layout.Arrangement$HorizontalOrVertical;
import androidx.compose.ui.graphics.vector.ImageVector;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Horizontal;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.material3.CardElevation;
import androidx.compose.material3.CardKt;
import androidx.compose.material3.CardDefaults;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ButtonColors;
import androidx.compose.material3.ButtonKt;
import androidx.compose.foundation.layout.SpacerKt;
import androidx.compose.material3.TextFieldColors;
import androidx.compose.foundation.text.KeyboardActions;
import androidx.compose.ui.text.input.VisualTransformation;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.material3.OutlinedTextFieldKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.input.PlatformImeOptions;
import androidx.compose.foundation.text.KeyboardOptions;
import androidx.compose.ui.text.input.KeyboardType;
import androidx.compose.foundation.interaction.MutableInteractionSource;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.SelectableChipElevation;
import androidx.compose.material3.SelectableChipColors;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.ChipKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material.icons.filled.TrendingUpKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.runtime.MutableState;

public final class rz1 implements od1
{
    public final MutableState c;
    public final MutableState n;
    public final MutableState v;
    public final MutableState w;
    public final MutableState x;
    
    public rz1(final MutableState c, final MutableState n, final MutableState v, final MutableState w, final MutableState x) {
        this.c = c;
        this.n = n;
        this.v = v;
        this.w = w;
        this.x = x;
    }
    
    public final Object invoke(Object rememberedValue, Object o, final Object o2) {
        final PaddingValues paddingValues = (PaddingValues)rememberedValue;
        final Composer composer = (Composer)o;
        int intValue;
        final int n = intValue = ((Number)o2).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), paddingValues);
            final float n3 = 16;
            final Modifier verticalScroll$default = ScrollKt.verticalScroll$default(PaddingKt.padding-3ABfNKs(padding, Dp.constructor-impl(n3)), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
            final Alignment$Companion companion2 = Alignment.Companion;
            final Alignment$Horizontal centerHorizontally = companion2.getCenterHorizontally();
            final Arrangement instance = Arrangement.INSTANCE;
            final MeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(instance.getTop(), centerHorizontally, composer, 48);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, verticalScroll$default);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, columnMeasurePolicy, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final ImageVector trendingUp = TrendingUpKt.getTrendingUp(Icons.INSTANCE.getDefault());
            final MaterialTheme instance3 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            IconKt.Icon-ww6aTOc(trendingUp, (String)null, SizeKt.height-3ABfNKs((Modifier)companion, Dp.constructor-impl((float)48)), instance3.getColorScheme(composer, $stable).getPrimary-0d7_KjU(), composer, 432, 0);
            final float n4 = 8;
            ap.l(n4, companion, composer, 6);
            TextKt.Text--4IGK_g("Plan Your Investment", (Modifier)null, 0L, 0L, (FontStyle)null, FontWeight.Companion.getBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getTitleLarge(), composer, 196614, 0, 65502);
            final float n5 = 24;
            ap.l(n5, companion, composer, 6);
            TextKt.Text--4IGK_g("Investment Type", ((ColumnScope)instance2).align((Modifier)companion, companion2.getStart()), 0L, 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance3.getTypography(composer, $stable).getTitleMedium(), composer, 6, 0, 65532);
            ap.l(n4, companion, composer, 6);
            final float n6 = 12;
            final Arrangement$HorizontalOrVertical spacedBy-0680j_4 = instance.spacedBy-0680j_4(Dp.constructor-impl(n6));
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)spacedBy-0680j_4, companion2.getTop(), composer, 6);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance4 = RowScopeInstance.INSTANCE;
            final MutableState c = this.c;
            final boolean booleanValue = (boolean)((State)c).getValue();
            composer.startReplaceGroup(-848644933);
            o = composer.rememberedValue();
            final Composer$Companion companion4 = Composer.Companion;
            final Object empty = companion4.getEmpty();
            final MutableState n7 = this.n;
            if ((rememberedValue = o) == empty) {
                rememberedValue = new n4(18, c, n7);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id1 = (id1)rememberedValue;
            composer.endReplaceGroup();
            ChipKt.FilterChip(booleanValue, id1, (nd1)da0.c, RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null), false, (nd1)null, (nd1)null, (Shape)null, (SelectableChipColors)null, (SelectableChipElevation)null, (BorderStroke)null, (MutableInteractionSource)null, composer, 432, 0, 4080);
            final boolean booleanValue2 = (boolean)((State)c).getValue();
            composer.startReplaceGroup(-848636868);
            rememberedValue = composer.rememberedValue();
            if (rememberedValue == companion4.getEmpty()) {
                rememberedValue = new n4(19, c, n7);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id2 = (id1)rememberedValue;
            composer.endReplaceGroup();
            ChipKt.FilterChip(booleanValue2 ^ true, id2, (nd1)da0.d, RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null), false, (nd1)null, (nd1)null, (Shape)null, (SelectableChipColors)null, (SelectableChipElevation)null, (BorderStroke)null, (MutableInteractionSource)null, composer, 432, 0, 4080);
            fe2.g(composer, n5, companion, composer, 6);
            final MutableState v = this.v;
            final String s = (String)((State)v).getValue();
            final KeyboardType$Companion companion5 = KeyboardType.Companion;
            final KeyboardOptions keyboardOptions = new KeyboardOptions(0, (Boolean)null, companion5.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null);
            final Modifier fillMaxWidth$default2 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            composer.startReplaceGroup(-1660276641);
            o = composer.rememberedValue();
            if ((rememberedValue = o) == companion4.getEmpty()) {
                rememberedValue = new hm1(v, 25);
                composer.updateRememberedValue(rememberedValue);
            }
            final jd1 jd1 = (jd1)rememberedValue;
            composer.endReplaceGroup();
            OutlinedTextFieldKt.OutlinedTextField(s, jd1, fillMaxWidth$default2, false, false, (TextStyle)null, (nd1)ComposableLambdaKt.rememberComposableLambda(1227674580, true, (Object)new nz1(c, 0), composer, 54), (nd1)null, (nd1)null, (nd1)null, (nd1)da0.e, (nd1)null, (nd1)null, false, (VisualTransformation)null, keyboardOptions, (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, composer, 1573296, 12779526, 0, 8223672);
            ap.l(n6, companion, composer, 6);
            final MutableState w = this.w;
            final String s2 = (String)((State)w).getValue();
            final KeyboardOptions keyboardOptions2 = new KeyboardOptions(0, (Boolean)null, companion5.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null);
            final Modifier fillMaxWidth$default3 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            composer.startReplaceGroup(-1660257059);
            o = composer.rememberedValue();
            if ((rememberedValue = o) == companion4.getEmpty()) {
                rememberedValue = new hm1(w, 26);
                composer.updateRememberedValue(rememberedValue);
            }
            final jd1 jd2 = (jd1)rememberedValue;
            composer.endReplaceGroup();
            OutlinedTextFieldKt.OutlinedTextField(s2, jd2, fillMaxWidth$default3, false, false, (TextStyle)null, (nd1)da0.f, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)da0.g, (nd1)null, false, (VisualTransformation)null, keyboardOptions2, (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, composer, 1573296, 12779568, 0, 8222648);
            ap.l(n6, companion, composer, 6);
            final MutableState x = this.x;
            final String s3 = (String)((State)x).getValue();
            final KeyboardOptions keyboardOptions3 = new KeyboardOptions(0, (Boolean)null, companion5.getDecimal-PjHm6EE(), 0, (PlatformImeOptions)null, (Boolean)null, (LocaleList)null, 123, (lu0)null);
            final Modifier fillMaxWidth$default4 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            composer.startReplaceGroup(-1660239015);
            o = composer.rememberedValue();
            if ((rememberedValue = o) == companion4.getEmpty()) {
                rememberedValue = new hm1(x, 27);
                composer.updateRememberedValue(rememberedValue);
            }
            final jd1 jd3 = (jd1)rememberedValue;
            composer.endReplaceGroup();
            OutlinedTextFieldKt.OutlinedTextField(s3, jd3, fillMaxWidth$default4, false, false, (TextStyle)null, (nd1)da0.h, (nd1)null, (nd1)null, (nd1)null, (nd1)null, (nd1)da0.i, (nd1)null, false, (VisualTransformation)null, keyboardOptions3, (KeyboardActions)null, true, 0, 0, (MutableInteractionSource)null, (Shape)null, (TextFieldColors)null, composer, 1573296, 12779568, 0, 8222648);
            SpacerKt.Spacer(SizeKt.height-3ABfNKs((Modifier)companion, Dp.constructor-impl(n5)), composer, 6);
            final Arrangement$HorizontalOrVertical spacedBy-0680j_5 = instance.spacedBy-0680j_4(Dp.constructor-impl(n6));
            final Modifier fillMaxWidth$default5 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy((Arrangement$Horizontal)spacedBy-0680j_5, companion2.getTop(), composer, 6);
            final int currentCompositeKeyHash3 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap3 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier3 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default5);
            final id1 constructor3 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor3);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl3 = Updater.constructor-impl(composer);
            final nd1 b3 = ap.b(companion3, constructor-impl3, rowMeasurePolicy2, constructor-impl3, currentCompositionLocalMap3);
            if (constructor-impl3.getInserting() || !kl1.b(constructor-impl3.rememberedValue(), (Object)currentCompositeKeyHash3)) {
                l3.i(currentCompositeKeyHash3, constructor-impl3, currentCompositeKeyHash3, b3);
            }
            Updater.set-impl(constructor-impl3, (Object)materializeModifier3, companion3.getSetModifier());
            composer.startReplaceGroup(-848564969);
            o = composer.rememberedValue();
            if ((rememberedValue = o) == companion4.getEmpty()) {
                rememberedValue = new e21(v, w, x, n7, 4);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id3 = (id1)rememberedValue;
            composer.endReplaceGroup();
            ButtonKt.OutlinedButton(id3, RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null), false, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)da0.j, composer, 805306374, 508);
            final boolean b4 = ((String)((State)v).getValue()).length() > 0 && ((String)((State)w).getValue()).length() > 0 && ((String)((State)x).getValue()).length() > 0;
            final Modifier weight$default = RowScope.weight$default((RowScope)instance4, (Modifier)companion, 1.0f, false, 2, (Object)null);
            composer.startReplaceGroup(-848552268);
            o = composer.rememberedValue();
            if ((rememberedValue = o) == companion4.getEmpty()) {
                rememberedValue = new io(v, w, x, c, n7, 3);
                composer.updateRememberedValue(rememberedValue);
            }
            final id1 id4 = (id1)rememberedValue;
            composer.endReplaceGroup();
            ButtonKt.Button(id4, weight$default, b4, (Shape)null, (ButtonColors)null, (ButtonElevation)null, (BorderStroke)null, (PaddingValues)null, (MutableInteractionSource)null, (od1)da0.k, composer, 805306374, 504);
            composer.endNode();
            final tz1 tz1 = (tz1)((State)n7).getValue();
            composer.startReplaceGroup(-1660174111);
            if (tz1 != null) {
                ap.l((float)32, companion, composer, 6);
                final Modifier fillMaxWidth$default6 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
                final CardDefaults instance5 = CardDefaults.INSTANCE;
                final long primaryContainer-0d7_KjU = instance3.getColorScheme(composer, $stable).getPrimaryContainer-0d7_KjU();
                final int n8 = CardDefaults.$stable << 12;
                CardKt.Card(fillMaxWidth$default6, (Shape)null, instance5.cardColors-ro_MJ88(primaryContainer-0d7_KjU, 0L, 0L, 0L, composer, n8, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(1098537881, true, (Object)new oz1(tz1), composer, 54), composer, 196614, 26);
                ap.l(n3, companion, composer, 6);
                CardKt.Card(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), (Shape)null, instance5.cardColors-ro_MJ88(instance3.getColorScheme(composer, $stable).getSecondaryContainer-0d7_KjU(), 0L, 0L, 0L, composer, n8, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(1826108816, true, (Object)new pz1(tz1, c), composer, 54), composer, 196614, 26);
                ap.l(n3, companion, composer, 6);
                CardKt.Card(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), (Shape)null, instance5.cardColors-ro_MJ88(Color.copy-wmQWz5c$default(ColorKt.Color(4283215696L), 0.15f, 0.0f, 0.0f, 0.0f, 14, (Object)null), 0L, 0L, 0L, composer, n8 | 0x6, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(1741299345, true, (Object)new qz1(tz1), composer, 54), composer, 196614, 26);
            }
            composer.endReplaceGroup();
            b02.a(PaddingKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), 0.0f, Dp.constructor-impl(n3), 0.0f, 0.0f, 13, (Object)null), composer, 6);
            composer.endNode();
        }
        return t43.a;
    }
}
