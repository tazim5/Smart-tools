public interface et2
{
    fw2 then(final Object p0);
}
