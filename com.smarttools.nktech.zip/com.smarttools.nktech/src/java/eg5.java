public final class eg5
{
    public final Object a;
    
    public eg5(final Object a) {
        this.a = a;
    }
}
