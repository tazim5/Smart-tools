import android.content.Context;
import android.media.AudioManager;
import android.media.AudioManager$OnAudioFocusChangeListener;

public final class oa4 implements AudioManager$OnAudioFocusChangeListener
{
    public final AudioManager a;
    public final y94 b;
    public boolean c;
    public boolean d;
    public boolean e;
    public float f;
    
    public oa4(final Context context, final y94 b) {
        this.f = 1.0f;
        this.a = (AudioManager)context.getSystemService("audio");
        this.b = b;
    }
    
    public final void a() {
        final boolean d = this.d;
        final y94 b = this.b;
        final boolean b2 = false;
        boolean c = false;
        final AudioManager a = this.a;
        if (d && !this.e && this.f > 0.0f) {
            if (!this.c) {
                if (a != null) {
                    if (a.requestAudioFocus((AudioManager$OnAudioFocusChangeListener)this, 3, 2) == 1) {
                        c = true;
                    }
                    this.c = c;
                }
                ((ka4)b).zzn();
            }
        }
        else if (this.c) {
            if (a != null) {
                boolean c2 = b2;
                if (a.abandonAudioFocus((AudioManager$OnAudioFocusChangeListener)this) == 0) {
                    c2 = true;
                }
                this.c = c2;
            }
            ((ka4)b).zzn();
        }
    }
    
    public final void onAudioFocusChange(final int n) {
        this.c = (n > 0);
        ((ka4)this.b).zzn();
    }
}
