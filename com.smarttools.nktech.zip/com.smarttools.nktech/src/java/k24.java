import com.google.android.gms.ads.mediation.MediationBannerAd;
import com.google.android.gms.ads.mediation.MediationInterscrollerAd;
import android.os.RemoteException;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.mediation.MediationAdLoadCallback;

public final class k24 implements MediationAdLoadCallback
{
    public final int c;
    public final y14 n;
    public final y04 v;
    
    public final void onFailure(final AdError adError) {
        switch (this.c) {
            default: {
                try {
                    this.n.zzf(adError.zza());
                }
                catch (final RemoteException ex) {
                    d94.zzh("", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    this.n.zzf(adError.zza());
                }
                catch (final RemoteException ex2) {
                    d94.zzh("", (Throwable)ex2);
                }
            }
        }
    }
    
    public final void onFailure(final String s) {
        switch (this.c) {
            default: {
                this.onFailure(new AdError(0, s, "undefined"));
                return;
            }
            case 0: {
                this.onFailure(new AdError(0, s, "undefined"));
            }
        }
    }
    
    public final Object onSuccess(Object o) {
        switch (this.c) {
            default: {
                final MediationInterscrollerAd mediationInterscrollerAd = (MediationInterscrollerAd)o;
                final y14 n = this.n;
                if (mediationInterscrollerAd == null) {
                    d94.zzj("Adapter incorrectly returned a null ad. The onFailure() callback should be called if an adapter fails to load an ad.");
                    o = null;
                    try {
                        n.a("Adapter returned null.");
                    }
                    catch (final RemoteException ex) {
                        d94.zzh("", (Throwable)ex);
                    }
                }
                else {
                    try {
                        n.V((c14)new p14(mediationInterscrollerAd));
                    }
                    catch (final RemoteException ex2) {
                        d94.zzh("", (Throwable)ex2);
                    }
                    o = new uu5((Object)this.v, 21);
                }
                return o;
            }
            case 0: {
                final MediationBannerAd mediationBannerAd = (MediationBannerAd)o;
                final y14 n2 = this.n;
                if (mediationBannerAd == null) {
                    d94.zzj("Adapter incorrectly returned a null ad. The onFailure() callback should be called if an adapter fails to load an ad.");
                    o = null;
                    try {
                        n2.a("Adapter returned null.");
                    }
                    catch (final RemoteException ex3) {
                        d94.zzh("", (Throwable)ex3);
                    }
                }
                else {
                    try {
                        n2.q((th1)new n32((Object)mediationBannerAd.getView()));
                    }
                    catch (final RemoteException ex4) {
                        d94.zzh("", (Throwable)ex4);
                    }
                    o = new uu5((Object)this.v, 21);
                }
                return o;
            }
        }
    }
}
