public interface c83
{
    b83 getViewModelStore();
}
