import android.os.Parcel;
import android.os.IInterface;

public final class b46 extends nd3
{
    public final th1 D(final n32 n32, final String s, final int n33) {
        final Parcel zza = this.zza();
        r74.d(zza, (IInterface)n32);
        zza.writeString(s);
        zza.writeInt(n33);
        return f83.b(this.zzB(2, zza));
    }
    
    public final th1 F(final n32 n32, final String s, final int n33, final n32 n34) {
        final Parcel zza = this.zza();
        r74.d(zza, (IInterface)n32);
        zza.writeString(s);
        zza.writeInt(n33);
        r74.d(zza, (IInterface)n34);
        return f83.b(this.zzB(8, zza));
    }
    
    public final th1 f1(final n32 n32, final String s, final int n33) {
        final Parcel zza = this.zza();
        r74.d(zza, (IInterface)n32);
        zza.writeString(s);
        zza.writeInt(n33);
        return f83.b(this.zzB(4, zza));
    }
}
