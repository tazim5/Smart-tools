import com.smarttools.nktech.navigation.NavRoutes;

public final class t02 extends NavRoutes
{
    public static final t02 a;
    
    static {
        a = (t02)new NavRoutes("category/{categoryId}", (lu0)null);
    }
    
    public final boolean equals(final Object o) {
        return this == o || o instanceof t02;
    }
    
    public final int hashCode() {
        return -1605481986;
    }
    
    public final String toString() {
        return "CategoryDetail";
    }
}
