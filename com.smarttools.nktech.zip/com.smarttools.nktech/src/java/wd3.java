import android.os.Handler;
import android.hardware.display.DisplayManager;
import android.hardware.display.DisplayManager$DisplayListener;

public final class wd3 implements DisplayManager$DisplayListener, vd3
{
    public final DisplayManager c;
    public tm3 n;
    
    public wd3(final DisplayManager c) {
        this.c = c;
    }
    
    public final void a(final tm3 n) {
        this.n = n;
        final Handler z = ec5.z();
        final DisplayManager c = this.c;
        c.registerDisplayListener((DisplayManager$DisplayListener)this, z);
        yd3.a((yd3)n.n, c.getDisplay(0));
    }
    
    public final void onDisplayAdded(final int n) {
    }
    
    public final void onDisplayChanged(final int n) {
        final tm3 n2 = this.n;
        if (n2 != null && n == 0) {
            yd3.a((yd3)n2.n, this.c.getDisplay(0));
        }
    }
    
    public final void onDisplayRemoved(final int n) {
    }
    
    public final void zza() {
        this.c.unregisterDisplayListener((DisplayManager$DisplayListener)this);
        this.n = null;
    }
}
