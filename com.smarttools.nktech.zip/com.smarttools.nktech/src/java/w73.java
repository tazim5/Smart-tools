import java.util.Set;
import java.util.Map;
import java.util.Collection;
import java.util.Iterator;
import java.io.Closeable;

public abstract class w73
{
    private final x73 impl;
    
    public w73() {
        this.impl = new x73();
    }
    
    @qw0
    public void addCloseable(final Closeable closeable) {
        final x73 impl = this.impl;
        if (impl != null) {
            if (impl.d) {
                x73.a((AutoCloseable)closeable);
            }
            else {
                final ic2 a = impl.a;
                synchronized (a) {
                    ((Collection)impl.c).add((Object)closeable);
                }
            }
        }
    }
    
    public void addCloseable(final AutoCloseable autoCloseable) {
        final x73 impl = this.impl;
        if (impl != null) {
            if (impl.d) {
                x73.a(autoCloseable);
            }
            else {
                final ic2 a = impl.a;
                synchronized (a) {
                    ((Collection)impl.c).add((Object)autoCloseable);
                }
            }
        }
    }
    
    public final void addCloseable(final String s, final AutoCloseable autoCloseable) {
        final x73 impl = this.impl;
        if (impl != null) {
            if (impl.d) {
                x73.a(autoCloseable);
            }
            else {
                final ic2 a = impl.a;
                synchronized (a) {
                    final AutoCloseable autoCloseable2 = (AutoCloseable)((Map)impl.b).put((Object)s, (Object)autoCloseable);
                    monitorexit(a);
                    x73.a(autoCloseable2);
                }
            }
        }
    }
    
    public final void clear$lifecycle_viewmodel_release() {
        final x73 impl = this.impl;
        Label_0129: {
            if (impl != null) {
                if (!impl.d) {
                    impl.d = true;
                    final ic2 a;
                    monitorenter(a = impl.a);
                    Label_0124: {
                        try {
                            final Iterator iterator = impl.b.values().iterator();
                            while (iterator.hasNext()) {
                                x73.a((AutoCloseable)iterator.next());
                            }
                        }
                        finally {
                            break Label_0124;
                        }
                        final x73 x73;
                        final Iterator iterator2 = ((Set)x73.c).iterator();
                        while (iterator2.hasNext()) {
                            x73.a((AutoCloseable)iterator2.next());
                        }
                        ((Set)x73.c).clear();
                        monitorexit(a);
                        break Label_0129;
                    }
                    monitorexit(a);
                }
            }
        }
        this.onCleared();
    }
    
    public final <T extends AutoCloseable> T getCloseable(final String s) {
        final x73 impl = this.impl;
        if (impl != null) {
            final ic2 a = impl.a;
            synchronized (a) {
                final AutoCloseable autoCloseable = (AutoCloseable)impl.b.get((Object)s);
                final AutoCloseable autoCloseable2;
                return (T)autoCloseable2;
            }
        }
        final AutoCloseable autoCloseable2 = null;
        return (T)autoCloseable2;
    }
    
    public void onCleared() {
    }
}
