import android.content.Context;
import com.google.android.gms.ads.internal.zzt;
import android.provider.CalendarContract$Events;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.DialogInterface$OnClickListener;

public final class p24 implements DialogInterface$OnClickListener
{
    public final int a;
    public final q24 b;
    
    public final void onClick(final DialogInterface dialogInterface, final int n) {
        switch (this.a) {
            default: {
                ((il3)this.b).k("Operation denied by user.");
                return;
            }
            case 0: {
                final q24 b = this.b;
                final Intent setData = new Intent("android.intent.action.EDIT").setData(CalendarContract$Events.CONTENT_URI);
                setData.putExtra("title", b.y);
                setData.putExtra("eventLocation", b.R);
                setData.putExtra("description", b.Q);
                final long z = b.z;
                if (z > -1L) {
                    setData.putExtra("beginTime", z);
                }
                final long p2 = b.P;
                if (p2 > -1L) {
                    setData.putExtra("endTime", p2);
                }
                setData.setFlags(268435456);
                zzt.zzp();
                com.google.android.gms.ads.internal.util.zzt.zzS((Context)b.x, setData);
            }
        }
    }
}
