import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.material3.TextKt;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.lazy.LazyItemScope;

public final class gy implements od1
{
    public static final gy c;
    
    static {
        c = (gy)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final LazyItemScope lazyItemScope = (LazyItemScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final MaterialTheme instance = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            TextKt.Text--4IGK_g("Tap a category to change its accent color", PaddingKt.padding-VpY3zN4((Modifier)Modifier.Companion, Dp.constructor-impl((float)16), Dp.constructor-impl((float)8)), instance.getColorScheme(composer, $stable).getOnSurfaceVariant-0d7_KjU(), 0L, (FontStyle)null, (FontWeight)null, (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, instance.getTypography(composer, $stable).getBodyMedium(), composer, 54, 0, 65528);
        }
        return t43.a;
    }
}
