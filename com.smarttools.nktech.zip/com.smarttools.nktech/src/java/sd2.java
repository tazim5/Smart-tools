import androidx.compose.runtime.State;
import androidx.compose.ui.node.ComposeUiNode$Companion;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.Alignment$Horizontal;
import androidx.compose.ui.Alignment$Companion;
import androidx.compose.ui.Modifier$Companion;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.material3.CardElevation;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.material3.CardKt;
import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.material3.CardDefaults;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.foundation.layout.RowScope;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.foundation.layout.RowScopeInstance;
import androidx.compose.foundation.layout.Arrangement$Horizontal;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.ui.Alignment;
import androidx.compose.foundation.gestures.FlingBehavior;
import androidx.compose.foundation.ScrollKt;
import androidx.compose.ui.unit.Dp;
import androidx.compose.foundation.layout.PaddingKt;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.ui.Modifier;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.PaddingValues;
import androidx.compose.runtime.MutableState;

public final class sd2 implements od1
{
    public final MutableState c;
    
    public sd2(final MutableState c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final PaddingValues paddingValues = (PaddingValues)o;
        final Composer composer = (Composer)o2;
        int intValue;
        final int n = intValue = ((Number)o3).intValue();
        if ((n & 0xE) == 0x0) {
            int n2;
            if (composer.changed((Object)paddingValues)) {
                n2 = 4;
            }
            else {
                n2 = 2;
            }
            intValue = (n | n2);
        }
        if ((intValue & 0x5B) == 0x12 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            final Modifier$Companion companion = Modifier.Companion;
            final Modifier padding = PaddingKt.padding(SizeKt.fillMaxSize$default((Modifier)companion, 0.0f, 1, (Object)null), paddingValues);
            final float n3 = 16;
            final Modifier verticalScroll$default = ScrollKt.verticalScroll$default(PaddingKt.padding-3ABfNKs(padding, Dp.constructor-impl(n3)), ScrollKt.rememberScrollState(0, composer, 0, 1), false, (FlingBehavior)null, false, 14, (Object)null);
            final Alignment$Companion companion2 = Alignment.Companion;
            final Alignment$Horizontal centerHorizontally = companion2.getCenterHorizontally();
            final Arrangement instance = Arrangement.INSTANCE;
            final MeasurePolicy d = m.d(n3, instance, centerHorizontally, composer, 54);
            final int currentCompositeKeyHash = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier = ComposedModifierKt.materializeModifier(composer, verticalScroll$default);
            final ComposeUiNode$Companion companion3 = ComposeUiNode.Companion;
            final id1 constructor = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl = Updater.constructor-impl(composer);
            final nd1 b = ap.b(companion3, constructor-impl, d, constructor-impl, currentCompositionLocalMap);
            if (constructor-impl.getInserting() || !kl1.b(constructor-impl.rememberedValue(), (Object)currentCompositeKeyHash)) {
                l3.i(currentCompositeKeyHash, constructor-impl, currentCompositeKeyHash, b);
            }
            Updater.set-impl(constructor-impl, (Object)materializeModifier, companion3.getSetModifier());
            final ColumnScopeInstance instance2 = ColumnScopeInstance.INSTANCE;
            final MutableState c = this.c;
            ud2.a(((od2)((State)c).getValue()).d, ((od2)((State)c).getValue()).e, composer, 0);
            final Modifier fillMaxWidth$default = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final MeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy((Arrangement$Horizontal)instance.spacedBy-0680j_4(Dp.constructor-impl((float)12)), companion2.getTop(), composer, 6);
            final int currentCompositeKeyHash2 = ComposablesKt.getCurrentCompositeKeyHash(composer, 0);
            final CompositionLocalMap currentCompositionLocalMap2 = composer.getCurrentCompositionLocalMap();
            final Modifier materializeModifier2 = ComposedModifierKt.materializeModifier(composer, fillMaxWidth$default);
            final id1 constructor2 = companion3.getConstructor();
            if (composer.getApplier() == null) {
                ComposablesKt.invalidApplier();
            }
            composer.startReusableNode();
            if (composer.getInserting()) {
                composer.createNode(constructor2);
            }
            else {
                composer.useNode();
            }
            final Composer constructor-impl2 = Updater.constructor-impl(composer);
            final nd1 b2 = ap.b(companion3, constructor-impl2, rowMeasurePolicy, constructor-impl2, currentCompositionLocalMap2);
            if (constructor-impl2.getInserting() || !kl1.b(constructor-impl2.rememberedValue(), (Object)currentCompositeKeyHash2)) {
                l3.i(currentCompositeKeyHash2, constructor-impl2, currentCompositeKeyHash2, b2);
            }
            Updater.set-impl(constructor-impl2, (Object)materializeModifier2, companion3.getSetModifier());
            final RowScopeInstance instance3 = RowScopeInstance.INSTANCE;
            final String e = ud2.e(((od2)((State)c).getValue()).a);
            final MaterialTheme instance4 = MaterialTheme.INSTANCE;
            final int $stable = MaterialTheme.$stable;
            ud2.d("Total", e, instance4.getColorScheme(composer, $stable).getPrimary-0d7_KjU(), RowScope.weight$default((RowScope)instance3, (Modifier)companion, 1.0f, false, 2, (Object)null), composer, 6);
            ud2.d("Used", ud2.e(((od2)((State)c).getValue()).c), ColorKt.Color(4293212469L), RowScope.weight$default((RowScope)instance3, (Modifier)companion, 1.0f, false, 2, (Object)null), composer, 390);
            ud2.d("Free", ud2.e(((od2)((State)c).getValue()).b), ColorKt.Color(4282622023L), RowScope.weight$default((RowScope)instance3, (Modifier)companion, 1.0f, false, 2, (Object)null), composer, 390);
            composer.endNode();
            final Modifier fillMaxWidth$default2 = SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null);
            final CardDefaults instance5 = CardDefaults.INSTANCE;
            final long copy-wmQWz5c$default = Color.copy-wmQWz5c$default(instance4.getColorScheme(composer, $stable).getSurfaceVariant-0d7_KjU(), 0.3f, 0.0f, 0.0f, 0.0f, 14, (Object)null);
            final int n4 = CardDefaults.$stable << 12;
            CardKt.Card(fillMaxWidth$default2, (Shape)null, instance5.cardColors-ro_MJ88(copy-wmQWz5c$default, 0L, 0L, 0L, composer, n4, 14), (CardElevation)null, (BorderStroke)null, (od1)ComposableLambdaKt.rememberComposableLambda(-973409174, true, (Object)new rd2(c), composer, 54), composer, 196614, 26);
            composer.startReplaceGroup(-919308810);
            if (((od2)((State)c).getValue()).e) {
                CardKt.Card(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), (Shape)null, instance5.cardColors-ro_MJ88(instance4.getColorScheme(composer, $stable).getErrorContainer-0d7_KjU(), 0L, 0L, 0L, composer, n4, 14), (CardElevation)null, (BorderStroke)null, (od1)je0.d, composer, 196614, 26);
            }
            composer.endReplaceGroup();
            CardKt.Card(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), (Shape)null, instance5.cardColors-ro_MJ88(Color.copy-wmQWz5c$default(instance4.getColorScheme(composer, $stable).getSurfaceVariant-0d7_KjU(), 0.2f, 0.0f, 0.0f, 0.0f, 14, (Object)null), 0L, 0L, 0L, composer, n4, 14), (CardElevation)null, (BorderStroke)null, (od1)je0.e, composer, 196614, 26);
            b02.a(PaddingKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth$default((Modifier)companion, 0.0f, 1, (Object)null), 0.0f, Dp.constructor-impl(n3), 0.0f, 0.0f, 13, (Object)null), composer, 6);
            composer.endNode();
        }
        return t43.a;
    }
}
