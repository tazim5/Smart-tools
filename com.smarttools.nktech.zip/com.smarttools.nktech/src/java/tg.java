import android.os.BaseBundle;
import com.google.android.gms.ads.internal.util.zzg;
import java.util.Iterator;
import com.google.android.gms.internal.ads.l0;
import com.google.android.gms.internal.ads.zzbbc;
import com.google.android.gms.internal.ads.zzazn;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import com.google.android.gms.ads.internal.util.zzj;
import android.os.Bundle;
import androidx.camera.core.impl.utils.executor.b;
import android.util.SparseBooleanArray;

public final class tg implements ig5
{
    public boolean c;
    public final Object n;
    
    public tg(final int n) {
        switch (n) {
            default: {
                this(null, false);
                return;
            }
            case 2: {
                this.n = new SparseBooleanArray();
            }
        }
    }
    
    public tg(final ak ak, final b b) {
        this.c = false;
        this.n = new c05((byte)0, 8);
    }
    
    public void a(final int n) {
        aq3.k(this.c ^ true);
        ((SparseBooleanArray)this.n).append(n, true);
    }
    
    public qg3 b() {
        aq3.k(this.c ^ true);
        this.c = true;
        return new qg3((SparseBooleanArray)this.n);
    }
    
    public void zza(final Throwable t) {
        d94.zzg("Failed to get signals bundle");
    }
    
    public void zzb(Object value) {
        final Bundle bundle = (Bundle)value;
        final ax4 ax4 = (ax4)this.n;
        if (((zzg)((b0)ax4).a).zzQ()) {
            return;
        }
        value = ((BaseBundle)bundle).get("ad_types");
        List list2 = null;
        Label_0144: {
            List list;
            if (value instanceof List) {
                list = (List)value;
            }
            else {
                if (!(value instanceof String[])) {
                    list2 = Collections.emptyList();
                    break Label_0144;
                }
                list = Arrays.asList((Object[])value);
            }
            final ArrayList list3 = new ArrayList(list.size());
            for (final Object next : list) {
                if (next instanceof String) {
                    list3.add((Object)next);
                }
            }
            list2 = Collections.unmodifiableList((List)list3);
        }
        final ArrayList list4 = new ArrayList();
        final Iterator iterator2 = list2.iterator();
        int n2;
        while (true) {
            final boolean hasNext = iterator2.hasNext();
            final int n = 0;
            n2 = 2;
            if (!hasNext) {
                break;
            }
            final String s = (String)iterator2.next();
            int n3 = 0;
            Label_0297: {
                switch (s.hashCode()) {
                    case 604727084: {
                        if (s.equals((Object)"interstitial")) {
                            n3 = 1;
                            break Label_0297;
                        }
                        break;
                    }
                    case -239580146: {
                        if (s.equals((Object)"rewarded")) {
                            n3 = 3;
                            break Label_0297;
                        }
                        break;
                    }
                    case -1052618729: {
                        if (s.equals((Object)"native")) {
                            n3 = 2;
                            break Label_0297;
                        }
                        break;
                    }
                    case -1396342996: {
                        if (s.equals((Object)"banner")) {
                            n3 = n;
                            break Label_0297;
                        }
                        break;
                    }
                }
                n3 = -1;
            }
            zzazn zzazn;
            if (n3 != 0) {
                if (n3 != 1) {
                    if (n3 != 2) {
                        if (n3 != 3) {
                            zzazn = com.google.android.gms.internal.ads.zzazn.c;
                        }
                        else {
                            zzazn = com.google.android.gms.internal.ads.zzazn.R;
                        }
                    }
                    else {
                        zzazn = com.google.android.gms.internal.ads.zzazn.y;
                    }
                }
                else {
                    zzazn = com.google.android.gms.internal.ads.zzazn.v;
                }
            }
            else {
                zzazn = com.google.android.gms.internal.ads.zzazn.n;
            }
            list4.add((Object)zzazn);
        }
        final zzbbc zzbbc = (zzbbc)ax4.h.get(((BaseBundle)pr3.a("network", pr3.a("device", bundle))).getInt("active_network_state", -1), (Object)com.google.android.gms.internal.ads.zzbbc.c);
        final ir3 v = l0.v();
        final int int1 = ((BaseBundle)bundle).getInt("cnt", -2);
        final int int2 = ((BaseBundle)bundle).getInt("gnt", 0);
        if (int1 == -1) {
            ax4.g = 2;
        }
        else {
            ax4.g = 1;
            if (int1 != 0) {
                if (int1 != 1) {
                    ((kp5)v).d();
                    l0.B((l0)((kp5)v).n, 1);
                }
                else {
                    ((kp5)v).d();
                    l0.B((l0)((kp5)v).n, 3);
                }
            }
            else {
                ((kp5)v).d();
                l0.B((l0)((kp5)v).n, 2);
            }
            while (true) {
                switch (int2) {
                    default: {
                        n2 = 1;
                    }
                    case 1:
                    case 2:
                    case 4:
                    case 7:
                    case 11:
                    case 16: {
                        ((kp5)v).d();
                        l0.C((l0)((kp5)v).n, n2);
                        break;
                    }
                    case 13: {
                        n2 = 5;
                        continue;
                    }
                    case 3:
                    case 5:
                    case 6:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 14:
                    case 15:
                    case 17: {
                        n2 = 3;
                        continue;
                    }
                }
                break;
            }
        }
        value = new bb5(this, this.c, list4, (l0)((kp5)v).b(), zzbbc);
        ((mw4)((b0)ax4).b).i((s75)value);
    }
}
