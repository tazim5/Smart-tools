public final class o84
{
    public final Object a = new Object();
    public volatile long b = 0L;
    public volatile int c = 1;
}
