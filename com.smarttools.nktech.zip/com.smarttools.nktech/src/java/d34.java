import com.google.android.gms.ads.nativead.NativeCustomFormatAd$OnCustomFormatAdLoadedListener;
import com.google.android.gms.ads.nativead.NativeCustomFormatAd;

public final class d34 extends qv3
{
    public final e34 c;
    
    public final void J(final gv3 gv3) {
        final e34 c = this.c;
        final NativeCustomFormatAd$OnCustomFormatAdLoadedListener a = c.a;
        synchronized (c) {
            final f34 c2 = c.c;
            Object o;
            if (c2 != null) {
                o = c2;
            }
            else {
                final f34 c3 = new f34(gv3);
                c.c = c3;
                o = c3;
            }
            monitorexit(c);
            a.onCustomFormatAdLoaded((NativeCustomFormatAd)o);
        }
    }
}
