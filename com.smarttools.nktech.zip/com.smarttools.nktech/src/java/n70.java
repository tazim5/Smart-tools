import androidx.compose.ui.Modifier;
import androidx.compose.material3.IconKt;
import androidx.compose.material3.MaterialTheme;
import androidx.compose.material.icons.filled.RefreshKt;
import androidx.compose.material.icons.Icons;
import androidx.compose.runtime.Composer;

public final class n70 implements nd1
{
    public static final n70 c;
    
    static {
        c = (n70)new Object();
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) == 0x2 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            IconKt.Icon-ww6aTOc(RefreshKt.getRefresh(Icons.INSTANCE.getDefault()), (String)null, (Modifier)null, MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getPrimary-0d7_KjU(), composer, 48, 4);
        }
        return t43.a;
    }
}
