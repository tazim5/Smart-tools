public abstract class d2 extends cs5
{
}
