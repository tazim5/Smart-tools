import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.runtime.Composer;
import com.smarttools.nktech.core.data.model.ToolCategory;

public final class oo implements nd1
{
    public final ToolCategory c;
    
    public oo(final ToolCategory c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2) {
        final Composer composer = (Composer)o;
        if ((((Number)o2).intValue() & 0xB) != 0x2 || !composer.getSkipping()) {
            TextKt.Text--4IGK_g(this.c.getDisplayName(), (Modifier)null, 0L, 0L, (FontStyle)null, FontWeight.Companion.getSemiBold(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 0, 0, (jd1)null, (TextStyle)null, composer, 196608, 0, 131038);
        }
        else {
            composer.skipToGroupEnd();
        }
        return t43.a;
    }
}
