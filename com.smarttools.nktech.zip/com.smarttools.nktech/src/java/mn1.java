public interface mn1 extends ln1
{
}
