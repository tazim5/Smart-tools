import java.nio.Buffer;
import android.database.sqlite.SQLiteProgram;
import android.database.sqlite.SQLiteDatabase$CursorFactory;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.nio.ByteBuffer;
import android.database.sqlite.SQLiteClosable;
import java.io.Closeable;

public class jc1 implements Closeable
{
    public static final String[] v;
    public final int c;
    public final Object n;
    
    static {
        v = new String[0];
    }
    
    public jc1(final ByteBuffer byteBuffer) {
        this.c = 2;
        this.n = byteBuffer.duplicate();
    }
    
    private final void C() {
    }
    
    public void F() {
        ((SQLiteDatabase)this.n).endTransaction();
    }
    
    public void I(final String s) {
        ((SQLiteDatabase)this.n).execSQL(s);
    }
    
    public Cursor V(final nt2 nt2) {
        return ((SQLiteDatabase)this.n).rawQueryWithFactory((SQLiteDatabase$CursorFactory)new ic1(nt2), nt2.c(), jc1.v, (String)null);
    }
    
    public Cursor W(final String s) {
        return this.V((nt2)new dh5(s, 2));
    }
    
    public void X() {
        ((SQLiteDatabase)this.n).setTransactionSuccessful();
    }
    
    public int Y(final ByteBuffer byteBuffer) {
        final ByteBuffer byteBuffer2 = (ByteBuffer)this.n;
        if (((Buffer)byteBuffer2).remaining() == 0 && ((Buffer)byteBuffer).remaining() > 0) {
            return -1;
        }
        final int min = Math.min(((Buffer)byteBuffer).remaining(), ((Buffer)byteBuffer2).remaining());
        final byte[] array = new byte[min];
        byteBuffer2.get(array);
        byteBuffer.put(array);
        return min;
    }
    
    public long Z() {
        return ((Buffer)this.n).position();
    }
    
    public void a() {
        ((SQLiteDatabase)this.n).beginTransaction();
    }
    
    public void c(final int n, final byte[] array) {
        ((SQLiteProgram)this.n).bindBlob(n, array);
    }
    
    public final void close() {
        switch (this.c) {
            default: {
                return;
            }
            case 1: {
                ((SQLiteClosable)this.n).close();
                return;
            }
            case 0: {
                ((SQLiteClosable)this.n).close();
            }
        }
    }
    
    public void l(final int n, final long n2) {
        ((SQLiteProgram)this.n).bindLong(n, n2);
    }
    
    public void p(final int n) {
        ((SQLiteProgram)this.n).bindNull(n);
    }
    
    public void r(final int n, final String s) {
        ((SQLiteProgram)this.n).bindString(n, s);
    }
}
