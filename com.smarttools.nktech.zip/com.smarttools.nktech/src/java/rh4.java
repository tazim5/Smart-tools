import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.ads.internal.client.zzl;
import java.util.Collections;
import org.json.JSONException;
import com.google.android.gms.ads.internal.zzt;
import com.google.android.gms.ads.internal.util.zze;
import java.io.UnsupportedEncodingException;
import android.util.Base64;
import org.json.JSONObject;
import com.google.android.gms.ads.nonagon.signalgeneration.zzc;
import com.google.android.gms.internal.ads.e;
import com.google.android.gms.internal.ads.zzdxn;
import android.text.TextUtils;
import java.util.concurrent.TimeUnit;
import com.google.android.gms.ads.internal.client.zzba;
import com.google.android.gms.internal.ads.zzfio;

public final class rh4
{
    public final an3 a;
    public final o65 b;
    public final z75 c;
    public final oe4 d;
    public final jz4 e;
    public final cl4 f;
    public k65 g;
    public final gl5 h;
    public final mi4 i;
    public final pg5 j;
    public final hv4 k;
    public final wx4 l;
    public final m14 m;
    public final vb3 n;
    
    public rh4(final an3 a, final o65 b, final z75 c, final oe4 d, final jz4 e, final cl4 f, final k65 g, final gl5 h, final mi4 i, final pg5 j, final hv4 k, final wx4 l, final m14 m, final vb3 n) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
        this.j = j;
        this.k = k;
        this.l = l;
        this.m = m;
        this.n = n;
    }
    
    public final u75 a(final yq1 yq1) {
        final gl5 a = this.c.b(yq1, (Object)zzfio.w).y((s75)new uu5((Object)this, 24)).A((cg5)this.e);
        final ur3 i4 = cs3.I4;
        gl5 e = a;
        if (!(boolean)zzba.zzc().a(i4)) {
            e = a.E((long)(int)zzba.zzc().a(cs3.J4), TimeUnit.SECONDS);
        }
        return e.r();
    }
    
    public final u75 b() {
        Object o = this.b.d;
        if (((zzl)o).zzx == null && ((zzl)o).zzs == null) {
            return this.c((yq1)this.i.a());
        }
        final zzfio g0 = zzfio.g0;
        final an3 a = this.a;
        final zzl d = ((o65)a.d).d;
        Object o2 = d.zzx;
        final boolean empty = TextUtils.isEmpty((CharSequence)o2);
        final uc4 uc4 = (uc4)a.a;
        final es4 es4 = (es4)a.h;
        Label_0513: {
            if (empty) {
                break Label_0513;
            }
            o = cs3.f6;
            if (!(boolean)zzba.zzc().a((ur3)o)) {
                break Label_0513;
            }
            final String d2 = an3.d((String)o2);
            final ur3 r6 = cs3.r6;
            o = d2;
            if (zzba.zzc().a(r6)) {
                o = d2;
                if (d2.isEmpty()) {
                    final int lastIndex = ((String)o2).lastIndexOf("&request_id=");
                    if (lastIndex != -1) {
                        o = ((String)o2).substring(lastIndex + 12);
                    }
                    else {
                        o = "";
                    }
                }
            }
        Label_0305_Outer:
            while (true) {
                if (TextUtils.isEmpty((CharSequence)o)) {
                    o = com.google.android.gms.internal.ads.e.p((Throwable)new zzdxn(15, "Invalid ad string."));
                    break Label_0212;
                }
                final String zzb = ((zzc)((nd4)uc4).H.zzb()).zzb((String)o, es4);
                String a2 = (String)o2;
                Label_0484: {
                    if (!(boolean)zzba.zzc().a(r6)) {
                        break Label_0484;
                    }
                    a2 = (String)o2;
                    Label_0680: {
                        Block_10: {
                            if (!TextUtils.isEmpty((CharSequence)zzb)) {
                                break Block_10;
                            }
                            break Label_0484;
                            break Label_0680;
                        }
                        while (true) {
                            try {
                                Boolean b;
                                if (new JSONObject(zzb).optString("is_gbid").equals((Object)"true")) {
                                    b = Boolean.TRUE;
                                }
                                else {
                                    b = Boolean.FALSE;
                                }
                                if (!b) {
                                    a2 = (String)o2;
                                }
                                else {
                                    final int lastIndex2 = ((String)o2).lastIndexOf("&");
                                    final yq1 yq1 = null;
                                    Object o3;
                                    if (lastIndex2 != -1) {
                                        o3 = ((String)o2).substring(0, lastIndex2);
                                    }
                                    else {
                                        o3 = null;
                                    }
                                    if (TextUtils.isEmpty((CharSequence)o3)) {
                                        a2 = (String)o2;
                                    }
                                    else {
                                        Label_0457: {
                                            byte[] bytes = null;
                                            Label_0442: {
                                                try {
                                                    o3 = Base64.decode((String)o3, 11);
                                                    bytes = ((String)o).getBytes("UTF-8");
                                                    final JSONObject jsonObject = new(org.json.JSONObject.class)();
                                                    final JSONObject jsonObject3;
                                                    final JSONObject jsonObject2 = jsonObject3 = jsonObject;
                                                    final String s = zzb;
                                                    new JSONObject(s);
                                                    final JSONObject jsonObject4 = jsonObject2;
                                                    final String s2 = "arek";
                                                    o = jsonObject4.getString(s2);
                                                    break Label_0442;
                                                }
                                                catch (final UnsupportedEncodingException o) {
                                                    break Label_0457;
                                                }
                                                try {
                                                    final JSONObject jsonObject = new(org.json.JSONObject.class)();
                                                    final JSONObject jsonObject3;
                                                    final JSONObject jsonObject2 = jsonObject3 = jsonObject;
                                                    final String s = zzb;
                                                    new JSONObject(s);
                                                    final JSONObject jsonObject4 = jsonObject2;
                                                    final String s2 = "arek";
                                                    o = jsonObject4.getString(s2);
                                                }
                                                catch (JSONException o) {
                                                    zze.zza("Failed to get key from QueryJSONMap".concat(o.toString()));
                                                    zzt.zzo().g("CryptoUtils.getKeyFromQueryJsonMap", (Throwable)o);
                                                    o = yq1;
                                                }
                                            }
                                            a2 = t65.a((byte[])o3, bytes, (String)o, es4);
                                            break Label_0484;
                                        }
                                        zze.zza("Failed to decode the adResponse. ".concat(o.toString()));
                                        zzt.zzo().g("PreloadedLoader.decryptAdResponseIfNecessary", (Throwable)o);
                                        a2 = (String)o2;
                                    }
                                }
                                if (TextUtils.isEmpty((CharSequence)zzb)) {
                                    o = d.zzs;
                                    Label_0661: {
                                        if (o != null) {
                                            if (zzba.zzc().a(cs3.d6)) {
                                                o2 = ((com.google.android.gms.ads.internal.client.zzc)o).zza;
                                                final String zzb2 = ((com.google.android.gms.ads.internal.client.zzc)o).zzb;
                                                o2 = an3.d((String)o2);
                                                final String d3 = an3.d(zzb2);
                                                if (TextUtils.isEmpty((CharSequence)d3) || !((String)o2).equals(d3)) {
                                                    es4.a.put((Object)"ridmm", (Object)"true");
                                                    break Label_0661;
                                                }
                                                ((zzc)((nd4)uc4).H.zzb()).zzf((String)o2);
                                                es4.a.put((Object)"rid", o2);
                                            }
                                            o = a.b(((com.google.android.gms.ads.internal.client.zzc)o).zza, a.c(((com.google.android.gms.ads.internal.client.zzc)o).zzb));
                                            continue Label_0305_Outer;
                                        }
                                    }
                                    o = com.google.android.gms.internal.ads.e.p((Throwable)new zzdxn(14, "Mismatch request IDs."));
                                    continue Label_0305_Outer;
                                }
                                o = a.b(a2, a.c(zzb));
                                continue Label_0305_Outer;
                                o2 = z75.d;
                                return new gl5(this.c, (Object)g0, (String)null, (yq1)o2, Collections.emptyList(), (yq1)o).r();
                            }
                            catch (final JSONException ex) {
                                continue;
                            }
                            break;
                        }
                    }
                }
                break;
            }
        }
    }
    
    public final u75 c(final yq1 yq1) {
        final k65 g = this.g;
        if (g != null) {
            return new gl5(this.c, (Object)zzfio.v, (String)null, (yq1)z75.d, Collections.emptyList(), (yq1)com.google.android.gms.internal.ads.e.r((Object)g)).r();
        }
        final zp3 zzc = zzt.zzc();
        zzc.getClass();
        if (zzba.zzc().a(cs3.E3)) {
            final Object c;
            monitorenter(c = zzc.c);
            Label_0114: {
                try {
                    zzc.d();
                    final ScheduledFuture a = zzc.a;
                    if (a != null) {
                        ((Future)a).cancel(false);
                    }
                    break Label_0114;
                }
                finally {
                    monitorexit(c);
                    zzc.a = ((ScheduledThreadPoolExecutor)k1.d).schedule((Runnable)zzc.b, (long)zzba.zzc().a(cs3.F3), TimeUnit.MILLISECONDS);
                    monitorexit(c);
                }
            }
        }
        if ((boolean)zzba.zzc().a(cs3.N9) && !(boolean)mt3.c.k()) {
            final of5 y = com.google.android.gms.internal.ads.e.y(yq1, (cg5)new dx3((Object)this.m, 6), (Executor)this.j);
            final u75 r = this.c.b((yq1)y, (Object)zzfio.y).A((cg5)new dx3((Object)this.h, 7)).r();
            return this.c.a(zzfio.v, new yq1[] { yq1, (yq1)y, (yq1)r }).a((Callable)new ph4(this, yq1, y, r)).A((cg5)qh4.b).r();
        }
        return this.c.b(yq1, (Object)zzfio.v).A((cg5)new dx3((Object)this.k, 8)).r();
    }
}
