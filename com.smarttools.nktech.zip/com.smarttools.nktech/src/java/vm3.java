import java.lang.ref.Reference;
import android.os.Bundle;
import android.app.Activity;
import java.lang.ref.WeakReference;
import android.app.Application;
import android.app.Application$ActivityLifecycleCallbacks;

public final class vm3 implements Application$ActivityLifecycleCallbacks
{
    public final int c;
    public final Application n;
    public final WeakReference v;
    public boolean w;
    
    public vm3(final Application n, final hn3 hn3) {
        this.c = 0;
        this.w = false;
        this.v = new WeakReference((Object)hn3);
        this.n = n;
    }
    
    public vm3(final Application n, final po3 po3) {
        this.c = 1;
        this.w = false;
        this.v = new WeakReference((Object)po3);
        this.n = n;
    }
    
    public final void onActivityCreated(final Activity activity, final Bundle bundle) {
        switch (this.c) {
            default: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks != null) {
                        application$ActivityLifecycleCallbacks.onActivityCreated(activity, bundle);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                }
                catch (final Exception ex) {
                    d94.zzh("Error while dispatching lifecycle callback.", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks2 = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks2 != null) {
                        application$ActivityLifecycleCallbacks2.onActivityCreated(activity, bundle);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                    return;
                }
                catch (final Exception ex2) {
                    return;
                }
                break;
            }
        }
    }
    
    public final void onActivityDestroyed(final Activity activity) {
        switch (this.c) {
            default: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks != null) {
                        application$ActivityLifecycleCallbacks.onActivityDestroyed(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                }
                catch (final Exception ex) {
                    d94.zzh("Error while dispatching lifecycle callback.", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks2 = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks2 != null) {
                        application$ActivityLifecycleCallbacks2.onActivityDestroyed(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                    return;
                }
                catch (final Exception ex2) {
                    return;
                }
                break;
            }
        }
    }
    
    public final void onActivityPaused(final Activity activity) {
        switch (this.c) {
            default: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks != null) {
                        application$ActivityLifecycleCallbacks.onActivityPaused(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                }
                catch (final Exception ex) {
                    d94.zzh("Error while dispatching lifecycle callback.", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks2 = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks2 != null) {
                        application$ActivityLifecycleCallbacks2.onActivityPaused(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                    return;
                }
                catch (final Exception ex2) {
                    return;
                }
                break;
            }
        }
    }
    
    public final void onActivityResumed(final Activity activity) {
        switch (this.c) {
            default: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks != null) {
                        application$ActivityLifecycleCallbacks.onActivityResumed(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                }
                catch (final Exception ex) {
                    d94.zzh("Error while dispatching lifecycle callback.", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks2 = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks2 != null) {
                        application$ActivityLifecycleCallbacks2.onActivityResumed(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                    return;
                }
                catch (final Exception ex2) {
                    return;
                }
                break;
            }
        }
    }
    
    public final void onActivitySaveInstanceState(final Activity activity, final Bundle bundle) {
        switch (this.c) {
            default: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks != null) {
                        application$ActivityLifecycleCallbacks.onActivitySaveInstanceState(activity, bundle);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                }
                catch (final Exception ex) {
                    d94.zzh("Error while dispatching lifecycle callback.", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks2 = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks2 != null) {
                        application$ActivityLifecycleCallbacks2.onActivitySaveInstanceState(activity, bundle);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                    return;
                }
                catch (final Exception ex2) {
                    return;
                }
                break;
            }
        }
    }
    
    public final void onActivityStarted(final Activity activity) {
        switch (this.c) {
            default: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks != null) {
                        application$ActivityLifecycleCallbacks.onActivityStarted(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                }
                catch (final Exception ex) {
                    d94.zzh("Error while dispatching lifecycle callback.", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks2 = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks2 != null) {
                        application$ActivityLifecycleCallbacks2.onActivityStarted(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                    return;
                }
                catch (final Exception ex2) {
                    return;
                }
                break;
            }
        }
    }
    
    public final void onActivityStopped(final Activity activity) {
        switch (this.c) {
            default: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks != null) {
                        application$ActivityLifecycleCallbacks.onActivityStopped(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                }
                catch (final Exception ex) {
                    d94.zzh("Error while dispatching lifecycle callback.", (Throwable)ex);
                }
                return;
            }
            case 0: {
                try {
                    final Application$ActivityLifecycleCallbacks application$ActivityLifecycleCallbacks2 = (Application$ActivityLifecycleCallbacks)((Reference)this.v).get();
                    if (application$ActivityLifecycleCallbacks2 != null) {
                        application$ActivityLifecycleCallbacks2.onActivityStopped(activity);
                    }
                    else if (!this.w) {
                        this.n.unregisterActivityLifecycleCallbacks((Application$ActivityLifecycleCallbacks)this);
                        this.w = true;
                    }
                    return;
                }
                catch (final Exception ex2) {
                    return;
                }
                break;
            }
        }
    }
}
