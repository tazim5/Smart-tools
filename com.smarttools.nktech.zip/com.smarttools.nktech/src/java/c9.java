import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.content.res.ColorStateList;
import java.lang.reflect.Field;
import android.graphics.drawable.Drawable;
import android.graphics.PorterDuff$Mode;
import android.view.View;

public final class c9
{
    public final View a;
    public final d9 b;
    public int c;
    public h95 d;
    public h95 e;
    public h95 f;
    
    public c9(final View a) {
        this.c = -1;
        this.a = a;
        final PorterDuff$Mode b = d9.b;
        final Class<d9> clazz;
        monitorenter(clazz = d9.class);
        Label_0039: {
            try {
                if (d9.c == null) {
                    d9.b();
                }
                break Label_0039;
            }
            finally {
                monitorexit(clazz);
                final d9 c = d9.c;
                monitorexit(clazz);
                this.b = c;
            }
        }
    }
    
    public final void a() {
        final View a = this.a;
        final Drawable background = a.getBackground();
        if (background != null) {
            if (this.d != null) {
                if (this.f == null) {
                    this.f = (h95)new Object();
                }
                final h95 f = this.f;
                f.c = null;
                f.b = false;
                f.d = null;
                f.a = false;
                final Field a2 = q73.a;
                final ColorStateList g = i73.g(a);
                if (g != null) {
                    f.b = true;
                    f.c = g;
                }
                final PorterDuff$Mode h = i73.h(a);
                if (h != null) {
                    f.a = true;
                    f.d = h;
                }
                if (f.b || f.a) {
                    d9.c(background, f, a.getDrawableState());
                    return;
                }
            }
            final h95 e = this.e;
            if (e != null) {
                d9.c(background, e, a.getDrawableState());
            }
            else {
                final h95 d = this.d;
                if (d != null) {
                    d9.c(background, d, a.getDrawableState());
                }
            }
        }
    }
    
    public final void b(AttributeSet b, int c) {
        final View a = this.a;
        final Context context = a.getContext();
        final int[] t = kd2.t;
        final w65 g = w65.G(context, b, t, c);
        final TypedArray typedArray = (TypedArray)g.v;
        final View a2 = this.a;
        q73.c(a2, a2.getContext(), t, b, (TypedArray)g.v, c);
        Label_0194: {
            Label_0145: {
                Context context2;
                AttributeSet set;
                try {
                    if (!typedArray.hasValue(0)) {
                        break Label_0145;
                    }
                    this.c = typedArray.getResourceId(0, -1);
                    b = (AttributeSet)this.b;
                    context2 = a.getContext();
                    c = this.c;
                    monitorenter(set = b);
                    final AttributeSet set2 = b;
                    final if2 if2 = ((d9)set2).a;
                    final int n = c;
                    final Context context3 = context2;
                    final ColorStateList list = if2.f(n, context3);
                    final AttributeSet set3 = set;
                    monitorexit(set3);
                    final ColorStateList list2 = list;
                    if (list2 != null) {
                        final c9 c2 = this;
                        final ColorStateList list3 = list;
                        c2.d(list3);
                    }
                    break Label_0145;
                }
                finally {
                    final AttributeSet set4;
                    b = set4;
                    break Label_0194;
                }
                try {
                    final AttributeSet set2 = b;
                    final if2 if2 = ((d9)set2).a;
                    final int n = c;
                    final Context context3 = context2;
                    final ColorStateList list = if2.f(n, context3);
                    final AttributeSet set3 = set;
                    monitorexit(set3);
                    final ColorStateList list2 = list;
                    if (list2 != null) {
                        final c9 c2 = this;
                        final ColorStateList list3 = list;
                        c2.d(list3);
                    }
                }
                finally {
                    monitorexit(set);
                }
            }
            final View view;
            if (typedArray.hasValue(1)) {
                i73.q(view, g.w(1));
            }
            if (typedArray.hasValue(2)) {
                i73.r(view, wz0.b(typedArray.getInt(2, -1), (PorterDuff$Mode)null));
            }
            g.L();
            return;
        }
        g.L();
        throw b;
    }
    
    public final void c(final int c) {
        this.c = c;
        final d9 b = this.b;
        final ColorStateList list;
        Label_0051: {
            if (b != null) {
                final Context context = this.a.getContext();
                synchronized (b) {
                    b.a.f(c, context);
                    break Label_0051;
                }
            }
            list = null;
        }
        this.d(list);
        this.a();
    }
    
    public final void d(final ColorStateList c) {
        if (c != null) {
            if (this.d == null) {
                this.d = (h95)new Object();
            }
            final h95 d = this.d;
            d.c = c;
            d.b = true;
        }
        else {
            this.d = null;
        }
        this.a();
    }
    
    public final void e(final ColorStateList c) {
        if (this.e == null) {
            this.e = (h95)new Object();
        }
        final h95 e = this.e;
        e.c = c;
        e.b = true;
        this.a();
    }
    
    public final void f(final PorterDuff$Mode d) {
        if (this.e == null) {
            this.e = (h95)new Object();
        }
        final h95 e = this.e;
        e.d = d;
        e.a = true;
        this.a();
    }
}
