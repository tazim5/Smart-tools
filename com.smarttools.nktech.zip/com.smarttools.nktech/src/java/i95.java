import java.lang.ref.Reference;
import android.view.View;
import java.util.Iterator;
import java.util.Collection;
import java.util.Collections;

public final class i95 extends l95
{
    public static final i95 w;
    
    static {
        w = (i95)new Object();
    }
    
    @Override
    public final void a(final boolean b) {
        final Iterator iterator = Collections.unmodifiableCollection((Collection)j95.c.a).iterator();
        while (iterator.hasNext()) {
            final s95 d = ((f95)iterator.next()).d;
            if (((Reference)d.a).get() != null) {
                String s;
                if (!b) {
                    s = "backgrounded";
                }
                else {
                    s = "foregrounded";
                }
                jt3.c(d.a(), "setState", new Object[] { s });
            }
        }
    }
    
    @Override
    public final boolean b() {
        final Iterator iterator = Collections.unmodifiableCollection((Collection)j95.c.b).iterator();
        while (iterator.hasNext()) {
            final View view = (View)((Reference)((f95)iterator.next()).c).get();
            if (view != null && view.hasWindowFocus()) {
                return true;
            }
        }
        return false;
    }
}
