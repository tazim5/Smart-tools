import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class mc4
{
    public static final Pattern a;
    public static final Pattern b;
    
    static {
        a = Pattern.compile("^\\uFEFF?\\s*(\\s*<!--([^-]|(?!-->))*-->)*\\s*<!DOCTYPE(\\s)+html(|(\\s)+[^>]*)>", 2);
        b = Pattern.compile("^\\uFEFF?\\s*(\\s*<!--([^-]|(?!-->))*-->)*?\\s*<!DOCTYPE[^>]*>", 2);
    }
    
    public static String a(final String s, final String... array) {
        final StringBuilder sb = new StringBuilder();
        final Matcher matcher = mc4.a.matcher((CharSequence)s);
        final boolean find = matcher.find();
        final int n = 0;
        int i = 0;
        if (find) {
            final int end = matcher.end();
            sb.append(s.substring(0, end));
            while (i <= 0) {
                final String s2 = array[i];
                if (s2 != null) {
                    sb.append(s2);
                }
                ++i;
            }
            sb.append(s.substring(end));
        }
        else {
            if (!mc4.b.matcher((CharSequence)s).find()) {
                for (int j = n; j <= 0; ++j) {
                    final String s3 = array[j];
                    if (s3 != null) {
                        sb.append(s3);
                    }
                }
            }
            sb.append(s);
        }
        return sb.toString();
    }
}
