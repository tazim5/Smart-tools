public final class sc implements h32
{
    public static final sc a;
    
    static {
        a = (sc)new Object();
        u81.b("messagingClientEventExtension");
    }
    
    public final void a(final Object o, final Object o2) {
        if (o == null) {
            throw null;
        }
        throw new ClassCastException();
    }
}
