import android.os.Parcel;
import android.os.ParcelFileDescriptor$AutoCloseInputStream;
import android.os.ParcelFileDescriptor;
import com.google.android.gms.ads.internal.util.zzbb;

public final class xu4 extends ho3 implements a54
{
    public final cv4 c;
    
    public xu4(final cv4 c) {
        this.c = c;
        super("com.google.android.gms.ads.internal.request.INonagonStreamingResponseListener");
    }
    
    public final void h(final zzbb zzbb) {
        this.c.a.zzd((Throwable)zzbb.zza());
    }
    
    public final void m(final ParcelFileDescriptor parcelFileDescriptor) {
        this.c.a.zzc((Object)new ParcelFileDescriptor$AutoCloseInputStream(parcelFileDescriptor));
    }
    
    public final boolean zzbK(final int n, final Parcel parcel, final Parcel parcel2, final int n2) {
        if (n != 1) {
            if (n != 2) {
                return false;
            }
            final zzbb zzbb = (zzbb)io3.a(parcel, com.google.android.gms.ads.internal.util.zzbb.CREATOR);
            io3.b(parcel);
            this.h(zzbb);
        }
        else {
            final ParcelFileDescriptor parcelFileDescriptor = (ParcelFileDescriptor)io3.a(parcel, ParcelFileDescriptor.CREATOR);
            io3.b(parcel);
            this.m(parcelFileDescriptor);
        }
        parcel2.writeNoException();
        return true;
    }
}
