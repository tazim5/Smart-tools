import java.util.List;
import java.util.ArrayList;

public interface db3
{
    void d(final ArrayList p0);
    
    void f(final List p0);
}
