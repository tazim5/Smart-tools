public final class bk5 extends b0
{
    public final int c;
    
    @Override
    public final ak5 b(final int n, final byte[] array) {
        switch (this.c) {
            default: {
                return (ak5)new zj5(array, n, 1);
            }
            case 0: {
                return (ak5)new zj5(array, n, 0);
            }
        }
    }
}
