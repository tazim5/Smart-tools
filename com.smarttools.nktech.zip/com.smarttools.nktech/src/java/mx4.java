public final class mx4 implements h32
{
    public static final mx4 a;
    
    static {
        a = (mx4)new Object();
        f83.q(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, f83.l(f83.i((Class)yj3.class, new og3(1)), 2)), 3)), 4)), 5)), 6)), 7)));
    }
}
