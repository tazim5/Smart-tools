import android.util.SparseBooleanArray;

public final class qg3
{
    public final SparseBooleanArray a = a;
    
    public final int a(final int n) {
        final SparseBooleanArray a = this.a;
        aq3.g(n, a.size());
        return a.keyAt(n);
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof qg3)) {
            return false;
        }
        final qg3 qg3 = (qg3)o;
        final int a = ec5.a;
        final SparseBooleanArray a2 = this.a;
        if (a >= 24) {
            return a2.equals((Object)qg3.a);
        }
        if (a2.size() == qg3.a.size()) {
            for (int i = 0; i < a2.size(); ++i) {
                if (this.a(i) != qg3.a(i)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        final int a = ec5.a;
        final SparseBooleanArray a2 = this.a;
        if (a < 24) {
            int size = a2.size();
            for (int i = 0; i < a2.size(); ++i) {
                size = size * 31 + this.a(i);
            }
            return size;
        }
        return a2.hashCode();
    }
}
