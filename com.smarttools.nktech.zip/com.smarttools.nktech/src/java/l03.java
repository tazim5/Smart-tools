public final class l03
{
    public final String a;
    public final String b;
    public final boolean c;
    
    public l03(final String a, final String b, final boolean c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof l03)) {
            return false;
        }
        final l03 l03 = (l03)o;
        return kl1.b((Object)this.a, (Object)l03.a) && kl1.b((Object)this.b, (Object)l03.b) && this.c == l03.c;
    }
    
    @Override
    public final int hashCode() {
        return Boolean.hashCode(this.c) + vo2.c(this.a.hashCode() * 31, 31, this.b);
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("WidgetTask(id=");
        sb.append(this.a);
        sb.append(", title=");
        sb.append(this.b);
        sb.append(", isCompleted=");
        sb.append(this.c);
        sb.append(")");
        return sb.toString();
    }
}
