import java.math.RoundingMode;

public final class uj3 implements ef3
{
    public final gh3 a;
    public final int b;
    public final long c;
    public final long d;
    public final long e;
    
    public uj3(final gh3 a, final int b, long n, final long n2) {
        this.a = a;
        this.b = b;
        this.c = n;
        n = (n2 - n) / a.c;
        this.d = n;
        this.e = this.c(n);
    }
    
    public final df3 a(long n) {
        final long n2 = this.b;
        final gh3 a = this.a;
        final long n3 = a.b * n / (n2 * 1000000L);
        final long d = this.d;
        final long max = Math.max(0L, Math.min(n3, d - 1L));
        final long n4 = a.c;
        final long c = this.c(max);
        final long c2 = this.c;
        final ff3 ff3 = new ff3(c, n4 * max + c2);
        if (c < n && max != d - 1L) {
            n = max + 1L;
            return new df3(ff3, new ff3(this.c(n), n * a.c + c2));
        }
        return new df3(ff3, ff3);
    }
    
    public final long c(final long n) {
        return ec5.w(n * this.b, 1000000L, (long)this.a.b, RoundingMode.FLOOR);
    }
    
    public final long zza() {
        return this.e;
    }
    
    public final boolean zzh() {
        return true;
    }
}
