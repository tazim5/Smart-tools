import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAd$OnNativeAdLoadedListener;

public final class g34 extends wv3
{
    public final NativeAd$OnNativeAdLoadedListener c;
    
    public g34(final NativeAd$OnNativeAdLoadedListener c) {
        this.c = c;
    }
    
    public final void R(final kw3 kw3) {
        this.c.onNativeAdLoaded((NativeAd)new y24(kw3));
    }
}
