import android.os.IInterface;
import android.os.IBinder;
import android.os.Parcel;

public final class s04 extends go3 implements t04
{
    public final boolean a(final String s) {
        final Parcel zza = this.zza();
        zza.writeString(s);
        final Parcel zzbh = this.zzbh(2, zza);
        final boolean f = io3.f(zzbh);
        zzbh.recycle();
        return f;
    }
    
    public final g24 c(final String s) {
        final Parcel zza = this.zza();
        zza.writeString(s);
        final Parcel zzbh = this.zzbh(3, zza);
        final IBinder strongBinder = zzbh.readStrongBinder();
        final int y = n24.y;
        Object o;
        if (strongBinder == null) {
            o = null;
        }
        else {
            final IInterface queryLocalInterface = strongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.rtb.IRtbAdapter");
            if (queryLocalInterface instanceof g24) {
                o = queryLocalInterface;
            }
            else {
                o = new go3(strongBinder, "com.google.android.gms.ads.internal.mediation.client.rtb.IRtbAdapter");
            }
        }
        zzbh.recycle();
        return (g24)o;
    }
    
    public final boolean e(final String s) {
        final Parcel zza = this.zza();
        zza.writeString(s);
        final Parcel zzbh = this.zzbh(4, zza);
        final boolean f = io3.f(zzbh);
        zzbh.recycle();
        return f;
    }
    
    public final v04 zzb(final String s) {
        final Parcel zza = this.zza();
        zza.writeString(s);
        final Parcel zzbh = this.zzbh(1, zza);
        final IBinder strongBinder = zzbh.readStrongBinder();
        Object o;
        if (strongBinder == null) {
            o = null;
        }
        else {
            final IInterface queryLocalInterface = strongBinder.queryLocalInterface("com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
            if (queryLocalInterface instanceof v04) {
                o = queryLocalInterface;
            }
            else {
                o = new go3(strongBinder, "com.google.android.gms.ads.internal.mediation.client.IMediationAdapter");
            }
        }
        zzbh.recycle();
        return (v04)o;
    }
}
