import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.Modifier;
import androidx.compose.material3.TextKt;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.unit.TextUnitKt;
import androidx.compose.runtime.Composer;
import androidx.compose.foundation.layout.RowScope;

public final class ej2 implements od1
{
    public final String c;
    
    public ej2(final String c) {
        this.c = c;
    }
    
    public final Object invoke(final Object o, final Object o2, final Object o3) {
        final RowScope rowScope = (RowScope)o;
        final Composer composer = (Composer)o2;
        if ((((Number)o3).intValue() & 0x51) == 0x10 && composer.getSkipping()) {
            composer.skipToGroupEnd();
        }
        else {
            TextKt.Text--4IGK_g(this.c, (Modifier)null, 0L, TextUnitKt.getSp(14), (FontStyle)null, FontWeight.Companion.getMedium(), (FontFamily)null, 0L, (TextDecoration)null, (TextAlign)null, 0L, 0, false, 1, 0, (jd1)null, (TextStyle)null, composer, 199680, 3072, 122838);
        }
        return t43.a;
    }
}
