public abstract class nl5
{
    public static final io4 a;
    
    static {
        a = new io4(8);
    }
}
