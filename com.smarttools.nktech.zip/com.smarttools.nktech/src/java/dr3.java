import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.AbstractAdViewAdapter;
import com.google.android.gms.ads.internal.client.zza;
import com.google.android.gms.ads.admanager.AppEventListener;
import com.google.android.gms.ads.AdListener;

public final class dr3 extends AdListener implements AppEventListener, zza
{
    public final AbstractAdViewAdapter c;
    public final MediationBannerListener n;
    
    public dr3(final AbstractAdViewAdapter c, final MediationBannerListener n) {
        this.c = c;
        this.n = n;
    }
    
    public final void onAdClicked() {
        this.n.onAdClicked((MediationBannerAdapter)this.c);
    }
    
    public final void onAdClosed() {
        this.n.onAdClosed((MediationBannerAdapter)this.c);
    }
    
    public final void onAdFailedToLoad(final LoadAdError loadAdError) {
        this.n.onAdFailedToLoad((MediationBannerAdapter)this.c, (AdError)loadAdError);
    }
    
    public final void onAdLoaded() {
        this.n.onAdLoaded((MediationBannerAdapter)this.c);
    }
    
    public final void onAdOpened() {
        this.n.onAdOpened((MediationBannerAdapter)this.c);
    }
    
    public final void onAppEvent(final String s, final String s2) {
        this.n.zzd((MediationBannerAdapter)this.c, s, s2);
    }
}
