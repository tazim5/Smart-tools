import com.google.firebase.installations.remote.InstallationResponse$ResponseCode;

public final class td
{
    public final String a;
    public final String b;
    public final String c;
    public final ve d;
    public final InstallationResponse$ResponseCode e;
    
    public td(final String a, final String b, final String c, final ve d, final InstallationResponse$ResponseCode e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    @Override
    public final boolean equals(final Object o) {
        boolean b = true;
        if (o == this) {
            return true;
        }
        if (o instanceof td) {
            final td td = (td)o;
            final String a = this.a;
            if (a == null) {
                if (td.a != null) {
                    return false;
                }
            }
            else if (!a.equals((Object)td.a)) {
                return false;
            }
            final String b2 = this.b;
            if (b2 == null) {
                if (td.b != null) {
                    return false;
                }
            }
            else if (!b2.equals((Object)td.b)) {
                return false;
            }
            final String c = this.c;
            if (c == null) {
                if (td.c != null) {
                    return false;
                }
            }
            else if (!c.equals((Object)td.c)) {
                return false;
            }
            final ve d = this.d;
            if (d == null) {
                if (td.d != null) {
                    return false;
                }
            }
            else if (!d.equals((Object)td.d)) {
                return false;
            }
            final InstallationResponse$ResponseCode e = this.e;
            if (e == null) {
                if (td.e == null) {
                    return b;
                }
            }
            else if (e.equals(td.e)) {
                return b;
            }
            b = false;
            return b;
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        int hashCode = 0;
        final String a = this.a;
        int hashCode2;
        if (a == null) {
            hashCode2 = 0;
        }
        else {
            hashCode2 = a.hashCode();
        }
        final String b = this.b;
        int hashCode3;
        if (b == null) {
            hashCode3 = 0;
        }
        else {
            hashCode3 = b.hashCode();
        }
        final String c = this.c;
        int hashCode4;
        if (c == null) {
            hashCode4 = 0;
        }
        else {
            hashCode4 = c.hashCode();
        }
        final ve d = this.d;
        int hashCode5;
        if (d == null) {
            hashCode5 = 0;
        }
        else {
            hashCode5 = d.hashCode();
        }
        final InstallationResponse$ResponseCode e = this.e;
        if (e != null) {
            hashCode = e.hashCode();
        }
        return hashCode ^ ((((hashCode2 ^ 0xF4243) * 1000003 ^ hashCode3) * 1000003 ^ hashCode4) * 1000003 ^ hashCode5) * 1000003;
    }
    
    @Override
    public final String toString() {
        final StringBuilder sb = new StringBuilder("InstallationResponse{uri=");
        sb.append(this.a);
        sb.append(", fid=");
        sb.append(this.b);
        sb.append(", refreshToken=");
        sb.append(this.c);
        sb.append(", authToken=");
        sb.append((Object)this.d);
        sb.append(", responseCode=");
        sb.append((Object)this.e);
        sb.append("}");
        return sb.toString();
    }
}
