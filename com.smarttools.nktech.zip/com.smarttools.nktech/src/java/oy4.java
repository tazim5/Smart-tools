import com.google.android.gms.internal.ads.zzbxc;

public final class oy4 extends u54 implements nj4
{
    public tz4 c;
    public y7 n;
    public b23 v;
    
    @Override
    public final void D(final y7 n) {
        synchronized (this) {
            this.n = n;
        }
    }
    
    public final void N(final th1 th1) {
        monitorenter(this);
        Label_0030: {
            try {
                final tz4 c = this.c;
                if (c != null) {
                    ((xo1)c.v).t0((gl4)c96.z);
                    monitorexit(this);
                    return;
                }
                break Label_0030;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void Q() {
        monitorenter(this);
        Label_0041: {
            try {
                final b23 v = this.v;
                if (v != null) {
                    d94.zzj("Fail to initialize adapter ".concat(String.valueOf((Object)((tx4)v.v).a)));
                    monitorexit(this);
                    return;
                }
                break Label_0041;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void S0(final th1 th1) {
        monitorenter(this);
        Label_0027: {
            try {
                final tz4 c = this.c;
                if (c != null) {
                    c.w.zzc();
                    monitorexit(this);
                    return;
                }
                break Label_0027;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void X0(final th1 th1) {
        monitorenter(this);
        Label_0025: {
            try {
                final tz4 c = this.c;
                if (c != null) {
                    c.X0(th1);
                    monitorexit(this);
                    return;
                }
                break Label_0025;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void Z0() {
        monitorenter(this);
        Label_0027: {
            try {
                final tz4 c = this.c;
                if (c != null) {
                    c.v.zzb();
                    monitorexit(this);
                    return;
                }
                break Label_0027;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void d0(final th1 th1) {
        monitorenter(this);
        Label_0085: {
            try {
                final b23 v = this.v;
                if (v != null) {
                    ((oz4)v.w).c.execute((Runnable)new zn((Object)v, (Object)v.c, (Object)v.n, (Object)v.v, 5, false));
                    monitorexit(this);
                    return;
                }
                break Label_0085;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void x0(final th1 th1, final zzbxc zzbxc) {
        monitorenter(this);
        Label_0028: {
            try {
                final tz4 c = this.c;
                if (c != null) {
                    c.w.n0(zzbxc);
                    monitorexit(this);
                    return;
                }
                break Label_0028;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zze(final th1 th1) {
        monitorenter(this);
        Label_0027: {
            try {
                final tz4 c = this.c;
                if (c != null) {
                    c.n.onAdClicked();
                    monitorexit(this);
                    return;
                }
                break Label_0027;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzg(final th1 th1, final int n) {
        monitorenter(this);
        Label_0025: {
            try {
                final y7 n2 = this.n;
                if (n2 != null) {
                    n2.j(n);
                    monitorexit(this);
                    return;
                }
                break Label_0025;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
    
    public final void zzi(final th1 th1) {
        synchronized (this) {
            final y7 n = this.n;
            if (n != null) {
                synchronized (n) {
                    ((m94)n.v).zzc((Object)null);
                }
            }
        }
    }
    
    public final void zzj(final th1 th1) {
        monitorenter(this);
        Label_0027: {
            try {
                final tz4 c = this.c;
                if (c != null) {
                    c.c.zzbw();
                    monitorexit(this);
                    return;
                }
                break Label_0027;
            }
            finally {
                monitorexit(this);
                monitorexit(this);
            }
        }
    }
}
