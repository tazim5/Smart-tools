import android.os.Parcelable;
import android.content.Intent;
import android.os.Parcel;
import android.os.IInterface;
import android.os.IBinder;

public final class i34 extends go3 implements k34
{
    public i34(final IBinder binder) {
        super(binder, "com.google.android.gms.ads.internal.offline.IOfflineUtils");
    }
    
    public final void q(final th1 th1) {
        final Parcel zza = this.zza();
        io3.e(zza, (IInterface)th1);
        this.zzbi(4, zza);
    }
    
    public final void s(final Intent intent) {
        final Parcel zza = this.zza();
        io3.c(zza, (Parcelable)intent);
        this.zzbi(1, zza);
    }
    
    public final void t(final th1 th1, final String s, final String s2) {
        final Parcel zza = this.zza();
        io3.e(zza, (IInterface)th1);
        zza.writeString(s);
        zza.writeString(s2);
        this.zzbi(2, zza);
    }
    
    public final void v(final String[] array, final int[] array2, final th1 th1) {
        final Parcel zza = this.zza();
        zza.writeStringArray(array);
        zza.writeIntArray(array2);
        io3.e(zza, (IInterface)th1);
        this.zzbi(5, zza);
    }
    
    public final void zzh() {
        this.zzbi(3, this.zza());
    }
}
