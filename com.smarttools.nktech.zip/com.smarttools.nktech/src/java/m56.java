import android.media.MediaCodecInfo$VideoCapabilities$PerformancePoint;
import java.util.List;
import android.media.MediaCodecInfo$VideoCapabilities;

public abstract class m56
{
    public static int a(final MediaCodecInfo$VideoCapabilities mediaCodecInfo$VideoCapabilities, int i, final int n, final double n2) {
        final List j = zu2.j(mediaCodecInfo$VideoCapabilities);
        final int n3 = 0;
        if (j != null && !j.isEmpty()) {
            final String b = ec5.b;
            if (!b.equals((Object)"sabrina") && !b.equals((Object)"boreal")) {
                final String d = ec5.d;
                if (!d.startsWith("Lenovo TB-X605") && !d.startsWith("Lenovo TB-X606")) {
                    if (!d.startsWith("Lenovo TB-X616")) {
                        final MediaCodecInfo$VideoCapabilities$PerformancePoint d2 = zu2.d(i, n, (int)n2);
                        for (i = n3; i < j.size(); ++i) {
                            if (zu2.t(zu2.e(j.get(i)), d2)) {
                                return 2;
                            }
                        }
                        return 1;
                    }
                }
            }
        }
        return 0;
    }
}
