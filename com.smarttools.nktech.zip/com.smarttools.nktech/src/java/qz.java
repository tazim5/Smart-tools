import androidx.compose.runtime.internal.ComposableLambdaKt;
import androidx.compose.runtime.internal.ComposableLambda;

public abstract class qz
{
    public static final ComposableLambda a;
    public static final ComposableLambda b;
    public static final ComposableLambda c;
    public static final ComposableLambda d;
    public static final ComposableLambda e;
    public static final ComposableLambda f;
    public static final ComposableLambda g;
    
    static {
        a = ComposableLambdaKt.composableLambdaInstance(1937420591, false, (Object)uu.m0);
        b = ComposableLambdaKt.composableLambdaInstance(-1820871346, false, (Object)kz.c);
        c = ComposableLambdaKt.composableLambdaInstance(-1975293876, false, (Object)lz.c);
        d = ComposableLambdaKt.composableLambdaInstance(44221763, false, (Object)mz.c);
        e = ComposableLambdaKt.composableLambdaInstance(1657149524, false, (Object)nz.c);
        f = ComposableLambdaKt.composableLambdaInstance(847814155, false, (Object)oz.c);
        g = ComposableLambdaKt.composableLambdaInstance(189495098, false, (Object)pz.c);
    }
}
