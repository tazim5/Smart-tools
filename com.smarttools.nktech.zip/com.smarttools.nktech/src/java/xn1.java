public interface xn1 extends ao1, id1
{
    Object get();
    
    Object getDelegate();
    
    wn1 getGetter();
}
